/**
 * BHOOMI-DRISHTI IMMUTABLE AUDIT LOGGING SERVICE
 * Implements tamper-evident, append-only administrative and security event logs.
 * Strictly adheres to SIH26017 Government Data Pipeline guidelines:
 * - Records timestamps, user IDs, administrative roles, actions, resources, results, and request IDs.
 * - NEVER stores passwords, bearer tokens, or authentication secrets.
 */

import { DatabaseSync } from 'node:sqlite';
import { randomBytes } from 'node:crypto';
import { getDatabase } from './database.ts';

export type AuditAction =
  | 'LOGIN'
  | 'LOGIN_SUCCESS'
  | 'LOGIN_FAILURE'
  | 'LOGOUT'
  | 'SESSION_EXPIRED'
  | 'ACCESS_DENIED'
  | 'ROLE_SWITCH'
  | 'CSV_UPLOAD'
  | 'CSV_VALIDATE'
  | 'CSV_APPROVE'
  | 'CSV_IMPORT'
  | 'CSV_EXPORT'
  | 'PROJECT_CREATE'
  | 'PROJECT_UPDATE'
  | 'PROJECT_DELETE'
  | 'PROJECT_DISCOVERED'
  | 'DATAHUB_SYNC'
  | 'DATAHUB_MANUAL_SYNC'
  | 'DATAHUB_INTERVAL_CHANGE'
  | 'DATA_REJECTION'
  | 'PREDICTION_GENERATION'
  | 'SHADOW_SCORING_RUN'
  | 'SHADOW_EVALUATION_RUN'
  | 'STATUTORY_DOCUMENT_INGESTION'
  | 'STATUTORY_REVIEW_DECISION'
  | 'CONFIGURATION_CHANGE'
  | 'UNAUTHORIZED_ACCESS_ATTEMPT';

export type AuditResult = 'SUCCESS' | 'FAILED' | 'REJECTED' | 'DENIED';

export interface AuditEventInput {
  userId: string;
  userName: string;
  userRole: string;
  action: AuditAction;
  resource: string;
  resourceId?: string;
  result: AuditResult;
  requestId?: string;
  ipAddress?: string;
  details?: Record<string, any> | string;
  oldValue?: string | Record<string, any>;
  newValue?: string | Record<string, any>;
}

export interface AuditEventRecord {
  id: string;
  timestamp: string;
  user_id: string;
  user_name: string;
  user_role: string;
  action: string;
  resource: string;
  resource_id: string | null;
  result: string;
  request_id: string | null;
  ip_address: string | null;
  details: string | null;
  old_value: string | null;
  new_value: string | null;
}

export class AuditService {
  /**
   * Initializes the audit_logs table with all required compliance columns.
   */
  public static initTable(db: DatabaseSync): void {
    db.exec(`
      CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        user_role TEXT NOT NULL,
        action TEXT NOT NULL,
        resource TEXT NOT NULL,
        resource_id TEXT,
        entity_type TEXT DEFAULT 'general',
        entity_id TEXT DEFAULT 'N/A',
        result TEXT NOT NULL,
        request_id TEXT,
        ip_address TEXT,
        details TEXT,
        old_value TEXT,
        new_value TEXT
      );
    `);

    // Migration for pre-existing audit_logs tables
    const alterCols = [
      "ALTER TABLE audit_logs ADD COLUMN user_name TEXT DEFAULT 'System User'",
      "ALTER TABLE audit_logs ADD COLUMN user_role TEXT DEFAULT 'NODAL_OFFICER'",
      "ALTER TABLE audit_logs ADD COLUMN resource TEXT DEFAULT 'general'",
      "ALTER TABLE audit_logs ADD COLUMN resource_id TEXT",
      "ALTER TABLE audit_logs ADD COLUMN entity_type TEXT DEFAULT 'general'",
      "ALTER TABLE audit_logs ADD COLUMN entity_id TEXT DEFAULT 'N/A'",
      "ALTER TABLE audit_logs ADD COLUMN result TEXT DEFAULT 'SUCCESS'",
      "ALTER TABLE audit_logs ADD COLUMN request_id TEXT",
      "ALTER TABLE audit_logs ADD COLUMN ip_address TEXT",
      "ALTER TABLE audit_logs ADD COLUMN details TEXT"
    ];
    for (const sql of alterCols) {
      try { db.exec(sql); } catch { /* column already exists */ }
    }

    try {
      db.exec(`
        CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp);
        CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
        CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);
        CREATE INDEX IF NOT EXISTS idx_audit_resource ON audit_logs(resource);
      `);
    } catch { /* indexes created */ }
  }

  /**
   * Appends an immutable audit record to the SQLite database.
   * Cleanses any potential credentials or secrets.
   */
  public static record(db: DatabaseSync, event: AuditEventInput): AuditEventRecord {
    this.initTable(db);

    const id = `AUD_${Date.now()}_${randomBytes(4).toString('hex')}`;
    const timestamp = new Date().toISOString();

    // Redact sensitive patterns from details, oldValue, newValue
    const sanitize = (val: any): string | null => {
      if (val === undefined || val === null) return null;
      let text = typeof val === 'object' ? JSON.stringify(val) : String(val);
      // Redact tokens, passwords, secrets, credentials, ID tokens, keys
      text = text.replace(/("?(password|token|secret|authorization|apiKey|idToken|id_token|credential|privateKey|private_key|bearer)"?\s*[:=]\s*)"[^"]+"/gi, '$1"[REDACTED]"');
      // Defang any Bearer strings or raw JWT structures
      text = text.replace(/Bearer\s+[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.?[A-Za-z0-9-_.+/=]*/gi, 'Bearer [REDACTED]');
      text = text.replace(/eyJ[A-Za-z0-9-_=]{10,}\.[A-Za-z0-9-_=]{10,}\.?[A-Za-z0-9-_.+/=]*/gi, '[REDACTED_JWT]');
      return text;
    };

    const detailsStr = sanitize(event.details);
    const oldValStr = sanitize(event.oldValue);
    const newValStr = sanitize(event.newValue);
    const entityType = event.resource || 'general';
    const entityId = event.resourceId || 'N/A';

    db.prepare(`
      INSERT INTO audit_logs (
        id, timestamp, user_id, user_name, user_role, action, resource,
        resource_id, entity_type, entity_id, result, request_id, ip_address, details, old_value, new_value
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      timestamp,
      event.userId,
      event.userName,
      event.userRole,
      event.action,
      event.resource,
      event.resourceId || null,
      entityType,
      entityId,
      event.result,
      event.requestId || null,
      event.ipAddress || null,
      detailsStr,
      oldValStr,
      newValStr
    );

    return {
      id,
      timestamp,
      user_id: event.userId,
      user_name: event.userName,
      user_role: event.userRole,
      action: event.action,
      resource: event.resource,
      resource_id: event.resourceId || null,
      result: event.result,
      request_id: event.requestId || null,
      ip_address: event.ipAddress || null,
      details: detailsStr,
      old_value: oldValStr,
      new_value: newValStr
    };
  }

  /**
   * Queries audit logs with pagination and filtering.
   */
  public static query(
    db: DatabaseSync,
    filter: {
      action?: string;
      userId?: string;
      resource?: string;
      limit?: number;
      offset?: number;
    } = {}
  ): { total: number; logs: AuditEventRecord[] } {
    this.initTable(db);

    let whereClauses: string[] = [];
    let params: any[] = [];

    if (filter.action) {
      whereClauses.push('action = ?');
      params.push(filter.action);
    }
    if (filter.userId) {
      whereClauses.push('user_id = ?');
      params.push(filter.userId);
    }
    if (filter.resource) {
      whereClauses.push('resource = ?');
      params.push(filter.resource);
    }

    const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';
    const countSql = `SELECT count(*) as count FROM audit_logs ${whereSql}`;
    const total = (db.prepare(countSql).get(...params) as any).count;

    const limit = filter.limit || 50;
    const offset = filter.offset || 0;

    const querySql = `
      SELECT * FROM audit_logs
      ${whereSql}
      ORDER BY timestamp DESC
      LIMIT ? OFFSET ?
    `;

    const logs = db.prepare(querySql).all(...params, limit, offset) as unknown as AuditEventRecord[];
    return { total, logs };
  }
}
