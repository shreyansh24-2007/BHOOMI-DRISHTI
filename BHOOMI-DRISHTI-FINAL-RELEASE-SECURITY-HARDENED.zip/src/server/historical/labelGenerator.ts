/**
 * BHOOMI-DRISHTI ML DATASET FOUNDATION — GROUND-TRUTH LABEL GENERATOR
 * Generates verified ground-truth labels grounded strictly in statutory timelines
 * (NH Act 1956 Section 3A(7), RFCTLARR 2013, and documented court injunctions).
 * 
 * STRICT: NEVER invents labels. NEVER uses heuristic scores as ground truth.
 * Projects with incomplete or in-progress status are tagged UNRESOLVED or INSUFFICIENT_EVIDENCE.
 */

import {
  HistoricalProject,
  StatutoryNotification,
  LegalEvent,
  PredictionTaskType,
  LabelState,
  LabelledObservation,
  ProvenanceType
} from './types.ts';

export class GroundTruthLabelGenerator {
  /**
   * Generates a verified label for an Early-Stage Delay Risk prediction task (T0 = Section 3A).
   * Evaluates Section 3A(7) statutory 1-year window to Section 3D.
   */
  public static generateEarlyStageLabel(
    project: HistoricalProject,
    snapshotId: string,
    predictionTimestamp: string,
    notifications: StatutoryNotification[],
    legalEvents: LegalEvent[]
  ): LabelledObservation {
    const isDemo = project.provenance === 'DEMONSTRATION';

    // 1. Check for demonstration / synthetic records
    if (isDemo) {
      return {
        id: `LBL_EARLY_${project.id}_${Date.now()}`,
        projectId: project.id,
        snapshotId,
        predictionTask: 'EARLY_STAGE_DELAY_RISK',
        predictionTimestamp,
        label: 'INSUFFICIENT_EVIDENCE',
        binaryTarget: null,
        labelDefinition: 'Demonstration seed record without authoritative e-Gazette publication timestamps.',
        evidenceSource: project.source,
        evidenceDate: predictionTimestamp,
        labelConfidence: 0.0,
        generationMethod: 'PROVENANCE_FILTERING',
        provenance: project.provenance,
        isEligibleForTraining: false,
        source: project.source,
        sourceUrl: project.sourceUrl || '',
        notificationId: null,
        retrievalTimestamp: predictionTimestamp,
        publicationDate: null,
        parserVersion: 'v2.5-bhoomirashi',
        sourceHash: '',
        ingestionRunId: 'RUN_HIST_0',
        provenanceStatus: project.provenance
      };
    }

    // 2. Find Section 3A notifications
    const notifs3A = notifications
      .filter(n => n.notificationType === '3a' || n.notificationType === '3A')
      .sort((a, b) => new Date(a.publishDate).getTime() - new Date(b.publishDate).getTime());

    if (notifs3A.length === 0) {
      return {
        id: `LBL_EARLY_${project.id}_${Date.now()}`,
        projectId: project.id,
        snapshotId,
        predictionTask: 'EARLY_STAGE_DELAY_RISK',
        predictionTimestamp,
        label: 'INSUFFICIENT_EVIDENCE',
        binaryTarget: null,
        labelDefinition: 'No Section 3A publication date available in verified records.',
        evidenceSource: project.sourceUrl || project.source,
        evidenceDate: predictionTimestamp,
        labelConfidence: 0.0,
        generationMethod: 'STATUTORY_NOTIFICATION_AUDIT',
        provenance: project.provenance,
        isEligibleForTraining: false,
        source: project.source,
        sourceUrl: project.sourceUrl || '',
        notificationId: null,
        retrievalTimestamp: predictionTimestamp,
        publicationDate: null,
        parserVersion: 'v2.5-bhoomirashi',
        sourceHash: '',
        ingestionRunId: 'RUN_HIST_0',
        provenanceStatus: project.provenance
      };
    }

    const earliest3A = notifs3A[0];
    const date3A = new Date(earliest3A.publishDate).getTime();

    // 3. Find Section 3D declarations
    const notifs3D = notifications
      .filter(n => n.notificationType === '3D')
      .sort((a, b) => new Date(a.publishDate).getTime() - new Date(b.publishDate).getTime());

    if (notifs3D.length > 0) {
      const earliest3D = notifs3D[0];
      const date3D = new Date(earliest3D.publishDate).getTime();
      const elapsedDays = Math.floor((date3D - date3A) / (1000 * 60 * 60 * 24));

      // Statutory deadline under Section 3A(7) of NH Act 1956 is 1 year (365 days)
      if (elapsedDays > 365) {
        return {
          id: `LBL_EARLY_${project.id}_${earliest3D.id}`,
          projectId: project.id,
          snapshotId,
          predictionTask: 'EARLY_STAGE_DELAY_RISK',
          predictionTimestamp,
          label: 'VERIFIED_DELAYED',
          binaryTarget: 1,
          labelDefinition: `Section 3D declaration published in ${elapsedDays} days, exceeding the 365-day statutory deadline under Section 3A(7) of National Highways Act 1956.`,
          evidenceSource: earliest3D.gazetteRef || `Notification No. ${earliest3D.notificationNumber}`,
          evidenceDate: earliest3D.publishDate,
          labelConfidence: 1.0,
          generationMethod: 'STATUTORY_TIMELINE_EVALUATION',
          provenance: project.provenance,
          isEligibleForTraining: true,
          source: project.source,
          sourceUrl: project.sourceUrl || '',
          notificationId: earliest3D.notificationNumber,
          retrievalTimestamp: predictionTimestamp,
          publicationDate: earliest3D.publishDate,
          parserVersion: 'v2.5-bhoomirashi',
          sourceHash: '',
          ingestionRunId: 'RUN_HIST_0',
          provenanceStatus: project.provenance
        };
      } else {
        return {
          id: `LBL_EARLY_${project.id}_${earliest3D.id}`,
          projectId: project.id,
          snapshotId,
          predictionTask: 'EARLY_STAGE_DELAY_RISK',
          predictionTimestamp,
          label: 'VERIFIED_NOT_DELAYED',
          binaryTarget: 0,
          labelDefinition: `Section 3D declaration published in ${elapsedDays} days, strictly within the 365-day statutory window under Section 3A(7) of NH Act 1956.`,
          evidenceSource: earliest3D.gazetteRef || `Notification No. ${earliest3D.notificationNumber}`,
          evidenceDate: earliest3D.publishDate,
          labelConfidence: 1.0,
          generationMethod: 'STATUTORY_TIMELINE_EVALUATION',
          provenance: project.provenance,
          isEligibleForTraining: true,
          source: project.source,
          sourceUrl: project.sourceUrl || '',
          notificationId: earliest3D.notificationNumber,
          retrievalTimestamp: predictionTimestamp,
          publicationDate: earliest3D.publishDate,
          parserVersion: 'v2.5-bhoomirashi',
          sourceHash: '',
          ingestionRunId: 'RUN_HIST_0',
          provenanceStatus: project.provenance
        };
      }
    }

    // 4. Section 3D has not been published yet.
    // Calculate elapsed time from 3A to current evaluation time
    const evalTime = new Date(predictionTimestamp).getTime();
    const elapsedDaysCurrent = Math.floor((evalTime - date3A) / (1000 * 60 * 60 * 24));

    if (elapsedDaysCurrent > 365) {
      return {
        id: `LBL_EARLY_${project.id}_LAPSE`,
        projectId: project.id,
        snapshotId,
        predictionTask: 'EARLY_STAGE_DELAY_RISK',
        predictionTimestamp,
        label: 'VERIFIED_DELAYED',
        binaryTarget: 1,
        labelDefinition: `Statutory lapse occurred: ${elapsedDaysCurrent} days have elapsed since Section 3A publication without Section 3D declaration (Section 3A(7) statutory limit is 365 days).`,
        evidenceSource: earliest3A.gazetteRef || `Notification No. ${earliest3A.notificationNumber}`,
        evidenceDate: earliest3A.publishDate,
        labelConfidence: 0.95,
        generationMethod: 'STATUTORY_TIMELINE_EVALUATION',
        provenance: project.provenance,
        isEligibleForTraining: true,
        source: project.source,
        sourceUrl: project.sourceUrl || '',
        notificationId: earliest3A.notificationNumber,
        retrievalTimestamp: predictionTimestamp,
        publicationDate: earliest3A.publishDate,
        parserVersion: 'v2.5-bhoomirashi',
        sourceHash: '',
        ingestionRunId: 'RUN_HIST_0',
        provenanceStatus: project.provenance
      };
    }

    // 5. In-progress within 365 days: Cannot be assigned a binary 0 or 1
    return {
      id: `LBL_EARLY_${project.id}_PENDING`,
      projectId: project.id,
      snapshotId,
      predictionTask: 'EARLY_STAGE_DELAY_RISK',
      predictionTimestamp,
      label: 'UNRESOLVED',
      binaryTarget: null,
      labelDefinition: `Project is actively progressing (${elapsedDaysCurrent} days elapsed since Section 3A) within the statutory 365-day deadline. Terminal outcome pending.`,
      evidenceSource: earliest3A.gazetteRef || `Notification No. ${earliest3A.notificationNumber}`,
      evidenceDate: earliest3A.publishDate,
      labelConfidence: 0.85,
      generationMethod: 'STATUTORY_TIMELINE_EVALUATION',
      provenance: project.provenance,
      isEligibleForTraining: false,
      source: project.source,
      sourceUrl: project.sourceUrl || '',
      notificationId: earliest3A.notificationNumber,
      retrievalTimestamp: predictionTimestamp,
      publicationDate: earliest3A.publishDate,
      parserVersion: 'v2.5-bhoomirashi',
      sourceHash: '',
      ingestionRunId: 'RUN_HIST_0',
      provenanceStatus: project.provenance
    };
  }

  /**
   * Generates a verified observation for an individual statutory Section 3A corridor proceeding.
   */
  public static generateStatutoryNotificationLabel(
    project: HistoricalProject,
    notif3A: StatutoryNotification,
    snapshotId: string,
    predictionTimestamp: string,
    allNotifications: StatutoryNotification[]
  ): LabelledObservation {
    const isDemo = project.provenance === 'DEMONSTRATION';
    if (isDemo) {
      return {
        id: `LBL_NOTIF_${notif3A.id}`,
        projectId: project.id,
        snapshotId,
        predictionTask: 'EARLY_STAGE_DELAY_RISK',
        predictionTimestamp,
        label: 'INSUFFICIENT_EVIDENCE',
        binaryTarget: null,
        labelDefinition: 'Demonstration record without verified statutory Gazette publication.',
        evidenceSource: project.source,
        evidenceDate: predictionTimestamp,
        labelConfidence: 0.0,
        generationMethod: 'PROVENANCE_FILTERING',
        provenance: project.provenance,
        isEligibleForTraining: false,
        source: project.source,
        sourceUrl: project.sourceUrl || '',
        notificationId: notif3A.notificationNumber,
        retrievalTimestamp: predictionTimestamp,
        publicationDate: notif3A.publishDate,
        parserVersion: 'v2.5-bhoomirashi',
        sourceHash: '',
        ingestionRunId: 'RUN_HIST_PHASE1',
        provenanceStatus: project.provenance
      };
    }

    const d3A = new Date(notif3A.publishDate).getTime();
    if (isNaN(d3A)) {
      return {
        id: `LBL_NOTIF_${notif3A.id}`,
        projectId: project.id,
        snapshotId,
        predictionTask: 'EARLY_STAGE_DELAY_RISK',
        predictionTimestamp,
        label: 'INSUFFICIENT_EVIDENCE',
        binaryTarget: null,
        labelDefinition: 'Section 3A notification has unparseable publication date.',
        evidenceSource: notif3A.gazetteRef || notif3A.notificationNumber,
        evidenceDate: predictionTimestamp,
        labelConfidence: 0.0,
        generationMethod: 'DATE_PARSING_AUDIT',
        provenance: project.provenance,
        isEligibleForTraining: false,
        source: project.source,
        sourceUrl: project.sourceUrl || '',
        notificationId: notif3A.notificationNumber,
        retrievalTimestamp: predictionTimestamp,
        publicationDate: null,
        parserVersion: 'v2.5-bhoomirashi',
        sourceHash: '',
        ingestionRunId: 'RUN_HIST_PHASE1',
        provenanceStatus: project.provenance
      };
    }

    // Find subsequent Section 3D declarations for this project
    const subsequent3D = allNotifications
      .filter(n => n.notificationType === '3D' && n.publishDate && new Date(n.publishDate).getTime() >= d3A)
      .sort((a, b) => new Date(a.publishDate).getTime() - new Date(b.publishDate).getTime());

    if (subsequent3D.length > 0) {
      const match3D = subsequent3D[0];
      const d3D = new Date(match3D.publishDate).getTime();
      const elapsedDays = Math.floor((d3D - d3A) / (1000 * 60 * 60 * 24));

      if (elapsedDays > 365) {
        return {
          id: `LBL_NOTIF_${notif3A.id}_${match3D.id}`,
          projectId: project.id,
          snapshotId,
          predictionTask: 'EARLY_STAGE_DELAY_RISK',
          predictionTimestamp,
          label: 'VERIFIED_DELAYED',
          binaryTarget: 1,
          labelDefinition: `Section 3D declaration (${match3D.notificationNumber}) published ${elapsedDays} days after Section 3A (${notif3A.notificationNumber}), exceeding statutory 365-day deadline under Section 3A(7) of NH Act 1956.`,
          evidenceSource: match3D.gazetteRef || `Notification No. ${match3D.notificationNumber}`,
          evidenceDate: match3D.publishDate,
          labelConfidence: 1.0,
          generationMethod: 'STATUTORY_TIMELINE_EVALUATION',
          provenance: project.provenance,
          isEligibleForTraining: true,
          source: project.source,
          sourceUrl: project.sourceUrl || '',
          notificationId: notif3A.notificationNumber,
          retrievalTimestamp: predictionTimestamp,
          publicationDate: notif3A.publishDate,
          parserVersion: 'v2.5-bhoomirashi',
          sourceHash: '',
          ingestionRunId: 'RUN_HIST_PHASE1',
          provenanceStatus: project.provenance
        };
      } else {
        return {
          id: `LBL_NOTIF_${notif3A.id}_${match3D.id}`,
          projectId: project.id,
          snapshotId,
          predictionTask: 'EARLY_STAGE_DELAY_RISK',
          predictionTimestamp,
          label: 'VERIFIED_NOT_DELAYED',
          binaryTarget: 0,
          labelDefinition: `Section 3D declaration (${match3D.notificationNumber}) published ${elapsedDays} days after Section 3A (${notif3A.notificationNumber}), strictly within statutory 365-day deadline under Section 3A(7) of NH Act 1956.`,
          evidenceSource: match3D.gazetteRef || `Notification No. ${match3D.notificationNumber}`,
          evidenceDate: match3D.publishDate,
          labelConfidence: 1.0,
          generationMethod: 'STATUTORY_TIMELINE_EVALUATION',
          provenance: project.provenance,
          isEligibleForTraining: true,
          source: project.source,
          sourceUrl: project.sourceUrl || '',
          notificationId: notif3A.notificationNumber,
          retrievalTimestamp: predictionTimestamp,
          publicationDate: notif3A.publishDate,
          parserVersion: 'v2.5-bhoomirashi',
          sourceHash: '',
          ingestionRunId: 'RUN_HIST_PHASE1',
          provenanceStatus: project.provenance
        };
      }
    }

    // No 3D declaration published yet
    const evalTime = new Date(predictionTimestamp).getTime();
    const elapsedSince = Math.floor((evalTime - d3A) / (1000 * 60 * 60 * 24));

    if (elapsedSince > 365) {
      return {
        id: `LBL_NOTIF_${notif3A.id}_LAPSE`,
        projectId: project.id,
        snapshotId,
        predictionTask: 'EARLY_STAGE_DELAY_RISK',
        predictionTimestamp,
        label: 'VERIFIED_DELAYED',
        binaryTarget: 1,
        labelDefinition: `Statutory lapse: ${elapsedSince} days have elapsed since Section 3A publication (${notif3A.notificationNumber}) without declaration under Section 3D (exceeds Section 3A(7) 365-day limit).`,
        evidenceSource: notif3A.gazetteRef || `Notification No. ${notif3A.notificationNumber}`,
        evidenceDate: notif3A.publishDate,
        labelConfidence: 0.95,
        generationMethod: 'STATUTORY_TIMELINE_EVALUATION',
        provenance: project.provenance,
        isEligibleForTraining: true,
        source: project.source,
        sourceUrl: project.sourceUrl || '',
        notificationId: notif3A.notificationNumber,
        retrievalTimestamp: predictionTimestamp,
        publicationDate: notif3A.publishDate,
        parserVersion: 'v2.5-bhoomirashi',
        sourceHash: '',
        ingestionRunId: 'RUN_HIST_PHASE1',
        provenanceStatus: project.provenance
      };
    }

    return {
      id: `LBL_NOTIF_${notif3A.id}_PENDING`,
      projectId: project.id,
      snapshotId,
      predictionTask: 'EARLY_STAGE_DELAY_RISK',
      predictionTimestamp,
      label: 'UNRESOLVED',
      binaryTarget: null,
      labelDefinition: `Statutory proceeding is actively progressing (${elapsedSince} days elapsed since Section 3A) within statutory 365-day limit.`,
      evidenceSource: notif3A.gazetteRef || `Notification No. ${notif3A.notificationNumber}`,
      evidenceDate: notif3A.publishDate,
      labelConfidence: 0.85,
      generationMethod: 'STATUTORY_TIMELINE_EVALUATION',
      provenance: project.provenance,
      isEligibleForTraining: false,
      source: project.source,
      sourceUrl: project.sourceUrl || '',
      notificationId: notif3A.notificationNumber,
      retrievalTimestamp: predictionTimestamp,
      publicationDate: notif3A.publishDate,
      parserVersion: 'v2.5-bhoomirashi',
      sourceHash: '',
      ingestionRunId: 'RUN_HIST_PHASE1',
      provenanceStatus: project.provenance
    };
  }

  /**
   * Generates a verified label for a Current-Stage Delay Risk prediction task.
   * Evaluates legal injunctions, stay orders, and physical handover progress.
   */
  public static generateCurrentStageLabel(
    project: HistoricalProject,
    snapshotId: string,
    predictionTimestamp: string,
    legalEvents: LegalEvent[],
    totalLandRequiredHa: number,
    landAcquiredHa: number
  ): LabelledObservation {
    if (project.provenance === 'DEMONSTRATION') {
      return {
        id: `LBL_CURR_${project.id}_DEMO`,
        projectId: project.id,
        snapshotId,
        predictionTask: 'CURRENT_STAGE_DELAY_RISK',
        predictionTimestamp,
        label: 'INSUFFICIENT_EVIDENCE',
        binaryTarget: null,
        labelDefinition: 'Demonstration project without authenticated court orders or revenue records.',
        evidenceSource: project.source,
        evidenceDate: predictionTimestamp,
        labelConfidence: 0.0,
        generationMethod: 'PROVENANCE_FILTERING',
        provenance: project.provenance,
        isEligibleForTraining: false,
        source: project.source,
        sourceUrl: project.sourceUrl || '',
        notificationId: null,
        retrievalTimestamp: predictionTimestamp,
        publicationDate: null,
        parserVersion: 'v2.5-bhoomirashi',
        sourceHash: '',
        ingestionRunId: 'RUN_HIST_0',
        provenanceStatus: project.provenance
      };
    }

    // Active court injunctions halting possession
    const activeStays = legalEvents.filter(l => l.stayActive && new Date(l.eventDate).getTime() <= new Date(predictionTimestamp).getTime());
    if (activeStays.length > 0) {
      const stay = activeStays[0];
      return {
        id: `LBL_CURR_${project.id}_STAY`,
        projectId: project.id,
        snapshotId,
        predictionTask: 'CURRENT_STAGE_DELAY_RISK',
        predictionTimestamp,
        label: 'VERIFIED_DELAYED',
        binaryTarget: 1,
        labelDefinition: `Judicial interim injunction granted by ${stay.courtName} halting land acquisition proceedings (${stay.details}).`,
        evidenceSource: `${stay.courtName} Case ${stay.caseNumber || 'Order'}`,
        evidenceDate: stay.eventDate,
        labelConfidence: 0.95,
        generationMethod: 'LEGAL_INJUNCTION_VERIFICATION',
        provenance: project.provenance,
        isEligibleForTraining: true,
        source: project.source,
        sourceUrl: project.sourceUrl || '',
        notificationId: null,
        retrievalTimestamp: predictionTimestamp,
        publicationDate: stay.eventDate,
        parserVersion: 'v2.5-bhoomirashi',
        sourceHash: '',
        ingestionRunId: 'RUN_HIST_0',
        provenanceStatus: project.provenance
      };
    }

    // Confirmed completion
    if (totalLandRequiredHa > 0 && landAcquiredHa >= totalLandRequiredHa * 0.95) {
      return {
        id: `LBL_CURR_${project.id}_COMPLETED`,
        projectId: project.id,
        snapshotId,
        predictionTask: 'CURRENT_STAGE_DELAY_RISK',
        predictionTimestamp,
        label: 'VERIFIED_NOT_DELAYED',
        binaryTarget: 0,
        labelDefinition: `Project achieved 95%+ land acquisition possession (${landAcquiredHa} of ${totalLandRequiredHa} Ha) without unresolved judicial stays.`,
        evidenceSource: 'MoRTH Physical Possession Revenue Register',
        evidenceDate: predictionTimestamp,
        labelConfidence: 0.90,
        generationMethod: 'POSSESSION_RATIO_VERIFICATION',
        provenance: project.provenance,
        isEligibleForTraining: true,
        source: project.source,
        sourceUrl: project.sourceUrl || '',
        notificationId: null,
        retrievalTimestamp: predictionTimestamp,
        publicationDate: null,
        parserVersion: 'v2.5-bhoomirashi',
        sourceHash: '',
        ingestionRunId: 'RUN_HIST_0',
        provenanceStatus: project.provenance
      };
    }

    // Otherwise in-progress
    return {
      id: `LBL_CURR_${project.id}_PROGRESS`,
      projectId: project.id,
      snapshotId,
      predictionTask: 'CURRENT_STAGE_DELAY_RISK',
      predictionTimestamp,
      label: 'UNRESOLVED',
      binaryTarget: null,
      labelDefinition: 'Project is in intermediate acquisition phase without confirmed stay or completion.',
      evidenceSource: project.sourceUrl || project.source,
      evidenceDate: predictionTimestamp,
      labelConfidence: 0.80,
      generationMethod: 'INTERMEDIATE_STAGE_AUDIT',
      provenance: project.provenance,
      isEligibleForTraining: false,
      source: project.source,
      sourceUrl: project.sourceUrl || '',
      notificationId: null,
      retrievalTimestamp: predictionTimestamp,
      publicationDate: null,
      parserVersion: 'v2.5-bhoomirashi',
      sourceHash: '',
      ingestionRunId: 'RUN_HIST_0',
      provenanceStatus: project.provenance
    };
  }
}
