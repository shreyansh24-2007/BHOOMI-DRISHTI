/**
 * BHOOMI-DRISHTI ML DATASET FOUNDATION — AUTOMATED DATA QUALITY AUDITOR
 * Comprehensive quality engine detecting:
 * 1. Duplicate records
 * 2. Conflicting dates
 * 3. Impossible dates
 * 4. Missing identifiers
 * 5. Invalid land values
 * 6. Inconsistent land balances
 * 7. Malformed source data
 * 8. Conflicting sources
 * 9. Suspicious duplicates
 */

import { DatabaseSync } from 'node:sqlite';
import { DataQualityIssue, DetailedDataQualityAudit } from './types.ts';

export class HistoricalDataQualityEngine {
  /**
   * Executes a full data-quality scan across all historical tables.
   * Records detected anomalies into ml_data_quality_issues table.
   */
  public static runAudit(db: DatabaseSync): DetailedDataQualityAudit {
    const now = new Date().toISOString();
    const issues: DataQualityIssue[] = [];

    // 1. Duplicate records: projects with same source_project_id or duplicate notification refs
    const dupProj = db.prepare(`
      SELECT source_project_id, count(*) as c
      FROM ml_historical_projects
      GROUP BY source_project_id
      HAVING c > 1
    `).all() as any[];
    for (const d of dupProj) {
      issues.push({
        id: `ISS_DUP_PROJ_${d.source_project_id}`,
        issueType: 'DUPLICATE_RECORD',
        severity: 'CRITICAL',
        recordIdentifier: d.source_project_id,
        description: `Duplicate project record detected with source_project_id ${d.source_project_id} (count: ${d.c})`,
        detectedAt: now
      });
    }

    const dupNotifs = db.prepare(`
      SELECT project_id, notification_type, notification_number, count(*) as c
      FROM ml_notifications
      WHERE notification_number IS NOT NULL AND notification_number != 'N/A' AND notification_number != ''
      GROUP BY project_id, notification_type, notification_number
      HAVING c > 1
    `).all() as any[];
    for (const dn of dupNotifs) {
      issues.push({
        id: `ISS_DUP_NOTIF_${dn.project_id}_${dn.notification_number}`,
        issueType: 'DUPLICATE_RECORD',
        severity: 'WARNING',
        projectId: dn.project_id,
        recordIdentifier: dn.notification_number,
        description: `Multiple identical notifications detected for ${dn.project_id} (${dn.notification_type}: ${dn.notification_number})`,
        detectedAt: now
      });
    }

    // 2. Conflicting dates: same notification number published under conflicting dates
    const confDates = db.prepare(`
      SELECT notification_number, count(DISTINCT publish_date) as distinct_dates
      FROM ml_notifications
      WHERE notification_number IS NOT NULL AND notification_number != 'N/A' AND notification_number != ''
      GROUP BY notification_number
      HAVING distinct_dates > 1
    `).all() as any[];
    for (const cd of confDates) {
      issues.push({
        id: `ISS_CONF_DATE_${cd.notification_number}`,
        issueType: 'CONFLICTING_DATES',
        severity: 'WARNING',
        recordIdentifier: cd.notification_number,
        description: `Notification ${cd.notification_number} records ${cd.distinct_dates} conflicting publication dates across entries`,
        detectedAt: now
      });
    }

    // 3. Impossible dates: Section 3D declared BEFORE Section 3A, or dates in the future
    const allProjs = db.prepare('SELECT id FROM ml_historical_projects').all() as any[];
    const nowMs = Date.now();

    for (const p of allProjs) {
      const notifs = db.prepare(`
        SELECT * FROM ml_notifications WHERE project_id = ? ORDER BY publish_date ASC
      `).all(p.id) as any[];

      const notifs3A = notifs.filter(n => (n.notification_type === '3A' || n.notification_type === '3a') && n.publish_date);
      const notifs3D = notifs.filter(n => n.notification_type === '3D' && n.publish_date);

      for (const n3A of notifs3A) {
        const d3A = new Date(n3A.publish_date).getTime();
        if (isNaN(d3A)) continue;

        if (d3A > nowMs + 86400000 * 30) {
          issues.push({
            id: `ISS_FUT_3A_${n3A.id}`,
            issueType: 'IMPOSSIBLE_DATES',
            severity: 'CRITICAL',
            projectId: p.id,
            recordIdentifier: n3A.id,
            description: `Notification 3A has future publication date: ${n3A.publish_date}`,
            detectedAt: now
          });
        }
      }

      for (const n3D of notifs3D) {
        const d3D = new Date(n3D.publish_date).getTime();
        if (isNaN(d3D)) continue;

        if (d3D > nowMs + 86400000 * 30) {
          issues.push({
            id: `ISS_FUT_3D_${n3D.id}`,
            issueType: 'IMPOSSIBLE_DATES',
            severity: 'CRITICAL',
            projectId: p.id,
            recordIdentifier: n3D.id,
            description: `Notification 3D has future declaration date: ${n3D.publish_date}`,
            detectedAt: now
          });
        }
      }

      // Check project-level chronological impossibility:
      // If the project's earliest Section 3D declaration predates its earliest Section 3A notification
      if (notifs3A.length > 0 && notifs3D.length > 0) {
        const earliest3A = new Date(notifs3A[0].publish_date).getTime();
        const earliest3D = new Date(notifs3D[0].publish_date).getTime();
        if (!isNaN(earliest3A) && !isNaN(earliest3D) && earliest3D < earliest3A) {
          issues.push({
            id: `ISS_REV_DATE_${p.id}`,
            issueType: 'IMPOSSIBLE_DATES',
            severity: 'CRITICAL',
            projectId: p.id,
            recordIdentifier: `${notifs3A[0].id} -> ${notifs3D[0].id}`,
            description: `Impossible project statutory chronology: earliest Section 3D declared on ${notifs3D[0].publish_date}, prior to earliest Section 3A notification on ${notifs3A[0].publish_date}`,
            detectedAt: now
          });
        }
      }
    }

    // 4. Missing identifiers: null project id, empty name, or empty state
    const missingIdProjects = db.prepare(`
      SELECT id, name, state FROM ml_historical_projects
      WHERE name IS NULL OR name = '' OR state IS NULL OR state = ''
    `).all() as any[];
    for (const mp of missingIdProjects) {
      issues.push({
        id: `ISS_MISS_ID_${mp.id}`,
        issueType: 'MISSING_IDENTIFIER',
        severity: 'CRITICAL',
        projectId: mp.id,
        description: `Project ${mp.id} is missing essential statutory identifiers (name: "${mp.name}", state: "${mp.state}")`,
        detectedAt: now
      });
    }

    // 5. Invalid land values: total land required <= 0, negative values, or NaN
    const invalidLand = db.prepare(`
      SELECT id, total_land_required_ha FROM ml_historical_projects
      WHERE total_land_required_ha IS NULL OR total_land_required_ha <= 0
    `).all() as any[];
    for (const il of invalidLand) {
      issues.push({
        id: `ISS_INV_LAND_${il.id}`,
        issueType: 'INVALID_LAND_VALUE',
        severity: 'WARNING',
        projectId: il.id,
        description: `Project ${il.id} has invalid statutory land requirement (${il.total_land_required_ha} Ha)`,
        detectedAt: now
      });
    }

    // 6. Inconsistent land balances: land acquired > total required
    const inconsistentBalances = db.prepare(`
      SELECT p.id, p.total_land_required_ha, max(pe.cumulative_acquired_ha) as acq
      FROM ml_historical_projects p
      JOIN ml_possession_events pe ON pe.project_id = p.id
      GROUP BY p.id
      HAVING acq > p.total_land_required_ha * 1.05 AND p.total_land_required_ha > 0
    `).all() as any[];
    for (const ib of inconsistentBalances) {
      issues.push({
        id: `ISS_INCONS_BAL_${ib.id}`,
        issueType: 'INCONSISTENT_LAND_BALANCE',
        severity: 'WARNING',
        projectId: ib.id,
        description: `Acquired land area (${ib.acq} Ha) significantly exceeds total required land (${ib.total_land_required_ha} Ha)`,
        detectedAt: now
      });
    }

    // 7. Malformed source data: check for unparseable raw JSON in source records
    const sourceRecords = db.prepare('SELECT id, source_project_id, raw_json FROM ml_source_records').all() as any[];
    let malformedCount = 0;
    for (const sr of sourceRecords) {
      try {
        JSON.parse(sr.raw_json);
      } catch (e) {
        malformedCount++;
        issues.push({
          id: `ISS_MAL_SRC_${sr.id}`,
          issueType: 'MALFORMED_SOURCE_DATA',
          severity: 'CRITICAL',
          recordIdentifier: sr.id,
          description: `Raw source payload for ${sr.source_project_id} contains malformed or unparseable JSON`,
          detectedAt: now
        });
      }
    }

    // 8. Conflicting sources: projects with differing values across BhoomiRashi and manual records
    // Check if projects table differs from ml_historical_projects on core attributes
    const confSources = db.prepare(`
      SELECT p.id, p.name as orig_name, hp.name as hist_name, p.state as orig_state, hp.state as hist_state
      FROM projects p
      JOIN ml_historical_projects hp ON hp.id = p.id
      WHERE p.name != hp.name OR p.state != hp.state
    `).all() as any[];
    for (const cs of confSources) {
      issues.push({
        id: `ISS_CONF_SRC_${cs.id}`,
        issueType: 'CONFLICTING_SOURCES',
        severity: 'INFO',
        projectId: cs.id,
        description: `Cross-table source attribute discrepancy for ${cs.id}: name or state divergence`,
        detectedAt: now
      });
    }

    // 9. Suspicious duplicates: same highway number and district with identical land requirements
    const suspDups = db.prepare(`
      SELECT highway_number, state, district, total_land_required_ha, count(*) as c
      FROM ml_historical_projects
      WHERE highway_number IS NOT NULL AND highway_number != '' AND total_land_required_ha > 0
      GROUP BY highway_number, state, district, total_land_required_ha
      HAVING c > 1
    `).all() as any[];
    for (const sd of suspDups) {
      issues.push({
        id: `ISS_SUSP_DUP_${sd.highway_number}_${sd.district}`,
        issueType: 'SUSPICIOUS_DUPLICATE',
        severity: 'WARNING',
        recordIdentifier: `${sd.highway_number}/${sd.district}`,
        description: `Potential duplicate corridor: ${sd.c} projects share identical highway (${sd.highway_number}), district (${sd.district}), and land requirement (${sd.total_land_required_ha} Ha)`,
        detectedAt: now
      });
    }

    // Persist issues into SQLite table
    db.exec('DELETE FROM ml_data_quality_issues;');
    const insertStmt = db.prepare(`
      INSERT OR REPLACE INTO ml_data_quality_issues (
        id, issue_type, severity, project_id, record_identifier, description, detected_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    for (const issue of issues) {
      insertStmt.run(
        issue.id,
        issue.issueType,
        issue.severity,
        issue.projectId || null,
        issue.recordIdentifier || null,
        issue.description,
        issue.detectedAt
      );
    }

    // Aggregate counts
    const summary: Record<string, number> = {
      DUPLICATE_RECORD: 0,
      CONFLICTING_DATES: 0,
      IMPOSSIBLE_DATES: 0,
      MISSING_IDENTIFIER: 0,
      INVALID_LAND_VALUE: 0,
      INCONSISTENT_LAND_BALANCE: 0,
      MALFORMED_SOURCE_DATA: 0,
      CONFLICTING_SOURCES: 0,
      SUSPICIOUS_DUPLICATE: 0
    };

    for (const iss of issues) {
      summary[iss.issueType] = (summary[iss.issueType] || 0) + 1;
    }

    return {
      auditTimestamp: now,
      totalIssuesDetected: issues.length,
      duplicateRecordsCount: summary.DUPLICATE_RECORD,
      conflictingDatesCount: summary.CONFLICTING_DATES,
      impossibleDatesCount: summary.IMPOSSIBLE_DATES,
      missingIdentifiersCount: summary.MISSING_IDENTIFIER,
      invalidLandValuesCount: summary.INVALID_LAND_VALUE,
      inconsistentLandBalancesCount: summary.INCONSISTENT_LAND_BALANCE,
      malformedSourceDataCount: summary.MALFORMED_SOURCE_DATA,
      conflictingSourcesCount: summary.CONFLICTING_SOURCES,
      suspiciousDuplicatesCount: summary.SUSPICIOUS_DUPLICATE,
      sourceFailuresCount: 0,
      issuesSummary: summary,
      qualityStatus: issues.filter(i => i.severity === 'CRITICAL').length === 0 ? 'PASSED_WITH_FLAGGED_EXCLUSIONS' : 'ACTION_REQUIRED'
    };
  }
}
