/**
 * BHOOMI-DRISHTI ML DATASET FOUNDATION — HISTORICAL DATA MODEL TYPES
 * Phase 0: Foundations for genuine supervised land-acquisition delay prediction.
 */

export type ProvenanceType =
  | 'SOURCE_VERIFIED' // Authenticated external government source (BhoomiRashi, e-Gazette, LACRRIS)
  | 'OFFICIAL_ENTRY'  // Official government gazette entry entered via administrative portal
  | 'DERIVED'         // Computed via deterministic statutory timeline rules with documentary backing
  | 'DEMONSTRATION';  // Test/synthetic seed data — STRICTLY ISOLATED from ML training

export type PredictionTaskType =
  | 'EARLY_STAGE_DELAY_RISK'   // Prediction at project inception / Section 3A publication (T0)
  | 'CURRENT_STAGE_DELAY_RISK'; // Prediction dynamically at intermediate statutory milestones (Tk)

export type LabelState =
  | 'VERIFIED_DELAYED'      // Confirmed statutory delay or lapse with documentary evidence
  | 'VERIFIED_NOT_DELAYED'  // Confirmed on-time milestone progression with documentary evidence
  | 'UNRESOLVED'            // In-progress project within legitimate statutory window (cannot assign binary 0/1)
  | 'INSUFFICIENT_EVIDENCE'; // Incomplete or synthetic record without ground-truth milestone timestamps

export interface HistoricalProject {
  id: string;
  source: string;
  sourceProjectId: string;
  sourceUrl?: string;
  name: string;
  state: string;
  district: string;
  agency: string;
  highwayNumber?: string | null;
  act: string;
  provenance: ProvenanceType;
  totalLandRequiredHa: number;
  initialSanctionAmountCr?: number;
  initialSanctionDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SourceRecord {
  id: string;
  source: string;
  sourceName?: string;
  sourceUrl: string;
  sourceProjectId: string;
  sourceIdentifier?: string;
  retrievalTimestamp: string;
  rawHash: string;
  sourceHash?: string;
  rawJson: string;
  provenance: ProvenanceType;
  provenanceStatus?: ProvenanceType;
  ingestionRunId: string;
  notificationNumber?: string | null;
  publicationDate?: string | null;
  projectIdentifier?: string;
  documentType?: string;
  parserVersion?: string;
}

export interface StatutoryNotification {
  id: string;
  projectId: string;
  notificationType: '3a' | '3A' | '3D' | '3G' | 'OTHER';
  notificationNumber: string;
  publishDate: string;
  gazetteRef?: string | null;
  surveyNumbers?: string | null;
  status: string;
  provenance: ProvenanceType;
}

export interface StatutoryMilestone {
  id: string;
  projectId: string;
  milestoneType:
    | 'SECTION_3A'
    | 'SECTION_3D'
    | 'SECTION_3G_AWARD'
    | 'COMPENSATION_DISBURSEMENT'
    | 'POSSESSION_3E'
    | 'PROJECT_CLOSURE';
  statutoryDeadline?: string | null;
  plannedDate?: string | null;
  actualDate?: string | null;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED' | 'STATUTORY_LAPSE' | 'DELAYED';
  varianceDays?: number | null;
  provenance: ProvenanceType;
}

export interface CompensationEvent {
  id: string;
  projectId: string;
  eventDate: string;
  eventType: 'SANCTION' | 'AWARD' | 'DISBURSEMENT_BATCH' | 'DIRECT_PURCHASE';
  amountCr: number;
  disbursedPercent?: number | null;
  details?: string | null;
  provenance: ProvenanceType;
}

export interface LegalEvent {
  id: string;
  projectId: string;
  eventDate: string;
  eventType: 'WRIT_FILED' | 'STAY_GRANTED' | 'STAY_VACATED' | 'ARBITRATION_ORDER' | 'CASE_DISMISSED';
  courtName: string;
  caseNumber?: string | null;
  details: string;
  stayActive: boolean;
  provenance: ProvenanceType;
}

export interface DocumentationEvent {
  id: string;
  projectId: string;
  eventDate: string;
  eventType: 'JMS_STARTED' | 'JMS_COMPLETED' | 'OBJECTIONS_FILED' | 'OBJECTIONS_HEARD' | 'MUTATION_PENDING' | 'MUTATION_RESOLVED';
  unresolvedCount: number;
  details: string;
  provenance: ProvenanceType;
}

export interface PossessionEvent {
  id: string;
  projectId: string;
  eventDate: string;
  parcelsCount: number;
  areaHa: number;
  cumulativeAcquiredHa: number;
  details: string;
  provenance: ProvenanceType;
}

export interface ProjectSnapshot {
  id: string;
  projectId: string;
  snapshotTimestamp: string;
  predictionTask: PredictionTaskType;
  stageAtT: string;
  landAcquiredRatioAtT: number;
  compDisbursedPercentAtT: number;
  activeCourtStaysAtT: number;
  unresolvedCasesAtT: number;
  incompleteDocsCountAtT: number;
  forestClearanceAtT: string;
  elapsedDaysSince3aAtT?: number | null;
  snapshotFeaturesJson: string; // Serialized point-in-time feature dictionary
}

export interface LabelledObservation {
  id: string;
  projectId: string;
  snapshotId: string;
  predictionTask: PredictionTaskType;
  predictionTimestamp: string;
  label: LabelState;
  binaryTarget: 0 | 1 | null; // Null if UNRESOLVED or INSUFFICIENT_EVIDENCE
  labelDefinition: string;
  evidenceSource: string;
  evidenceDate: string;
  labelConfidence: number; // 0.0 to 1.0
  generationMethod: string;
  provenance: ProvenanceType;
  isEligibleForTraining: boolean; // True ONLY if SOURCE_VERIFIED & (VERIFIED_DELAYED | VERIFIED_NOT_DELAYED)

  // Explicit Phase 1 Provenance Attributes
  source: string;
  sourceUrl: string;
  notificationId?: string | null;
  retrievalTimestamp: string;
  publicationDate?: string | null;
  parserVersion: string;
  sourceHash: string;
  ingestionRunId: string;
  provenanceStatus: string;
}

export interface DatasetVersion {
  id: string;
  versionName: string;
  createdAt: string;
  task: PredictionTaskType;
  totalObservations: number;
  sourceVerifiedCount: number;
  demonstrationCount: number;
  verifiedDelayedCount: number;
  verifiedNotDelayedCount: number;
  unresolvedCount: number;
  insufficientEvidenceCount: number;
  eligibleTrainingCount: number;
  schemaVersion: string;
  featureSchemaVersion: string;
  auditHash: string;
}

export interface DataQualityIssue {
  id: string;
  issueType:
    | 'DUPLICATE_RECORD'
    | 'CONFLICTING_DATES'
    | 'IMPOSSIBLE_DATES'
    | 'MISSING_IDENTIFIER'
    | 'INVALID_LAND_VALUE'
    | 'INCONSISTENT_LAND_BALANCE'
    | 'MALFORMED_SOURCE_DATA'
    | 'CONFLICTING_SOURCES'
    | 'SUSPICIOUS_DUPLICATE';
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  projectId?: string;
  recordIdentifier?: string;
  description: string;
  detectedAt: string;
}

export interface DetailedDataQualityAudit {
  auditTimestamp: string;
  totalIssuesDetected: number;
  duplicateRecordsCount: number;
  conflictingDatesCount: number;
  impossibleDatesCount: number;
  missingIdentifiersCount: number;
  invalidLandValuesCount: number;
  inconsistentLandBalancesCount: number;
  malformedSourceDataCount: number;
  conflictingSourcesCount: number;
  suspiciousDuplicatesCount: number;
  sourceFailuresCount: number;
  issuesSummary: Record<string, number>;
  qualityStatus: 'PASSED_WITH_FLAGGED_EXCLUSIONS' | 'ACTION_REQUIRED';
}

export interface HistoricalDataQualityReport {
  totalProjects: number;
  sourceVerifiedProjects: number;
  demonstrationProjects: number;
  totalSnapshots: number;
  totalNotifications: number;
  totalMilestones: number;
  totalLabelledObservations: number;
  eligibleTrainingObservations: number;
  labelsDistribution: {
    verifiedDelayed: number;
    verifiedNotDelayed: number;
    unresolved: number;
    insufficientEvidence: number;
  };
  provenanceDistribution: Record<ProvenanceType, number>;
  stateDistribution: Record<string, number>;
  agencyDistribution: Record<string, number>;
  yearDistribution: Record<string, number>;
  missingValueAnalysis: {
    missingCompletionDatesCount: number;
    missingSanctionDatesCount: number;
    missing3aDatesCount: number;
    missing3dDatesCount: number;
  };
  leakageProtectionCheck: {
    hasFutureInformationLeakage: boolean;
    futureEventsFilteredCount: number;
    status: 'PASS' | 'FAIL';
  };
  readinessConclusion: 'READY_FOR_ML_TRAINING' | 'NOT_READY_FOR_ML_TRAINING' | 'NOT_READY_FOR_ML_TRAINING — ADDITIONAL LABELLED DATA REQUIRED';
  readinessReason: string;
}
