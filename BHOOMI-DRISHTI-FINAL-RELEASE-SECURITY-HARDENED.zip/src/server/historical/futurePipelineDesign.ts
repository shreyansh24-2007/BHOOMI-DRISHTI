/**
 * BHOOMI-DRISHTI — FUTURE ML PIPELINE ARCHITECTURE & SPECIFICATION
 * Documented engineering blueprint for Phase 1 supervised model training,
 * feature engineering, cross-validation, probability calibration, and deployment.
 */

export const FUTURE_ML_PIPELINE_SPECIFICATION = {
  architectureOverview: {
    systemName: "BhoomiDrishti Supervised Land Acquisition Risk Engine (B-SLARE)",
    targetTasks: [
      {
        taskId: "TASK_A_EARLY_STAGE",
        taskName: "Early-Stage Corridor Delay Risk (T0 Prediction)",
        predictionPoint: "At publication of initial statutory notification (Section 3A / 3a)",
        targetVariable: "Binary indicator: Section 3D declaration exceeds 365 days statutory deadline under Section 3A(7) of NH Act 1956 (1 = Delayed/Lapsed, 0 = On-Time)",
        objective: "Early warning during DPR/Feasibility stage to alert Project Directors of high-friction corridors prior to capital commitment."
      },
      {
        taskId: "TASK_B_CURRENT_STAGE",
        taskName: "Current-Stage Dynamic Delay Forecasting (Tk Prediction)",
        predictionPoint: "At intermediate statutory milestones (post-3D declaration, post-3G award, ongoing compensation disbursement)",
        targetVariable: "Continuous variance in months and binary indicator of project delay > 6 months past target completion date",
        objective: "Dynamic escalation engine for active PMU monitoring, prioritizing field intervention for stalled disbursements and court stays."
      }
    ]
  },

  preprocessingAndFeatureEngineering: {
    staticCorridorFeatures: [
      "total_land_required_ha: Continuous scalar (log1p transformed)",
      "state_district_encoding: Target-encoded historical acquisition velocity by district",
      "agency_type: One-hot encoded (NHAI, MoRTH, State PWD, RVNL, NHIDCL)",
      "highway_corridor_type: Categorical (Greenfield Expressway, Brownfield Widening, Bypass, Spur)",
      "cadastral_complexity_proxy: Estimated parcels per kilometer based on regional land fragmentation indices"
    ],
    dynamicMilestoneFeatures: [
      "elapsed_days_since_3a: Number of calendar days elapsed since first Section 3A notification",
      "disbursement_velocity: Compensation disbursed (Cr) / elapsed months since 3G award",
      "active_court_stays_count: Integer count of active interim injunctions halting possession",
      "unresolved_legal_cases: Total pending civil writs and land acquisition references",
      "incomplete_mutation_backlog: Ratio of land surveyed without record-of-rights mutation",
      "forest_stage_clearance: Ordinal encoding (Stage-0: No Forest, Stage-1: In-Principle, Stage-2: Final)"
    ],
    imputationAndScaling: {
      numerical: "Median imputation within same state/agency group followed by RobustScaler to handle heavy-tailed land areas",
      categorical: "Target encoding with additive smoothing for high-cardinality districts; one-hot encoding for agencies",
      temporalLeakageGuard: "All scalers and encoders MUST be fitted ONLY on training folds and never on validation/test folds."
    }
  },

  crossValidationStrategy: {
    method: "StratifiedGroupKFold and TemporalHoldoutSplit",
    groupingVariable: "corridor_project_id",
    rationale: "Multiple parcels or notification packages belonging to the same highway corridor must never appear in both training and validation splits. GroupKFold prevents spatial corridor leakage.",
    temporalHoldout: "Corridors initiated prior to 2024 for training/validation (5-fold StratifiedGroupKFold); Corridors initiated in 2024-2025 reserved as an untouched out-of-time evaluation set.",
    classBalanceHandling: "Balanced class weights in loss function; synthetic oversampling (SMOTE) strictly restricted to training folds."
  },

  candidateModelArchitectures: [
    {
      name: "LightGBM Classifier & Regressor",
      justification: "Native handling of categorical variables, robust to skewed financial distributions, high inference speed for interactive what-if scenarios, fast exact TreeSHAP computation.",
      hyperparameterSearch: "Bayesian optimization (Optuna) tuning num_leaves, min_child_samples, learning_rate, subsample, colsample_bytree, reg_alpha, reg_lambda."
    },
    {
      name: "XGBoost Classifier",
      justification: "Second tree-based ensemble candidate providing regularized split trees with monotonic constraints on risk variables (e.g. risk must monotonically increase with active court stays).",
      hyperparameterSearch: "Grid search on max_depth (3 to 6), gamma, subsample, min_child_weight."
    },
    {
      name: "Calibrated Logistic Regression (Linear Baseline)",
      justification: "Parsimonious reference baseline to verify non-linear performance gains over traditional linear risk scoring."
    }
  ],

  probabilityCalibration: {
    technique: "Isotonic Regression and Platt Scaling (Sigmoidal Logistic)",
    validation: "Brier score minimization and reliability diagrams (10 calibration bins)",
    requirement: "A predicted probability of 70% delay risk MUST correspond to empirical statutory delay in 70% of historical test instances."
  },

  explainabilityArchitecture: {
    method: "TreeSHAP (Lundberg et al., Nature MI)",
    outputs: {
      globalExplanations: "Mean absolute SHAP values ranking corridor risk drivers across national portfolio.",
      localExplanations: "Per-project waterfall breakdown attributing exact percentage contribution to each risk driver (e.g. Court Stay: +24%, Land Fragmentation: +12%, Fast Disbursement: -8%).",
      fidelityGuarantee: "SHAP sum equals model output log-odds exactly; no heuristic approximations."
    }
  },

  productionDeploymentAndMonitoring: {
    servingArchitecture: "ONNX Runtime or serialized Python microservice with sub-10ms inference latency.",
    modelRegistry: "Immutable MLflow / Git-backed model artifacts storing model weights, feature signature, Git commit, training data hash, and calibration curve.",
    continuousMonitoring: {
      dataDrift: "Population Stability Index (PSI) computed weekly on incoming project features against training baseline. Alert if PSI > 0.2.",
      conceptDrift: "Quarterly re-evaluation of statutory lapse rates as state land acquisition policies and circle rates evolve.",
      retrainingTrigger: "Automated retraining pipeline triggered when 200 new source-verified project outcomes are registered."
    }
  }
};
