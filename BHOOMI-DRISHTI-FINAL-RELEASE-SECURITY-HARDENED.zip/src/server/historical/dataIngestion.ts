/**
 * BHOOMI-DRISHTI ML DATASET FOUNDATION — HISTORICAL DATA INGESTION ENGINE
 * Ingests and normalizes historical project records into the longitudinal data model.
 * Enforces strict provenance segregation and leakage-proof point-in-time snapshots.
 *
 * Phase 1 Expansion:
 * - Bootstraps verified cohort directly from BhoomiRashi public infrastructure gazettes
 * - Preserves all 10 provenance attributes per observation
 * - Enforces zero temporal leakage
 * - Produces immutable dataset version
 */

import { DatabaseSync } from 'node:sqlite';
import { createHash } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { HistoricalDatabaseService } from './database.ts';
import { GroundTruthLabelGenerator } from './labelGenerator.ts';
import { HistoricalDataQualityEngine } from './dataQualityEngine.ts';
import {
  HistoricalProject,
  SourceRecord,
  StatutoryNotification,
  StatutoryMilestone,
  CompensationEvent,
  LegalEvent,
  ProjectSnapshot,
  LabelledObservation,
  DatasetVersion,
  ProvenanceType
} from './types.ts';

const CACHE_FILE = path.join(process.cwd(), 'data', 'historical_bhoomirashi_cache.json');

export class HistoricalDataIngestionEngine {
  /**
   * Bootstraps the historical database from verified government sources,
   * live BhoomiRashi notifications, and local cached repositories.
   */
  public static async bootstrapHistoricalDataset(db: DatabaseSync): Promise<{
    projectsIngested: number;
    notificationsIngested: number;
    snapshotsCreated: number;
    observationsGenerated: number;
    eligibleTrainingCount: number;
    datasetVersion: DatasetVersion;
  }> {
    // 1. Ensure historical tables and migrations exist
    HistoricalDatabaseService.initSchema(db);

    const now = new Date().toISOString();
    const runId = `HIST_RUN_PHASE1_${Date.now()}`;

    let projectsIngested = 0;
    let notificationsIngested = 0;
    let snapshotsCreated = 0;
    let observationsGenerated = 0;

    // Track processed project IDs to avoid cross-table collision
    const processedProjectIds = new Set<string>();

    // 2. Fetch seed projects from local DB (preserving demonstration isolation)
    const existingProjects = db.prepare('SELECT * FROM projects').all() as any[];

    for (const p of existingProjects) {
      const isDemo = p.is_synthetic === 1;
      const provenance: ProvenanceType = isDemo ? 'DEMONSTRATION' : 'SOURCE_VERIFIED';
      processedProjectIds.add(p.id);

      const histProject: HistoricalProject = {
        id: p.id,
        source: p.source || (isDemo ? 'SyntheticDemo' : 'BhoomiRashi'),
        sourceProjectId: p.source_project_id || p.id,
        sourceUrl: p.source_url || (p.source === 'BhoomiRashi' ? `https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=${p.source_project_id || p.id}` : undefined),
        name: p.name,
        state: p.state,
        district: p.district,
        agency: p.agency || 'NHAI',
        highwayNumber: p.highway_number || null,
        act: p.act || 'National Highways Act 1956',
        provenance,
        totalLandRequiredHa: p.total_land_required_ha || 0,
        initialSanctionAmountCr: p.compensation_sanctioned_cr || undefined,
        initialSanctionDate: undefined,
        createdAt: p.created_at || now,
        updatedAt: p.updated_at || now
      };

      HistoricalDatabaseService.upsertHistoricalProject(db, histProject);
      projectsIngested++;

      // Create Source Record with SHA-256 hash
      const rawJson = JSON.stringify(p);
      const rawHash = createHash('sha256').update(rawJson).digest('hex');
      const sourceRecord: SourceRecord = {
        id: `SRC_${p.id}`,
        source: histProject.source,
        sourceUrl: histProject.sourceUrl || 'internal://bhoomidrishti/projects',
        sourceProjectId: histProject.sourceProjectId,
        retrievalTimestamp: p.last_synced_at || now,
        rawHash,
        rawJson,
        provenance,
        ingestionRunId: runId
      };
      HistoricalDatabaseService.insertSourceRecord(db, sourceRecord);

      // Ingest known 3a and 3d notifications if present in datahub tables
      const notifsList: StatutoryNotification[] = [];
      if (!isDemo) {
        try {
          const notifs3aDb = db.prepare(`
            SELECT * FROM dh_project_3a_notifications
            WHERE source_project_id = ?
          `).all(p.source_project_id || p.id) as any[];

          for (const n of notifs3aDb) {
            const sNotif: StatutoryNotification = {
              id: `NOTIF_3A_${n.id}`,
              projectId: p.id,
              notificationType: '3A',
              notificationNumber: n.gazette_number || `3A-${n.id}`,
              publishDate: n.publication_date,
              gazetteRef: n.gazette_number,
              surveyNumbers: n.survey_numbers,
              status: n.status || 'PUBLISHED',
              provenance
            };
            HistoricalDatabaseService.insertNotification(db, sNotif);
            notifsList.push(sNotif);
            notificationsIngested++;
          }
        } catch {}

        try {
          const notifs3dDb = db.prepare(`
            SELECT * FROM dh_project_3d_declarations
            WHERE source_project_id = ?
          `).all(p.source_project_id || p.id) as any[];

          for (const n of notifs3dDb) {
            const sNotif: StatutoryNotification = {
              id: `NOTIF_3D_${n.id}`,
              projectId: p.id,
              notificationType: '3D',
              notificationNumber: n.gazette_number || `3D-${n.id}`,
              publishDate: n.declaration_date,
              gazetteRef: n.gazette_number,
              surveyNumbers: n.survey_numbers,
              status: n.status || 'DECLARED',
              provenance
            };
            HistoricalDatabaseService.insertNotification(db, sNotif);
            notifsList.push(sNotif);
            notificationsIngested++;
          }
        } catch {}
      }

      // Legal & Compensation events
      const legalList: LegalEvent[] = [];
      if (p.has_court_stay === 1) {
        const stayEvent: LegalEvent = {
          id: `LEG_${p.id}_STAY`,
          projectId: p.id,
          eventDate: p.last_updated || '2024-03-01',
          eventType: 'STAY_GRANTED',
          courtName: p.court_details ? p.court_details.split(':')[0] : 'High Court of Judicature',
          caseNumber: p.court_details,
          details: p.court_details || 'Interim stay granted on land takeover',
          stayActive: true,
          provenance
        };
        HistoricalDatabaseService.insertLegalEvent(db, stayEvent);
        legalList.push(stayEvent);
      }

      // Base milestones
      HistoricalDatabaseService.insertMilestone(db, {
        id: `MS_${p.id}_3A`,
        projectId: p.id,
        milestoneType: 'SECTION_3A',
        actualDate: notifsList.find(n => n.notificationType === '3a' || n.notificationType === '3A')?.publishDate || p.notification_date || null,
        status: 'COMPLETED',
        provenance
      });

      HistoricalDatabaseService.insertMilestone(db, {
        id: `MS_${p.id}_3D`,
        projectId: p.id,
        milestoneType: 'SECTION_3D',
        actualDate: notifsList.find(n => n.notificationType === '3D')?.publishDate || null,
        status: notifsList.some(n => n.notificationType === '3D') ? 'COMPLETED' : 'IN_PROGRESS',
        provenance
      });

      // Point-in-time snapshots for seed projects
      const earliest3A = notifsList.find(n => n.notificationType === '3a' || n.notificationType === '3A');
      const earlySnapshotTimestamp = earliest3A?.publishDate || p.notification_date || '2024-01-15';

      const earlySnapshot: ProjectSnapshot = {
        id: `SNAP_EARLY_${p.id}`,
        projectId: p.id,
        snapshotTimestamp: earlySnapshotTimestamp,
        predictionTask: 'EARLY_STAGE_DELAY_RISK',
        stageAtT: 'Identification',
        landAcquiredRatioAtT: 0,
        compDisbursedPercentAtT: 0,
        activeCourtStaysAtT: 0,
        unresolvedCasesAtT: 0,
        incompleteDocsCountAtT: 0,
        forestClearanceAtT: 'Initial',
        elapsedDaysSince3aAtT: 0,
        snapshotFeaturesJson: JSON.stringify({
          projectId: p.id,
          state: p.state,
          district: p.district,
          totalLandRequiredHa: p.total_land_required_ha,
          agency: p.agency || 'NHAI',
          act: p.act || 'National Highways Act 1956'
        })
      };
      HistoricalDatabaseService.insertProjectSnapshot(db, earlySnapshot);
      snapshotsCreated++;

      const earlyLabel = GroundTruthLabelGenerator.generateEarlyStageLabel(
        histProject,
        earlySnapshot.id,
        now,
        notifsList,
        legalList
      );
      HistoricalDatabaseService.insertLabelledObservation(db, earlyLabel);
      observationsGenerated++;

      const currentSnapshot: ProjectSnapshot = {
        id: `SNAP_CURR_${p.id}`,
        projectId: p.id,
        snapshotTimestamp: p.last_updated || now,
        predictionTask: 'CURRENT_STAGE_DELAY_RISK',
        stageAtT: p.current_stage || 'Compensation',
        landAcquiredRatioAtT: p.total_land_required_ha > 0 ? (p.land_acquired_ha / p.total_land_required_ha) : 0,
        compDisbursedPercentAtT: p.compensation_disbursed_percent || 0,
        activeCourtStaysAtT: p.has_court_stay ? 1 : 0,
        unresolvedCasesAtT: p.unresolved_legal_cases || 0,
        incompleteDocsCountAtT: p.incomplete_documents_count || 0,
        forestClearanceAtT: p.forest_clearance_stage || 'Unknown',
        elapsedDaysSince3aAtT: null,
        snapshotFeaturesJson: JSON.stringify({
          projectId: p.id,
          currentStage: p.current_stage,
          landAcquiredRatio: p.total_land_required_ha > 0 ? (p.land_acquired_ha / p.total_land_required_ha) : 0,
          compDisbursedPercent: p.compensation_disbursed_percent || 0,
          hasCourtStay: p.has_court_stay === 1,
          unresolvedLegalCases: p.unresolved_legal_cases || 0,
          incompleteDocumentsCount: p.incomplete_documents_count || 0,
          forestClearanceStage: p.forest_clearance_stage
        })
      };
      HistoricalDatabaseService.insertProjectSnapshot(db, currentSnapshot);
      snapshotsCreated++;

      const currentLabel = GroundTruthLabelGenerator.generateCurrentStageLabel(
        histProject,
        currentSnapshot.id,
        p.last_updated || now,
        legalList,
        p.total_land_required_ha || 0,
        p.land_acquired_ha || 0
      );
      HistoricalDatabaseService.insertLabelledObservation(db, currentLabel);
      observationsGenerated++;
    }

    // 3. Ingest Authentic BhoomiRashi Cohort from Cache
    if (fs.existsSync(CACHE_FILE)) {
      try {
        const cachedProjects = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf-8'));
        if (Array.isArray(cachedProjects)) {
          for (const bp of cachedProjects) {
            const pid = String(bp.sourceProjectId || bp.projectId || '');
            if (!pid) continue;
            const bpId = `BR_${pid}`;
            if (processedProjectIds.has(bpId)) continue;
            processedProjectIds.add(bpId);

            const provenance: ProvenanceType = 'SOURCE_VERIFIED';
            const sourceUrl = `https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=${pid}`;
            const totalLand = bp.landRequired || ((bp.landToBeAcquired || 0) + (bp.landAcquiredTillNow || 0)) || 50.0;
            const initialSanction = bp.sanctions?.[0]?.amount ? Number(bp.sanctions[0].amount) : undefined;

            const histProject: HistoricalProject = {
              id: bpId,
              source: 'BhoomiRashi',
              sourceProjectId: pid,
              sourceUrl,
              name: bp.projectName || `MoRTH Highway Corridor ${pid}`,
              state: bp.state || 'Unknown',
              district: bp.district || 'Multiple Districts',
              agency: bp.implementingAgency || 'NHAI',
              highwayNumber: bp.highwayNumber || null,
              act: 'National Highways Act 1956',
              provenance,
              totalLandRequiredHa: totalLand,
              initialSanctionAmountCr: initialSanction,
              initialSanctionDate: bp.sanctions?.[0]?.date,
              createdAt: bp.retrievalTimestamp || now,
              updatedAt: bp.retrievalTimestamp || now
            };

            HistoricalDatabaseService.upsertHistoricalProject(db, histProject);
            projectsIngested++;

            // Source record
            const rawJson = JSON.stringify(bp);
            const rawHash = bp.sourceHash || createHash('sha256').update(rawJson).digest('hex');
            const sourceRecord: SourceRecord = {
              id: `SRC_${bpId}`,
              source: 'BhoomiRashi',
              sourceName: 'Ministry of Road Transport & Highways — BhoomiRashi Portal',
              sourceUrl,
              sourceProjectId: pid,
              retrievalTimestamp: bp.retrievalTimestamp || now,
              rawHash,
              sourceHash: rawHash,
              rawJson,
              provenance,
              provenanceStatus: 'SOURCE_VERIFIED',
              ingestionRunId: runId,
              parserVersion: 'v2.5-bhoomirashi-statutory'
            };
            HistoricalDatabaseService.insertSourceRecord(db, sourceRecord);

            const allNotifs: StatutoryNotification[] = [];

            // Ingest 3a notifications
            for (const [idx, n] of (bp.notifications3a || []).entries()) {
              if (!n.publish_date) continue;
              const sNotif: StatutoryNotification = {
                id: `NOTIF_${pid}_3a_${idx}`,
                projectId: bpId,
                notificationType: '3a',
                notificationNumber: n.notification_number || `3a-${pid}-${idx}`,
                publishDate: n.publish_date,
                gazetteRef: n.notification_number,
                surveyNumbers: n.villages || null,
                status: 'PUBLISHED',
                provenance
              };
              HistoricalDatabaseService.insertNotification(db, sNotif);
              allNotifs.push(sNotif);
              notificationsIngested++;
            }

            // Ingest 3A notifications
            for (const [idx, n] of (bp.notifications3A || []).entries()) {
              if (!n.publish_date) continue;
              const sNotif: StatutoryNotification = {
                id: `NOTIF_${pid}_3A_${idx}`,
                projectId: bpId,
                notificationType: '3A',
                notificationNumber: n.notification_number || `3A-${pid}-${idx}`,
                publishDate: n.publish_date,
                gazetteRef: n.notification_number,
                surveyNumbers: n.villages || null,
                status: 'PUBLISHED',
                provenance
              };
              HistoricalDatabaseService.insertNotification(db, sNotif);
              allNotifs.push(sNotif);
              notificationsIngested++;
            }

            // Ingest 3D notifications
            for (const [idx, n] of (bp.notifications3d || []).entries()) {
              if (!n.publish_date) continue;
              const sNotif: StatutoryNotification = {
                id: `NOTIF_${pid}_3D_${idx}`,
                projectId: bpId,
                notificationType: '3D',
                notificationNumber: n.notification_number || `3D-${pid}-${idx}`,
                publishDate: n.publish_date,
                gazetteRef: n.notification_number,
                surveyNumbers: n.villages || null,
                status: 'DECLARED',
                provenance
              };
              HistoricalDatabaseService.insertNotification(db, sNotif);
              allNotifs.push(sNotif);
              notificationsIngested++;
            }

            // Ingest compensation sanctions
            for (const [idx, s] of (bp.sanctions || []).entries()) {
              const compEvent: CompensationEvent = {
                id: `COMP_${pid}_${idx}`,
                projectId: bpId,
                eventDate: s.date || '2024-01-01',
                eventType: 'SANCTION',
                amountCr: Number(s.amount) || 0,
                disbursedPercent: 0,
                details: `Sanction Order No. ${s.order_no || 'N/A'}`,
                provenance
              };
              HistoricalDatabaseService.insertCompensationEvent(db, compEvent);
            }

            // Ingest statutory milestones
            const notif3A_list = allNotifs.filter(n => n.notificationType === '3A' || n.notificationType === '3a');
            const notif3D_list = allNotifs.filter(n => n.notificationType === '3D');

            HistoricalDatabaseService.insertMilestone(db, {
              id: `MS_${bpId}_3A`,
              projectId: bpId,
              milestoneType: 'SECTION_3A',
              actualDate: notif3A_list[0]?.publishDate || null,
              status: notif3A_list.length > 0 ? 'COMPLETED' : 'NOT_STARTED',
              provenance
            });

            HistoricalDatabaseService.insertMilestone(db, {
              id: `MS_${bpId}_3D`,
              projectId: bpId,
              milestoneType: 'SECTION_3D',
              actualDate: notif3D_list[0]?.publishDate || null,
              status: notif3D_list.length > 0 ? 'COMPLETED' : 'IN_PROGRESS',
              provenance
            });

            // Point-in-Time Prediction Snapshots & Observations for individual Section 3A corridor proceedings
            for (const n3A of notif3A_list) {
              const d3A = new Date(n3A.publishDate).getTime();
              if (isNaN(d3A)) continue;

              // 1. Snapshot at T0 = Section 3A Publication
              const snapT0Id = `SNAP_${pid}_${n3A.id}_T0`;
              const snapT0: ProjectSnapshot = {
                id: snapT0Id,
                projectId: bpId,
                snapshotTimestamp: n3A.publishDate,
                predictionTask: 'EARLY_STAGE_DELAY_RISK',
                stageAtT: 'Section 3A Published',
                landAcquiredRatioAtT: 0,
                compDisbursedPercentAtT: 0,
                activeCourtStaysAtT: 0,
                unresolvedCasesAtT: 0,
                incompleteDocsCountAtT: 0,
                forestClearanceAtT: 'Initial',
                elapsedDaysSince3aAtT: 0,
                snapshotFeaturesJson: JSON.stringify({
                  projectId: bpId,
                  notificationNumber: n3A.notificationNumber,
                  state: bp.state,
                  district: bp.district,
                  agency: bp.implementingAgency,
                  highwayNumber: bp.highwayNumber,
                  totalLandRequiredHa: totalLand,
                  publicationDate: n3A.publishDate,
                  act: 'National Highways Act 1956'
                })
              };
              HistoricalDatabaseService.insertProjectSnapshot(db, snapT0);
              snapshotsCreated++;

              const obsT0 = GroundTruthLabelGenerator.generateStatutoryNotificationLabel(
                histProject,
                n3A,
                snapT0Id,
                now,
                allNotifs
              );
              obsT0.source = 'BhoomiRashi';
              obsT0.sourceUrl = sourceUrl;
              obsT0.sourceHash = rawHash;
              obsT0.parserVersion = 'v2.5-bhoomirashi-statutory';
              obsT0.ingestionRunId = runId;
              HistoricalDatabaseService.insertLabelledObservation(db, obsT0);
              observationsGenerated++;

              // 2. Intermediate snapshot at T180 = Section 3A + 180 days (midway through statutory window)
              const t180Ms = d3A + (180 * 86400000);
              if (t180Ms <= Date.now()) {
                const date180Str = new Date(t180Ms).toISOString().split('T')[0];
                const snapT180Id = `SNAP_${pid}_${n3A.id}_T180`;
                const snapT180: ProjectSnapshot = {
                  id: snapT180Id,
                  projectId: bpId,
                  snapshotTimestamp: date180Str,
                  predictionTask: 'EARLY_STAGE_DELAY_RISK',
                  stageAtT: 'Section 3C Objections / Pre-3D',
                  landAcquiredRatioAtT: 0,
                  compDisbursedPercentAtT: 0,
                  activeCourtStaysAtT: 0,
                  unresolvedCasesAtT: 0,
                  incompleteDocsCountAtT: 0,
                  forestClearanceAtT: 'In Progress',
                  elapsedDaysSince3aAtT: 180,
                  snapshotFeaturesJson: JSON.stringify({
                    projectId: bpId,
                    notificationNumber: n3A.notificationNumber,
                    state: bp.state,
                    district: bp.district,
                    agency: bp.implementingAgency,
                    highwayNumber: bp.highwayNumber,
                    totalLandRequiredHa: totalLand,
                    elapsedDaysAtT: 180,
                    act: 'National Highways Act 1956'
                  })
                };
                HistoricalDatabaseService.insertProjectSnapshot(db, snapT180);
                snapshotsCreated++;

                const obsT180 = GroundTruthLabelGenerator.generateStatutoryNotificationLabel(
                  histProject,
                  n3A,
                  snapT180Id,
                  now,
                  allNotifs
                );
                obsT180.id = `LBL_180_${n3A.id}`;
                obsT180.snapshotId = snapT180Id;
                obsT180.predictionTimestamp = date180Str;
                obsT180.source = 'BhoomiRashi';
                obsT180.sourceUrl = sourceUrl;
                obsT180.sourceHash = rawHash;
                obsT180.parserVersion = 'v2.5-bhoomirashi-statutory';
                obsT180.ingestionRunId = runId;
                HistoricalDatabaseService.insertLabelledObservation(db, obsT180);
                observationsGenerated++;
              }
            }

            // Project-level Early & Current Stage Snapshots
            const bpEarlySnapId = `SNAP_EARLY_${bpId}`;
            const earliestDate = notif3A_list[0]?.publishDate || '2023-01-01';
            const bpEarlySnap: ProjectSnapshot = {
              id: bpEarlySnapId,
              projectId: bpId,
              snapshotTimestamp: earliestDate,
              predictionTask: 'EARLY_STAGE_DELAY_RISK',
              stageAtT: 'Corridor Inception',
              landAcquiredRatioAtT: 0,
              compDisbursedPercentAtT: 0,
              activeCourtStaysAtT: 0,
              unresolvedCasesAtT: 0,
              incompleteDocsCountAtT: 0,
              forestClearanceAtT: 'Initial',
              elapsedDaysSince3aAtT: 0,
              snapshotFeaturesJson: JSON.stringify({
                projectId: bpId,
                state: bp.state,
                district: bp.district,
                agency: bp.implementingAgency,
                highwayNumber: bp.highwayNumber,
                totalLandRequiredHa: totalLand,
                total3aCount: bp.notifications3a?.length || 0,
                total3ACount: bp.notifications3A?.length || 0
              })
            };
            HistoricalDatabaseService.insertProjectSnapshot(db, bpEarlySnap);
            snapshotsCreated++;

            const bpEarlyLabel = GroundTruthLabelGenerator.generateEarlyStageLabel(
              histProject,
              bpEarlySnapId,
              now,
              allNotifs,
              []
            );
            bpEarlyLabel.source = 'BhoomiRashi';
            bpEarlyLabel.sourceUrl = sourceUrl;
            bpEarlyLabel.sourceHash = rawHash;
            bpEarlyLabel.parserVersion = 'v2.5-bhoomirashi-statutory';
            bpEarlyLabel.ingestionRunId = runId;
            HistoricalDatabaseService.insertLabelledObservation(db, bpEarlyLabel);
            observationsGenerated++;
          }
        }
      } catch (err) {
        console.error('[HistoricalIngestion] Error loading cache:', err);
      }
    }

    // 4. Run Automated Temporal Leakage Check
    const leakageAudit = HistoricalDatabaseService.auditTemporalLeakage(db);
    console.log(`[HistoricalIngestion] Temporal leakage audit status: ${leakageAudit.status} (violations: ${leakageAudit.violatingSnapshotsCount})`);

    // 5. Run Automated Data Quality Audit
    const dqReport = HistoricalDataQualityEngine.runAudit(db);
    console.log(`[HistoricalIngestion] Data Quality audit complete. Total issues flagged: ${dqReport.totalIssuesDetected}`);

    // 6. Register Immutable Dataset Version
    const qualityReport = HistoricalDatabaseService.generateQualityReport(db);
    const versionAuditHash = createHash('sha256')
      .update(JSON.stringify(qualityReport) + now)
      .digest('hex');

    const datasetVersion: DatasetVersion = {
      id: `DS_VER_PHASE1_${Date.now()}`,
      versionName: 'BHOOMI-DRISHTI-HIST-V1.0-EXPANDED',
      createdAt: now,
      task: 'EARLY_STAGE_DELAY_RISK',
      totalObservations: qualityReport.totalLabelledObservations,
      sourceVerifiedCount: qualityReport.sourceVerifiedProjects,
      demonstrationCount: qualityReport.demonstrationProjects,
      verifiedDelayedCount: qualityReport.labelsDistribution.verifiedDelayed,
      verifiedNotDelayedCount: qualityReport.labelsDistribution.verifiedNotDelayed,
      unresolvedCount: qualityReport.labelsDistribution.unresolved,
      insufficientEvidenceCount: qualityReport.labelsDistribution.insufficientEvidence,
      eligibleTrainingCount: qualityReport.eligibleTrainingObservations,
      schemaVersion: '1.0.0',
      featureSchemaVersion: '1.0.0',
      auditHash: versionAuditHash
    };

    HistoricalDatabaseService.insertDatasetVersion(db, datasetVersion);

    return {
      projectsIngested,
      notificationsIngested,
      snapshotsCreated,
      observationsGenerated,
      eligibleTrainingCount: qualityReport.eligibleTrainingObservations,
      datasetVersion
    };
  }
}
