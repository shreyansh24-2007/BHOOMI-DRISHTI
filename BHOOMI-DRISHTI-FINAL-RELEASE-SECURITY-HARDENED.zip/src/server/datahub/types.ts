/**
 * Data Hub Type Definitions
 * Phase 1: BhoomiRashi Data Collection & Synchronization Hub
 * Smart India Hackathon 2026 - SIH26017
 */

export type DiscoveryMethod = 'AUTO_DISCOVERED' | 'MANUALLY_REGISTERED' | 'IMPORTED' | 'DEMO' | 'CONTROLLED_DISCOVERY' | 'GAZETTE_INGESTION';
export type DataStatus = 'SYNCHRONIZED' | 'RECENTLY_UPDATED' | 'UNCHANGED' | 'SOURCE_ERROR' | 'IMPORTED' | 'DEMO' | 'NEW' | 'UPDATED' | 'FAILED' | 'REJECTED' | 'PARSE_FAILED' | 'SOURCE_INVALID';
export type SyncRunStatus = 'RUNNING' | 'SUCCESS' | 'PARTIAL' | 'PARTIAL_SUCCESS' | 'FAILED' | 'REJECTED';
export type HistoryChangeType = 'INITIAL' | 'UPDATED' | 'UNCHANGED' | 'IMPORTED';

export interface DataHubSource {
  id: string;
  source_name: string;
  organization: string;
  base_url: string;
  source_type: string;
  enabled: boolean;
  check_interval_minutes: number;
  last_check_at: string | null;
  last_success_at: string | null;
  last_error_at: string | null;
  next_check_at: string | null;
  status: 'CONNECTED' | 'CHECKING' | 'ERROR' | 'DISABLED';
  created_at: string;
  updated_at: string;
}

export interface SourceProjectRecord {
  id: string;
  source_name: string;
  source_project_id: string;
  project_number: string | null;
  project_name: string;
  source_url: string;
  discovery_method: DiscoveryMethod;
  first_seen_at: string;
  last_checked_at: string | null;
  last_changed_at: string | null;
  current_hash: string | null;
  source_status: string;
  data_status: DataStatus;
  created_at: string;
  updated_at: string;
}

export interface ProjectCurrentRecord {
  source_project_id: string;
  project_name: string;
  project_number: string | null;
  state: string | null;
  district: string | null;
  implementing_agency: string | null;
  highway_number: string | null;
  land_required: number;
  land_available: number;
  land_to_be_acquired: number;
  land_acquired_till_now: number;
  sanction_number: string | null;
  sanction_date: string | null;
  sanction_amount: number | null;
  additional_info: string | null; // JSON
  created_at: string;
  updated_at: string;
  last_source_check: string;
}

export interface Project3aNotification {
  id: string;
  source_project_id: string;
  publish_date: string | null;
  notification_number: string | null;
  cala: string | null;
  villages: string | null;
  status: string | null;
  raw_value: string | null;
  created_at: string;
}

export interface Project3ANotification {
  id: string;
  source_project_id: string;
  publish_date: string | null;
  notification_number: string | null;
  survey_numbers: string | null;
  objections: string | null;
  status: string | null;
  raw_value: string | null;
  created_at: string;
}

export interface Project3dNotification {
  id: string;
  source_project_id: string;
  publish_date: string | null;
  notification_number: string | null;
  survey_numbers: string | null;
  status: string | null;
  raw_value: string | null;
  created_at: string;
}

export interface ProjectSanction {
  id: string;
  source_project_id: string;
  sanction_number: string | null;
  sanction_date: string | null;
  sanction_amount: number | null;
  status: string | null;
  raw_value: string | null;
  created_at: string;
}

export interface ProjectConsentPurchase {
  id: string;
  source_project_id: string;
  state: string | null;
  district: string | null;
  sub_district: string | null;
  village: string | null;
  survey_number: string | null;
  land_party: string | null;
  amount: number | null;
  disbursement_details: string | null;
  created_at: string;
}

export interface ProjectHistoryRecord {
  id: string;
  source_project_id: string;
  snapshot_hash: string;
  snapshot_json: string;
  captured_at: string;
  change_type: HistoryChangeType;
}

export interface SyncRunRecord {
  id: string;
  source_name: string;
  started_at: string;
  completed_at: string | null;
  status: SyncRunStatus;
  projects_checked: number;
  new_projects: number;
  updated_projects: number;
  unchanged_projects: number;
  error_projects: number;
  parser_failures?: number;
  source_failures?: number;
  duration_ms?: number;
  rejected_records?: number;
  error_message: string | null;
}

export interface SyncChangeRecord {
  id: string;
  sync_run_id: string;
  source_project_id: string;
  field_name: string;
  old_value: string | null;
  new_value: string | null;
  detected_at: string;
  project_name?: string;
}

export interface SyncErrorRecord {
  id: string;
  sync_run_id: string;
  source_project_id: string;
  error_type: string;
  error_message: string;
  http_status: number | null;
  occurred_at: string;
  retry_count: number;
}

export interface NormalizedProjectPayload {
  sourceProjectId: string;
  projectName: string;
  projectNumber: string;
  state: string;
  district: string;
  implementingAgency: string;
  highwayNumber: string;
  landRequired: number;
  landAvailable: number;
  landToBeAcquired: number;
  landAcquiredTillNow: number;
  sanctionNumber?: string;
  sanctionDate?: string;
  sanctionAmount?: number;
  notifications3a: Partial<Project3aNotification>[];
  notifications3A: Partial<Project3ANotification>[];
  notifications3d: Partial<Project3dNotification>[];
  sanctions: Partial<ProjectSanction>[];
  consentPurchases: Partial<ProjectConsentPurchase>[];
  additionalInfo?: Record<string, any>;
  rawValues?: Record<string, string>;
}

export interface SourceTestResult {
  // Exact Section 5 & 18 diagnostic interface:
  sourceUrl: string;
  projectId: string;
  httpStatus: number;
  responseTimeMs: number;
  responseSizeBytes: number;
  fieldsExtractedCount: number;
  validationStatus: 'VALID' | 'INVALID' | 'REJECTED' | 'NOT_APPLICABLE';
  parserStatus: 'PARSED' | 'PARSE_FAILED' | 'NOT_APPLICABLE';
  errorCode: string | null;
  errorMessage: string | null;
  retrievedAt: string;

  // Backward compatibility & detailed diagnostic fields:
  sourceProjectId?: string;
  htmlLength?: number;
  canonicalHash?: string;
  parsingSuccess?: boolean;
  validationSuccess?: boolean;
  status?: string; // e.g. "HTTP 200 — OK (PARSED)", "HTTP 200 — PARSE FAILED", "HTTP 200 — VALIDATION FAILED", "HTTP 404 — NOT FOUND", "NETWORK ERROR"
  reason?: string;
  fetchedAt?: string;
  extractedSample?: {
    projectName?: string;
    projectNumber?: string;
    state?: string;
    district?: string;
    implementingAgency?: string;
    highwayNumber?: string;
    landRequired?: number;
    landAvailable?: number;
    landToBeAcquired?: number;
    landAcquiredTillNow?: number;
    sanctionNumber?: string;
    sanctionDate?: string;
    sanctionAmount?: number;
    notificationsCount?: number;
    [key: string]: any;
  };
  note?: string;
  success: boolean;
}

export interface ProjectProvenance {
  source: string;
  source_url: string;
  source_project_id: string;
  retrieved_at: string;
  source_hash: string;
  parser_version: string;
  sync_run_id: string;
  provenance_status: 'AUTHENTIC_SOURCE' | 'STAGED' | 'VERIFIED' | 'FAILED';
}

export interface DiscoveryLimitationReport {
  code: 'NEW_PROJECT_DISCOVERY_LIMITATION';
  title: string;
  portalUrl: string;
  explanation: string;
  technicalConstraints: string[];
  activeMechanisms: {
    mechanism: string;
    status: 'ACTIVE' | 'RESTRICTED' | 'UNAVAILABLE';
    details: string;
  }[];
  statutoryNotice: string;
}

export interface DataHubStatusOverview {
  source: {
    name: string;
    organization: string;
    url: string;
    status: string;
  };
  totalRegisteredProjects: number;
  lastCheck: string | null;
  nextCheck: string | null;
  lastSuccessfulSync: string | null;
  syncIntervalMinutes: number;
  currentRunStatus: string;
  counts: {
    newProjects: number;
    updatedProjects: number;
    unchangedProjects: number;
    errorProjects: number;
  };
}

// ============================================================================
// PHASE 7B-4: PRODUCTION AUTHORITATIVE STATUTORY EVIDENCE TYPES
// ============================================================================

export type StatutorySourceType =
  | 'LIVE_EXTERNAL'
  | 'STATIC_REFERENCE'
  | 'MANUAL_OFFICIAL_DOCUMENT'
  | 'SYNTHETIC'
  | 'UNAVAILABLE';

export type StatutoryVerificationStatus =
  | 'UNVERIFIED'
  | 'VERIFIED'
  | 'REJECTED'
  | 'NEEDS_HUMAN_REVIEW'
  | 'SOURCE_ACCESS_BLOCKED';

export type IngestionRunStatus =
  | 'RUNNING'
  | 'COMPLETED'
  | 'PARTIAL'
  | 'SOURCE_ACCESS_BLOCKED'
  | 'FAILED';

export type ReviewDecision = 'APPROVED' | 'REJECTED' | 'REQUEST_MORE_EVIDENCE';

export interface AuthoritativeStatutoryNotification {
  id: string;
  source_type: StatutorySourceType;
  source_name: string;
  source_reference: string;
  source_record_id: string;
  project_id: string;
  source_project_id: string;
  notification_number: string;
  statutory_section: '3A' | '3D' | '3G' | 'OTHER';
  notification_type: string;
  publication_date: string; // YYYY-MM-DD
  source_updated_at: string | null;
  retrieval_timestamp: string;
  source_url: string | null;
  document_reference: string | null;
  document_sha256: string | null;
  verification_status: StatutoryVerificationStatus;
  verification_method: string;
  content_hash: string;
  raw_payload_hash: string;
  created_at: string;
  updated_at: string;
  is_authoritative: number; // 1 or 0
  is_synthetic: number; // 1 or 0
  supersedes_record_id: string | null;
  ingestion_run_id: string;
  rejection_reason?: string | null;
}

export interface StatutoryIngestionRun {
  run_id: string;
  source: string;
  started_at: string;
  completed_at: string | null;
  status: IngestionRunStatus;
  records_discovered: number;
  records_downloaded: number;
  records_normalized: number;
  records_verified: number;
  records_rejected: number;
  records_needing_review: number;
  records_unchanged: number;
  records_updated: number;
  source_access_status: string;
  error_summary: string | null;
}

export interface StatutoryReviewItem {
  id: string;
  project_id: string;
  source_name: string;
  issue_type:
    | 'AMBIGUOUS_PROJECT_MATCH'
    | 'DOCUMENT_REQUIRES_VERIFICATION'
    | 'CONFLICTING_SOURCE_RECORDS'
    | 'SOURCE_CORRECTION'
    | 'PRE_3A_STATUS_CONFIRMATION';
  evidence_json: string;
  created_at: string;
  reviewer_id: string | null;
  reviewer_name: string | null;
  decision: ReviewDecision | 'PENDING';
  decision_at: string | null;
  notes: string | null;
}

export interface ProjectEvidenceQualityReport {
  project_id: string;
  evidence_status: 'COMPLETE' | 'PARTIAL' | 'OUT_OF_BOUNDS' | 'INSUFFICIENT_EVIDENCE';
  validation_status: 'PASS' | 'OUT_OF_BOUNDS' | 'DRIFT_DETECTED';
  is_shadow_scoreable: boolean;
  section_3a: {
    status: 'VERIFIED' | 'MISSING' | 'NEEDS_REVIEW' | 'PRE_3A_STAGE';
    first_verified_date: string | null;
    notification_number: string | null;
    source_reference: string | null;
    source_url: string | null;
  };
  notifications: {
    verified_count: number;
    earliest_date: string | null;
    latest_date: string | null;
    cadence_days: number | null;
  };
  reasons: string[];
  last_verified_at: string | null;
  source_type: StatutorySourceType;
  is_synthetic: boolean;
}

