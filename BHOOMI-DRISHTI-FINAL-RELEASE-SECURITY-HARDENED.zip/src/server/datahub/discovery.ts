/**
 * BhoomiRashi Statutory Project Discovery Engine
 * Phase 0.7: DataHub Reliability + New Project Discovery
 * Ministry of Road Transport & Highways (MoRTH)
 * Smart India Hackathon 2026 - SIH26017
 *
 * Implements Controlled Statutory Project Discovery and documents
 * NEW_PROJECT_DISCOVERY_LIMITATION for unconstrained portal discovery.
 */

import { DatabaseSync } from 'node:sqlite';
import { getDataHubDb } from './database.ts';
import { BhoomiRashiCollector } from './bhoomiRashiCollector.ts';
import { ChangeDetectionEngine } from './changeDetection.ts';
import { DataHubBridge } from './bridge.ts';
import { AuditService } from '../auditService.ts';
import { DiscoveryLimitationReport, NormalizedProjectPayload } from './types.ts';

export interface DiscoveryCandidateResult {
  candidateId: string;
  status: 'DISCOVERED' | 'DUPLICATE' | 'PARSE_FAILED' | 'SOURCE_INVALID' | 'UNAVAILABLE';
  httpStatus?: number;
  reason?: string;
  projectName?: string;
  storedProjectId?: string;
}

export interface DiscoveryRunReport {
  runId: string;
  executedAt: string;
  discoveryMethod: 'CONTROLLED_RANGE_DISCOVERY' | 'GAZETTE_CANDIDATE_QUEUE';
  totalCandidatesEvaluated: number;
  newProjectsDiscovered: number;
  duplicatesSkipped: number;
  rejectedOrFailed: number;
  results: DiscoveryCandidateResult[];
  limitationNotice: string;
}

export class BhoomiRashiDiscoveryService {
  private static readonly MAX_RANGE_WINDOW = 2; // Strict bound: baseId ± 2 (max 5 IDs)
  private static readonly POLITE_DELAY_MS = 600; // Rate limit protection for gov portal

  /**
   * Reports the statutory discovery architecture and limitations of BhoomiRashi
   */
  public static getDiscoveryLimitationReport(): DiscoveryLimitationReport {
    return {
      code: 'NEW_PROJECT_DISCOVERY_LIMITATION',
      title: 'BhoomiRashi Public Portal Discovery Architecture Limitation',
      portalUrl: 'https://bhoomirashi.gov.in',
      explanation:
        'The official MoRTH BhoomiRashi public portal (bhoomirashi.gov.in) does not expose an unauthenticated public enumeration API, RSS feed, sitemap, or unpaginated global project index. Project search forms require ASP.NET session state and CAPTCHA challenge. Blind sequential crawling is strictly restricted by NIC firewall security policies. Consequently, BhoomiDrishti operates honest Controlled Statutory Discovery rather than brute-force scraping.',
      technicalConstraints: [
        'No public OpenAPI or unauthenticated REST catalog endpoint for global project enumeration',
        'Search forms require ASP.NET ViewState session tokens and interactive CAPTCHA verification',
        'National Informatics Centre (NIC) Web Application Firewall (WAF) blocks high-frequency crawler patterns',
        'Public project detail pages are accessible strictly via validated statutory project_id parameters'
      ],
      activeMechanisms: [
        {
          mechanism: 'Controlled Statutory Range Discovery',
          status: 'ACTIVE',
          details: 'Controlled probe of bounded candidate ID intervals around verified national highway projects (bounded to ±2 IDs, polite 600ms spacing, circuit breaker).'
        },
        {
          mechanism: 'Statutory Gazette & CALA Candidate Queue',
          status: 'ACTIVE',
          details: 'Controlled ingestion of candidate project IDs from official Gazette notifications or CALA records through the Discovery Pipeline.'
        },
        {
          mechanism: 'Automated Global Web Crawler',
          status: 'RESTRICTED',
          details: 'Global unconstrained enumeration is disabled by policy to prevent CAPTCHA triggering, firewall blocking, and service disruption.'
        }
      ],
      statutoryNotice:
        'BhoomiDrishti adheres to government portal fair-use and data governance rules. Only controlled statutory discovery and authorized candidate queues are executed.'
    };
  }

  /**
   * Executes the strict Discovery Pipeline for a list of candidate project IDs:
   * Candidate -> Deduplicate -> Fetch -> Parse -> Validate -> Store -> Snapshot -> Audit
   */
  public static async ingestCandidateProjects(
    candidateIds: string[],
    options: {
      db?: DatabaseSync;
      discoveryMethod?: 'CONTROLLED_DISCOVERY' | 'GAZETTE_INGESTION';
      requestedBy?: string;
      userRole?: string;
    } = {}
  ): Promise<DiscoveryRunReport> {
    const db = options.db || getDataHubDb();
    const runId = `DISC_${Date.now()}`;
    const executedAt = new Date().toISOString();
    const method = options.discoveryMethod || 'CONTROLLED_DISCOVERY';
    const requestedBy = options.requestedBy || 'Nodal Officer';
    const userRole = options.userRole || 'NODAL_OFFICER';

    const cleanIds = Array.from(new Set(candidateIds.map(id => String(id).trim()).filter(Boolean)));
    const results: DiscoveryCandidateResult[] = [];
    let discoveredCount = 0;
    let duplicateCount = 0;
    let rejectedCount = 0;

    for (let i = 0; i < cleanIds.length; i++) {
      const candidateId = cleanIds[i];

      // Rate limit protection
      if (i > 0) {
        await new Promise(r => setTimeout(r, this.POLITE_DELAY_MS));
      }

      // Step 1: Deduplication check
      const existing = db.prepare('SELECT source_project_id, project_name FROM dh_source_projects WHERE source_project_id = ?').get(candidateId) as any;
      if (existing) {
        duplicateCount++;
        results.push({
          candidateId,
          status: 'DUPLICATE',
          reason: `Project ${candidateId} already registered in database ("${existing.project_name}")`
        });
        continue;
      }

      // Step 2: Fetch & Parse Candidate Page
      try {
        const fetchResult = await BhoomiRashiCollector.fetchAndParseProject(candidateId);

        if (!fetchResult.success || !fetchResult.payload) {
          rejectedCount++;
          const status = fetchResult.httpStatus === 200 ? 'PARSE_FAILED' : 'SOURCE_INVALID';
          results.push({
            candidateId,
            status,
            httpStatus: fetchResult.httpStatus,
            reason: fetchResult.errorMessage || 'Candidate page rejected by parser or portal error'
          });
          continue;
        }

        const payload: NormalizedProjectPayload = fetchResult.payload;

        // Step 3: Strict Validation Check (re-verify mandatory fields)
        if (!payload.projectName || payload.projectName.length < 10 || payload.landRequired <= 0) {
          rejectedCount++;
          results.push({
            candidateId,
            status: 'SOURCE_INVALID',
            httpStatus: fetchResult.httpStatus,
            reason: 'Missing mandatory statutory attributes (name or land required)'
          });
          continue;
        }

        // Step 4: Atomic Store and Snapshot
        const evalResult = ChangeDetectionEngine.evaluateChange(db, payload, runId);
        ChangeDetectionEngine.applyChange(db, evalResult, payload, runId, method as any);

        // Bridge newly discovered project to main application
        DataHubBridge.syncToMainApp(candidateId);

        // Step 5: Audit Event Creation
        AuditService.record(db, {
          userId: requestedBy,
          userName: requestedBy,
          userRole: userRole as any,
          action: 'PROJECT_DISCOVERED',
          resource: 'bhoomirashi_discovery',
          resourceId: candidateId,
          result: 'SUCCESS',
          details: {
            runId,
            discoveryMethod: method,
            sourceProjectId: candidateId,
            projectName: payload.projectName,
            projectNumber: payload.projectNumber,
            state: payload.state,
            landRequiredHa: payload.landRequired,
            sourceHash: evalResult.newHash
          }
        });

        discoveredCount++;
        results.push({
          candidateId,
          status: 'DISCOVERED',
          httpStatus: 200,
          projectName: payload.projectName,
          storedProjectId: `BhoomiRashi_${candidateId}`
        });

      } catch (err: any) {
        rejectedCount++;
        results.push({
          candidateId,
          status: 'UNAVAILABLE',
          reason: `Exception during candidate ingestion: ${err.message}`
        });
      }
    }

    return {
      runId,
      executedAt,
      discoveryMethod: method === 'GAZETTE_INGESTION' ? 'GAZETTE_CANDIDATE_QUEUE' : 'CONTROLLED_RANGE_DISCOVERY',
      totalCandidatesEvaluated: cleanIds.length,
      newProjectsDiscovered: discoveredCount,
      duplicatesSkipped: duplicateCount,
      rejectedOrFailed: rejectedCount,
      results,
      limitationNotice:
        'Controlled Discovery operates strictly on bounded candidate pools. Global unconstrained scanning is restricted per NEW_PROJECT_DISCOVERY_LIMITATION.'
    };
  }

  /**
   * Controlled Statutory Range Discovery:
   * Probes bounded adjacent IDs around a known authentic project ID.
   */
  public static async discoverFromIdRange(
    baseProjectId: string,
    windowSize: number = 1,
    options: {
      db?: DatabaseSync;
      requestedBy?: string;
      userRole?: string;
    } = {}
  ): Promise<DiscoveryRunReport> {
    const cleanBase = baseProjectId.trim();
    const baseNum = parseInt(cleanBase, 10);

    if (isNaN(baseNum) || baseNum <= 0) {
      throw new Error(`Invalid base project ID for range discovery: "${baseProjectId}". Must be a positive integer.`);
    }

    const clampedWindow = Math.max(1, Math.min(this.MAX_RANGE_WINDOW, windowSize));
    const candidates: string[] = [];

    for (let offset = -clampedWindow; offset <= clampedWindow; offset++) {
      if (offset === 0) continue; // Skip the base project itself
      const cand = baseNum + offset;
      if (cand > 0) {
        candidates.push(String(cand));
      }
    }

    return this.ingestCandidateProjects(candidates, {
      ...options,
      discoveryMethod: 'CONTROLLED_DISCOVERY'
    });
  }
}
