import { Request, Response, NextFunction } from 'express';

interface RateLimitRecord {
  count: number;
  resetTime: number;
}

export interface RateLimiterOptions {
  windowMs: number;
  maxRequests: number;
  message?: string;
  keyGenerator?: (req: Request) => string;
}

/**
 * Production-grade in-memory Rate Limiter
 * Mitigates DoS and brute-force attacks against ML inference, scenario simulations, and authentication.
 */
export function createRateLimiter(options: RateLimiterOptions) {
  const {
    windowMs,
    maxRequests,
    message = 'Too many requests. Please wait before retrying.',
    keyGenerator = (req: Request) => {
      try {
        const xForwarded = req.headers ? (req.headers['x-forwarded-for'] as string) : undefined;
        const clientIp = xForwarded ? xForwarded.split(',')[0].trim() : undefined;
        return clientIp || req.ip || (req.socket && req.socket.remoteAddress) || '127.0.0.1';
      } catch {
        return '127.0.0.1';
      }
    }
  } = options;

  const hits = new Map<string, RateLimitRecord>();

  // Prune expired records every 60 seconds
  const cleanupInterval = setInterval(() => {
    const now = Date.now();
    for (const [key, record] of hits.entries()) {
      if (now > record.resetTime) {
        hits.delete(key);
      }
    }
  }, 60000);
  if (cleanupInterval.unref) cleanupInterval.unref();

  const middleware = (req: Request, res: Response, next: NextFunction): void => {
    // In automated testing without explicit rate-limit testing header, allow pass-through
    if (process.env.NODE_ENV === 'test' && !req.headers['x-test-rate-limit']) {
      return next();
    }

    const key = keyGenerator(req);
    const now = Date.now();
    let record = hits.get(key);

    if (!record || now > record.resetTime) {
      record = {
        count: 1,
        resetTime: now + windowMs
      };
      hits.set(key, record);
    } else {
      record.count += 1;
    }

    const remaining = Math.max(0, maxRequests - record.count);
    const resetSeconds = Math.ceil((record.resetTime - now) / 1000);

    res.setHeader('RateLimit-Limit', maxRequests.toString());
    res.setHeader('RateLimit-Remaining', remaining.toString());
    res.setHeader('RateLimit-Reset', resetSeconds.toString());

    if (record.count > maxRequests) {
      res.setHeader('Retry-After', resetSeconds.toString());
      res.status(429).json({
        success: false,
        error: 'RATE_LIMIT_EXCEEDED',
        message
      });
      return;
    }

    next();
  };

  (middleware as any).reset = () => hits.clear();
  return middleware;
}
