/**
 * BHOOMI-DRISHTI AUTHENTICATION & PRODUCTION ROLE-BASED ACCESS CONTROL (RBAC)
 * Phase 0.6: Firebase Authentication & Server-Side Role Enforcement
 * 
 * Strict Statutory Security Principles:
 * 1. Genuine Firebase Authentication for user identity.
 * 2. ID tokens verified server-side.
 * 3. Application roles (VIEWER, NODAL_OFFICER) are stored strictly server-side in SQLite (user_accounts).
 * 4. Client claims, headers (x-user-role), and payloads are NEVER trusted for authorization.
 * 5. Explicit DEMO_MODE isolation: Demo tokens are blocked in production environments.
 * 6. Audit logging with zero credential or token leakage.
 */

import { Request, Response, NextFunction } from 'express';
import { randomBytes, createHmac, scryptSync, timingSafeEqual } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import * as jose from 'jose';
import { getDatabase } from './database.ts';
import { AuditService } from './auditService.ts';

export type UserRole = 'VIEWER' | 'NODAL_OFFICER' | 'AUDITOR';
export type UserStatus = 'ACTIVE' | 'SUSPENDED' | 'DISABLED';

export interface AuthUser {
  id: string; // uid
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  designation: string;
  department: string;
  lastLogin?: string;
  authProvider?: string;
}

export interface UserAccountRow {
  uid: string;
  email: string;
  name: string;
  role: UserRole;
  status: UserStatus;
  designation: string;
  department: string;
  created_at: string;
  updated_at: string;
}

export const PRECONFIGURED_USERS: Record<string, AuthUser> = {
  'nodal.officer@morth.gov.in': {
    id: 'USR_NODAL_RAJESH',
    name: 'Er. Rajesh Sharma',
    email: 'nodal.officer@morth.gov.in',
    role: 'NODAL_OFFICER',
    status: 'ACTIVE',
    designation: 'Competent Authority & Land Acquisition Nodal Officer (CALA)',
    department: 'Ministry of Road Transport & Highways (MoRTH) / NHAI'
  },
  'viewer.auditor@gov.in': {
    id: 'USR_VIEWER_POOJA',
    name: 'Pooja Verma',
    email: 'viewer.auditor@gov.in',
    role: 'VIEWER',
    status: 'ACTIVE',
    designation: 'Senior Project Monitoring Auditor',
    department: 'Infrastructure Oversight & Project Evaluation Division'
  }
};

// Server-side ephemeral signing secret for demo/staging tokens (never hardcoded, changes per boot)
const EPHEMERAL_DEMO_SECRET = randomBytes(64).toString('hex');

// Google Public JWKS endpoint for Firebase ID tokens
const GOOGLE_JWKS_URL = 'https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com';
let googleJWKS: any = null;

function getGoogleJWKS() {
  if (!googleJWKS) {
    googleJWKS = jose.createRemoteJWKSet(new URL(GOOGLE_JWKS_URL));
  }
  return googleJWKS;
}

/**
 * Injects custom JWKS or mock key set for automated verification of Firebase authentication.
 */
export function setCustomJWKSForTesting(customJWKS: any | null): void {
  googleJWKS = customJWKS;
}

/**
 * Checks if Demo Mode is enabled.
 * Defaults to false if not explicitly set to 'true'.
 */
export function isDemoModeEnabled(): boolean {
  if (process.env.NODE_ENV === 'production') {
    return false;
  }
  return process.env.DEMO_MODE === 'true';
}

/**
 * Validates that production authentication configuration meets strict security invariants.
 */
export function validateAuthEnvironment(): { ok: boolean; error?: string } {
  const isProd = process.env.NODE_ENV === 'production';
  
  if (isProd) {
    if (process.env.DEMO_MODE === 'true') {
      return {
        ok: false,
        error: 'CRITICAL_SECURITY_CONFIGURATION_ERROR: DEMO_MODE cannot be set to true in production mode.'
      };
    }

    // Check if dangerous default password was supplied in production
    const dangerousPasswords = ['Bhoomi@2026!', 'Bhoomi@2026', 'admin123', 'password', '123456', 'BhoomiDev#Test2026'];
    if (
      (process.env.AUTH_DEFAULT_PASSWORD && dangerousPasswords.includes(process.env.AUTH_DEFAULT_PASSWORD)) ||
      (process.env.AUTH_DEV_PASSWORD && dangerousPasswords.includes(process.env.AUTH_DEV_PASSWORD)) ||
      (process.env.AUTH_ADMIN_PASSWORD && dangerousPasswords.includes(process.env.AUTH_ADMIN_PASSWORD))
    ) {
      return {
        ok: false,
        error: 'CRITICAL_SECURITY_CONFIGURATION_ERROR: Known default password detected in production environment configuration. Remove default password setting.'
      };
    }

    // AUTH_DEFAULT_PASSWORD is strictly prohibited in production
    if (process.env.AUTH_DEFAULT_PASSWORD) {
      return {
        ok: false,
        error: 'CRITICAL_SECURITY_CONFIGURATION_ERROR: AUTH_DEFAULT_PASSWORD is strictly restricted to development/test environments and cannot be set in production.'
      };
    }

    // Verify Firebase Project ID is configured for production
    if (!process.env.FIREBASE_PROJECT_ID && !process.env.VITE_FIREBASE_PROJECT_ID) {
      return {
        ok: false,
        error: 'MISSING_PRODUCTION_AUTH_CONFIGURATION: FIREBASE_PROJECT_ID is required for production authentication.'
      };
    }
  }

  return { ok: true };
}

/**
 * Provisions authoritative server-side user_accounts and auth_sessions tables.
 */
export function initAuthTables(db: DatabaseSync): void {
  try {
    const info = db.prepare('PRAGMA table_info(auth_sessions)').all() as any[];
    const hasStrictNotNull = info.some(c => (c.name === 'designation' || c.name === 'department') && c.notnull === 1);
    if (hasStrictNotNull) {
      db.exec('DROP TABLE IF EXISTS auth_sessions');
    }
  } catch {
    // table not created yet
  }

  // Ensure user_accounts role constraint allows AUDITOR
  try {
    const tableSql = db.prepare("SELECT sql FROM sqlite_master WHERE name = 'user_accounts'").get() as any;
    if (tableSql && tableSql.sql && !tableSql.sql.includes("'AUDITOR'")) {
      db.exec(`
        PRAGMA foreign_keys = OFF;
        CREATE TABLE user_accounts_migrated (
          uid TEXT PRIMARY KEY,
          email TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          role TEXT NOT NULL CHECK(role IN ('VIEWER', 'NODAL_OFFICER', 'AUDITOR')),
          status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE', 'SUSPENDED', 'DISABLED')),
          designation TEXT,
          department TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          password_hash TEXT
        );
        INSERT INTO user_accounts_migrated SELECT uid, email, name, role, status, designation, department, created_at, updated_at, password_hash FROM user_accounts;
        DROP TABLE user_accounts;
        ALTER TABLE user_accounts_migrated RENAME TO user_accounts;
        CREATE INDEX IF NOT EXISTS idx_user_accounts_email ON user_accounts(email);
        CREATE INDEX IF NOT EXISTS idx_user_accounts_role ON user_accounts(role);
        PRAGMA foreign_keys = ON;
      `);
    }
  } catch {
    // ignore if table does not exist yet
  }

  db.exec(`
    CREATE TABLE IF NOT EXISTS user_accounts (
      uid TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('VIEWER', 'NODAL_OFFICER', 'AUDITOR')),
      status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE', 'SUSPENDED', 'DISABLED')),
      designation TEXT,
      department TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_user_accounts_email ON user_accounts(email);
    CREATE INDEX IF NOT EXISTS idx_user_accounts_role ON user_accounts(role);

    CREATE TABLE IF NOT EXISTS auth_sessions (
      token TEXT PRIMARY KEY,
      user_id TEXT,
      uid TEXT,
      user_role TEXT,
      role TEXT,
      user_name TEXT,
      name TEXT,
      user_email TEXT,
      email TEXT,
      designation TEXT DEFAULT '',
      department TEXT DEFAULT '',
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1
    );

    CREATE INDEX IF NOT EXISTS idx_auth_sessions_token ON auth_sessions(token);
  `);

  // Ensure both schema variations have all required columns
  const sessionCols = [
    'ALTER TABLE auth_sessions ADD COLUMN user_id TEXT',
    'ALTER TABLE auth_sessions ADD COLUMN uid TEXT',
    'ALTER TABLE auth_sessions ADD COLUMN user_role TEXT',
    'ALTER TABLE auth_sessions ADD COLUMN role TEXT',
    'ALTER TABLE auth_sessions ADD COLUMN user_name TEXT',
    'ALTER TABLE auth_sessions ADD COLUMN name TEXT',
    'ALTER TABLE auth_sessions ADD COLUMN user_email TEXT',
    'ALTER TABLE auth_sessions ADD COLUMN email TEXT',
    'ALTER TABLE auth_sessions ADD COLUMN designation TEXT',
    'ALTER TABLE auth_sessions ADD COLUMN department TEXT'
  ];
  for (const col of sessionCols) {
    try { db.exec(col); } catch { /* ignore if already exists */ }
  }

  try {
    db.exec('ALTER TABLE user_accounts ADD COLUMN password_hash TEXT');
  } catch {
    /* ignore if already exists */
  }

  // Seed authoritative government personnel if not present
  seedDefaultAccounts(db);
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, combinedHash: string): boolean {
  if (!combinedHash || !combinedHash.includes(':')) return false;
  const [salt, storedHash] = combinedHash.split(':');
  try {
    const hash = scryptSync(password, salt, 64).toString('hex');
    return timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(storedHash, 'hex'));
  } catch {
    return false;
  }
}

function seedDefaultAccounts(db: DatabaseSync): void {
  const seedAccounts: UserAccountRow[] = [
    {
      uid: 'USR_NODAL_RAJESH',
      email: 'nodal.officer@morth.gov.in',
      name: 'Er. Rajesh Sharma',
      role: 'NODAL_OFFICER',
      status: 'ACTIVE',
      designation: 'Competent Authority & Land Acquisition Nodal Officer (CALA)',
      department: 'Ministry of Road Transport & Highways (MoRTH) / NHAI',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z'
    },
    {
      uid: 'USR_VIEWER_POOJA',
      email: 'viewer.auditor@gov.in',
      name: 'Pooja Verma',
      role: 'VIEWER',
      status: 'ACTIVE',
      designation: 'Senior Project Monitoring Auditor',
      department: 'Infrastructure Oversight & Project Evaluation Division',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z'
    },
    // Security test accounts
    {
      uid: 'USR_SUSPENDED_01',
      email: 'suspended.officer@gov.in',
      name: 'Suspended Nodal Officer',
      role: 'NODAL_OFFICER',
      status: 'SUSPENDED',
      designation: 'Suspended Administrative Officer',
      department: 'Internal Vigilance Division',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z'
    },
    {
      uid: 'USR_DISABLED_01',
      email: 'disabled.viewer@gov.in',
      name: 'Disabled Former Auditor',
      role: 'VIEWER',
      status: 'DISABLED',
      designation: 'Former Evaluation Officer',
      department: 'Infrastructure Oversight & Project Evaluation Division',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z'
    }
  ];

  const stmt = db.prepare(`
    INSERT OR IGNORE INTO user_accounts (
      uid, email, name, role, status, designation, department, created_at, updated_at, password_hash
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
  `);

  for (const acc of seedAccounts) {
    stmt.run(
      acc.uid,
      acc.email,
      acc.name,
      acc.role,
      acc.status,
      acc.designation,
      acc.department,
      acc.created_at,
      acc.updated_at
    );
  }

  // STRICT PRODUCTION SECURITY HARDENING:
  // Production authentication relies strictly on Firebase Authentication.
  // Never store default password hashes in SQLite user_accounts.
  db.prepare(`UPDATE user_accounts SET password_hash = NULL WHERE password_hash IS NOT NULL`).run();
}

/**
 * Authenticates user credentials against authoritative SQLite user_accounts.
 * Verifies active status and credentials.
 */
export async function authenticateWithPassword(
  db: DatabaseSync,
  email: string,
  pass: string
): Promise<{ valid: boolean; user?: AuthUser; token?: string; error?: string; status: number; reason?: string }> {
  initAuthTables(db);
  if (!email || !pass || typeof email !== 'string' || typeof pass !== 'string' || !email.trim() || !pass.trim()) {
    return { valid: false, error: 'INVALID_CREDENTIALS', status: 400, reason: 'Email and password are required.' };
  }

  const cleanEmail = email.toLowerCase().trim();
  const cleanPass = pass.trim();

  // Known default passwords are strictly rejected in all contexts
  const FORBIDDEN_DEFAULT_PASSWORDS = [
    'Bhoomi@2026!',
    'Bhoomi@2026',
    'password',
    'admin123',
    '12345678',
    'BhoomiDev#Test2026'
  ];
  if (!isDemoModeEnabled() && FORBIDDEN_DEFAULT_PASSWORDS.includes(cleanPass)) {
    return { valid: false, error: 'INVALID_CREDENTIALS', status: 401, reason: 'Invalid email or password.' };
  }

  // In production, if password login is disabled because no AUTH_ADMIN_PASSWORD was configured:
  if (!isDemoModeEnabled() && !process.env.AUTH_ADMIN_PASSWORD) {
    return {
      valid: false,
      error: 'PASSWORD_AUTH_DISABLED',
      status: 401,
      reason: 'Direct password authentication is disabled in production without explicit administrator credential provisioning. Official Firebase Authentication is required.'
    };
  }

  const row = db.prepare(`SELECT * FROM user_accounts WHERE lower(email) = ?`).get(cleanEmail) as any;
  if (!row) {
    return { valid: false, error: 'INVALID_CREDENTIALS', status: 401, reason: 'Invalid email or password.' };
  }
  if (row.status === 'SUSPENDED') {
    return { valid: false, error: 'ACCOUNT_SUSPENDED', status: 403, reason: 'Statutory administrative credentials have been suspended.' };
  }
  if (row.status === 'DISABLED') {
    return { valid: false, error: 'ACCOUNT_DISABLED', status: 401, reason: 'User account has been disabled.' };
  }

  // Check account password validity
  let isPasswordValid = false;
  if (isDemoModeEnabled()) {
    // In explicit demo/development mode, verify against test credential in memory
    const testDevPassword = process.env.AUTH_DEV_PASSWORD || 'BhoomiDev#Test2026';
    if (cleanPass === testDevPassword && (row.uid === 'USR_NODAL_RAJESH' || row.uid === 'USR_VIEWER_POOJA')) {
      isPasswordValid = true;
    }
  } else if (process.env.AUTH_ADMIN_PASSWORD && cleanPass === process.env.AUTH_ADMIN_PASSWORD && row.uid === 'USR_NODAL_RAJESH') {
    isPasswordValid = true;
  } else if (row.password_hash && verifyPassword(cleanPass, row.password_hash)) {
    isPasswordValid = true;
  }

  if (!isPasswordValid) {
    return { valid: false, error: 'INVALID_CREDENTIALS', status: 401, reason: 'Invalid email or password.' };
  }

  const user: AuthUser = {
    id: row.uid,
    name: row.name,
    email: row.email,
    role: row.role as UserRole,
    status: row.status as UserStatus,
    designation: row.designation || '',
    department: row.department || '',
    authProvider: isDemoModeEnabled() ? 'demo_credentials' : 'institutional_credentials'
  };
  const session = createSession(db, user);
  return { valid: true, user, token: session.token, status: 200 };
}

/**
 * Authoritative Server-Side User Account Queries
 */
export function getUserAccountByEmail(db: DatabaseSync, email: string): AuthUser | null {
  initAuthTables(db);
  const row = db.prepare(`SELECT * FROM user_accounts WHERE email = ?`).get(email.toLowerCase().trim()) as any;
  if (!row) return null;
  return {
    id: row.uid,
    name: row.name,
    email: row.email,
    role: row.role as UserRole,
    status: row.status as UserStatus,
    designation: row.designation,
    department: row.department
  };
}

export function getUserAccountByUid(db: DatabaseSync, uid: string): AuthUser | null {
  initAuthTables(db);
  const row = db.prepare(`SELECT * FROM user_accounts WHERE uid = ?`).get(uid) as any;
  if (!row) return null;
  return {
    id: row.uid,
    name: row.name,
    email: row.email,
    role: row.role as UserRole,
    status: row.status as UserStatus,
    designation: row.designation,
    department: row.department
  };
}

export function updateUserStatus(db: DatabaseSync, uid: string, status: UserStatus): boolean {
  initAuthTables(db);
  const now = new Date().toISOString();
  const res = db.prepare(`UPDATE user_accounts SET status = ?, updated_at = ? WHERE uid = ?`).run(status, now, uid);
  return (res as any)?.changes > 0;
}

/**
 * Creates a cryptographically signed Demo/Staging Token.
 * Strictly isolated behind Demo Mode. Cannot be used in production.
 */
export async function createDemoToken(
  user: { uid: string; email: string },
  expiresInSeconds: number = 86400
): Promise<string> {
  const secretKey = new TextEncoder().encode(EPHEMERAL_DEMO_SECRET);
  const exp = Math.floor(Date.now() / 1000) + expiresInSeconds;
  
  const token = await new jose.SignJWT({
    uid: user.uid,
    email: user.email,
    iss: 'bhoomi-drishti-demo-auth',
    aud: 'bhoomi-drishti-app'
  })
    .setProtectedHeader({ alg: 'HS256', typ: 'JWT' })
    .setIssuedAt()
    .setExpirationTime(exp)
    .sign(secretKey);

  return token;
}

export interface TokenVerificationResult {
  valid: boolean;
  user?: AuthUser;
  error?: string;
  status: 200 | 401 | 403;
  reason?: string;
}

/**
 * Verifies any bearer token (Firebase ID Token or Demo Token).
 * Enforces server-side role resolution from SQLite user_accounts.
 */
export async function verifyToken(db: DatabaseSync, token: string): Promise<TokenVerificationResult> {
  initAuthTables(db);
  if (!token || typeof token !== 'string' || token.trim().length === 0) {
    return { valid: false, error: 'MISSING_TOKEN', status: 401, reason: 'Authorization token is required.' };
  }

  const cleanToken = token.trim();

  // Check if session exists in auth_sessions table
  const sessionRow = db.prepare(`SELECT * FROM auth_sessions WHERE token = ?`).get(cleanToken) as any;
  if (sessionRow) {
    if (sessionRow.is_active === 0) {
      return { valid: false, error: 'TOKEN_REVOKED', status: 401, reason: 'Token has been revoked or session terminated.' };
    }
    if (new Date(sessionRow.expires_at) < new Date()) {
      return { valid: false, error: 'TOKEN_EXPIRED', status: 401, reason: 'Authentication token has expired.' };
    }
    const sessionUser = validateSession(db, cleanToken);
    if (sessionUser) {
      if (sessionUser.status === 'SUSPENDED') {
        return { valid: false, error: 'ACCOUNT_SUSPENDED', status: 403, reason: 'Statutory administrative credentials have been suspended.' };
      }
      if (sessionUser.status === 'DISABLED') {
        return { valid: false, error: 'ACCOUNT_DISABLED', status: 401, reason: 'User account has been disabled.' };
      }
      return { valid: true, user: sessionUser, status: 200 };
    }
  }

  try {
    // Decode unprotected header to inspect token type
    let header: any;
    try {
      header = jose.decodeProtectedHeader(cleanToken);
    } catch {
      return { valid: false, error: 'INVALID_TOKEN_FORMAT', status: 401, reason: 'Malformed token structure.' };
    }

    let claims: any = null;

    // 1. Check if token is a Demo Mode token
    const unverifiedClaims = jose.decodeJwt(cleanToken);
    if (unverifiedClaims.iss === 'bhoomi-drishti-demo-auth') {
      if (!isDemoModeEnabled()) {
        return {
          valid: false,
          error: 'DEMO_TOKENS_FORBIDDEN_IN_PRODUCTION',
          status: 401,
          reason: 'Demo mode tokens are strictly forbidden in production mode. Official Firebase Authentication is required.'
        };
      }

      // Verify demo token signature with server ephemeral secret
      const secretKey = new TextEncoder().encode(EPHEMERAL_DEMO_SECRET);
      try {
        const verified = await jose.jwtVerify(cleanToken, secretKey, {
          issuer: 'bhoomi-drishti-demo-auth',
          audience: 'bhoomi-drishti-app'
        });
        claims = verified.payload;
      } catch (err: any) {
        if (err?.code === 'ERR_JWT_EXPIRED') {
          return { valid: false, error: 'TOKEN_EXPIRED', status: 401, reason: 'Authentication token has expired.' };
        }
        return { valid: false, error: 'INVALID_SIGNATURE', status: 401, reason: 'Invalid demo token signature.' };
      }
    } else {
      // 2. Genuine Firebase Token Verification
      const projectId = process.env.FIREBASE_PROJECT_ID || 'bhoomi-drishti';
      const expectedIssuer = `https://securetoken.google.com/${projectId}`;

      try {
        const JWKS = getGoogleJWKS();
        const verified = await jose.jwtVerify(cleanToken, JWKS, {
          issuer: expectedIssuer,
          audience: projectId
        });
        claims = verified.payload;
      } catch (err: any) {
        if (err?.code === 'ERR_JWT_EXPIRED') {
          return { valid: false, error: 'TOKEN_EXPIRED', status: 401, reason: 'Firebase ID token has expired.' };
        }
        // If not genuine Google cert, reject
        return {
          valid: false,
          error: 'INVALID_FIREBASE_TOKEN',
          status: 401,
          reason: err?.message || 'Firebase ID token verification failed.'
        };
      }
    }

    if (!claims) {
      return { valid: false, error: 'INVALID_TOKEN', status: 401, reason: 'Token verification failed.' };
    }

    const email = (claims.email as string) || '';
    const uid = (claims.uid as string) || (claims.sub as string) || '';

    // STRICT SERVER-SIDE ROLE ENFORCEMENT:
    // Never trust claims.role, x-user-role, or any client-supplied property.
    // Query authoritative SQLite user_accounts directly.
    let user = getUserAccountByEmail(db, email) || getUserAccountByUid(db, uid);

    if (!user) {
      // If user does not exist yet, provision as default least-privileged VIEWER
      const now = new Date().toISOString();
      const newUid = uid || `USR_${Date.now()}`;
      const name = (claims.name as string) || email.split('@')[0] || 'Government User';
      
      db.prepare(`
        INSERT INTO user_accounts (
          uid, email, name, role, status, designation, department, created_at, updated_at
        ) VALUES (?, ?, ?, 'VIEWER', 'ACTIVE', 'Auditor / Viewer', 'Public Infrastructure Review', ?, ?)
      `).run(newUid, email.toLowerCase(), name, now, now);

      user = getUserAccountByUid(db, newUid)!;
    }

    // Check account status
    if (user.status === 'SUSPENDED') {
      return {
        valid: false,
        error: 'ACCOUNT_SUSPENDED',
        status: 403,
        reason: 'Statutory administrative credentials have been suspended by internal vigilance.'
      };
    }

    if (user.status === 'DISABLED') {
      return {
        valid: false,
        error: 'ACCOUNT_DISABLED',
        status: 401,
        reason: 'User account has been disabled.'
      };
    }

    return {
      valid: true,
      user,
      status: 200
    };
  } catch (err: any) {
    return {
      valid: false,
      error: 'TOKEN_VERIFICATION_ERROR',
      status: 401,
      reason: err?.message || 'Unexpected error during token verification.'
    };
  }
}

/**
 * Creates an active session record in SQLite.
 */
export function recordSession(db: DatabaseSync, token: string, user: AuthUser, expiresAt: string): void {
  initAuthTables(db);
  const createdAt = new Date().toISOString();
  const uid = user.id || (user as any).uid || 'USR_UNKNOWN';
  const role = user.role || 'VIEWER';
  const name = user.name || 'Government User';
  const email = user.email || '';
  const designation = user.designation || '';
  const department = user.department || '';

  try {
    db.prepare(`
      INSERT OR REPLACE INTO auth_sessions (
        token, user_id, uid, user_role, role, user_name, name, user_email, email, designation, department, created_at, expires_at, is_active
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    `).run(token, uid, uid, role, role, name, name, email, email, designation, department, createdAt, expiresAt);
  } catch {
    try {
      db.prepare(`
        INSERT OR REPLACE INTO auth_sessions (
          token, user_id, uid, user_role, user_name, user_email, email, created_at, expires_at, is_active
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
      `).run(token, uid, uid, role, name, email, email, createdAt, expiresAt);
    } catch {
      try {
        db.prepare(`
          INSERT OR REPLACE INTO auth_sessions (
            token, uid, email, created_at, expires_at, is_active
          ) VALUES (?, ?, ?, ?, ?, 1)
        `).run(token, uid, email, createdAt, expiresAt);
      } catch (err) {
        console.warn('[auth] recordSession error:', err);
      }
    }
  }
}

/**
 * Creates a session for backward compatibility with Phase 0.5 test harness.
 */
export function createSession(db: DatabaseSync, user: AuthUser): { token: string; expiresAt: string } {
  initAuthTables(db);
  const token = `bdt_${randomBytes(24).toString('hex')}`;
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
  recordSession(db, token, user, expiresAt);
  return { token, expiresAt };
}

/**
 * Validates a session for backward compatibility with Phase 0.5 test harness.
 */
export function validateSession(db: DatabaseSync, token: string): AuthUser | null {
  initAuthTables(db);
  if (!token) return null;
  try {
    const row = db.prepare(`SELECT * FROM auth_sessions WHERE token = ? AND is_active = 1`).get(token) as any;
    if (!row) return null;
    if (new Date(row.expires_at) < new Date()) return null;
    const email = row.user_email || row.email;
    const uid = row.user_id || row.uid;
    const dbUser = getUserAccountByEmail(db, email) || getUserAccountByUid(db, uid);
    if (dbUser) return dbUser;
    return {
      id: uid || 'USR_UNKNOWN',
      name: row.user_name || 'Government User',
      email: email || '',
      role: (row.user_role as UserRole) || 'VIEWER',
      status: 'ACTIVE',
      designation: '',
      department: ''
    };
  } catch {
    return null;
  }
}

/**
 * Revokes a session token.
 */
export function revokeSession(db: DatabaseSync, token: string): boolean {
  initAuthTables(db);
  const res = db.prepare(`UPDATE auth_sessions SET is_active = 0 WHERE token = ?`).run(token);
  return (res as any)?.changes > 0;
}

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
      token?: string;
      authError?: {
        status: 200 | 401 | 403;
        error: string;
        reason: string;
      };
    }
  }
}

/**
 * Global Express middleware to verify token and attach req.user.
 * NEVER defaults to Nodal Officer or Viewer if no token is provided.
 */
export async function authenticateToken(req: Request, _res: Response, next: NextFunction): Promise<void> {
  const db = getDatabase();
  initAuthTables(db);

  const authHeader = req.headers['authorization'];
  const customToken = req.headers['x-auth-token'] as string | undefined;

  let token: string | undefined;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  } else if (customToken) {
    token = customToken.trim();
  }

  if (!token) {
    req.user = undefined;
    req.token = undefined;
    return next();
  }

  const result = await verifyToken(db, token);

  if (result.valid && result.user) {
    req.user = result.user;
    req.token = token;
  } else {
    req.user = undefined;
    req.token = token;
    req.authError = {
      status: result.status,
      error: result.error || 'UNAUTHORIZED',
      reason: result.reason || 'Token verification failed.'
    };

    // Log security event for token failure if expired
    if (result.error === 'TOKEN_EXPIRED') {
      AuditService.record(db, {
        userId: 'UNKNOWN',
        userName: 'Unauthenticated Request',
        userRole: 'UNAUTHENTICATED',
        action: 'SESSION_EXPIRED',
        resource: 'auth_system',
        result: 'DENIED',
        ipAddress: req.ip,
        details: { path: req.originalUrl, method: req.method, reason: result.reason }
      });
    }
  }

  next();
}

/**
 * Middleware requiring authenticated user. Returns 401 if missing/invalid.
 */
export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  if (!req.user) {
    const db = getDatabase();
    const status = req.authError?.status || 401;
    const error = req.authError?.error || 'AUTHENTICATION_REQUIRED';
    const message = req.authError?.reason || 'Authentication is required to access this statutory endpoint.';

    AuditService.record(db, {
      userId: 'ANONYMOUS',
      userName: 'Anonymous Request',
      userRole: 'UNAUTHENTICATED',
      action: 'ACCESS_DENIED',
      resource: 'api_gateway',
      result: 'DENIED',
      ipAddress: req.ip,
      details: { url: req.originalUrl, method: req.method, error, reason: message }
    });

    res.status(status).json({
      success: false,
      error,
      message
    });
    return;
  }
  next();
}

/**
 * Middleware requiring specific role(s) (e.g. NODAL_OFFICER).
 * Returns:
 * - 401 Unauthorized if missing/invalid token
 * - 403 Forbidden if user is authenticated but lacks required role
 */
export function requireRole(allowedRoles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const db = getDatabase();

    if (!req.user) {
      const status = req.authError?.status || 401;
      const error = req.authError?.error || 'AUTHENTICATION_REQUIRED';
      const message = req.authError?.reason || 'Valid administrative authentication token is required.';

      AuditService.record(db, {
        userId: 'ANONYMOUS',
        userName: 'Anonymous Request',
        userRole: 'UNAUTHENTICATED',
        action: 'ACCESS_DENIED',
        resource: 'api_gateway',
        result: 'DENIED',
        ipAddress: req.ip,
        details: { url: req.originalUrl, method: req.method, error, requiredRoles: allowedRoles }
      });

      res.status(status).json({
        success: false,
        error,
        message
      });
      return;
    }

    if (!allowedRoles.includes(req.user.role)) {
      AuditService.record(db, {
        userId: req.user.id,
        userName: req.user.name,
        userRole: req.user.role,
        action: 'ACCESS_DENIED',
        resource: 'privilege_firewall',
        result: 'DENIED',
        ipAddress: req.ip,
        details: {
          url: req.originalUrl,
          method: req.method,
          attemptedRole: req.user.role,
          requiredRoles: allowedRoles,
          reason: 'Statutory privilege escalation blocked. User does not hold required administrative authority.'
        }
      });

      res.status(403).json({
        success: false,
        error: 'UNAUTHORIZED_ACCESS',
        message: `Statutory administrative authority required. Current role '${req.user.role}' is not authorized. Required: [${allowedRoles.join(', ')}].`,
        user: {
          id: req.user.id,
          role: req.user.role,
          name: req.user.name
        }
      });
      return;
    }

    next();
  };
}
