/**
 * BHOOMI-DRISHTI PHASE 7B-6: STATISTICAL SHADOW DRIFT ENGINE
 * 
 * Provides mathematically rigorous and defensible statistical monitoring:
 * 1. Population Stability Index (PSI) for continuous & discrete features
 * 2. Two-Sample Kolmogorov-Smirnov (KS) test statistic & p-value
 * 3. Categorical frequency shift and unseen category detection
 * 4. Prediction distribution shift & percentiles (P10, P25, P50, P75, P90)
 * 5. V1 vs V2 model disagreement diagnostics
 * 6. Deterministic shadow scoring stability verification
 * 7. Ground truth statutory outcome maturity & calibration metrics
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { ORDERED_SHADOW_FEATURES, ShadowFeatureVector } from './shadowFeatureSchema.ts';

export const CANONICAL_BASELINE_DATASET_SHA = '0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a';
export const BASELINE_DATASET_PATH = 'data/reconstructed_longitudinal_dataset_v2.json';

export interface DriftThresholdConfig {
  psiStableMax: number;   // default 0.10
  psiReviewMax: number;   // default 0.25
  ksSignificance: number; // default 0.05
  minSampleForMetrics: number; // default 10
}

export const DEFAULT_DRIFT_CONFIG: DriftThresholdConfig = {
  psiStableMax: 0.10,
  psiReviewMax: 0.25,
  ksSignificance: 0.05,
  minSampleForMetrics: 10
};

export interface NumericFeatureStats {
  count: number;
  mean: number;
  median: number;
  min: number;
  max: number;
  stdDev: number;
}

export interface FeatureDriftResult {
  featureName: string;
  isNumeric: boolean;
  baselineCount: number;
  currentCount: number;
  psi: number;
  ksStatistic?: number | null;
  ksPValue?: number | null;
  status: 'STABLE' | 'REVIEW' | 'MATERIAL_DRIFT';
  baselineStats?: NumericFeatureStats;
  currentStats?: NumericFeatureStats;
  unseenCategories?: string[];
  message: string;
}

export interface PredictionDistributionStats {
  count: number;
  mean: number;
  median: number;
  min: number;
  max: number;
  stdDev: number;
  p10: number;
  p25: number;
  p75: number;
  p90: number;
  histogram: { binStart: number; binEnd: number; count: number; percentage: number }[];
}

export interface V1V2ComparisonStats {
  comparedProjectsCount: number;
  meanAbsoluteDifference: number;
  medianAbsoluteDifference: number;
  maxAbsoluteDifference: number;
  correlation: number;
  stateDisagreementCount: number;
  stateDisagreementRate: number;
  comparisons: {
    projectId: string;
    v1Probability: number;
    v2Probability: number;
    absDiff: number;
    signedDiff: number;
    v1State: string;
    v2State: string;
    disagrees: boolean;
  }[];
}

export interface OutcomeMaturitySummary {
  totalPredictions: number;
  matureOutcomesCount: number;
  pendingOutcomesCount: number;
  insufficientEvidenceCount: number;
  maturityPercentage: number;
  completedOnTimeCount: number;
  delayedLapsedCount: number;
  evaluationStatus: 'COMPLETE' | 'OUTCOME_MATURITY_INSUFFICIENT';
  brierScore: number | null;
  rocAuc: number | null;
  calibrationStatus: 'STABLE' | 'CALIBRATION_REVIEW_REQUIRED' | 'OUTCOME_DATA_INSUFFICIENT';
  message: string;
}

export class ShadowDriftEngine {
  private static cachedBaseline: any[] | null = null;
  private static cachedBaselineSha: string | null = null;

  /**
   * Loads and validates the Phase 4C authentic baseline dataset
   */
  public static getBaselineObservations(): any[] {
    if (this.cachedBaseline) return this.cachedBaseline;

    const absPath = path.resolve(process.cwd(), BASELINE_DATASET_PATH);
    if (!fs.existsSync(absPath)) {
      throw new Error(`Baseline dataset not found at ${absPath}`);
    }

    const rawBuf = fs.readFileSync(absPath);
    const sha = crypto.createHash('sha256').update(rawBuf).digest('hex');
    this.cachedBaselineSha = sha;

    if (sha !== CANONICAL_BASELINE_DATASET_SHA) {
      throw new Error(`Baseline dataset SHA mismatch! Expected ${CANONICAL_BASELINE_DATASET_SHA}, got ${sha}`);
    }

    const parsed = JSON.parse(rawBuf.toString('utf-8'));
    this.cachedBaseline = parsed.observations || [];
    return this.cachedBaseline!;
  }

  public static getBaselineSha(): string {
    if (!this.cachedBaselineSha) {
      this.getBaselineObservations();
    }
    return this.cachedBaselineSha!;
  }

  /**
   * Computes standard summary statistics for numeric array
   */
  public static computeNumericStats(values: number[]): NumericFeatureStats {
    if (values.length === 0) {
      return { count: 0, mean: 0, median: 0, min: 0, max: 0, stdDev: 0 };
    }
    const sorted = [...values].sort((a, b) => a - b);
    const n = sorted.length;
    const sum = sorted.reduce((acc, v) => acc + v, 0);
    const mean = sum / n;
    const median = n % 2 === 1 ? sorted[Math.floor(n / 2)] : (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
    const variance = sorted.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / n;
    const stdDev = Math.sqrt(variance);

    return {
      count: n,
      mean: Number(mean.toFixed(4)),
      median: Number(median.toFixed(4)),
      min: Number(sorted[0].toFixed(4)),
      max: Number(sorted[n - 1].toFixed(4)),
      stdDev: Number(stdDev.toFixed(4))
    };
  }

  /**
   * Computes Population Stability Index (PSI) between two numeric arrays
   */
  public static calculateNumericPSI(
    baselineValues: number[],
    currentValues: number[],
    numBins: number = 5
  ): number {
    if (baselineValues.length === 0 || currentValues.length === 0) return 0.0;

    const sortedBase = [...baselineValues].sort((a, b) => a - b);
    const minVal = sortedBase[0];
    const maxVal = sortedBase[sortedBase.length - 1];

    if (minVal === maxVal) {
      return 0.0;
    }

    // Determine quantile boundaries from baseline
    const binEdges: number[] = [];
    for (let i = 1; i < numBins; i++) {
      const idx = Math.floor((i / numBins) * sortedBase.length);
      binEdges.push(sortedBase[idx]);
    }

    const baseBins = new Array(numBins).fill(0);
    const currBins = new Array(numBins).fill(0);

    for (const v of baselineValues) {
      let b = 0;
      while (b < binEdges.length && v > binEdges[b]) b++;
      baseBins[b]++;
    }

    for (const v of currentValues) {
      let b = 0;
      while (b < binEdges.length && v > binEdges[b]) b++;
      currBins[b]++;
    }

    const nBase = baselineValues.length;
    const nCurr = currentValues.length;
    const eps = 1e-4;

    let psi = 0;
    for (let i = 0; i < numBins; i++) {
      const pBase = Math.max(eps, baseBins[i] / nBase);
      const pCurr = Math.max(eps, currBins[i] / nCurr);
      psi += (pCurr - pBase) * Math.log(pCurr / pBase);
    }

    return Number(Math.max(0, psi).toFixed(4));
  }

  /**
   * Computes 2-Sample Kolmogorov-Smirnov test statistic D and p-value
   */
  public static calculateKS(
    sample1: number[],
    sample2: number[]
  ): { dStatistic: number; pValue: number } {
    if (sample1.length === 0 || sample2.length === 0) {
      return { dStatistic: 0, pValue: 1.0 };
    }

    const s1 = [...sample1].sort((a, b) => a - b);
    const s2 = [...sample2].sort((a, b) => a - b);
    const n1 = s1.length;
    const n2 = s2.length;

    let dMax = 0;
    let i = 0;
    let j = 0;

    while (i < n1 && j < n2) {
      const x1 = s1[i];
      const x2 = s2[j];
      const cdf1 = (i + 1) / n1;
      const cdf2 = (j + 1) / n2;

      if (x1 < x2) {
        dMax = Math.max(dMax, Math.abs(cdf1 - (j / n2)));
        i++;
      } else if (x1 > x2) {
        dMax = Math.max(dMax, Math.abs((i / n1) - cdf2));
        j++;
      } else {
        dMax = Math.max(dMax, Math.abs(cdf1 - cdf2));
        i++;
        j++;
      }
    }

    // Asymptotic p-value approximation via Kolmogorov distribution
    const en = Math.sqrt((n1 * n2) / (n1 + n2));
    const lambda = (en + 0.12 + 0.11 / en) * dMax;
    let pValue = 1.0;
    if (lambda > 0) {
      let sum = 0;
      for (let k = 1; k <= 100; k++) {
        const term = 2 * Math.pow(-1, k - 1) * Math.exp(-2 * k * k * lambda * lambda);
        sum += term;
        if (Math.abs(term) < 1e-6) break;
      }
      pValue = Math.max(0, Math.min(1, sum));
    }

    return {
      dStatistic: Number(dMax.toFixed(4)),
      pValue: Number(pValue.toFixed(4))
    };
  }

  /**
   * Computes categorical frequency shift and PSI
   */
  public static calculateCategoricalPSI(
    baselineCategories: string[],
    currentCategories: string[]
  ): { psi: number; unseen: string[] } {
    if (baselineCategories.length === 0 || currentCategories.length === 0) {
      return { psi: 0.0, unseen: [] };
    }

    const baseCounts: Record<string, number> = {};
    for (const c of baselineCategories) {
      baseCounts[c] = (baseCounts[c] || 0) + 1;
    }

    const currCounts: Record<string, number> = {};
    const unseen: string[] = [];
    for (const c of currentCategories) {
      currCounts[c] = (currCounts[c] || 0) + 1;
      if (!(c in baseCounts) && !unseen.includes(c)) {
        unseen.push(c);
      }
    }

    const allKeys = Array.from(new Set([...Object.keys(baseCounts), ...Object.keys(currCounts)]));
    const nBase = baselineCategories.length;
    const nCurr = currentCategories.length;
    const eps = 1e-4;

    let psi = 0;
    for (const key of allKeys) {
      const pBase = Math.max(eps, (baseCounts[key] || 0) / nBase);
      const pCurr = Math.max(eps, (currCounts[key] || 0) / nCurr);
      psi += (pCurr - pBase) * Math.log(pCurr / pBase);
    }

    return {
      psi: Number(Math.max(0, psi).toFixed(4)),
      unseen
    };
  }

  /**
   * Evaluates feature drift for all 10 schema features against baseline dataset
   */
  public static evaluateAllFeaturesDrift(
    currentVectors: ShadowFeatureVector[],
    config: DriftThresholdConfig = DEFAULT_DRIFT_CONFIG
  ): FeatureDriftResult[] {
    const baselineObs = this.getBaselineObservations();
    const results: FeatureDriftResult[] = [];

    for (const feat of ORDERED_SHADOW_FEATURES) {
      const isNumeric = feat !== 'statutory_stage_at_t' && feat !== 'implementing_agency' && feat !== 'state_jurisdiction';

      if (isNumeric) {
        const baseVals: number[] = baselineObs
          .map(o => o.features?.[feat])
          .filter(v => typeof v === 'number' && !isNaN(v));
        const currVals: number[] = currentVectors
          .map(v => (v as any)[feat])
          .filter(v => typeof v === 'number' && !isNaN(v));

        const psi = this.calculateNumericPSI(baseVals, currVals);
        const ks = this.calculateKS(baseVals, currVals);
        const baseStats = this.computeNumericStats(baseVals);
        const currStats = this.computeNumericStats(currVals);

        let status: 'STABLE' | 'REVIEW' | 'MATERIAL_DRIFT' = 'STABLE';
        if (psi > config.psiReviewMax) status = 'MATERIAL_DRIFT';
        else if (psi > config.psiStableMax) status = 'REVIEW';

        results.push({
          featureName: feat,
          isNumeric: true,
          baselineCount: baseVals.length,
          currentCount: currVals.length,
          psi,
          ksStatistic: ks.dStatistic,
          ksPValue: ks.pValue,
          status,
          baselineStats: baseStats,
          currentStats: currStats,
          message: status === 'STABLE'
            ? 'Distribution aligned with baseline holdout.'
            : `PSI ${psi} indicates ${status.toLowerCase()} relative to Phase 4C baseline.`
        });
      } else {
        const baseCats: string[] = baselineObs
          .map(o => String(o.features?.[feat] || ''))
          .filter(s => s.length > 0);
        const currCats: string[] = currentVectors
          .map(v => String((v as any)[feat] || ''))
          .filter(s => s.length > 0);

        const catRes = this.calculateCategoricalPSI(baseCats, currCats);
        let status: 'STABLE' | 'REVIEW' | 'MATERIAL_DRIFT' = 'STABLE';
        if (catRes.psi > config.psiReviewMax || catRes.unseen.length > 0) status = 'MATERIAL_DRIFT';
        else if (catRes.psi > config.psiStableMax) status = 'REVIEW';

        results.push({
          featureName: feat,
          isNumeric: false,
          baselineCount: baseCats.length,
          currentCount: currCats.length,
          psi: catRes.psi,
          ksStatistic: null,
          ksPValue: null,
          status,
          unseenCategories: catRes.unseen,
          message: catRes.unseen.length > 0
            ? `Detected ${catRes.unseen.length} novel categories: ${catRes.unseen.join(', ')}`
            : `Categorical stability: PSI ${catRes.psi}`
        });
      }
    }

    return results;
  }

  /**
   * Computes comprehensive prediction distribution statistics
   */
  public static computePredictionDistribution(probabilities: number[]): PredictionDistributionStats {
    if (probabilities.length === 0) {
      return {
        count: 0, mean: 0, median: 0, min: 0, max: 0, stdDev: 0,
        p10: 0, p25: 0, p75: 0, p90: 0, histogram: []
      };
    }

    const sorted = [...probabilities].sort((a, b) => a - b);
    const n = sorted.length;
    const stats = this.computeNumericStats(probabilities);

    const getPercentile = (p: number) => {
      const idx = (p / 100) * (n - 1);
      const low = Math.floor(idx);
      const high = Math.ceil(idx);
      if (low === high) return sorted[low];
      return sorted[low] + (idx - low) * (sorted[high] - sorted[low]);
    };

    // 5-bin histogram: [0-0.2, 0.2-0.4, 0.4-0.6, 0.6-0.8, 0.8-1.0]
    const bins = [
      { binStart: 0.0, binEnd: 0.2, count: 0, percentage: 0 },
      { binStart: 0.2, binEnd: 0.4, count: 0, percentage: 0 },
      { binStart: 0.4, binEnd: 0.6, count: 0, percentage: 0 },
      { binStart: 0.6, binEnd: 0.8, count: 0, percentage: 0 },
      { binStart: 0.8, binEnd: 1.0, count: 0, percentage: 0 }
    ];

    for (const p of probabilities) {
      let b = Math.min(4, Math.floor(p * 5));
      bins[b].count++;
    }

    for (const b of bins) {
      b.percentage = Number(((b.count / n) * 100).toFixed(1));
    }

    return {
      count: n,
      mean: stats.mean,
      median: stats.median,
      min: stats.min,
      max: stats.max,
      stdDev: stats.stdDev,
      p10: Number(getPercentile(10).toFixed(4)),
      p25: Number(getPercentile(25).toFixed(4)),
      p75: Number(getPercentile(75).toFixed(4)),
      p90: Number(getPercentile(90).toFixed(4)),
      histogram: bins
    };
  }

  /**
   * Computes V1 vs V2 Comparison Diagnostics
   */
  public static compareV1AndV2(
    items: {
      projectId: string;
      v1Probability: number;
      v2Probability: number;
      v1RiskLevel: string;
    }[]
  ): V1V2ComparisonStats {
    if (items.length === 0) {
      return {
        comparedProjectsCount: 0,
        meanAbsoluteDifference: 0,
        medianAbsoluteDifference: 0,
        maxAbsoluteDifference: 0,
        correlation: 0,
        stateDisagreementCount: 0,
        stateDisagreementRate: 0,
        comparisons: []
      };
    }

    const diffs: number[] = [];
    const v1Probs: number[] = [];
    const v2Probs: number[] = [];
    let disagreements = 0;

    const comparisons = items.map(item => {
      const absDiff = Math.abs(item.v1Probability - item.v2Probability);
      const signedDiff = item.v2Probability - item.v1Probability;
      diffs.push(absDiff);
      v1Probs.push(item.v1Probability);
      v2Probs.push(item.v2Probability);

      // Diagnostic tentative mapping: >= 0.5 is Higher, < 0.5 is Lower
      const v2TentativeState = item.v2Probability >= 0.5 ? 'HIGH' : 'LOW';
      const v1MappedState = item.v1RiskLevel === 'HIGH' ? 'HIGH' : 'LOW';
      const disagrees = v2TentativeState !== v1MappedState;
      if (disagrees) disagreements++;

      return {
        projectId: item.projectId,
        v1Probability: Number(item.v1Probability.toFixed(4)),
        v2Probability: Number(item.v2Probability.toFixed(4)),
        absDiff: Number(absDiff.toFixed(4)),
        signedDiff: Number(signedDiff.toFixed(4)),
        v1State: item.v1RiskLevel,
        v2State: `DIAGNOSTIC_${v2TentativeState}`,
        disagrees
      };
    });

    const diffStats = this.computeNumericStats(diffs);

    // Pearson correlation
    let correlation = 0;
    if (items.length > 1) {
      const v1Stats = this.computeNumericStats(v1Probs);
      const v2Stats = this.computeNumericStats(v2Probs);
      if (v1Stats.stdDev > 0 && v2Stats.stdDev > 0) {
        let cov = 0;
        for (let i = 0; i < items.length; i++) {
          cov += (v1Probs[i] - v1Stats.mean) * (v2Probs[i] - v2Stats.mean);
        }
        cov /= items.length;
        correlation = Number((cov / (v1Stats.stdDev * v2Stats.stdDev)).toFixed(4));
      }
    }

    return {
      comparedProjectsCount: items.length,
      meanAbsoluteDifference: diffStats.mean,
      medianAbsoluteDifference: diffStats.median,
      maxAbsoluteDifference: diffStats.max,
      correlation,
      stateDisagreementCount: disagreements,
      stateDisagreementRate: Number(((disagreements / items.length) * 100).toFixed(1)),
      comparisons
    };
  }

  /**
   * Reconciles authoritative eventual statutory outcomes and computes maturity
   */
  public static evaluateOutcomes(
    records: {
      projectId: string;
      observationTimestamp: string;
      first3aDate: string;
      section3dDate: string | null;
      predictedProbability: number | null;
    }[],
    minSampleRequired: number = DEFAULT_DRIFT_CONFIG.minSampleForMetrics
  ): OutcomeMaturitySummary {
    let completedOnTime = 0;
    let delayedLapsed = 0;
    let pending = 0;
    let maturePairs: { prob: number; label: number }[] = [];

    for (const r of records) {
      if (!r.first3aDate) continue;

      if (r.section3dDate) {
        const d3a = new Date(r.first3aDate).getTime();
        const d3d = new Date(r.section3dDate).getTime();
        const days = Math.round((d3d - d3a) / (1000 * 60 * 60 * 24));

        if (days <= 365) {
          completedOnTime++;
          if (r.predictedProbability !== null) {
            maturePairs.push({ prob: r.predictedProbability, label: 0 }); // 0 = on-time
          }
        } else {
          delayedLapsed++;
          if (r.predictedProbability !== null) {
            maturePairs.push({ prob: r.predictedProbability, label: 1 }); // 1 = delayed
          }
        }
      } else {
        // No authoritative 3D notice published yet -> OUTCOME_PENDING
        pending++;
      }
    }

    const totalMature = completedOnTime + delayedLapsed;
    const total = records.length;
    const maturityPct = total > 0 ? Number(((totalMature / total) * 100).toFixed(1)) : 0;

    if (totalMature < minSampleRequired) {
      return {
        totalPredictions: total,
        matureOutcomesCount: totalMature,
        pendingOutcomesCount: pending,
        insufficientEvidenceCount: total - (totalMature + pending),
        maturityPercentage: maturityPct,
        completedOnTimeCount: completedOnTime,
        delayedLapsedCount: delayedLapsed,
        evaluationStatus: 'OUTCOME_MATURITY_INSUFFICIENT',
        brierScore: null,
        rocAuc: null,
        calibrationStatus: 'OUTCOME_DATA_INSUFFICIENT',
        message: `Outcome maturity insufficient: Only ${totalMature} mature authoritative outcomes observed (minimum ${minSampleRequired} required for unbiased validation).`
      };
    }

    // Compute Brier score: mean((prob - label)^2)
    const brierSum = maturePairs.reduce((acc, p) => acc + Math.pow(p.prob - p.label, 2), 0);
    const brierScore = Number((brierSum / maturePairs.length).toFixed(4));

    // Simple ROC-AUC computation
    let rocAuc = 0.5;
    const positives = maturePairs.filter(p => p.label === 1);
    const negatives = maturePairs.filter(p => p.label === 0);
    if (positives.length > 0 && negatives.length > 0) {
      let concordant = 0;
      for (const pos of positives) {
        for (const neg of negatives) {
          if (pos.prob > neg.prob) concordant += 1;
          else if (pos.prob === neg.prob) concordant += 0.5;
        }
      }
      rocAuc = Number((concordant / (positives.length * negatives.length)).toFixed(4));
    }

    return {
      totalPredictions: total,
      matureOutcomesCount: totalMature,
      pendingOutcomesCount: pending,
      insufficientEvidenceCount: total - (totalMature + pending),
      maturityPercentage: maturityPct,
      completedOnTimeCount: completedOnTime,
      delayedLapsedCount: delayedLapsed,
      evaluationStatus: 'COMPLETE',
      brierScore,
      rocAuc,
      calibrationStatus: brierScore > 0.25 ? 'CALIBRATION_REVIEW_REQUIRED' : 'STABLE',
      message: `Statutory evaluation complete across ${totalMature} mature corridors.`
    };
  }
}
