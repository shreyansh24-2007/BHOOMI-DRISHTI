/**
 * BHOOMI-DRISHTI PHASE 6A: IMMUTABLE SHADOW FEATURE SCHEMA
 * 
 * Identifier: SCHEMA-LONGITUDINAL-V2.0-10FEAT
 * 
 * Exactly 10 audited authentic longitudinal features:
 * 1. elapsed_days_since_first_3a (number)
 * 2. cumulative_notifications_count_at_t (number)
 * 3. notification_cadence_days (number)
 * 4. days_since_last_notification (number)
 * 5. statutory_stage_at_t (string)
 * 6. statutory_notification_frequency_180d (number)
 * 7. total_land_required_ha (number)
 * 8. implementing_agency (string)
 * 9. state_jurisdiction (string)
 * 10. initial_sanction_available_at_t (number: 0 or 1)
 * 
 * Strict Quarantine & Rejection:
 * - Rejects Section 3D declaration dates
 * - Rejects target variables / eventual statutory outcomes
 * - Rejects synthetic T180 indicators
 * - Rejects retired legacy defaulted features
 */

import crypto from 'node:crypto';

export const SHADOW_FEATURE_SCHEMA_VERSION = 'SCHEMA-LONGITUDINAL-V2.0-10FEAT';

export const ORDERED_SHADOW_FEATURES = [
  'elapsed_days_since_first_3a',
  'cumulative_notifications_count_at_t',
  'notification_cadence_days',
  'days_since_last_notification',
  'statutory_stage_at_t',
  'statutory_notification_frequency_180d',
  'total_land_required_ha',
  'implementing_agency',
  'state_jurisdiction',
  'initial_sanction_available_at_t'
] as const;

export type ShadowFeatureName = typeof ORDERED_SHADOW_FEATURES[number];

export interface ShadowFeatureVector {
  elapsed_days_since_first_3a: number;
  cumulative_notifications_count_at_t: number;
  notification_cadence_days: number;
  days_since_last_notification: number;
  statutory_stage_at_t: string;
  statutory_notification_frequency_180d: number;
  total_land_required_ha: number;
  implementing_agency: string;
  state_jurisdiction: string;
  initial_sanction_available_at_t: number;
}

export const FORBIDDEN_QUARANTINE_KEYS = [
  'section_3d_date',
  'first_3d_date',
  '3d_date',
  'publish_date_3d',
  'delayed',
  'target',
  'target_type',
  'eventual_duration_days',
  'duration_days',
  'is_t180',
  't180',
  'snapshot_t180',
  'land_acquired_ratio_at_t',
  'comp_disbursed_percent_at_t',
  'active_court_stays_at_t',
  'unresolved_cases_at_t',
  'incomplete_docs_count_at_t',
  'forest_clearance_at_t'
] as const;

export interface SchemaValidationResult {
  valid: boolean;
  errors: string[];
  normalizedVector?: ShadowFeatureVector;
}

/**
 * Validates a candidate feature payload against SCHEMA-LONGITUDINAL-V2.0-10FEAT.
 * Enforces exact key matching and quarantine rules.
 */
export function validateShadowFeatureSchema(rawFeatures: Record<string, any>): SchemaValidationResult {
  const errors: string[] = [];

  if (!rawFeatures || typeof rawFeatures !== 'object') {
    return { valid: false, errors: ['Features payload must be a non-null object.'] };
  }

  const rawKeys = Object.keys(rawFeatures);

  // 1. Quarantine Check: Reject any forbidden key
  for (const forbidden of FORBIDDEN_QUARANTINE_KEYS) {
    if (forbidden in rawFeatures || rawKeys.some(k => k.toLowerCase() === forbidden.toLowerCase())) {
      errors.push(`Quarantine breach: forbidden key '${forbidden}' detected in feature payload.`);
    }
  }

  // 2. Check for missing required features
  for (const reqFeat of ORDERED_SHADOW_FEATURES) {
    if (!(reqFeat in rawFeatures) || rawFeatures[reqFeat] === undefined || rawFeatures[reqFeat] === null) {
      errors.push(`Missing mandatory feature: '${reqFeat}'.`);
    }
  }

  // 3. Check for unauthorized extra features
  for (const k of rawKeys) {
    if (!ORDERED_SHADOW_FEATURES.includes(k as any)) {
      errors.push(`Unauthorized extraneous feature key: '${k}'.`);
    }
  }

  // 4. Type & Value Checks
  if (typeof rawFeatures.elapsed_days_since_first_3a !== 'number' || isNaN(rawFeatures.elapsed_days_since_first_3a) || rawFeatures.elapsed_days_since_first_3a < 0) {
    errors.push('Feature elapsed_days_since_first_3a must be a non-negative number.');
  }

  if (typeof rawFeatures.cumulative_notifications_count_at_t !== 'number' || rawFeatures.cumulative_notifications_count_at_t < 1) {
    errors.push('Feature cumulative_notifications_count_at_t must be an integer >= 1.');
  }

  if (typeof rawFeatures.notification_cadence_days !== 'number' || rawFeatures.notification_cadence_days < 0) {
    errors.push('Feature notification_cadence_days must be a non-negative number.');
  }

  if (typeof rawFeatures.days_since_last_notification !== 'number' || rawFeatures.days_since_last_notification < 0) {
    errors.push('Feature days_since_last_notification must be a non-negative number.');
  }

  if (typeof rawFeatures.statutory_stage_at_t !== 'string' || !rawFeatures.statutory_stage_at_t.trim()) {
    errors.push('Feature statutory_stage_at_t must be a non-empty string.');
  }

  if (typeof rawFeatures.statutory_notification_frequency_180d !== 'number' || rawFeatures.statutory_notification_frequency_180d < 1) {
    errors.push('Feature statutory_notification_frequency_180d must be an integer >= 1.');
  }

  if (typeof rawFeatures.total_land_required_ha !== 'number' || isNaN(rawFeatures.total_land_required_ha) || rawFeatures.total_land_required_ha <= 0 || rawFeatures.total_land_required_ha > 10000) {
    errors.push('Feature total_land_required_ha must be a positive number <= 10,000 ha.');
  }

  if (typeof rawFeatures.implementing_agency !== 'string' || !rawFeatures.implementing_agency.trim()) {
    errors.push('Feature implementing_agency must be a non-empty string.');
  }

  if (typeof rawFeatures.state_jurisdiction !== 'string' || !rawFeatures.state_jurisdiction.trim()) {
    errors.push('Feature state_jurisdiction must be a non-empty string.');
  }

  if (![0, 1].includes(rawFeatures.initial_sanction_available_at_t)) {
    errors.push('Feature initial_sanction_available_at_t must be binary (0 or 1).');
  }

  if (errors.length > 0) {
    return { valid: false, errors };
  }

  const normalizedVector: ShadowFeatureVector = {
    elapsed_days_since_first_3a: Number(rawFeatures.elapsed_days_since_first_3a),
    cumulative_notifications_count_at_t: Math.floor(rawFeatures.cumulative_notifications_count_at_t),
    notification_cadence_days: Number(rawFeatures.notification_cadence_days),
    days_since_last_notification: Number(rawFeatures.days_since_last_notification),
    statutory_stage_at_t: String(rawFeatures.statutory_stage_at_t).trim(),
    statutory_notification_frequency_180d: Math.floor(rawFeatures.statutory_notification_frequency_180d),
    total_land_required_ha: Number(rawFeatures.total_land_required_ha),
    implementing_agency: String(rawFeatures.implementing_agency).trim(),
    state_jurisdiction: String(rawFeatures.state_jurisdiction).trim(),
    initial_sanction_available_at_t: rawFeatures.initial_sanction_available_at_t === 1 ? 1 : 0
  };

  return { valid: true, errors: [], normalizedVector };
}

/**
 * Computes a deterministic SHA-256 hash of the normalized feature vector.
 * Guarantees that identical inputs always produce identical digests by sorting
 * and serializing strictly in canonical schema order.
 */
export function computeFeatureSnapshotHash(features: ShadowFeatureVector): string {
  const canonicalEntries = ORDERED_SHADOW_FEATURES.map(field => {
    const val = features[field];
    return `${field}:${typeof val === 'number' ? val.toFixed(4) : String(val)}`;
  });
  const canonicalString = canonicalEntries.join('|');
  return crypto.createHash('sha256').update(canonicalString, 'utf-8').digest('hex');
}
