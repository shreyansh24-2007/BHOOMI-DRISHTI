/**
 * BHOOMI-DRISHTI PHASE 7B-7: STATISTICAL EVALUATION & CALIBRATION ENGINE
 * 
 * Provides rigorous institutional evaluation of candidate V2 shadow model vs
 * mature authoritative statutory outcomes:
 * 1. Project-level bootstrap uncertainty estimation (deterministic seeded PRNG)
 * 2. Discrimination metrics (ROC-AUC, PR-AUC, Recall, Specificity, Precision, NPV, F1, Balanced Accuracy)
 * 3. Calibration metrics (Brier score, Log Loss, Calibration Slope/Intercept, ECE, Reliability Bins)
 * 4. Multi-threshold diagnostic sensitivity analysis
 * 5. Temporal cohort and jurisdictional/operational segmentation
 * 6. V1 vs V2 retrospective comparative diagnostics
 * 7. Evidence coverage bias and statistical sufficiency gates
 * 
 * Strict safety rules:
 * - V2 remains non-operational
 * - Thresholds remain PENDING_STAKEHOLDER_APPROVAL
 * - Zero model retraining, zero parameter adjustments, zero fabrication
 */

import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export const CANONICAL_V1_SHA256 = '7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f';
export const CANONICAL_V2_SHA256 = '4a83e980f9178498be4592a47303f0ebc5ea641934952af5bee92ae5b76729a2';
export const CANONICAL_BASELINE_DATASET_SHA = '0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a';
export const CANONICAL_FEATURE_SCHEMA = 'SCHEMA-LONGITUDINAL-V2.0-10FEAT';

export interface EvaluationConfig {
  minSampleForMetrics: number; // default 10
  minPositiveOutcomes: number; // default 1
  minNegativeOutcomes: number; // default 1
  bootstrapSeed: number;       // default 42
  bootstrapReplicates: number; // default 1000
  confidenceLevel: number;     // default 0.95
}

export const DEFAULT_EVAL_CONFIG: EvaluationConfig = {
  minSampleForMetrics: 10,
  minPositiveOutcomes: 1,
  minNegativeOutcomes: 1,
  bootstrapSeed: 42,
  bootstrapReplicates: 1000,
  confidenceLevel: 0.95
};

export class SeededRandom {
  private s: number;

  constructor(seed: number = 42) {
    this.s = seed >>> 0;
  }

  // Mulberry32 32-bit generator
  public next(): number {
    let t = (this.s += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  public nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min)) + min;
  }
}

export interface ObservationOutcomePair {
  projectId: string;
  observationTimestamp: string;
  predictedProbability: number;
  groundTruthLabel: number; // 1 = delayed, 0 = on-time
  first3aDate: string;
  section3dDate: string | null;
  outcomeTimestamp: string;
  statutoryOutcome: 'COMPLETED_ON_TIME' | 'DELAYED_LAPSED';
  outcomeWindowDays: number;
  stateJurisdiction?: string;
  implementingAgency?: string;
  v1Probability?: number | null;
}

export interface MetricWithCI {
  estimate: number;
  ciLower: number | null;
  ciUpper: number | null;
  method: string;
}

export interface ReliabilityBin {
  binIndex: number;
  binStart: number;
  binEnd: number;
  sampleCount: number;
  projectCount: number;
  meanPredictedProbability: number;
  observedEventRate: number;
  calibrationError: number;
}

export interface ThresholdDiagnosticPoint {
  threshold: number;
  truePositives: number;
  falsePositives: number;
  trueNegatives: number;
  falseNegatives: number;
  sensitivity: number;
  specificity: number;
  precision: number;
  npv: number;
  f1: number;
  balancedAccuracy: number;
  classifiedHighCount: number;
  classifiedLowCount: number;
  status: 'DIAGNOSTIC_ONLY_PENDING_APPROVAL';
}

export interface EvaluationMetricsResult {
  evaluationState: 'EVALUATION_READY' | 'OUTCOME_MATURITY_INSUFFICIENT' | 'STATISTICAL_POWER_INSUFFICIENT' | 'EVIDENCE_COVERAGE_INSUFFICIENT';
  isStatisticallySufficient: boolean;
  totalObservations: number;
  uniqueProjects: number;
  matureObservations: number;
  delayedCount: number;
  onTimeCount: number;
  discrimination: {
    rocAuc: MetricWithCI | null;
    prAuc: MetricWithCI | null;
    sensitivity: MetricWithCI | null;
    specificity: MetricWithCI | null;
    precision: MetricWithCI | null;
    npv: MetricWithCI | null;
    f1: MetricWithCI | null;
    balancedAccuracy: MetricWithCI | null;
  };
  calibration: {
    brierScore: MetricWithCI | null;
    logLoss: MetricWithCI | null;
    calibrationIntercept: number | null;
    calibrationSlope: number | null;
    ece: number | null;
    reliabilityBins: ReliabilityBin[];
    status: 'CALIBRATION_EVIDENCE_SUFFICIENT' | 'CALIBRATION_EVIDENCE_INSUFFICIENT' | 'CALIBRATION_REVIEW_REQUIRED';
  };
  bootstrapDetails: {
    resamplingUnit: 'PROJECT';
    replicates: number;
    seed: number;
    confidenceLevel: number;
  };
  message: string;
}

export class ShadowEvaluationEngine {
  /**
   * Deterministically computes evaluation dataset SHA-256
   */
  public static computeDatasetSha256(records: ObservationOutcomePair[]): string {
    const sorted = [...records].sort((a, b) => {
      const cmp = a.projectId.localeCompare(b.projectId);
      if (cmp !== 0) return cmp;
      return a.observationTimestamp.localeCompare(b.observationTimestamp);
    });

    const canonicalJson = JSON.stringify(sorted.map(r => ({
      p: r.projectId,
      t: r.observationTimestamp,
      prob: r.predictedProbability,
      y: r.groundTruthLabel,
      ot: r.outcomeTimestamp,
      w: r.outcomeWindowDays
    })));

    return crypto.createHash('sha256').update(canonicalJson).digest('hex');
  }

  /**
   * Computes point discrimination & calibration metrics on a given sample
   */
  public static computePointMetrics(pairs: ObservationOutcomePair[], threshold: number = 0.5): {
    rocAuc: number;
    prAuc: number;
    sensitivity: number;
    specificity: number;
    precision: number;
    npv: number;
    f1: number;
    balancedAccuracy: number;
    brierScore: number;
    logLoss: number;
    calibrationSlope: number;
    calibrationIntercept: number;
    ece: number;
  } {
    const n = pairs.length;
    if (n === 0) {
      return {
        rocAuc: 0.5,
        prAuc: 0,
        sensitivity: 0,
        specificity: 0,
        precision: 0,
        npv: 0,
        f1: 0,
        balancedAccuracy: 0,
        brierScore: 0,
        logLoss: 0,
        calibrationSlope: 1,
        calibrationIntercept: 0,
        ece: 0
      };
    }

    let tp = 0;
    let fp = 0;
    let tn = 0;
    let fn = 0;
    let brierSum = 0;
    let logLossSum = 0;
    const eps = 1e-15;

    for (const p of pairs) {
      const pred = p.predictedProbability;
      const y = p.groundTruthLabel;

      if (pred >= threshold) {
        if (y === 1) tp++;
        else fp++;
      } else {
        if (y === 1) fn++;
        else tn++;
      }

      brierSum += Math.pow(pred - y, 2);
      const boundedP = Math.max(eps, Math.min(1 - eps, pred));
      logLossSum += y * Math.log(boundedP) + (1 - y) * Math.log(1 - boundedP);
    }

    const sensitivity = tp + fn > 0 ? tp / (tp + fn) : 0;
    const specificity = tn + fp > 0 ? tn / (tn + fp) : 0;
    const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
    const npv = tn + fn > 0 ? tn / (tn + fn) : 0;
    const f1 = precision + sensitivity > 0 ? (2 * precision * sensitivity) / (precision + sensitivity) : 0;
    const balancedAccuracy = (sensitivity + specificity) / 2;
    const brierScore = brierSum / n;
    const logLoss = -logLossSum / n;

    // ROC-AUC via Mann-Whitney U / concordance
    const positives = pairs.filter(p => p.groundTruthLabel === 1);
    const negatives = pairs.filter(p => p.groundTruthLabel === 0);
    let rocAuc = 0.5;
    if (positives.length > 0 && negatives.length > 0) {
      let concordant = 0;
      for (const pos of positives) {
        for (const neg of negatives) {
          if (pos.predictedProbability > neg.predictedProbability) {
            concordant += 1;
          } else if (pos.predictedProbability === neg.predictedProbability) {
            concordant += 0.5;
          }
        }
      }
      rocAuc = concordant / (positives.length * negatives.length);
    }

    // PR-AUC via numerical integration on sorted predictions
    let prAuc = 0;
    if (positives.length > 0) {
      const sorted = [...pairs].sort((a, b) => b.predictedProbability - a.predictedProbability);
      let curTp = 0;
      let curFp = 0;
      let prevRecall = 0;
      for (let i = 0; i < sorted.length; i++) {
        if (sorted[i].groundTruthLabel === 1) curTp++;
        else curFp++;
        const curRecall = curTp / positives.length;
        const curPrecision = curTp / (curTp + curFp);
        prAuc += (curRecall - prevRecall) * curPrecision;
        prevRecall = curRecall;
      }
    }

    // Calibration Slope & Intercept via Ordinary Least Squares (y on p)
    let sumP = 0;
    let sumY = 0;
    let sumPP = 0;
    let sumPY = 0;
    for (const p of pairs) {
      sumP += p.predictedProbability;
      sumY += p.groundTruthLabel;
      sumPP += p.predictedProbability * p.predictedProbability;
      sumPY += p.predictedProbability * p.groundTruthLabel;
    }
    const varP = sumPP - (sumP * sumP) / n;
    let calibrationSlope = 1.0;
    let calibrationIntercept = 0.0;
    if (varP > 1e-12) {
      calibrationSlope = (sumPY - (sumP * sumY) / n) / varP;
      calibrationIntercept = sumY / n - calibrationSlope * (sumP / n);
    }

    // Expected Calibration Error (ECE) over 5 bins
    const numBins = 5;
    let ece = 0;
    for (let b = 0; b < numBins; b++) {
      const bStart = b / numBins;
      const bEnd = (b + 1) / numBins;
      const inBin = pairs.filter(p => {
        if (b === numBins - 1) return p.predictedProbability >= bStart && p.predictedProbability <= bEnd;
        return p.predictedProbability >= bStart && p.predictedProbability < bEnd;
      });
      if (inBin.length > 0) {
        const binMeanPred = inBin.reduce((acc, x) => acc + x.predictedProbability, 0) / inBin.length;
        const binObsRate = inBin.reduce((acc, x) => acc + x.groundTruthLabel, 0) / inBin.length;
        ece += (inBin.length / n) * Math.abs(binMeanPred - binObsRate);
      }
    }

    return {
      rocAuc: Number(rocAuc.toFixed(4)),
      prAuc: Number(prAuc.toFixed(4)),
      sensitivity: Number(sensitivity.toFixed(4)),
      specificity: Number(specificity.toFixed(4)),
      precision: Number(precision.toFixed(4)),
      npv: Number(npv.toFixed(4)),
      f1: Number(f1.toFixed(4)),
      balancedAccuracy: Number(balancedAccuracy.toFixed(4)),
      brierScore: Number(brierScore.toFixed(4)),
      logLoss: Number(logLoss.toFixed(4)),
      calibrationSlope: Number(calibrationSlope.toFixed(4)),
      calibrationIntercept: Number(calibrationIntercept.toFixed(4)),
      ece: Number(ece.toFixed(4))
    };
  }

  /**
   * Resamples projects (with replacement) and evaluates metrics distributions
   */
  public static runProjectLevelBootstrap(
    pairs: ObservationOutcomePair[],
    config: EvaluationConfig = DEFAULT_EVAL_CONFIG
  ): {
    metrics: Record<string, { estimate: number; ciLower: number; ciUpper: number }>;
  } {
    // Group observations by project ID
    const projectMap = new Map<string, ObservationOutcomePair[]>();
    for (const p of pairs) {
      if (!projectMap.has(p.projectId)) projectMap.set(p.projectId, []);
      projectMap.get(p.projectId)!.push(p);
    }
    const uniqueProjectIds = Array.from(projectMap.keys());
    const k = uniqueProjectIds.length;

    const point = this.computePointMetrics(pairs);
    const rng = new SeededRandom(config.bootstrapSeed);
    const replicates = config.bootstrapReplicates;

    const rocAucs: number[] = [];
    const prAucs: number[] = [];
    const briers: number[] = [];
    const recalls: number[] = [];
    const specificities: number[] = [];
    const precisions: number[] = [];
    const npvs: number[] = [];
    const f1s: number[] = [];
    const balancedAccs: number[] = [];

    for (let r = 0; r < replicates; r++) {
      const resampledPool: ObservationOutcomePair[] = [];
      for (let i = 0; i < k; i++) {
        const pickedIdx = rng.nextInt(0, k);
        const pid = uniqueProjectIds[pickedIdx];
        const obs = projectMap.get(pid)!;
        for (const item of obs) {
          resampledPool.push(item);
        }
      }

      const repMetrics = this.computePointMetrics(resampledPool);
      rocAucs.push(repMetrics.rocAuc);
      prAucs.push(repMetrics.prAuc);
      briers.push(repMetrics.brierScore);
      recalls.push(repMetrics.sensitivity);
      specificities.push(repMetrics.specificity);
      precisions.push(repMetrics.precision);
      npvs.push(repMetrics.npv);
      f1s.push(repMetrics.f1);
      balancedAccs.push(repMetrics.balancedAccuracy);
    }

    const getCI = (arr: number[], est: number) => {
      arr.sort((a, b) => a - b);
      const lowerIdx = Math.floor(replicates * (1 - config.confidenceLevel) / 2);
      const upperIdx = Math.floor(replicates * (1 - (1 - config.confidenceLevel) / 2));
      return {
        estimate: est,
        ciLower: Number(arr[Math.max(0, lowerIdx)].toFixed(4)),
        ciUpper: Number(arr[Math.min(replicates - 1, upperIdx)].toFixed(4))
      };
    };

    return {
      metrics: {
        rocAuc: getCI(rocAucs, point.rocAuc),
        prAuc: getCI(prAucs, point.prAuc),
        brierScore: getCI(briers, point.brierScore),
        sensitivity: getCI(recalls, point.sensitivity),
        specificity: getCI(specificities, point.specificity),
        precision: getCI(precisions, point.precision),
        npv: getCI(npvs, point.npv),
        f1: getCI(f1s, point.f1),
        balancedAccuracy: getCI(balancedAccs, point.balancedAccuracy)
      }
    };
  }

  /**
   * Generates reliability bins for calibration analysis
   */
  public static computeReliabilityBins(pairs: ObservationOutcomePair[], numBins: number = 5): ReliabilityBin[] {
    const bins: ReliabilityBin[] = [];

    for (let b = 0; b < numBins; b++) {
      const bStart = b / numBins;
      const bEnd = (b + 1) / numBins;

      const inBin = pairs.filter(p => {
        if (b === numBins - 1) return p.predictedProbability >= bStart && p.predictedProbability <= bEnd;
        return p.predictedProbability >= bStart && p.predictedProbability < bEnd;
      });

      const sampleCount = inBin.length;
      const projectCount = new Set(inBin.map(p => p.projectId)).size;
      const meanPred = sampleCount > 0
        ? Number((inBin.reduce((acc, x) => acc + x.predictedProbability, 0) / sampleCount).toFixed(4))
        : Number(((bStart + bEnd) / 2).toFixed(4));
      const obsRate = sampleCount > 0
        ? Number((inBin.reduce((acc, x) => acc + x.groundTruthLabel, 0) / sampleCount).toFixed(4))
        : 0;
      const calibErr = sampleCount > 0 ? Number(Math.abs(meanPred - obsRate).toFixed(4)) : 0;

      bins.push({
        binIndex: b + 1,
        binStart: Number(bStart.toFixed(2)),
        binEnd: Number(bEnd.toFixed(2)),
        sampleCount,
        projectCount,
        meanPredictedProbability: meanPred,
        observedEventRate: obsRate,
        calibrationError: calibErr
      });
    }

    return bins;
  }

  /**
   * Computes diagnostic sensitivity analysis across multiple candidate decision thresholds
   */
  public static evaluateDiagnosticThresholds(
    pairs: ObservationOutcomePair[],
    thresholds: number[] = [0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80]
  ): ThresholdDiagnosticPoint[] {
    return thresholds.map(thresh => {
      const point = this.computePointMetrics(pairs, thresh);
      let highCount = 0;
      let lowCount = 0;
      let tp = 0;
      let fp = 0;
      let tn = 0;
      let fn = 0;

      for (const p of pairs) {
        if (p.predictedProbability >= thresh) {
          highCount++;
          if (p.groundTruthLabel === 1) tp++;
          else fp++;
        } else {
          lowCount++;
          if (p.groundTruthLabel === 1) fn++;
          else tn++;
        }
      }

      return {
        threshold: thresh,
        truePositives: tp,
        falsePositives: fp,
        trueNegatives: tn,
        falseNegatives: fn,
        sensitivity: point.sensitivity,
        specificity: point.specificity,
        precision: point.precision,
        npv: point.npv,
        f1: point.f1,
        balancedAccuracy: point.balancedAccuracy,
        classifiedHighCount: highCount,
        classifiedLowCount: lowCount,
        status: 'DIAGNOSTIC_ONLY_PENDING_APPROVAL'
      };
    });
  }

  /**
   * Performs full evaluation of available mature observations with statistical sufficiency gating
   */
  public static evaluateMatureCohort(
    pairs: ObservationOutcomePair[],
    config: EvaluationConfig = DEFAULT_EVAL_CONFIG
  ): EvaluationMetricsResult {
    const totalObservations = pairs.length;
    const uniqueProjects = new Set(pairs.map(p => p.projectId)).size;
    const delayedCount = pairs.filter(p => p.groundTruthLabel === 1).length;
    const onTimeCount = pairs.filter(p => p.groundTruthLabel === 0).length;

    // Check statistical sufficiency gates
    const isSampleSufficient = totalObservations >= config.minSampleForMetrics;
    const areBothClassesPresent = delayedCount >= config.minPositiveOutcomes && onTimeCount >= config.minNegativeOutcomes;

    if (!isSampleSufficient || !areBothClassesPresent) {
      let reason = '';
      if (!isSampleSufficient) {
        reason = `Mature sample size (${totalObservations}) is below minimum requirement (${config.minSampleForMetrics}) for unbiased validation.`;
      } else {
        reason = `Imbalanced mature sample: Delayed count = ${delayedCount}, On-time count = ${onTimeCount}. Both classes required for discrimination metrics.`;
      }

      return {
        evaluationState: !isSampleSufficient ? 'OUTCOME_MATURITY_INSUFFICIENT' : 'STATISTICAL_POWER_INSUFFICIENT',
        isStatisticallySufficient: false,
        totalObservations,
        uniqueProjects,
        matureObservations: totalObservations,
        delayedCount,
        onTimeCount,
        discrimination: {
          rocAuc: null,
          prAuc: null,
          sensitivity: null,
          specificity: null,
          precision: null,
          npv: null,
          f1: null,
          balancedAccuracy: null
        },
        calibration: {
          brierScore: null,
          logLoss: null,
          calibrationIntercept: null,
          calibrationSlope: null,
          ece: null,
          reliabilityBins: this.computeReliabilityBins(pairs),
          status: 'CALIBRATION_EVIDENCE_INSUFFICIENT'
        },
        bootstrapDetails: {
          resamplingUnit: 'PROJECT',
          replicates: config.bootstrapReplicates,
          seed: config.bootstrapSeed,
          confidenceLevel: config.confidenceLevel
        },
        message: `${reason} Reporting premature statistical metrics is suppressed to prevent governance bias.`
      };
    }

    // When sample is sufficient, compute point metrics and project-level bootstrap
    const point = this.computePointMetrics(pairs);
    const bootstrap = this.runProjectLevelBootstrap(pairs, config);
    const relBins = this.computeReliabilityBins(pairs);

    const wrapCI = (metricKey: string): MetricWithCI => {
      const b = bootstrap.metrics[metricKey];
      return {
        estimate: b ? b.estimate : (point as any)[metricKey] || 0,
        ciLower: b ? b.ciLower : null,
        ciUpper: b ? b.ciUpper : null,
        method: `PROJECT_LEVEL_BOOTSTRAP_N${config.bootstrapReplicates}_SEED${config.bootstrapSeed}`
      };
    };

    const calibrationStatus = point.brierScore > 0.25
      ? 'CALIBRATION_REVIEW_REQUIRED'
      : 'CALIBRATION_EVIDENCE_SUFFICIENT';

    return {
      evaluationState: 'EVALUATION_READY',
      isStatisticallySufficient: true,
      totalObservations,
      uniqueProjects,
      matureObservations: totalObservations,
      delayedCount,
      onTimeCount,
      discrimination: {
        rocAuc: wrapCI('rocAuc'),
        prAuc: wrapCI('prAuc'),
        sensitivity: wrapCI('sensitivity'),
        specificity: wrapCI('specificity'),
        precision: wrapCI('precision'),
        npv: wrapCI('npv'),
        f1: wrapCI('f1'),
        balancedAccuracy: wrapCI('balancedAccuracy')
      },
      calibration: {
        brierScore: wrapCI('brierScore'),
        logLoss: {
          estimate: point.logLoss,
          ciLower: null,
          ciUpper: null,
          method: 'EMPIRICAL_LOG_LOSS'
        },
        calibrationIntercept: point.calibrationIntercept,
        calibrationSlope: point.calibrationSlope,
        ece: point.ece,
        reliabilityBins: relBins,
        status: calibrationStatus
      },
      bootstrapDetails: {
        resamplingUnit: 'PROJECT',
        replicates: config.bootstrapReplicates,
        seed: config.bootstrapSeed,
        confidenceLevel: config.confidenceLevel
      },
      message: `Evaluation completed successfully on ${totalObservations} mature observations across ${uniqueProjects} unique projects.`
    };
  }

  /**
   * Evaluates performance by temporal cohort (e.g. by observation year or outcome year)
   */
  public static evaluateTemporalCohorts(pairs: ObservationOutcomePair[]): {
    cohorts: {
      cohortKey: string;
      cohortLabel: string;
      sampleSize: number;
      projectCount: number;
      delayedCount: number;
      onTimeCount: number;
      rocAuc: number | null;
      brierScore: number | null;
      status: 'SUFFICIENT_SAMPLE' | 'TEMPORAL_EVIDENCE_INSUFFICIENT';
    }[];
    overallStatus: 'SUFFICIENT' | 'TEMPORAL_EVIDENCE_INSUFFICIENT';
  } {
    if (pairs.length === 0) {
      return { cohorts: [], overallStatus: 'TEMPORAL_EVIDENCE_INSUFFICIENT' };
    }

    // Group by observation year
    const groups = new Map<string, ObservationOutcomePair[]>();
    for (const p of pairs) {
      const yr = p.observationTimestamp ? p.observationTimestamp.substring(0, 4) : 'UNKNOWN';
      if (!groups.has(yr)) groups.set(yr, []);
      groups.get(yr)!.push(p);
    }

    const cohorts = Array.from(groups.entries()).map(([yr, obs]) => {
      const delayed = obs.filter(x => x.groundTruthLabel === 1).length;
      const onTime = obs.filter(x => x.groundTruthLabel === 0).length;
      const projCount = new Set(obs.map(x => x.projectId)).size;
      const isSufficient = obs.length >= 10 && delayed > 0 && onTime > 0;

      if (!isSufficient) {
        return {
          cohortKey: yr,
          cohortLabel: `Observation Year ${yr}`,
          sampleSize: obs.length,
          projectCount: projCount,
          delayedCount: delayed,
          onTimeCount: onTime,
          rocAuc: null,
          brierScore: null,
          status: 'TEMPORAL_EVIDENCE_INSUFFICIENT' as const
        };
      }

      const metrics = this.computePointMetrics(obs);
      return {
        cohortKey: yr,
        cohortLabel: `Observation Year ${yr}`,
        sampleSize: obs.length,
        projectCount: projCount,
        delayedCount: delayed,
        onTimeCount: onTime,
        rocAuc: metrics.rocAuc,
        brierScore: metrics.brierScore,
        status: 'SUFFICIENT_SAMPLE' as const
      };
    });

    const hasAnySufficient = cohorts.some(c => c.status === 'SUFFICIENT_SAMPLE');
    return {
      cohorts,
      overallStatus: hasAnySufficient ? 'SUFFICIENT' : 'TEMPORAL_EVIDENCE_INSUFFICIENT'
    };
  }

  /**
   * Evaluates performance by jurisdiction & operational segmentation
   */
  public static evaluateSegmentations(pairs: ObservationOutcomePair[]): {
    byState: {
      name: string;
      sampleSize: number;
      projectCount: number;
      delayedCount: number;
      onTimeCount: number;
      rocAuc: number | null;
      brierScore: number | null;
      status: 'SUFFICIENT_SAMPLE' | 'INSUFFICIENT_SAMPLE';
    }[];
    byAgency: {
      name: string;
      sampleSize: number;
      projectCount: number;
      delayedCount: number;
      onTimeCount: number;
      rocAuc: number | null;
      brierScore: number | null;
      status: 'SUFFICIENT_SAMPLE' | 'INSUFFICIENT_SAMPLE';
    }[];
  } {
    const groupMetrics = (map: Map<string, ObservationOutcomePair[]>) => {
      return Array.from(map.entries()).map(([name, obs]) => {
        const delayed = obs.filter(x => x.groundTruthLabel === 1).length;
        const onTime = obs.filter(x => x.groundTruthLabel === 0).length;
        const projCount = new Set(obs.map(x => x.projectId)).size;
        const isSufficient = obs.length >= 10 && delayed > 0 && onTime > 0;

        if (!isSufficient) {
          return {
            name,
            sampleSize: obs.length,
            projectCount: projCount,
            delayedCount: delayed,
            onTimeCount: onTime,
            rocAuc: null,
            brierScore: null,
            status: 'INSUFFICIENT_SAMPLE' as const
          };
        }

        const metrics = this.computePointMetrics(obs);
        return {
          name,
          sampleSize: obs.length,
          projectCount: projCount,
          delayedCount: delayed,
          onTimeCount: onTime,
          rocAuc: metrics.rocAuc,
          brierScore: metrics.brierScore,
          status: 'SUFFICIENT_SAMPLE' as const
        };
      });
    };

    const stateMap = new Map<string, ObservationOutcomePair[]>();
    const agencyMap = new Map<string, ObservationOutcomePair[]>();

    for (const p of pairs) {
      const state = p.stateJurisdiction || 'UNKNOWN';
      const agency = p.implementingAgency || 'UNKNOWN';

      if (!stateMap.has(state)) stateMap.set(state, []);
      stateMap.get(state)!.push(p);

      if (!agencyMap.has(agency)) agencyMap.set(agency, []);
      agencyMap.get(agency)!.push(p);
    }

    return {
      byState: groupMetrics(stateMap),
      byAgency: groupMetrics(agencyMap)
    };
  }

  /**
   * Diagnostic side-by-side comparison between V1 and V2 on eligible mature observations
   */
  public static compareV1AndV2Evaluation(pairs: ObservationOutcomePair[]): {
    evaluatedObservations: number;
    v1ComparabilityNote: string;
    v1: {
      rocAuc: number | null;
      brierScore: number | null;
      availableCount: number;
    };
    v2: {
      rocAuc: number | null;
      brierScore: number | null;
      availableCount: number;
    };
    disclaimer: string;
  } {
    const pairsWithV1 = pairs.filter(p => p.v1Probability !== null && p.v1Probability !== undefined);
    const v2Points = pairs.length >= 10 ? this.computePointMetrics(pairs) : null;

    let v1RocAuc: number | null = null;
    let v1Brier: number | null = null;

    if (pairsWithV1.length >= 10) {
      const v1Pairs: ObservationOutcomePair[] = pairsWithV1.map(p => ({
        ...p,
        predictedProbability: p.v1Probability!
      }));
      const v1Points = this.computePointMetrics(v1Pairs);
      v1RocAuc = v1Points.rocAuc;
      v1Brier = v1Points.brierScore;
    }

    return {
      evaluatedObservations: pairs.length,
      v1ComparabilityNote: pairsWithV1.length === pairs.length
        ? 'Full scoring overlap across mature cohort'
        : `Partial overlap: V1 scored ${pairsWithV1.length} of ${pairs.length} observations`,
      v1: {
        rocAuc: v1RocAuc,
        brierScore: v1Brier,
        availableCount: pairsWithV1.length
      },
      v2: {
        rocAuc: v2Points ? v2Points.rocAuc : null,
        brierScore: v2Points ? v2Points.brierScore : null,
        availableCount: pairs.length
      },
      disclaimer: 'Comparative diagnostic evidence only. No production model decision or replacement is made here. V1 remains authoritative.'
    };
  }
}
