/**
 * BHOOMI-DRISHTI PHASE 7B-6: SHADOW MONITORING DATA STORE
 * 
 * Provides durable, isolated monitoring schemas for the V2 shadow candidate model:
 * 1. shadow_prediction_monitoring (prediction history snapshots)
 * 2. shadow_feature_monitoring (10-feature longitudinal vectors at observation time)
 * 3. shadow_monitoring_runs (periodic & on-demand monitoring run summaries)
 * 4. shadow_eventual_outcomes (authoritative retrospective ground-truth reconciliation)
 * 
 * Safety invariants:
 * - V2 remains non-operational (is_operational = 0)
 * - Threshold governance remains PENDING_STAKEHOLDER_APPROVAL
 * - Zero mutation to operational projects or production risk scores
 */

import { DatabaseSync } from 'node:sqlite';
import { getDatabase } from '../database.ts';
import { ShadowFeatureVector } from './shadowFeatureSchema.ts';

export interface ShadowPredictionMonitoringRecord {
  monitoring_id: string;
  shadow_run_id: string;
  project_id: string;
  observation_timestamp: string;
  model_version: string;
  model_artifact_sha256: string;
  dataset_version: string;
  prediction_probability: number | null;
  prediction_state: string;
  evidence_status: string;
  validation_status: string;
  feature_snapshot_hash: string;
  scoring_timestamp: string;
  monitoring_timestamp: string;
  is_operational: number;
}

export interface ShadowFeatureMonitoringRecord {
  monitoring_id: string;
  project_id: string;
  observation_timestamp: string;
  elapsed_days_since_first_3a: number;
  cumulative_notifications_count_at_t: number;
  notification_cadence_days: number;
  days_since_last_notification: number;
  statutory_stage_at_t: string;
  statutory_notification_frequency_180d: number;
  total_land_required_ha: number;
  implementing_agency: string;
  state_jurisdiction: string;
  initial_sanction_available_at_t: number;
  recorded_at: string;
}

export interface ShadowMonitoringRunRecord {
  monitoring_run_id: string;
  started_at: string;
  completed_at: string;
  population_count: number;
  complete_evidence_count: number;
  insufficient_evidence_count: number;
  drift_status: 'STABLE' | 'REVIEW' | 'DRIFT_DETECTED';
  prediction_drift_status: 'STABLE' | 'REVIEW' | 'DRIFT_DETECTED';
  feature_drift_status: 'STABLE' | 'REVIEW' | 'DRIFT_DETECTED';
  outcome_status: 'STABLE' | 'OUTCOME_DATA_INSUFFICIENT' | 'CALIBRATION_REVIEW_REQUIRED';
  overall_status: 'STABLE' | 'REVIEW' | 'DRIFT_DETECTED' | 'DATA_QUALITY_DEGRADED' | 'OUTCOME_DATA_INSUFFICIENT';
  model_version: string;
  model_sha256: string;
  metrics_json: string;
}

export interface ShadowEventualOutcomeRecord {
  outcome_id: string;
  project_id: string;
  shadow_run_id: string;
  observation_timestamp: string;
  prediction_probability: number | null;
  first_3a_date: string;
  section_3d_date: string | null;
  outcome_timestamp: string | null;
  statutory_outcome: 'COMPLETED_ON_TIME' | 'DELAYED_LAPSED' | 'OUTCOME_PENDING' | 'INSUFFICIENT_EVIDENCE';
  outcome_window_days: number | null;
  reconciled_at: string;
  provenance_reference: string | null;
  is_mature: number;
}

let tablesInitialized = false;

export function initShadowMonitoringTables(dbInstance?: DatabaseSync): DatabaseSync {
  const db = dbInstance || getDatabase();
  if (tablesInitialized) return db;

  db.exec(`
    -- 1. Shadow Prediction Monitoring Log
    CREATE TABLE IF NOT EXISTS shadow_prediction_monitoring (
      monitoring_id TEXT PRIMARY KEY,
      shadow_run_id TEXT NOT NULL,
      project_id TEXT NOT NULL,
      observation_timestamp TEXT NOT NULL,
      model_version TEXT NOT NULL,
      model_artifact_sha256 TEXT NOT NULL,
      dataset_version TEXT NOT NULL,
      prediction_probability REAL,
      prediction_state TEXT NOT NULL,
      evidence_status TEXT NOT NULL,
      validation_status TEXT NOT NULL,
      feature_snapshot_hash TEXT NOT NULL,
      scoring_timestamp TEXT NOT NULL,
      monitoring_timestamp TEXT NOT NULL,
      is_operational INTEGER NOT NULL DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS idx_spm_proj 
      ON shadow_prediction_monitoring(project_id);
    CREATE INDEX IF NOT EXISTS idx_spm_run 
      ON shadow_prediction_monitoring(shadow_run_id);
    CREATE INDEX IF NOT EXISTS idx_spm_timestamp 
      ON shadow_prediction_monitoring(monitoring_timestamp);

    -- 2. Shadow Feature Monitoring Snapshot
    CREATE TABLE IF NOT EXISTS shadow_feature_monitoring (
      monitoring_id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      observation_timestamp TEXT NOT NULL,
      elapsed_days_since_first_3a REAL NOT NULL,
      cumulative_notifications_count_at_t REAL NOT NULL,
      notification_cadence_days REAL NOT NULL,
      days_since_last_notification REAL NOT NULL,
      statutory_stage_at_t TEXT NOT NULL,
      statutory_notification_frequency_180d REAL NOT NULL,
      total_land_required_ha REAL NOT NULL,
      implementing_agency TEXT NOT NULL,
      state_jurisdiction TEXT NOT NULL,
      initial_sanction_available_at_t INTEGER NOT NULL,
      recorded_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_sfm_proj 
      ON shadow_feature_monitoring(project_id);

    -- 3. Shadow Monitoring Runs Ledger
    CREATE TABLE IF NOT EXISTS shadow_monitoring_runs (
      monitoring_run_id TEXT PRIMARY KEY,
      started_at TEXT NOT NULL,
      completed_at TEXT NOT NULL,
      population_count INTEGER NOT NULL,
      complete_evidence_count INTEGER NOT NULL,
      insufficient_evidence_count INTEGER NOT NULL,
      drift_status TEXT NOT NULL,
      prediction_drift_status TEXT NOT NULL,
      feature_drift_status TEXT NOT NULL,
      outcome_status TEXT NOT NULL,
      overall_status TEXT NOT NULL,
      model_version TEXT NOT NULL,
      model_sha256 TEXT NOT NULL,
      metrics_json TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_smr_completed 
      ON shadow_monitoring_runs(completed_at);

    -- 4. Eventual Statutory Outcome Reconciliation
    CREATE TABLE IF NOT EXISTS shadow_eventual_outcomes (
      outcome_id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      shadow_run_id TEXT NOT NULL,
      observation_timestamp TEXT NOT NULL,
      prediction_probability REAL,
      first_3a_date TEXT NOT NULL,
      section_3d_date TEXT,
      outcome_timestamp TEXT,
      statutory_outcome TEXT NOT NULL,
      outcome_window_days INTEGER,
      reconciled_at TEXT NOT NULL,
      provenance_reference TEXT,
      is_mature INTEGER NOT NULL DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS idx_seo_proj 
      ON shadow_eventual_outcomes(project_id);
    CREATE INDEX IF NOT EXISTS idx_seo_mature 
      ON shadow_eventual_outcomes(is_mature);
  `);

  tablesInitialized = true;
  return db;
}

export class ShadowMonitoringStore {
  public static recordPredictionMonitoring(rec: ShadowPredictionMonitoringRecord): void {
    const db = initShadowMonitoringTables();
    db.prepare(`
      INSERT OR REPLACE INTO shadow_prediction_monitoring (
        monitoring_id, shadow_run_id, project_id, observation_timestamp,
        model_version, model_artifact_sha256, dataset_version, prediction_probability,
        prediction_state, evidence_status, validation_status, feature_snapshot_hash,
        scoring_timestamp, monitoring_timestamp, is_operational
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      rec.monitoring_id, rec.shadow_run_id, rec.project_id, rec.observation_timestamp,
      rec.model_version, rec.model_artifact_sha256, rec.dataset_version, rec.prediction_probability,
      rec.prediction_state, rec.evidence_status, rec.validation_status, rec.feature_snapshot_hash,
      rec.scoring_timestamp, rec.monitoring_timestamp, rec.is_operational
    );
  }

  public static recordFeatureMonitoring(rec: ShadowFeatureMonitoringRecord): void {
    const db = initShadowMonitoringTables();
    db.prepare(`
      INSERT OR REPLACE INTO shadow_feature_monitoring (
        monitoring_id, project_id, observation_timestamp,
        elapsed_days_since_first_3a, cumulative_notifications_count_at_t,
        notification_cadence_days, days_since_last_notification,
        statutory_stage_at_t, statutory_notification_frequency_180d,
        total_land_required_ha, implementing_agency, state_jurisdiction,
        initial_sanction_available_at_t, recorded_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      rec.monitoring_id, rec.project_id, rec.observation_timestamp,
      rec.elapsed_days_since_first_3a, rec.cumulative_notifications_count_at_t,
      rec.notification_cadence_days, rec.days_since_last_notification,
      rec.statutory_stage_at_t, rec.statutory_notification_frequency_180d,
      rec.total_land_required_ha, rec.implementing_agency, rec.state_jurisdiction,
      rec.initial_sanction_available_at_t, rec.recorded_at
    );
  }

  public static recordMonitoringRun(run: ShadowMonitoringRunRecord): void {
    const db = initShadowMonitoringTables();
    db.prepare(`
      INSERT OR REPLACE INTO shadow_monitoring_runs (
        monitoring_run_id, started_at, completed_at, population_count,
        complete_evidence_count, insufficient_evidence_count, drift_status,
        prediction_drift_status, feature_drift_status, outcome_status,
        overall_status, model_version, model_sha256, metrics_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      run.monitoring_run_id, run.started_at, run.completed_at, run.population_count,
      run.complete_evidence_count, run.insufficient_evidence_count, run.drift_status,
      run.prediction_drift_status, run.feature_drift_status, run.outcome_status,
      run.overall_status, run.model_version, run.model_sha256, run.metrics_json
    );
  }

  public static recordOutcome(outcome: ShadowEventualOutcomeRecord): void {
    const db = initShadowMonitoringTables();
    db.prepare(`
      INSERT OR REPLACE INTO shadow_eventual_outcomes (
        outcome_id, project_id, shadow_run_id, observation_timestamp,
        prediction_probability, first_3a_date, section_3d_date,
        outcome_timestamp, statutory_outcome, outcome_window_days,
        reconciled_at, provenance_reference, is_mature
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      outcome.outcome_id, outcome.project_id, outcome.shadow_run_id, outcome.observation_timestamp,
      outcome.prediction_probability, outcome.first_3a_date, outcome.section_3d_date,
      outcome.outcome_timestamp, outcome.statutory_outcome, outcome.outcome_window_days,
      outcome.reconciled_at, outcome.provenance_reference, outcome.is_mature
    );
  }

  public static getLatestMonitoringRun(): ShadowMonitoringRunRecord | null {
    const db = initShadowMonitoringTables();
    const row = db.prepare('SELECT * FROM shadow_monitoring_runs ORDER BY completed_at DESC LIMIT 1').get();
    return (row as unknown as ShadowMonitoringRunRecord) || null;
  }

  public static getMonitoringRuns(limit: number = 20): ShadowMonitoringRunRecord[] {
    const db = initShadowMonitoringTables();
    return db.prepare('SELECT * FROM shadow_monitoring_runs ORDER BY completed_at DESC LIMIT ?').all(limit) as unknown as ShadowMonitoringRunRecord[];
  }

  public static getRecentFeatureSnapshots(limit: number = 50): ShadowFeatureMonitoringRecord[] {
    const db = initShadowMonitoringTables();
    return db.prepare('SELECT * FROM shadow_feature_monitoring ORDER BY recorded_at DESC LIMIT ?').all(limit) as unknown as ShadowFeatureMonitoringRecord[];
  }

  public static getOutcomes(): ShadowEventualOutcomeRecord[] {
    const db = initShadowMonitoringTables();
    return db.prepare('SELECT * FROM shadow_eventual_outcomes ORDER BY reconciled_at DESC').all() as unknown as ShadowEventualOutcomeRecord[];
  }
}
