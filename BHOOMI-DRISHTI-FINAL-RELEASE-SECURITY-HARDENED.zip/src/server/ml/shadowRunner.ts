/**
 * BHOOMI-DRISHTI PHASE 6A: ISOLATED SHADOW SCORING RUNNER
 * 
 * Non-operational candidate scoring execution engine.
 * 
 * Absolute Safety Rules:
 * 1. NEVER writes to projects, project_stages, alerts, or recommendations.
 * 2. NEVER alters production risk state or dashboard outputs.
 * 3. Enforces Point-in-Time Evidence Gate prior to model invocation.
 * 4. Stores outputs strictly in isolated shadow_predictions table.
 * 5. Uses PENDING_STAKEHOLDER_APPROVAL placeholders for thresholds.
 * 6. Records all executions in immutable audit_logs.
 */

import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { DatabaseSync } from 'node:sqlite';
import { SHADOW_FEATURE_SCHEMA_VERSION, computeFeatureSnapshotHash, ShadowFeatureVector } from './shadowFeatureSchema.ts';
import { validateShadowEvidence, ShadowEvidenceInput, EvidenceGateResult } from './shadowEvidenceGate.ts';
import { AuditService } from '../auditService.ts';
import { AuthUser } from '../auth.ts';

// Governance Configuration Placeholders (Phase 5C Policy)
export const SHADOW_POLICY_CONFIG = {
  HIGHER_RISK_THRESHOLD: 'PENDING_STAKEHOLDER_APPROVAL',
  LOWER_RISK_THRESHOLD: 'PENDING_STAKEHOLDER_APPROVAL',
  COST_MATRIX_VERSION: 'PENDING_STAKEHOLDER_APPROVAL',
  CANDIDATE_MODEL_DIR: 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/',
  CANDIDATE_MODEL_PATH: 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_pipeline.joblib',
  CANDIDATE_MODEL_VERSION: 'BHOOMI-DRISHTI-ML-V2.0-SHADOW',
  DATASET_VERSION: '2.0.0-phase4c-authentic',
  DATASET_SHA256: '0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a',
  SCHEMA_VERSION: SHADOW_FEATURE_SCHEMA_VERSION
} as const;

export type ShadowPredictionState = 'HIGHER_RISK_SIGNAL' | 'LOWER_RISK_SIGNAL' | 'INSUFFICIENT_EVIDENCE';
export type ShadowEvidenceStatus = 'COMPLETE' | 'PARTIAL' | 'INVALID';
export type ShadowValidationStatus = 'PASS' | 'OUT_OF_BOUNDS' | 'DRIFT_DETECTED';

export interface ShadowRecord {
  shadow_run_id: string;
  project_id: string;
  observation_timestamp: string;
  model_version: string;
  model_artifact_sha256: string;
  dataset_version: string;
  prediction_probability: number | null;
  prediction_state: ShadowPredictionState;
  feature_snapshot_hash: string;
  scoring_timestamp: string;
  evidence_status: ShadowEvidenceStatus;
  validation_status: ShadowValidationStatus;
}

export interface ShadowRunExecutionResult {
  success: boolean;
  shadowRecord: ShadowRecord;
  evidenceResult: EvidenceGateResult;
  candidateProbability?: number | null;
  auditLogId?: string;
  notes: string[];
}

/**
 * Executes deterministic offline inference against the isolated V2 candidate pipeline.
 * Does not mutate any databases or operational states.
 */
export function scoreCandidateArtifact(vector: ShadowFeatureVector): number {
  const pyCode = `
import sys, json, joblib, pandas as pd
payload = json.loads(sys.stdin.read())
p = joblib.load('${SHADOW_POLICY_CONFIG.CANDIDATE_MODEL_PATH}')
df = pd.DataFrame([payload])
prob = float(p.predict_proba(df)[0, 1])
print(prob)
`;
  const out = execFileSync('python3', ['-c', pyCode], {
    input: JSON.stringify(vector),
    encoding: 'utf-8'
  }).trim();
  const prob = parseFloat(out);
  if (isNaN(prob)) {
    throw new Error(`Failed to parse candidate probability output: ${out}`);
  }
  return prob;
}

/**
 * Ensures the isolated shadow_predictions table and indexes exist.
 * Does not alter or touch any operational project tables.
 */
export function ensureShadowStorage(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS shadow_predictions (
      shadow_run_id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      observation_timestamp TEXT NOT NULL,
      model_version TEXT NOT NULL,
      model_artifact_sha256 TEXT NOT NULL,
      dataset_version TEXT NOT NULL,
      prediction_probability REAL,
      prediction_state TEXT NOT NULL CHECK(prediction_state IN ('HIGHER_RISK_SIGNAL', 'LOWER_RISK_SIGNAL', 'INSUFFICIENT_EVIDENCE')),
      feature_snapshot_hash TEXT NOT NULL,
      scoring_timestamp TEXT NOT NULL,
      evidence_status TEXT NOT NULL CHECK(evidence_status IN ('COMPLETE', 'PARTIAL', 'INVALID')),
      validation_status TEXT NOT NULL CHECK(validation_status IN ('PASS', 'OUT_OF_BOUNDS', 'DRIFT_DETECTED'))
    );

    CREATE INDEX IF NOT EXISTS idx_shadow_predictions_project_id ON shadow_predictions(project_id);
    CREATE INDEX IF NOT EXISTS idx_shadow_predictions_obs_timestamp ON shadow_predictions(observation_timestamp);
    CREATE INDEX IF NOT EXISTS idx_shadow_predictions_model_version ON shadow_predictions(model_version);
    CREATE INDEX IF NOT EXISTS idx_shadow_predictions_scoring_time ON shadow_predictions(scoring_timestamp);
    CREATE INDEX IF NOT EXISTS idx_shadow_predictions_pred_state ON shadow_predictions(prediction_state);
  `);
}

/**
 * Checks candidate model artifact existence and computes SHA-256.
 * Adheres strictly to rule: "If the candidate model artifact does not yet exist,
 * STOP before inventing/training one."
 */
export function inspectCandidateArtifact(): { exists: boolean; path: string; sha256: string } {
  const fullPath = path.resolve(process.cwd(), SHADOW_POLICY_CONFIG.CANDIDATE_MODEL_PATH);
  if (!fs.existsSync(fullPath)) {
    return {
      exists: false,
      path: SHADOW_POLICY_CONFIG.CANDIDATE_MODEL_PATH,
      sha256: 'UNPROVISIONED_PENDING_TRAINING'
    };
  }
  const fileBuf = fs.readFileSync(fullPath);
  const sha = crypto.createHash('sha256').update(fileBuf).digest('hex');
  return {
    exists: true,
    path: SHADOW_POLICY_CONFIG.CANDIDATE_MODEL_PATH,
    sha256: sha
  };
}

/**
 * Executes an isolated shadow scoring evaluation for an observation.
 * 
 * Guarantees:
 * - Evidence gate strictly evaluated first.
 * - Deterministic feature snapshot hash computed.
 * - If evidence fails or artifact is unprovisioned or policy is unapproved:
 *   prediction_state is strictly INSUFFICIENT_EVIDENCE.
 * - Writes ONLY to shadow_predictions and audit_logs.
 * - Operational project records are completely untouched.
 */
export function executeShadowScoring(
  db: DatabaseSync,
  input: ShadowEvidenceInput,
  user?: AuthUser
): ShadowRunExecutionResult {
  ensureShadowStorage(db);
  const nowIso = new Date().toISOString();
  const shadowRunId = input.shadow_run_id || `SHD_${crypto.randomUUID()}`;
  const notes: string[] = [];

  // Step 1: Evidence Gate Evaluation
  const evidenceResult = validateShadowEvidence(input);
  for (const r of evidenceResult.reasons) {
    notes.push(`EvidenceGate: ${r}`);
  }

  // Step 2: Compute deterministic feature snapshot hash
  let snapshotHash: string;
  if (evidenceResult.normalizedVector) {
    snapshotHash = computeFeatureSnapshotHash(evidenceResult.normalizedVector);
  } else {
    // Deterministic fallback hash for partial payload
    const sortedRaw = Object.keys(input.features || {})
      .sort()
      .map(k => `${k}:${input.features[k]}`)
      .join('|');
    snapshotHash = crypto.createHash('sha256').update(sortedRaw, 'utf-8').digest('hex');
  }

  // Step 3: Inspect Candidate Artifact
  const artifactStatus = inspectCandidateArtifact();
  if (!artifactStatus.exists) {
    notes.push('CandidateModel: Artifact not yet provisioned at designated path. Adhering to Phase 6A freeze.');
  }

  // Step 4: Policy & State Determination
  // Threshold policy is PENDING_STAKEHOLDER_APPROVAL; operational decisions cannot be emitted
  let predictionState: ShadowPredictionState = 'INSUFFICIENT_EVIDENCE';
  let predictionProb: number | null = null;
  let candidateProb: number | null = null;

  if (evidenceResult.passed && artifactStatus.exists) {
    try {
      candidateProb = scoreCandidateArtifact(evidenceResult.normalizedVector!);
      notes.push(`V2CandidateProbability: ${candidateProb}`);
    } catch (e: any) {
      notes.push(`V2InferenceError: ${e.message}`);
    }
    // Threshold policy is PENDING_STAKEHOLDER_APPROVAL; operational decisions cannot be emitted
    notes.push('PolicyGate: Operational thresholds are PENDING_STAKEHOLDER_APPROVAL. Emitting INSUFFICIENT_EVIDENCE.');
  } else {
    notes.push(`EvidenceStatus: ${evidenceResult.evidence_status}, ValidationStatus: ${evidenceResult.validation_status}`);
  }

  const shadowRecord: ShadowRecord = {
    shadow_run_id: shadowRunId,
    project_id: input.project_id,
    observation_timestamp: input.observation_timestamp,
    model_version: SHADOW_POLICY_CONFIG.CANDIDATE_MODEL_VERSION,
    model_artifact_sha256: artifactStatus.sha256,
    dataset_version: SHADOW_POLICY_CONFIG.DATASET_VERSION,
    prediction_probability: predictionProb,
    prediction_state: predictionState,
    feature_snapshot_hash: snapshotHash,
    scoring_timestamp: nowIso,
    evidence_status: evidenceResult.evidence_status,
    validation_status: evidenceResult.validation_status
  };

  // Step 5: Isolated write to shadow_predictions
  db.prepare(`
    INSERT INTO shadow_predictions (
      shadow_run_id, project_id, observation_timestamp, model_version,
      model_artifact_sha256, dataset_version, prediction_probability,
      prediction_state, feature_snapshot_hash, scoring_timestamp,
      evidence_status, validation_status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    shadowRecord.shadow_run_id,
    shadowRecord.project_id,
    shadowRecord.observation_timestamp,
    shadowRecord.model_version,
    shadowRecord.model_artifact_sha256,
    shadowRecord.dataset_version,
    shadowRecord.prediction_probability,
    shadowRecord.prediction_state,
    shadowRecord.feature_snapshot_hash,
    shadowRecord.scoring_timestamp,
    shadowRecord.evidence_status,
    shadowRecord.validation_status
  );

  // Step 6: Immutable Audit Logging
  const auditEntry = AuditService.record(db, {
    userId: user?.id || 'SYSTEM_SHADOW_RUNNER',
    userName: user?.name || 'Shadow Runner Engine',
    userRole: user?.role || 'NODAL_OFFICER',
    action: 'SHADOW_SCORING_RUN',
    resource: 'shadow_predictions',
    resourceId: shadowRunId,
    result: 'SUCCESS',
    details: {
      shadow_run_id: shadowRunId,
      project_id: input.project_id,
      model_version: shadowRecord.model_version,
      artifact_sha: shadowRecord.model_artifact_sha256,
      scoring_timestamp: nowIso,
      prediction_state: shadowRecord.prediction_state,
      evidence_status: shadowRecord.evidence_status,
      validation_status: shadowRecord.validation_status,
      feature_snapshot_hash: snapshotHash,
      candidate_probability: candidateProb
    }
  });

  return {
    success: true,
    shadowRecord,
    evidenceResult,
    candidateProbability: candidateProb,
    auditLogId: auditEntry.id,
    notes
  };
}

/**
 * Queries shadow predictions with pagination and optional state/project filters.
 */
export function queryShadowPredictions(
  db: DatabaseSync,
  params?: {
    projectId?: string;
    predictionState?: string;
    limit?: number;
    offset?: number;
  }
): { records: ShadowRecord[]; total: number } {
  ensureShadowStorage(db);
  const limit = Math.min(params?.limit || 50, 200);
  const offset = params?.offset || 0;

  const whereClauses: string[] = [];
  const args: any[] = [];

  if (params?.projectId) {
    whereClauses.push('project_id = ?');
    args.push(params.projectId);
  }
  if (params?.predictionState) {
    whereClauses.push('prediction_state = ?');
    args.push(params.predictionState);
  }

  const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

  const total = (db.prepare(`SELECT count(*) as c FROM shadow_predictions ${whereSql}`).get(...args) as any).c;
  const records = db.prepare(`
    SELECT * FROM shadow_predictions ${whereSql}
    ORDER BY scoring_timestamp DESC
    LIMIT ? OFFSET ?
  `).all(...args, limit, offset) as unknown as ShadowRecord[];

  return { records, total };
}
