/**
 * BHOOMI-DRISHTI PHASE 7B-7: SHADOW EVALUATION DATA STORE & AUDIT LEDGER
 * 
 * Provides immutable, durable audit tables for V2 model-vs-outcome evaluation:
 * 1. shadow_evaluation_runs (immutable ledger of evaluation runs, metrics, and CI configs)
 * 2. shadow_evaluation_exclusions (traceable ledger of excluded prediction/outcome pairs)
 * 3. shadow_evaluation_records (point-in-time point-by-point joined dataset records)
 * 4. shadow_evaluation_manifest (persisted JSON evaluation manifests)
 * 
 * Strict safety invariants:
 * - V2 remains non-operational
 * - Threshold governance remains strictly PENDING_STAKEHOLDER_APPROVAL
 * - Zero modification to production V1 artifact, operational risk scores, or operational projects
 */

import { DatabaseSync } from 'node:sqlite';
import { getDatabase } from '../database.ts';

export interface ShadowEvaluationRunRecord {
  run_id: string;
  run_timestamp: string;
  model_version: string;
  model_artifact_sha256: string;
  dataset_version: string;
  evaluation_dataset_sha256: string;
  evaluation_scope: string;
  eligible_projects: number;
  eligible_observations: number;
  mature_projects: number;
  mature_observations: number;
  excluded_projects: number;
  excluded_observations: number;
  exclusion_reasons: string; // JSON
  roc_auc: number | null;
  pr_auc: number | null;
  brier_score: number | null;
  log_loss: number | null;
  precision: number | null;
  recall: number | null;
  specificity: number | null;
  npv: number | null;
  f1: number | null;
  balanced_accuracy: number | null;
  calibration_intercept: number | null;
  calibration_slope: number | null;
  ece: number | null;
  confidence_interval_method: string;
  bootstrap_seed: number;
  bootstrap_replicates: number;
  evaluation_state: string;
  created_by: string;
  created_at: string;
}

export interface ShadowEvaluationExclusionRecord {
  exclusion_id: string;
  run_id: string;
  project_id: string;
  observation_timestamp: string;
  reason: string;
  details: string;
  recorded_at: string;
}

export interface ShadowEvaluationJoinedRecord {
  eval_record_id: string;
  run_id: string;
  project_id: string;
  observation_timestamp: string;
  prediction_probability: number;
  model_version: string;
  model_artifact_sha256: string;
  dataset_version: string;
  feature_snapshot_hash: string;
  outcome_event_timestamp: string;
  outcome_type: string;
  outcome_maturity_timestamp: string;
  evaluation_timestamp: string;
  ground_truth_label: number; // 1 = delayed, 0 = on-time
  is_mature: number;
}

let tablesInitialized = false;

export function initShadowEvaluationTables(dbInstance?: DatabaseSync): DatabaseSync {
  const db = dbInstance || getDatabase();
  if (tablesInitialized) return db;

  db.exec(`
    -- 1. Immutable Evaluation Runs Ledger
    CREATE TABLE IF NOT EXISTS shadow_evaluation_runs (
      run_id TEXT PRIMARY KEY,
      run_timestamp TEXT NOT NULL,
      model_version TEXT NOT NULL,
      model_artifact_sha256 TEXT NOT NULL,
      dataset_version TEXT NOT NULL,
      evaluation_dataset_sha256 TEXT NOT NULL,
      evaluation_scope TEXT NOT NULL,
      eligible_projects INTEGER NOT NULL,
      eligible_observations INTEGER NOT NULL,
      mature_projects INTEGER NOT NULL,
      mature_observations INTEGER NOT NULL,
      excluded_projects INTEGER NOT NULL,
      excluded_observations INTEGER NOT NULL,
      exclusion_reasons TEXT NOT NULL,
      roc_auc REAL,
      pr_auc REAL,
      brier_score REAL,
      log_loss REAL,
      precision REAL,
      recall REAL,
      specificity REAL,
      npv REAL,
      f1 REAL,
      balanced_accuracy REAL,
      calibration_intercept REAL,
      calibration_slope REAL,
      ece REAL,
      confidence_interval_method TEXT NOT NULL,
      bootstrap_seed INTEGER NOT NULL,
      bootstrap_replicates INTEGER NOT NULL,
      evaluation_state TEXT NOT NULL,
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_ser_timestamp 
      ON shadow_evaluation_runs(run_timestamp);
    CREATE INDEX IF NOT EXISTS idx_ser_state 
      ON shadow_evaluation_runs(evaluation_state);

    -- 2. Evaluation Exclusion Ledger
    CREATE TABLE IF NOT EXISTS shadow_evaluation_exclusions (
      exclusion_id TEXT PRIMARY KEY,
      run_id TEXT NOT NULL,
      project_id TEXT NOT NULL,
      observation_timestamp TEXT NOT NULL,
      reason TEXT NOT NULL,
      details TEXT NOT NULL,
      recorded_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_see_run 
      ON shadow_evaluation_exclusions(run_id);
    CREATE INDEX IF NOT EXISTS idx_see_proj 
      ON shadow_evaluation_exclusions(project_id);
    CREATE INDEX IF NOT EXISTS idx_see_reason 
      ON shadow_evaluation_exclusions(reason);

    -- 3. Point-in-Time Joined Evaluation Records
    CREATE TABLE IF NOT EXISTS shadow_evaluation_records (
      eval_record_id TEXT PRIMARY KEY,
      run_id TEXT NOT NULL,
      project_id TEXT NOT NULL,
      observation_timestamp TEXT NOT NULL,
      prediction_probability REAL NOT NULL,
      model_version TEXT NOT NULL,
      model_artifact_sha256 TEXT NOT NULL,
      dataset_version TEXT NOT NULL,
      feature_snapshot_hash TEXT NOT NULL,
      outcome_event_timestamp TEXT NOT NULL,
      outcome_type TEXT NOT NULL,
      outcome_maturity_timestamp TEXT NOT NULL,
      evaluation_timestamp TEXT NOT NULL,
      ground_truth_label INTEGER NOT NULL,
      is_mature INTEGER NOT NULL DEFAULT 1
    );

    CREATE INDEX IF NOT EXISTS idx_sev_run 
      ON shadow_evaluation_records(run_id);
    CREATE INDEX IF NOT EXISTS idx_sev_proj 
      ON shadow_evaluation_records(project_id);

    -- 4. Persisted Evaluation Manifests
    CREATE TABLE IF NOT EXISTS shadow_evaluation_manifests (
      manifest_id TEXT PRIMARY KEY,
      run_id TEXT NOT NULL,
      manifest_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_sem_run 
      ON shadow_evaluation_manifests(run_id);
  `);

  tablesInitialized = true;
  return db;
}

export class ShadowEvaluationStore {
  public static recordRun(run: ShadowEvaluationRunRecord): void {
    const db = initShadowEvaluationTables();
    db.prepare(`
      INSERT OR REPLACE INTO shadow_evaluation_runs (
        run_id, run_timestamp, model_version, model_artifact_sha256,
        dataset_version, evaluation_dataset_sha256, evaluation_scope,
        eligible_projects, eligible_observations, mature_projects, mature_observations,
        excluded_projects, excluded_observations, exclusion_reasons,
        roc_auc, pr_auc, brier_score, log_loss, precision, recall, specificity, npv, f1,
        balanced_accuracy, calibration_intercept, calibration_slope, ece,
        confidence_interval_method, bootstrap_seed, bootstrap_replicates,
        evaluation_state, created_by, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      run.run_id,
      run.run_timestamp,
      run.model_version,
      run.model_artifact_sha256,
      run.dataset_version,
      run.evaluation_dataset_sha256,
      run.evaluation_scope,
      run.eligible_projects,
      run.eligible_observations,
      run.mature_projects,
      run.mature_observations,
      run.excluded_projects,
      run.excluded_observations,
      run.exclusion_reasons,
      run.roc_auc,
      run.pr_auc,
      run.brier_score,
      run.log_loss,
      run.precision,
      run.recall,
      run.specificity,
      run.npv,
      run.f1,
      run.balanced_accuracy,
      run.calibration_intercept,
      run.calibration_slope,
      run.ece,
      run.confidence_interval_method,
      run.bootstrap_seed,
      run.bootstrap_replicates,
      run.evaluation_state,
      run.created_by,
      run.created_at
    );
  }

  public static recordExclusion(ex: ShadowEvaluationExclusionRecord): void {
    const db = initShadowEvaluationTables();
    db.prepare(`
      INSERT OR REPLACE INTO shadow_evaluation_exclusions (
        exclusion_id, run_id, project_id, observation_timestamp,
        reason, details, recorded_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      ex.exclusion_id,
      ex.run_id,
      ex.project_id,
      ex.observation_timestamp,
      ex.reason,
      ex.details,
      ex.recorded_at
    );
  }

  public static recordJoinedRecord(rec: ShadowEvaluationJoinedRecord): void {
    const db = initShadowEvaluationTables();
    db.prepare(`
      INSERT OR REPLACE INTO shadow_evaluation_records (
        eval_record_id, run_id, project_id, observation_timestamp,
        prediction_probability, model_version, model_artifact_sha256,
        dataset_version, feature_snapshot_hash, outcome_event_timestamp,
        outcome_type, outcome_maturity_timestamp, evaluation_timestamp,
        ground_truth_label, is_mature
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      rec.eval_record_id,
      rec.run_id,
      rec.project_id,
      rec.observation_timestamp,
      rec.prediction_probability,
      rec.model_version,
      rec.model_artifact_sha256,
      rec.dataset_version,
      rec.feature_snapshot_hash,
      rec.outcome_event_timestamp,
      rec.outcome_type,
      rec.outcome_maturity_timestamp,
      rec.evaluation_timestamp,
      rec.ground_truth_label,
      rec.is_mature
    );
  }

  public static recordManifest(manifestId: string, runId: string, manifestJson: string): void {
    const db = initShadowEvaluationTables();
    db.prepare(`
      INSERT OR REPLACE INTO shadow_evaluation_manifests (
        manifest_id, run_id, manifest_json, created_at
      ) VALUES (?, ?, ?, ?)
    `).run(manifestId, runId, manifestJson, new Date().toISOString());
  }

  public static getLatestRun(): ShadowEvaluationRunRecord | null {
    const db = initShadowEvaluationTables();
    const row = db.prepare(`
      SELECT * FROM shadow_evaluation_runs 
      ORDER BY run_timestamp DESC LIMIT 1
    `).get() as any;
    return row || null;
  }

  public static getRuns(limit: number = 20): ShadowEvaluationRunRecord[] {
    const db = initShadowEvaluationTables();
    const rows = db.prepare(`
      SELECT * FROM shadow_evaluation_runs 
      ORDER BY run_timestamp DESC LIMIT ?
    `).all(limit) as any[];
    return rows;
  }

  public static getExclusions(runId?: string): ShadowEvaluationExclusionRecord[] {
    const db = initShadowEvaluationTables();
    if (runId) {
      return db.prepare(`
        SELECT * FROM shadow_evaluation_exclusions 
        WHERE run_id = ? 
        ORDER BY recorded_at DESC
      `).all(runId) as any[];
    }
    return db.prepare(`
      SELECT * FROM shadow_evaluation_exclusions 
      ORDER BY recorded_at DESC LIMIT 100
    `).all() as any[];
  }

  public static getJoinedRecords(runId: string): ShadowEvaluationJoinedRecord[] {
    const db = initShadowEvaluationTables();
    return db.prepare(`
      SELECT * FROM shadow_evaluation_records 
      WHERE run_id = ? 
      ORDER BY project_id ASC, observation_timestamp ASC
    `).all(runId) as any[];
  }

  public static getManifest(runId: string): string | null {
    const db = initShadowEvaluationTables();
    const row = db.prepare(`
      SELECT manifest_json FROM shadow_evaluation_manifests 
      WHERE run_id = ? LIMIT 1
    `).get() as any;
    return row ? row.manifest_json : null;
  }
}
