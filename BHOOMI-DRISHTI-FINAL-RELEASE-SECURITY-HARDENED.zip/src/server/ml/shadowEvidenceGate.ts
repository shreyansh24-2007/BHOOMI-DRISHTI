/**
 * BHOOMI-DRISHTI PHASE 6A: POINT-IN-TIME EVIDENCE GATE
 * 
 * Reusable statutory evidence validator executed prior to candidate model scoring.
 * 
 * Strict Enforcement:
 * 1. Verified first Section 3A date exists in authoritative gazette records.
 * 2. Observation timestamp t corresponds to an authentic source event.
 * 3. All event-derived features strictly respect event_date <= t.
 * 4. No future notifications in the feature snapshot (max_notification_date <= t).
 * 5. Sanction status uses only sanction events <= t.
 * 6. Required baseline features are present and non-empty.
 * 7. State jurisdiction is valid against approved administrative jurisdictions.
 * 8. Land requirement is within validated historical boundary (0 < ha <= 10,000).
 * 9. Feature schema strictly conforms to SCHEMA-LONGITUDINAL-V2.0-10FEAT.
 * 
 * Hard Failure Behavior:
 * Emits INSUFFICIENT_EVIDENCE with PARTIAL/INVALID status.
 * NEVER substitutes zeros, medians, or default placeholders.
 */

import { validateShadowFeatureSchema, ShadowFeatureVector } from './shadowFeatureSchema.ts';

export const VALID_INDIAN_JURISDICTIONS = new Set([
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand',
  'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
  'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
  'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura',
  'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Delhi', 'Jammu & Kashmir',
  'Ladakh', 'Puducherry', 'Chandigarh', 'Dadra and Nagar Haveli and Daman and Diu'
]);

export interface ShadowEvidenceInput {
  shadow_run_id?: string;
  project_id: string;
  observation_timestamp: string; // ISO date 'YYYY-MM-DD'
  first_3a_date?: string | null;
  latest_event_date_in_snapshot?: string | null;
  sanction_event_date?: string | null;
  features: Record<string, any>;
  provenance_verified?: boolean;
}

export interface EvidenceGateResult {
  passed: boolean;
  evidence_status: 'COMPLETE' | 'PARTIAL' | 'INVALID';
  validation_status: 'PASS' | 'OUT_OF_BOUNDS' | 'DRIFT_DETECTED';
  reasons: string[];
  normalizedVector?: ShadowFeatureVector;
}

/**
 * Validates observation evidence against point-in-time and data completeness rules.
 */
export function validateShadowEvidence(input: ShadowEvidenceInput): EvidenceGateResult {
  const reasons: string[] = [];
  let evidence_status: 'COMPLETE' | 'PARTIAL' | 'INVALID' = 'COMPLETE';
  let validation_status: 'PASS' | 'OUT_OF_BOUNDS' | 'DRIFT_DETECTED' = 'PASS';

  // 1. Mandatory Project ID & Observation Timestamp
  if (!input.project_id || typeof input.project_id !== 'string' || !input.project_id.trim()) {
    reasons.push('Invalid or missing project_id.');
    evidence_status = 'INVALID';
  }

  if (!input.observation_timestamp || typeof input.observation_timestamp !== 'string') {
    reasons.push('Invalid or missing observation_timestamp.');
    evidence_status = 'INVALID';
  }

  const obsTime = new Date(input.observation_timestamp).getTime();
  if (isNaN(obsTime)) {
    reasons.push(`Malformed observation_timestamp: '${input.observation_timestamp}'.`);
    evidence_status = 'INVALID';
  }

  // 2. Verified first Section 3A date existence
  if (!input.first_3a_date || typeof input.first_3a_date !== 'string') {
    reasons.push('Missing verified Section 3A date: corridor has no authoritative statutory start date.');
    evidence_status = 'PARTIAL';
  } else {
    const first3aTime = new Date(input.first_3a_date).getTime();
    if (isNaN(first3aTime)) {
      reasons.push(`Malformed first_3a_date: '${input.first_3a_date}'.`);
      evidence_status = 'INVALID';
    } else if (first3aTime > obsTime) {
      reasons.push(`Temporal violation: Section 3A date (${input.first_3a_date}) occurs after observation timestamp (${input.observation_timestamp}).`);
      evidence_status = 'INVALID';
      validation_status = 'OUT_OF_BOUNDS';
    }
  }

  // 3. Point-in-time check: No future notifications in snapshot
  if (input.latest_event_date_in_snapshot) {
    const latestEventTime = new Date(input.latest_event_date_in_snapshot).getTime();
    if (!isNaN(latestEventTime) && latestEventTime > obsTime) {
      reasons.push(`Temporal leakage: Feature snapshot contains notification date (${input.latest_event_date_in_snapshot}) after observation timestamp (${input.observation_timestamp}).`);
      evidence_status = 'INVALID';
      validation_status = 'OUT_OF_BOUNDS';
    }
  }

  // 4. Point-in-time check: Sanction status uses only sanction events <= observation_timestamp
  if (input.sanction_event_date && input.features?.initial_sanction_available_at_t === 1) {
    const sanctionTime = new Date(input.sanction_event_date).getTime();
    if (!isNaN(sanctionTime) && sanctionTime > obsTime) {
      reasons.push(`Temporal leakage: Sanction flag set to 1 but sanction event date (${input.sanction_event_date}) > observation timestamp (${input.observation_timestamp}).`);
      evidence_status = 'INVALID';
      validation_status = 'OUT_OF_BOUNDS';
    }
  }

  // 5. Schema validation & Quarantine checks
  const schemaResult = validateShadowFeatureSchema(input.features);
  if (!schemaResult.valid) {
    for (const err of schemaResult.errors) {
      reasons.push(err);
      if (err.includes('Quarantine') || err.includes('Unauthorized')) {
        evidence_status = 'INVALID';
        validation_status = 'DRIFT_DETECTED';
      } else if (err.includes('total_land_required_ha') || err.includes('range') || err.includes('bounds') || err.includes('number')) {
        evidence_status = 'PARTIAL';
        validation_status = 'OUT_OF_BOUNDS';
      } else {
        evidence_status = 'PARTIAL';
      }
    }
  }

  // 6. Jurisdiction & Baseline Land Range Validation
  if (schemaResult.valid && schemaResult.normalizedVector) {
    const vec = schemaResult.normalizedVector;

    // Check valid Indian jurisdiction
    const cleanJurisdiction = vec.state_jurisdiction.trim();
    if (!VALID_INDIAN_JURISDICTIONS.has(cleanJurisdiction) && cleanJurisdiction !== 'National Highways' && cleanJurisdiction !== 'Unknown') {
      reasons.push(`Unrecognized state jurisdiction: '${vec.state_jurisdiction}'.`);
      validation_status = 'OUT_OF_BOUNDS';
      if (evidence_status === 'COMPLETE') evidence_status = 'PARTIAL';
    }

    // Check land range boundaries
    if (vec.total_land_required_ha <= 0 || vec.total_land_required_ha > 10000) {
      reasons.push(`Total land requirement (${vec.total_land_required_ha} ha) outside validated bounds (0, 10000] ha.`);
      validation_status = 'OUT_OF_BOUNDS';
      if (evidence_status === 'COMPLETE') evidence_status = 'PARTIAL';
    }

    // Check elapsed days non-negative
    if (vec.elapsed_days_since_first_3a < 0) {
      reasons.push(`Negative elapsed days since 3A: ${vec.elapsed_days_since_first_3a}.`);
      validation_status = 'OUT_OF_BOUNDS';
      evidence_status = 'INVALID';
    }
  }

  const passed = reasons.length === 0 && evidence_status === 'COMPLETE' && validation_status === 'PASS';

  return {
    passed,
    evidence_status,
    validation_status,
    reasons,
    normalizedVector: passed ? schemaResult.normalizedVector : undefined
  };
}
