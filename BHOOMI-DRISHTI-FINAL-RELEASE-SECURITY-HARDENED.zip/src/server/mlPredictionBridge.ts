/**
 * BhoomiDrishti Phase 3: ML Model Prediction Bridge
 * Interfaces Node.js/Express with Canonical Supervised ML Model (BHOOMI-DRISHTI-ML-V1.0)
 * 
 * Strict Integrity & Isolation Rules:
 * - Read-only access to SQLite database.
 * - Zero modification of historical datasets, labels, or snapshots.
 * - Zero modification of trained model artifact (SHA-256 verified).
 * - Exact 9 approved features contract.
 * - Model status explicitly marked EXPERIMENTAL.
 */

import { spawn, ChildProcess } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { getDatabase } from './database.ts';

export const CANONICAL_MODEL_SHA256 = '7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f';
export const MODEL_ARTIFACT_REL_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib';
export const MODEL_VERSION = 'BHOOMI-DRISHTI-ML-V1.0';
export const DATASET_VERSION = 'BHOOMI-DRISHTI-HIST-V1.1-REMEDIATED';
export const FEATURE_SCHEMA_VERSION = '1.1.0';
export const MODEL_STATUS = 'EXPERIMENTAL';

export const APPROVED_RAW_FEATURES = [
  'stage_at_t',
  'land_acquired_ratio_at_t',
  'comp_disbursed_percent_at_t',
  'active_court_stays_at_t',
  'unresolved_cases_at_t',
  'incomplete_docs_count_at_t',
  'forest_clearance_at_t',
  'elapsed_days_since_3a_at_t',
  'initial_sanction_amount_available'
] as const;

export interface ApprovedMLFeatures {
  stage_at_t: string;
  land_acquired_ratio_at_t: number;
  comp_disbursed_percent_at_t: number;
  active_court_stays_at_t: number;
  unresolved_cases_at_t: number;
  incomplete_docs_count_at_t: number;
  forest_clearance_at_t: string;
  elapsed_days_since_3a_at_t: number | null;
  initial_sanction_amount_available: number; // strictly 0 or 1
}

export interface MLPredictionResponse {
  success: boolean;
  prediction?: {
    delay_probability: number;
    raw_probability: number;
    risk_level: 'HIGH' | 'MEDIUM' | 'LOW';
  };
  model?: {
    model_version: string;
    model_type: string;
    algorithm: string;
    status: string;
  };
  metadata?: {
    prediction_timestamp: string;
    feature_schema_version: string;
    dataset_version: string;
    artifact_sha256: string;
    imputed_features: string[];
    preprocessing_imputation_policy?: Record<string, string>;
    input_features?: ApprovedMLFeatures;
    projectId?: string;
    feature_provenance?: 'snapshot' | 'project_record';
  };
  error_code?: string;
  error?: string;
}

class MLPredictionBridgeService {
  private workerProcess: ChildProcess | null = null;
  private isReady = false;
  private pendingRequests = new Map<number, { resolve: (val: any) => void; reject: (err: any) => void; timeout: NodeJS.Timeout }>();
  private requestIdCounter = 0;
  private buffer = '';
  private cachedModelInfo: any = null;

  constructor() {
    this.startWorker();
  }

  /**
   * Verify model artifact integrity via SHA-256
   */
  public verifyArtifactIntegrity(): { verified: boolean; actualHash?: string; expectedHash: string; error?: string } {
    const fullPath = path.resolve(process.cwd(), MODEL_ARTIFACT_REL_PATH);
    if (!fs.existsSync(fullPath)) {
      return { verified: false, expectedHash: CANONICAL_MODEL_SHA256, error: `Model artifact not found at ${MODEL_ARTIFACT_REL_PATH}` };
    }

    try {
      const fileBuffer = fs.readFileSync(fullPath);
      const actualHash = crypto.createHash('sha256').update(fileBuffer).digest('hex');
      const verified = (actualHash === CANONICAL_MODEL_SHA256);
      return { verified, actualHash, expectedHash: CANONICAL_MODEL_SHA256 };
    } catch (e: any) {
      return { verified: false, expectedHash: CANONICAL_MODEL_SHA256, error: e.message };
    }
  }

  private startWorker() {
    const scriptPath = path.resolve(process.cwd(), 'scripts/ml_prediction_service.py');
    if (!fs.existsSync(scriptPath)) {
      console.error('[ML Bridge] Script not found:', scriptPath);
      return;
    }

    // Verify hash before launching worker
    const integrity = this.verifyArtifactIntegrity();
    if (!integrity.verified) {
      console.error(`[ML Bridge] FATAL: Model integrity check failed! Expected ${CANONICAL_MODEL_SHA256}, got ${integrity.actualHash || 'NONE'}`);
      return;
    }

    try {
      this.workerProcess = spawn('python3', [scriptPath, '--serve'], {
        cwd: process.cwd(),
        stdio: ['pipe', 'pipe', 'pipe']
      });

      this.workerProcess.stdout?.on('data', (chunk: Buffer) => {
        this.buffer += chunk.toString('utf-8');
        const lines = this.buffer.split('\n');
        this.buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          try {
            const msg = JSON.parse(trimmed);
            if (msg.ready !== undefined) {
              if (msg.ready) {
                this.isReady = true;
                this.cachedModelInfo = msg;
                console.log(`[ML Bridge] Python prediction worker initialized successfully. Model: ${msg.model_version} (Status: ${msg.status})`);
              } else {
                console.error('[ML Bridge] Python worker failed initialization:', msg.error);
              }
              continue;
            }

            const reqId = msg.id;
            if (reqId !== undefined && this.pendingRequests.has(reqId)) {
              const { resolve, timeout } = this.pendingRequests.get(reqId)!;
              clearTimeout(timeout);
              this.pendingRequests.delete(reqId);
              resolve(msg);
            }
          } catch (e) {
            console.error('[ML Bridge] Failed to parse message from python worker:', trimmed, e);
          }
        }
      });

      this.workerProcess.stderr?.on('data', (data: Buffer) => {
        const text = data.toString('utf-8');
        console.error('[ML Bridge Worker Stderr]', text.trim());
      });

      this.workerProcess.on('exit', (code, signal) => {
        console.warn(`[ML Bridge] Worker exited with code ${code}, signal ${signal}. Resetting.`);
        this.isReady = false;
        this.workerProcess = null;
        // Reject all pending requests
        for (const [id, req] of this.pendingRequests.entries()) {
          clearTimeout(req.timeout);
          req.reject(new Error('ML Prediction worker process terminated unexpectedly'));
        }
        this.pendingRequests.clear();
      });
    } catch (err: any) {
      console.error('[ML Bridge] Failed to spawn worker process:', err);
    }
  }

  /**
   * Executes inference via worker process or fallback invocation
   */
  public async predict(features: Record<string, any>): Promise<MLPredictionResponse> {
    // 1. Verify model integrity first
    const integrity = this.verifyArtifactIntegrity();
    if (!integrity.verified) {
      return {
        success: false,
        error_code: 'MODEL_INTEGRITY_ERROR',
        error: `Model artifact integrity verification failed. Expected SHA-256: ${CANONICAL_MODEL_SHA256}`
      };
    }

    // 2. Validate input features strictly in Node as well
    const validation = this.validateFeatures(features);
    if (!validation.isValid) {
      return {
        success: false,
        error_code: 'INVALID_FEATURE_INPUT',
        error: validation.error
      };
    }

    // 3. Send to worker process if alive, otherwise fallback to direct execution
    if (this.workerProcess && this.isReady && !this.workerProcess.killed) {
      return new Promise((resolve) => {
        const reqId = ++this.requestIdCounter;
        const timeout = setTimeout(() => {
          if (this.pendingRequests.has(reqId)) {
            this.pendingRequests.delete(reqId);
            resolve({
              success: false,
              error_code: 'MODEL_PREDICTION_ERROR',
              error: 'Inference request timed out after 5000ms'
            });
          }
        }, 5000);

        this.pendingRequests.set(reqId, {
          resolve: (resp: any) => {
            if (resp.success && resp.metadata) {
              resp.metadata.input_features = validation.sanitized;
            }
            resolve(resp);
          },
          reject: (err: any) => {
            resolve({
              success: false,
              error_code: 'MODEL_PREDICTION_ERROR',
              error: err.message || 'Worker prediction error'
            });
          },
          timeout
        });

        try {
          const payload = JSON.stringify({ id: reqId, action: 'predict', features: validation.sanitized }) + '\n';
          this.workerProcess.stdin?.write(payload);
        } catch (e: any) {
          clearTimeout(timeout);
          this.pendingRequests.delete(reqId);
          resolve(this.fallbackPredict(validation.sanitized!));
        }
      });
    }

    // Fallback direct execution
    return this.fallbackPredict(validation.sanitized!);
  }

  /**
   * One-shot fallback execution
   */
  private async fallbackPredict(features: ApprovedMLFeatures): Promise<MLPredictionResponse> {
    return new Promise((resolve) => {
      const scriptPath = path.resolve(process.cwd(), 'scripts/ml_prediction_service.py');
      const proc = spawn('python3', [scriptPath, '--predict-json', JSON.stringify(features)], {
        cwd: process.cwd()
      });

      let stdout = '';
      let stderr = '';

      proc.stdout.on('data', (d) => { stdout += d.toString(); });
      proc.stderr.on('data', (d) => { stderr += d.toString(); });

      proc.on('close', (code) => {
        if (code !== 0) {
          resolve({
            success: false,
            error_code: 'MODEL_PREDICTION_ERROR',
            error: `Inference failed with exit code ${code}: ${stderr || stdout}`
          });
          return;
        }

        try {
          const resp = JSON.parse(stdout);
          if (resp.success && resp.metadata) {
            resp.metadata.input_features = features;
          }
          resolve(resp);
        } catch (e: any) {
          resolve({
            success: false,
            error_code: 'MODEL_PREDICTION_ERROR',
            error: `Failed to parse Python model response: ${e.message}`
          });
        }
      });

      proc.on('error', (err) => {
        resolve({
          success: false,
          error_code: 'MODEL_NOT_FOUND',
          error: `Failed to launch python inference runtime: ${err.message}`
        });
      });
    });
  }

  /**
   * Validates features according to the 9 approved features contract
   */
  public validateFeatures(raw: any): { isValid: boolean; sanitized?: ApprovedMLFeatures; error?: string } {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
      return { isValid: false, error: 'Feature input must be a non-null object' };
    }

    // Check for forbidden fields
    const forbidden = ['delayProbability', 'delay_probability', 'riskLevel', 'risk_level', 'binary_target', 'label'];
    for (const f of forbidden) {
      if (raw[f] !== undefined && raw[f] !== null) {
        return {
          isValid: false,
          error: `Forbidden parameter '${f}' detected. Target labels and heuristic probabilities must never be supplied as ML features.`
        };
      }
    }

    // Check presence of all 9 approved features
    for (const feat of APPROVED_RAW_FEATURES) {
      if (raw[feat] === undefined) {
        return { isValid: false, error: `Missing required approved feature: '${feat}'` };
      }
    }

    // Validate stage_at_t
    if (typeof raw.stage_at_t !== 'string' || !raw.stage_at_t.trim()) {
      return { isValid: false, error: "Feature 'stage_at_t' must be a non-empty string" };
    }

    // Validate land_acquired_ratio_at_t
    const lar = Number(raw.land_acquired_ratio_at_t);
    if (isNaN(lar) || lar < 0) {
      return { isValid: false, error: "Feature 'land_acquired_ratio_at_t' must be a non-negative number" };
    }

    // Validate comp_disbursed_percent_at_t
    const cdp = Number(raw.comp_disbursed_percent_at_t);
    if (isNaN(cdp) || cdp < 0) {
      return { isValid: false, error: "Feature 'comp_disbursed_percent_at_t' must be a non-negative number" };
    }

    // Validate active_court_stays_at_t
    if (typeof raw.active_court_stays_at_t === 'boolean' || raw.active_court_stays_at_t === null) {
      return { isValid: false, error: "Feature 'active_court_stays_at_t' must be a non-negative integer count" };
    }
    const stays = Number(raw.active_court_stays_at_t);
    if (!Number.isInteger(stays) || stays < 0) {
      return { isValid: false, error: "Feature 'active_court_stays_at_t' must be a non-negative integer" };
    }

    // Validate unresolved_cases_at_t
    if (typeof raw.unresolved_cases_at_t === 'boolean' || raw.unresolved_cases_at_t === null) {
      return { isValid: false, error: "Feature 'unresolved_cases_at_t' must be a non-negative integer count" };
    }
    const cases = Number(raw.unresolved_cases_at_t);
    if (!Number.isInteger(cases) || cases < 0) {
      return { isValid: false, error: "Feature 'unresolved_cases_at_t' must be a non-negative integer" };
    }

    // Validate incomplete_docs_count_at_t
    if (typeof raw.incomplete_docs_count_at_t === 'boolean' || raw.incomplete_docs_count_at_t === null) {
      return { isValid: false, error: "Feature 'incomplete_docs_count_at_t' must be a non-negative integer count" };
    }
    const docs = Number(raw.incomplete_docs_count_at_t);
    if (!Number.isInteger(docs) || docs < 0) {
      return { isValid: false, error: "Feature 'incomplete_docs_count_at_t' must be a non-negative integer" };
    }

    // Validate forest_clearance_at_t
    if (typeof raw.forest_clearance_at_t !== 'string' || !raw.forest_clearance_at_t.trim()) {
      return { isValid: false, error: "Feature 'forest_clearance_at_t' must be a non-empty string" };
    }

    // Validate elapsed_days_since_3a_at_t (null or non-negative number)
    let elapsed: number | null = null;
    if (raw.elapsed_days_since_3a_at_t !== null && raw.elapsed_days_since_3a_at_t !== '') {
      const el = Number(raw.elapsed_days_since_3a_at_t);
      if (isNaN(el) || el < 0) {
        return { isValid: false, error: "Feature 'elapsed_days_since_3a_at_t' must be null or a non-negative number" };
      }
      elapsed = el;
    }

    // Validate initial_sanction_amount_available (strictly 0 or 1)
    const rawSanction = raw.initial_sanction_amount_available;
    if (rawSanction !== 0 && rawSanction !== 1 && rawSanction !== '0' && rawSanction !== '1') {
      return { isValid: false, error: "Feature 'initial_sanction_amount_available' must be strictly binary 0 (unavailable) or 1 (available)" };
    }
    const sanctionInt = Number(rawSanction);
    if (sanctionInt !== 0 && sanctionInt !== 1) {
      return { isValid: false, error: "Feature 'initial_sanction_amount_available' must be strictly 0 or 1" };
    }

    const sanitized: ApprovedMLFeatures = {
      stage_at_t: raw.stage_at_t.trim(),
      land_acquired_ratio_at_t: lar,
      comp_disbursed_percent_at_t: cdp,
      active_court_stays_at_t: stays,
      unresolved_cases_at_t: cases,
      incomplete_docs_count_at_t: docs,
      forest_clearance_at_t: raw.forest_clearance_at_t.trim(),
      elapsed_days_since_3a_at_t: elapsed,
      initial_sanction_amount_available: sanctionInt
    };

    return { isValid: true, sanitized };
  }

  /**
   * Centralized feature extraction for a project record in SQLite.
   * Priority:
   * 1. Latest snapshot from ml_project_snapshots
   * 2. Live row from projects table
   * Keeps missing elapsed_days_since_3a_at_t strictly null.
   * Does NOT write to SQLite.
   */
  public extractFeaturesFromDatabase(projectId: string): {
    found: boolean;
    features?: ApprovedMLFeatures;
    provenance?: 'snapshot' | 'project_record';
    error?: string;
  } {
    const cleanId = (projectId || '').trim();
    if (!cleanId) {
      return { found: false, error: 'Project ID cannot be empty' };
    }

    const db = getDatabase();

    // 1. Try ml_project_snapshots first (rich point-in-time statutory snapshot)
    try {
      const snapStmt = db.prepare(`
        SELECT 
          stage_at_t,
          land_acquired_ratio_at_t,
          comp_disbursed_percent_at_t,
          active_court_stays_at_t,
          unresolved_cases_at_t,
          incomplete_docs_count_at_t,
          forest_clearance_at_t,
          elapsed_days_since_3a_at_t,
          snapshot_features_json
        FROM ml_project_snapshots
        WHERE project_id = ? OR project_id = ? OR project_id = ?
        ORDER BY snapshot_timestamp DESC, id DESC
        LIMIT 1
      `);

      const unprefixed = cleanId.replace(/^BhoomiRashi_/, '');
      const prefixed = cleanId.startsWith('BhoomiRashi_') ? cleanId : `BhoomiRashi_${cleanId}`;
      const snapRow = snapStmt.get(cleanId, unprefixed, prefixed) as any;

      if (snapRow) {
        let sanctionAvail = 0;
        try {
          const parsedJson = JSON.parse(snapRow.snapshot_features_json || '{}');
          sanctionAvail = parsedJson.initialSanctionAmountAvailable === 1 || parsedJson.initialSanctionAmountAvailable === '1' ? 1 : 0;
        } catch {}

        let elapsed = snapRow.elapsed_days_since_3a_at_t !== null ? Number(snapRow.elapsed_days_since_3a_at_t) : null;
        if (elapsed === null) {
          try {
            const pRow = db.prepare('SELECT section_3a_date FROM projects WHERE id = ? OR source_project_id = ? OR id = ? LIMIT 1').get(cleanId, unprefixed, prefixed) as any;
            if (pRow && pRow.section_3a_date && typeof pRow.section_3a_date === 'string' && pRow.section_3a_date.trim()) {
              const parsed3a = new Date(pRow.section_3a_date.trim()).getTime();
              if (!isNaN(parsed3a) && parsed3a > 0) {
                elapsed = Math.max(0, Math.round((Date.now() - parsed3a) / (1000 * 60 * 60 * 24)));
              }
            }
          } catch {}
        }

        const features: ApprovedMLFeatures = {
          stage_at_t: snapRow.stage_at_t || 'Compensation',
          land_acquired_ratio_at_t: Math.max(0, Number(snapRow.land_acquired_ratio_at_t) || 0),
          comp_disbursed_percent_at_t: Math.max(0, Number(snapRow.comp_disbursed_percent_at_t) || 0),
          active_court_stays_at_t: Math.max(0, Number(snapRow.active_court_stays_at_t) || 0),
          unresolved_cases_at_t: Math.max(0, Number(snapRow.unresolved_cases_at_t) || 0),
          incomplete_docs_count_at_t: Math.max(0, Number(snapRow.incomplete_docs_count_at_t) || 0),
          forest_clearance_at_t: snapRow.forest_clearance_at_t || 'Not Required',
          // Preserve NULL strictly if no date exists; use verified date calculation if available
          elapsed_days_since_3a_at_t: elapsed,
          initial_sanction_amount_available: sanctionAvail
        };

        return { found: true, features, provenance: 'snapshot' };
      }
    } catch (e: any) {
      console.warn('[ML Bridge] Snapshot query error, falling back to projects table:', e.message);
    }

    // 2. Fall back to authoritative projects table
    try {
      const projStmt = db.prepare(`
        SELECT 
          current_stage,
          total_land_required_ha,
          land_acquired_ha,
          compensation_disbursed_percent,
          has_court_stay,
          unresolved_legal_cases,
          incomplete_documents_count,
          forest_clearance_stage,
          compensation_sanctioned_cr,
          section_3a_date
        FROM projects
        WHERE id = ? OR source_project_id = ? OR id = ?
        LIMIT 1
      `);

      const unprefixed = cleanId.replace(/^BhoomiRashi_/, '');
      const prefixed = cleanId.startsWith('BhoomiRashi_') ? cleanId : `BhoomiRashi_${cleanId}`;
      const projRow = projStmt.get(cleanId, unprefixed, prefixed) as any;

      if (projRow) {
        const totalReq = Number(projRow.total_land_required_ha) || 0;
        const acquired = Number(projRow.land_acquired_ha) || 0;
        const landRatio = totalReq > 0 ? (acquired / totalReq) : 0;
        const hasSanctionCr = Number(projRow.compensation_sanctioned_cr) > 0 ? 1 : 0;

        // Calculate elapsed calendar days from verified Section 3A date if authoritative source exists
        let elapsedDays: number | null = null;
        if (projRow.section_3a_date && typeof projRow.section_3a_date === 'string' && projRow.section_3a_date.trim()) {
          const parsed3a = new Date(projRow.section_3a_date.trim()).getTime();
          if (!isNaN(parsed3a) && parsed3a > 0) {
            elapsedDays = Math.max(0, Math.round((Date.now() - parsed3a) / (1000 * 60 * 60 * 24)));
          }
        }

        const features: ApprovedMLFeatures = {
          stage_at_t: projRow.current_stage || 'Compensation',
          land_acquired_ratio_at_t: Math.max(0, landRatio),
          comp_disbursed_percent_at_t: Math.max(0, Number(projRow.compensation_disbursed_percent) || 0),
          active_court_stays_at_t: projRow.has_court_stay ? 1 : 0,
          unresolved_cases_at_t: Math.max(0, Number(projRow.unresolved_legal_cases) || 0),
          incomplete_docs_count_at_t: Math.max(0, Number(projRow.incomplete_documents_count) || 0),
          forest_clearance_at_t: projRow.forest_clearance_stage || 'Not Required',
          // Real calculated elapsed calendar days if verified Section 3A date exists, else strictly null (never arbitrary 180)
          elapsed_days_since_3a_at_t: elapsedDays,
          initial_sanction_amount_available: hasSanctionCr
        };

        return { found: true, features, provenance: 'project_record' };
      }
    } catch (e: any) {
      return { found: false, error: `Database project lookup failed: ${e.message}` };
    }

    return { found: false, error: `Project '${cleanId}' not found in authoritative database` };
  }

  /**
   * Predict for a project by ID
   */
  public async predictForProject(projectId: string): Promise<MLPredictionResponse> {
    const extracted = this.extractFeaturesFromDatabase(projectId);
    if (!extracted.found || !extracted.features) {
      return {
        success: false,
        error_code: 'PROJECT_NOT_FOUND',
        error: extracted.error || `Project '${projectId}' not found in SQLite database`
      };
    }

    const prediction = await this.predict(extracted.features);
    if (prediction.success && prediction.metadata) {
      prediction.metadata.projectId = projectId;
      prediction.metadata.feature_provenance = extracted.provenance;
    }
    return prediction;
  }

  /**
   * Phase 3.5: Controlled What-If Scenario Analysis
   * - Evaluates hypothetical feature changes against the validated ML model pipeline
   * - Baseline extracted strictly from authoritative database
   * - In-memory scenario copy only (zero database or training data mutation)
   * - Probability difference calculated in absolute and percentage points
   * - Reuses exact Phase 3 prediction pipeline and risk thresholds
   */
  public async runWhatIfScenario(input: any): Promise<any> {
    if (!input || typeof input !== 'object') {
      return {
        success: false,
        error_code: 'INVALID_FEATURE_INPUT',
        error: 'Scenario request must be a valid JSON object'
      };
    }

    const projectId = typeof input.projectId === 'string' ? input.projectId.trim() : '';
    if (!projectId) {
      return {
        success: false,
        error_code: 'PROJECT_NOT_FOUND',
        error: 'Project ID is required for What-If scenario analysis'
      };
    }

    // 1. Verify model integrity first
    const integrity = this.verifyArtifactIntegrity();
    if (!integrity.verified) {
      return {
        success: false,
        error_code: 'MODEL_INTEGRITY_ERROR',
        error: `Model artifact integrity verification failed. Expected SHA-256: ${CANONICAL_MODEL_SHA256}`
      };
    }

    // 2. Extract baseline project state from database
    const extracted = this.extractFeaturesFromDatabase(projectId);
    if (!extracted.found || !extracted.features) {
      return {
        success: false,
        error_code: 'PROJECT_NOT_FOUND',
        error: extracted.error || `Project '${projectId}' not found in authoritative database`
      };
    }
    const baselineFeatures = extracted.features;

    // Optional project name lookup for UI reporting
    let projectName = projectId;
    try {
      const db = getDatabase();
      const pRow = db.prepare('SELECT name FROM projects WHERE id = ? OR source_project_id = ? LIMIT 1').get(projectId, projectId) as any;
      if (pRow && pRow.name) projectName = pRow.name;
    } catch {}

    // 3. Extract changes object
    let rawChanges: Record<string, any> = {};
    if (input.changes !== undefined) {
      if (input.changes === null || typeof input.changes !== 'object' || Array.isArray(input.changes)) {
        return {
          success: false,
          error_code: 'INVALID_FEATURE_INPUT',
          error: 'Scenario changes must be an object of key-value pairs'
        };
      }
      rawChanges = input.changes;
    } else {
      // Flat request mode
      const shallow = { ...input };
      delete shallow.projectId;
      delete shallow.userId;
      delete shallow.userRole;
      rawChanges = shallow;
    }

    // 4. Prohibited parameters check
    const forbiddenFields = [
      'delayProbability', 'delay_probability', 'riskLevel', 'risk_level',
      'binary_target', 'label', 'project_id', 'corridor_id', 'state',
      'highway_number', 'gazette_id', 'notification_id', 'db_id',
      'initial_sanction_amount_cr', 'compensation_sanctioned_cr'
    ];
    for (const k of Object.keys(rawChanges)) {
      if (forbiddenFields.includes(k)) {
        return {
          success: false,
          error_code: 'INVALID_SCENARIO_FIELD',
          error: `Forbidden parameter '${k}' cannot be used in a scenario. Target labels, baseline probabilities, and administrative identifiers are strictly forbidden.`
        };
      }
    }

    // 5. Allowed feature mapping
    const fieldMapping: Record<string, keyof ApprovedMLFeatures> = {
      // 9 Approved feature names
      stage_at_t: 'stage_at_t',
      land_acquired_ratio_at_t: 'land_acquired_ratio_at_t',
      comp_disbursed_percent_at_t: 'comp_disbursed_percent_at_t',
      active_court_stays_at_t: 'active_court_stays_at_t',
      unresolved_cases_at_t: 'unresolved_cases_at_t',
      incomplete_docs_count_at_t: 'incomplete_docs_count_at_t',
      forest_clearance_at_t: 'forest_clearance_at_t',
      elapsed_days_since_3a_at_t: 'elapsed_days_since_3a_at_t',
      initial_sanction_amount_available: 'initial_sanction_amount_available',
      // Legacy UI aliases
      compensationDisbursedPercent: 'comp_disbursed_percent_at_t',
      hasCourtStay: 'active_court_stays_at_t',
      unresolvedLegalCases: 'unresolved_cases_at_t',
      incompleteDocumentsCount: 'incomplete_docs_count_at_t',
      forestClearanceStage: 'forest_clearance_at_t',
      landAcquiredRatio: 'land_acquired_ratio_at_t',
      elapsedDaysSince3a: 'elapsed_days_since_3a_at_t',
      initialSanctionAmountAvailable: 'initial_sanction_amount_available',
      currentStage: 'stage_at_t'
    };

    for (const k of Object.keys(rawChanges)) {
      if (!fieldMapping[k]) {
        return {
          success: false,
          error_code: 'INVALID_SCENARIO_FIELD',
          error: `Unrecognized scenario field '${k}'. Only the approved 9 model features may be varied.`
        };
      }
    }

    // 6. In-memory scenario clone and validation
    const scenarioFeatures: ApprovedMLFeatures = { ...baselineFeatures };

    for (const [rawKey, rawVal] of Object.entries(rawChanges)) {
      const targetFeature = fieldMapping[rawKey];
      if (!targetFeature) continue;

      if (targetFeature === 'stage_at_t') {
        if (typeof rawVal !== 'string' || !rawVal.trim()) {
          return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'stage_at_t' must be a non-empty string" };
        }
        scenarioFeatures.stage_at_t = rawVal.trim();
      } else if (targetFeature === 'forest_clearance_at_t') {
        if (typeof rawVal !== 'string' || !rawVal.trim()) {
          return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'forest_clearance_at_t' must be a non-empty string" };
        }
        scenarioFeatures.forest_clearance_at_t = rawVal.trim();
      } else if (targetFeature === 'land_acquired_ratio_at_t') {
        const val = Number(rawVal);
        if (isNaN(val) || val < 0) {
          return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'land_acquired_ratio_at_t' must be a non-negative number" };
        }
        scenarioFeatures.land_acquired_ratio_at_t = val;
      } else if (targetFeature === 'comp_disbursed_percent_at_t') {
        const val = Number(rawVal);
        if (isNaN(val) || val < 0) {
          return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'comp_disbursed_percent_at_t' must be a non-negative number" };
        }
        scenarioFeatures.comp_disbursed_percent_at_t = val;
      } else if (targetFeature === 'active_court_stays_at_t') {
        let intVal: number;
        if (typeof rawVal === 'boolean') {
          intVal = rawVal ? 1 : 0;
        } else {
          if (rawVal === null || typeof rawVal === 'boolean') {
            return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'active_court_stays_at_t' must be a non-negative integer count" };
          }
          intVal = Number(rawVal);
          if (!Number.isInteger(intVal) || intVal < 0) {
            return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'active_court_stays_at_t' must be a non-negative integer" };
          }
        }
        scenarioFeatures.active_court_stays_at_t = intVal;
      } else if (targetFeature === 'unresolved_cases_at_t') {
        if (rawVal === null || typeof rawVal === 'boolean') {
          return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'unresolved_cases_at_t' must be a non-negative integer count" };
        }
        const intVal = Number(rawVal);
        if (!Number.isInteger(intVal) || intVal < 0) {
          return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'unresolved_cases_at_t' must be a non-negative integer" };
        }
        scenarioFeatures.unresolved_cases_at_t = intVal;
      } else if (targetFeature === 'incomplete_docs_count_at_t') {
        if (rawVal === null || typeof rawVal === 'boolean') {
          return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'incomplete_docs_count_at_t' must be a non-negative integer count" };
        }
        const intVal = Number(rawVal);
        if (!Number.isInteger(intVal) || intVal < 0) {
          return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'incomplete_docs_count_at_t' must be a non-negative integer" };
        }
        scenarioFeatures.incomplete_docs_count_at_t = intVal;
      } else if (targetFeature === 'elapsed_days_since_3a_at_t') {
        if (rawVal === null || rawVal === '') {
          scenarioFeatures.elapsed_days_since_3a_at_t = null;
        } else {
          const val = Number(rawVal);
          if (isNaN(val) || val < 0) {
            return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'elapsed_days_since_3a_at_t' must be null or a non-negative number" };
          }
          scenarioFeatures.elapsed_days_since_3a_at_t = val;
        }
      } else if (targetFeature === 'initial_sanction_amount_available') {
        if (rawVal !== 0 && rawVal !== 1 && rawVal !== '0' && rawVal !== '1') {
          return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'initial_sanction_amount_available' must be strictly binary 0 (unavailable) or 1 (available)" };
        }
        const val = Number(rawVal);
        if (val !== 0 && val !== 1) {
          return { success: false, error_code: 'INVALID_FEATURE_INPUT', error: "Feature 'initial_sanction_amount_available' must be strictly 0 or 1" };
        }
        scenarioFeatures.initial_sanction_amount_available = val;
      }
    }

    // 7. Track changed and unchanged features
    const changed_features: Record<string, { from: any; to: any }> = {};
    const unchanged_features: Record<string, any> = {};

    for (const feat of APPROVED_RAW_FEATURES) {
      if (scenarioFeatures[feat] !== baselineFeatures[feat]) {
        changed_features[feat] = {
          from: baselineFeatures[feat],
          to: scenarioFeatures[feat]
        };
      } else {
        unchanged_features[feat] = scenarioFeatures[feat];
      }
    }

    // 8. Run baseline and scenario predictions using the exact same ML pipeline
    const baselineResult = await this.predict(baselineFeatures);
    if (!baselineResult.success || !baselineResult.prediction) {
      return {
        success: false,
        error_code: baselineResult.error_code || 'MODEL_PREDICTION_ERROR',
        error: baselineResult.error || 'Failed to calculate baseline prediction'
      };
    }

    const scenarioResult = await this.predict(scenarioFeatures);
    if (!scenarioResult.success || !scenarioResult.prediction) {
      return {
        success: false,
        error_code: scenarioResult.error_code || 'MODEL_PREDICTION_ERROR',
        error: scenarioResult.error || 'Failed to calculate scenario prediction'
      };
    }

    const baseRaw = baselineResult.prediction.raw_probability;
    const scenRaw = scenarioResult.prediction.raw_probability;
    const absChange = Math.round((scenRaw - baseRaw) * 10000) / 10000;
    const pctPointChange = Math.round((scenRaw - baseRaw) * 10000) / 100;

    // 9. Neutral drivers description
    const primaryDrivers: string[] = [];
    for (const [feat, diff] of Object.entries(changed_features)) {
      primaryDrivers.push(`Hypothetical change in ${feat}: configured from ${diff.from} to ${diff.to}`);
    }
    if (primaryDrivers.length === 0) {
      primaryDrivers.push('Baseline parameters maintained with zero variation.');
    }

    return {
      success: true,
      baseline: {
        delay_probability: baselineResult.prediction.delay_probability,
        raw_probability: baselineResult.prediction.raw_probability,
        risk_level: baselineResult.prediction.risk_level
      },
      scenario: {
        delay_probability: scenarioResult.prediction.delay_probability,
        raw_probability: scenarioResult.prediction.raw_probability,
        risk_level: scenarioResult.prediction.risk_level
      },
      change: {
        absolute_probability_change: absChange,
        percentage_point_change: pctPointChange
      },
      changed_features,
      unchanged_features,
      model: {
        version: MODEL_VERSION,
        status: MODEL_STATUS,
        algorithm: 'RandomForestClassifier(n_estimators=100, max_depth=6, min_samples_leaf=2, class_weight="balanced", random_state=42)'
      },
      dataset_version: DATASET_VERSION,
      feature_schema_version: FEATURE_SCHEMA_VERSION,
      scenario_only: true,
      timestamp: new Date().toISOString(),
      interpretation: 'Modelled probability change under the specified hypothetical feature configuration; not a causal guarantee.',

      // Backward compatibility fields
      projectId,
      projectName,
      currentRisk: {
        delayProbability: Math.round(baselineResult.prediction.delay_probability * 1000) / 10,
        riskLevel: baselineResult.prediction.risk_level
      },
      scenarioRisk: {
        delayProbability: Math.round(scenarioResult.prediction.delay_probability * 1000) / 10,
        riskLevel: scenarioResult.prediction.risk_level
      },
      simulatedRisk: {
        delayProbability: Math.round(scenarioResult.prediction.delay_probability * 1000) / 10,
        riskLevel: scenarioResult.prediction.risk_level,
        delayVarianceMonths: 0
      },
      riskChangePercentagePoints: pctPointChange,
      primaryDrivers,
      impactSummary: `Under this hypothetical feature configuration, the modelled delay probability changes by ${pctPointChange >= 0 ? '+' : ''}${pctPointChange} percentage points.`,
      disclaimer: 'What-If results represent model sensitivity under a hypothetical feature configuration. They are not causal estimates and do not guarantee that a real-world intervention will produce the same outcome.'
    };
  }

  /**
   * Retrieve genuine ML model info and metadata
   */
  public getModelInfo() {
    const integrity = this.verifyArtifactIntegrity();
    return {
      model_version: MODEL_VERSION,
      model_name: 'BhoomiDrishti Delay Risk Prediction Engine',
      model_type: 'Class-Weighted Random Forest',
      algorithm: 'RandomForestClassifier(n_estimators=100, max_depth=6, min_samples_leaf=2, class_weight="balanced", random_state=42)',
      dataset_version: DATASET_VERSION,
      feature_schema_version: FEATURE_SCHEMA_VERSION,
      status: MODEL_STATUS,
      artifact_path: MODEL_ARTIFACT_REL_PATH,
      expected_sha256: CANONICAL_MODEL_SHA256,
      actual_sha256: integrity.actualHash,
      integrity_verified: integrity.verified,
      approved_features: [...APPROVED_RAW_FEATURES],
      missing_value_policy: {
        elapsed_days_since_3a_at_t: "SimpleImputer(strategy='median') ~ 180.0 days (handled in model pipeline; never imputed into database)",
        initial_sanction_amount_available: "Strict binary missingness indicator (0 = unavailable, 1 = available)",
        raw_sanction_amount_cr: "Excluded from features to prevent leakage"
      },
      risk_band_thresholds: {
        HIGH: 'Delay Probability >= 0.70 (70%)',
        MEDIUM: 'Delay Probability >= 0.35 and < 0.70 (35% - 69%)',
        LOW: 'Delay Probability < 0.35 (< 35%)'
      },
      known_limitations: [
        'Temporal holdout ROC-AUC is 0.5000 due to pre-2025 milestone standardization (zero feature variance).',
        'Model status is strictly EXPERIMENTAL; not certified for autonomous statutory procurement decisions.',
        'elapsed_days_since_3a_at_t represents 83.1% Gini importance (acts as milestone maturity coordinate).',
        'Calibration improves probability Brier score alignment but does not restore temporal discrimination.'
      ]
    };
  }
}

// Singleton instance
export const mlBridge = new MLPredictionBridgeService();
