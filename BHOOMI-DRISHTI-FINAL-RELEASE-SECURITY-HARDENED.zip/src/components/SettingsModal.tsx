import React, { useState, useEffect } from 'react';
import { X, Sliders, Bell, Database, Check, Cpu, Award, ShieldCheck, UserCheck, Lock } from 'lucide-react';
import { api } from '../services/apiClient.ts';
import { SystemStatus, AuthUser } from '../types.ts';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: AuthUser | null;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, currentUser }) => {
  const [status, setStatus] = useState<SystemStatus | null>(null);

  useEffect(() => {
    if (isOpen) {
      api.getSystemStatus().then(setStatus).catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isNodal = currentUser?.role === 'NODAL_OFFICER';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">System Architecture &amp; Role Settings</h2>
              <p className="text-xs text-slate-500">Government credentials, database status &amp; predictive engine</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
            aria-label="Close settings"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Active User Session & Privileges */}
        <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-blue-700" />
              <span className="font-bold text-slate-900">Active Officer Session</span>
            </div>
            <span className="font-mono text-[11px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900 border border-blue-200">
              {currentUser?.role || 'VIEWER'}
            </span>
          </div>
          <p className="text-xs text-slate-600 font-medium">
            User: <strong className="text-slate-900">{currentUser?.name || 'Authorized Auditor'}</strong> ({currentUser?.email || 'officer@morth.gov.in'})
          </p>
          <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-200/60 leading-relaxed">
            {isNodal ? (
              <span className="text-emerald-700 font-medium">
                Full Operational Privileges: Add new national highway corridors, execute e-Gazette sync, update acquisition records, and review statutory escalations.
              </span>
            ) : (
              <span className="text-slate-600">
                Auditor Read-Only Mode: Transparent access to executive dashboards, corridor dossiers, what-if simulations, and immutable cryptographic audit trails.
              </span>
            )}
          </div>
        </div>

        {/* Risk Thresholds with plain language */}
        <div className="space-y-2.5">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
            Statutory Delay Risk Thresholds
          </label>
          <div className="space-y-1.5 text-xs">
            <div className="flex items-center justify-between p-2.5 bg-red-50/70 border border-red-200 rounded-lg">
              <div>
                <span className="font-semibold text-red-800">High Risk Level</span>
                <p className="text-[10px] text-red-600">Court stays, severe compensation lag, acute statutory risk</p>
              </div>
              <span className="font-mono font-bold text-red-700">≥ 70% probability</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-amber-50/70 border border-amber-200 rounded-lg">
              <div>
                <span className="font-semibold text-amber-800">Medium Risk Level</span>
                <p className="text-[10px] text-amber-600">Pending clearances, approaching milestone deadlines</p>
              </div>
              <span className="font-mono font-bold text-amber-700">35% – 69.9% probability</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-emerald-50/70 border border-emerald-200 rounded-lg">
              <div>
                <span className="font-semibold text-emerald-800">On Track / Low Risk</span>
                <p className="text-[10px] text-emerald-600">Acquisition milestones proceeding within statutory timeline</p>
              </div>
              <span className="font-mono font-bold text-emerald-700">&lt; 35% probability</span>
            </div>
          </div>
        </div>

        {/* ML Model Engine */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
            Official Delay Risk Model (Production V1)
          </label>
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs text-slate-700">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-blue-700" />
                <span className="font-semibold text-slate-900">BHOOMI-DRISHTI-ML-V1.0</span>
              </div>
              <span className="font-mono text-[11px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold border border-emerald-200">
                PRODUCTION / AUTHORITATIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              Class-Weighted Random Forest classifier trained on 2,871 verified historical observations across 155 highway packages.
            </p>
            <div className="grid grid-cols-3 gap-2 pt-1 border-t border-slate-200/60 text-center">
              <div className="bg-white p-2 rounded-lg border border-slate-200">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">Test Accuracy</div>
                <div className="text-xs font-bold text-slate-900">88.0%</div>
                <div className="text-[9px] text-slate-400">Correct classifications</div>
              </div>
              <div className="bg-white p-2 rounded-lg border border-slate-200">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">F1 Score</div>
                <div className="text-xs font-bold text-slate-900">85.0%</div>
                <div className="text-[9px] text-slate-400">Balanced metric</div>
              </div>
              <div className="bg-white p-2 rounded-lg border border-slate-200">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">ROC-AUC</div>
                <div className="text-xs font-bold text-slate-900">0.883</div>
                <div className="text-[9px] text-slate-400">Diagnostic separation</div>
              </div>
            </div>
          </div>
        </div>

        {/* Database & Data Source */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
            Authoritative Storage &amp; Database Integrity
          </label>
          <div className="flex items-start gap-2.5 text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <Database className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="font-semibold text-slate-900">
                Authoritative SQLite Database (WAL Mode Enabled)
              </div>
              <div className="text-[11px] text-slate-500">
                Indexed: <strong className="text-slate-800">31 national corridor packages</strong> • PRAGMA integrity_check: <strong className="text-emerald-700">OK</strong>
              </div>
              <div className="text-[10.5px] text-slate-500 font-mono pt-1">
                Artifact Hash (V1): 7e0e1a7dac2e082c...7f (Verified)
              </div>
            </div>
          </div>
        </div>

        {/* Candidate Model Governance */}
        <div className="p-3 bg-amber-50/60 border border-amber-200 rounded-xl text-xs space-y-1">
          <div className="flex items-center justify-between text-amber-900 font-bold">
            <span>Candidate Model V2.0 Status:</span>
            <span className="font-mono text-[10.5px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300">
              SHADOW EVALUATION
            </span>
          </div>
          <p className="text-[11px] text-amber-950/80 leading-relaxed">
            Candidate model V2 operates in strict shadow mode for internal evaluation. It has zero operational authority and its decision thresholds remain locked to <strong className="text-amber-950">PENDING_STAKEHOLDER_APPROVAL</strong>.
          </p>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold tracking-wide transition-colors cursor-pointer"
        >
          Close Settings
        </button>
      </div>
    </div>
  );
};
