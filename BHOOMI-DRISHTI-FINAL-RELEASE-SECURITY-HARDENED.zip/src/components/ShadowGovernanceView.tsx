/**
 * BHOOMI-DRISHTI PHASE UI-1: SHADOW GOVERNANCE & STATISTICAL TELEMETRY WORKSPACE
 * 
 * Ministry of Road Transport & Highways (MoRTH) / National Highways Authority of India (NHAI)
 * 
 * Strict Institutional Governance Disciplines:
 * 1. Production model V1.0 remains the sole operational system (SHA-256: 7e0e1a7dac2e082c...7f).
 * 2. Candidate model V2.0 operates strictly as SHADOW_CANDIDATE / NON_OPERATIONAL (SHA-256: 4a83e980...a2).
 * 3. Threshold governance status strictly remains PENDING_STAKEHOLDER_APPROVAL.
 * 4. Zero automated promotion or threshold activation controls.
 * 5. Complete RBAC visibility: NODAL_OFFICER, AUDITOR, and VIEWER (Read-Only Audit Mode).
 * 6. Authoritative statutory evidence only — zero fabricated dates, gazette numbers, or outcomes.
 */

import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  FileText,
  Database,
  GitBranch,
  Layers,
  Activity,
  Sliders,
  CheckCircle2,
  XCircle,
  Clock,
  HelpCircle,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Filter,
  Eye,
  Lock,
  Printer,
  Download,
  Copy,
  Check,
  Calendar,
  Search,
  RefreshCw,
  Info
} from 'lucide-react';
import { api } from '../services/apiClient.ts';
import { AuditLogItem } from '../types.ts';
import { ShadowMonitoringWorkspace } from './ShadowMonitoringWorkspace.tsx';
import { ShadowEvaluationWorkspace } from './ShadowEvaluationWorkspace.tsx';
import { AuthoritativeEvidenceWorkspace } from './AuthoritativeEvidenceWorkspace.tsx';

interface ShadowDiagnostics {
  policyConfig: {
    HIGHER_RISK_THRESHOLD: string;
    LOWER_RISK_THRESHOLD: string;
    COST_MATRIX_VERSION: string;
    CANDIDATE_MODEL_PATH: string;
    CANDIDATE_MODEL_VERSION: string;
    DATASET_VERSION: string;
    DATASET_SHA256: string;
    SCHEMA_VERSION: string;
  };
  artifact: {
    exists: boolean;
    path: string;
    sha256: string;
    isAuthorizedArtifact: boolean;
  };
  status: string;
  isOperational: boolean;
}

interface ShadowRecordItem {
  shadow_run_id: string;
  project_id: string;
  observation_timestamp: string;
  model_version: string;
  model_artifact_sha256: string;
  dataset_version: string;
  prediction_probability: number | null;
  prediction_state: 'HIGHER_RISK_SIGNAL' | 'LOWER_RISK_SIGNAL' | 'INSUFFICIENT_EVIDENCE';
  feature_snapshot_hash: string;
  scoring_timestamp: string;
  evidence_status: 'COMPLETE' | 'PARTIAL' | 'INVALID';
  validation_status: 'PASS' | 'OUT_OF_BOUNDS' | 'DRIFT_DETECTED';
}

interface ShadowGovernanceViewProps {
  userRole?: string;
}

export const ShadowGovernanceView: React.FC<ShadowGovernanceViewProps> = ({ userRole }) => {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'evidence' | 'outcomes' | 'monitoring' | 'evaluation' | 'package' | 'thresholds' | 'comparison' | 'gates' | 'memorandum' | 'audit'
  >('overview');

  const [diagnostics, setDiagnostics] = useState<ShadowDiagnostics | null>(null);
  const [records, setRecords] = useState<ShadowRecordItem[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [evidencePackage, setEvidencePackage] = useState<any | null>(null);
  const [outcomesData, setOutcomesData] = useState<any[]>([]);
  const [outcomesSummary, setOutcomesSummary] = useState<any | null>(null);
  const [evalRuns, setEvalRuns] = useState<any[]>([]);
  const [evalExclusions, setEvalExclusions] = useState<any[]>([]);
  const [copiedPackage, setCopiedPackage] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Filters for shadow observations
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [searchProject, setSearchProject] = useState<string>('');

  const isNodalOrAuditor = userRole === 'NODAL_OFFICER' || userRole === 'AUDITOR';
  const isViewer = userRole === 'VIEWER';

  useEffect(() => {
    let mounted = true;
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const [diagRes, runsRes, auditRes, pkgRes, outcomesRes, evalRunsRes, evalExclRes] = await Promise.all([
          api.shadow.getDiagnostics().catch(() => null),
          api.shadow.getRuns({ limit: 100 }).catch(() => ({ records: [], total: 0 })),
          api.getAuditLogs(50).catch(() => []),
          api.shadow.getEvidencePackage().catch(() => null),
          api.shadow.getOutcomes().catch(() => null),
          api.shadow.getEvaluationRuns().catch(() => null),
          api.shadow.getEvaluationExclusions().catch(() => null)
        ]);

        if (mounted) {
          setDiagnostics(diagRes);
          setRecords(runsRes.records || []);
          setTotalRecords(runsRes.total || 0);
          setAuditLogs(auditRes.filter((l: AuditLogItem) => l.entityType === 'shadow_predictions' || l.action === 'SHADOW_SCORING_RUN'));
          if (pkgRes && pkgRes.evidencePackage) {
            setEvidencePackage(pkgRes.evidencePackage);
          }
          if (outcomesRes) {
            setOutcomesData(outcomesRes.outcomes || []);
            setOutcomesSummary(outcomesRes.summary || null);
          }
          if (evalRunsRes && evalRunsRes.runs) {
            setEvalRuns(evalRunsRes.runs);
          }
          if (evalExclRes && evalExclRes.exclusions) {
            setEvalExclusions(evalExclRes.exclusions);
          }
        }
      } catch (err: any) {
        if (mounted) {
          setError(err.message || 'Unable to load shadow governance diagnostics.');
        }
      } finally {
        if (mounted) setLoading(false);
      }
    };

    fetchData();
    return () => {
      mounted = false;
    };
  }, []);

  // Filtered shadow observations
  const filteredRecords = records.filter(r => {
    if (selectedStatusFilter !== 'ALL' && r.prediction_state !== selectedStatusFilter) return false;
    if (searchProject && !r.project_id.toLowerCase().includes(searchProject.toLowerCase())) return false;
    return true;
  });

  // Calculate evidence quality metrics
  const completeEvidenceCount = records.filter(r => r.evidence_status === 'COMPLETE').length;
  const partialEvidenceCount = records.filter(r => r.evidence_status === 'PARTIAL').length;
  const invalidEvidenceCount = records.filter(r => r.evidence_status === 'INVALID').length;
  const outOfBoundsCount = records.filter(r => r.validation_status === 'OUT_OF_BOUNDS').length;
  const insufficientEvidenceCount = records.filter(r => r.prediction_state === 'INSUFFICIENT_EVIDENCE').length;

  return (
    <div className="space-y-6">
      {/* Read-Only Viewer Notice if applicable */}
      {isViewer && (
        <div className="p-4 bg-blue-50 border border-blue-200 text-blue-900 rounded-xl flex items-center justify-between text-xs">
          <div className="flex items-center gap-2.5">
            <Lock className="w-4 h-4 text-blue-700 shrink-0" />
            <div>
              <span className="font-bold">VIEWER SESSION (READ-ONLY AUDIT MODE):</span>{' '}
              All governance telemetry, model cards, evidence packages, and audit trails are fully transparent and inspectable.
              Privileged mutations (running shadow evaluations, approving review items, ingesting gazettes) require Nodal Officer / Auditor credentials.
            </div>
          </div>
          <span className="px-2.5 py-0.5 rounded bg-blue-100 text-blue-800 text-[10px] font-bold border border-blue-300 shrink-0">
            AUDIT READ-ONLY
          </span>
        </div>
      )}

      {/* Mandatory Institutional Governance Banner */}
      <div className="p-5 rounded-2xl bg-amber-50/80 border-2 border-amber-300 text-slate-800 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 bg-amber-100 text-amber-800 rounded-lg border border-amber-300 mt-0.5 shrink-0">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-xs font-black tracking-widest text-amber-950 uppercase bg-amber-200 px-2.5 py-0.5 rounded border border-amber-400">
                  V2 SHADOW CANDIDATE — NON-OPERATIONAL
                </span>
                <span className="text-xs font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                  THRESHOLDS: PENDING STAKEHOLDER APPROVAL
                </span>
                <span className="text-xs text-amber-800 font-medium">
                  Section 3A(7) Statutory Framework · Phase 7B Protocol
                </span>
              </div>
              <h1 className="text-lg font-bold text-slate-900 mt-1">
                Candidate Model Shadow Governance &amp; Independent Evaluation Workspace
              </h1>
              <p className="text-xs text-slate-700 mt-1 max-w-4xl leading-relaxed">
                <strong>Purpose of Shadow Evaluation:</strong> Testing next-generation forecasting capabilities alongside official operations without operational risk.
                Production model V1.0 remains active and authoritative. Candidate model V2.0 runs strictly in an isolated shadow environment and <strong>does not alter</strong> operational
                risk levels, executive alerts, project attention items, official reports, or database records.
                The decision threshold policy is strictly <strong>PENDING STAKEHOLDER APPROVAL</strong>.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-start md:self-center shrink-0">
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              Print Governance Brief
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div role="tablist" aria-label="Shadow Governance Navigation" className="flex flex-wrap items-center gap-1 border-b border-slate-200 pb-px">
        {[
          { id: 'overview', label: 'Governance Overview', icon: Layers },
          { id: 'evidence', label: 'Authoritative Evidence Matrix', icon: ShieldCheck },
          { id: 'outcomes', label: 'Statutory Outcome Tracking', icon: Calendar },
          { id: 'monitoring', label: 'Drift & Continuous Monitoring (Phase 7B-6)', icon: Activity },
          { id: 'evaluation', label: 'Model Evaluation & Calibration (Phase 7B-7)', icon: ShieldCheck },
          { id: 'package', label: 'Governance Evidence Package (Phase 7B-10)', icon: FileText },
          { id: 'thresholds', label: 'Threshold Policy & Cost Matrix', icon: Sliders },
          { id: 'comparison', label: 'V1 vs Candidate Comparison', icon: GitBranch },
          { id: 'gates', label: 'Six Promotion Gates', icon: CheckCircle2 },
          { id: 'memorandum', label: 'Draft Policy Memorandum', icon: FileText },
          { id: 'audit', label: 'Shadow Audit Ledger & Provenance', icon: Database }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              role="tab"
              aria-selected={isActive}
              aria-controls={`panel-${tab.id}`}
              id={`tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3 py-2 text-xs font-medium border-b-2 transition-colors cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-slate-900 focus-visible:ring-offset-1 ${
                isActive
                  ? 'border-slate-900 text-slate-900 font-bold bg-white rounded-t-lg'
                  : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-900' : 'text-slate-400'}`} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: OVERVIEW                                                           */}
      {/* ========================================================================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Top Status Banner */}
          <div className="bg-slate-900 text-white rounded-xl p-6 border border-slate-800 shadow-sm space-y-3">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-lg border border-indigo-500/40 shrink-0">
                <Activity className="w-6 h-6" />
              </div>
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="text-xs font-black tracking-wider uppercase bg-amber-400 text-slate-950 px-2 py-0.5 rounded">
                    V2 SHADOW CANDIDATE — NON-OPERATIONAL
                  </span>
                  <span className="text-xs font-bold text-amber-300 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800">
                    THRESHOLDS: PENDING STAKEHOLDER APPROVAL
                  </span>
                </div>
                <h3 className="text-base font-bold text-white">
                  CANDIDATE V2 ARTIFACT VERIFIED &amp; MONITORED IN SHADOW MODE
                </h3>
                <p className="text-xs text-slate-300 max-w-4xl leading-relaxed">
                  Candidate model V2.0 artifact is verified and frozen (SHA-256: <code>4a83e980f9178498be4592a47303f0ebc5ea641934952af5bee92ae5b76729a2</code>).
                  Longitudinal feature extraction (SCHEMA-LONGITUDINAL-V2.0-10FEAT), statistical drift detection (PSI/KS), and Section 3A/3D statutory outcome tracking
                  are operational in shadow mode with zero production mutation. Production model V1.0 (SHA-256: <code>7e0e1a7dac2e082c...7f</code>) remains 100% active and authoritative.
                </p>
              </div>
            </div>
          </div>

          {/* Model / Dataset Governance Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Production Model</span>
              <div className="text-sm font-bold text-slate-900 mt-1">BHOOMI-DRISHTI-ML-V1.0</div>
              <div className="text-[11px] text-emerald-700 font-semibold mt-0.5 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Active Operational Model
              </div>
              <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 font-mono break-all">
                SHA-256: 7e0e1a7dac2e082c...7f
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Candidate Shadow Model</span>
              <div className="text-sm font-bold text-slate-900 mt-1">BHOOMI-DRISHTI-ML-V2.0-SHADOW</div>
              <div className="text-[11px] text-indigo-700 font-semibold mt-0.5 flex items-center gap-1">
                <Activity className="w-3.5 h-3.5" />
                SHADOW_CANDIDATE (Non-Operational)
              </div>
              <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 font-mono break-all">
                SHA-256: 4a83e980f9178498...a2
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Benchmark Dataset</span>
              <div className="text-sm font-bold text-slate-900 mt-1">2.0.0-phase4c-authentic</div>
              <div className="text-[11px] text-slate-600 font-medium mt-0.5">
                399 Observations · 152 Unique Projects
              </div>
              <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 font-mono break-all">
                SHA-256: 0da40152ca0866ec...2a
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Threshold Governance</span>
              <div className="text-sm font-bold text-slate-900 mt-1">PENDING APPROVAL</div>
              <div className="text-[11px] text-rose-700 font-semibold mt-0.5 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Cost Matrix Not Yet Approved
              </div>
              <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 font-mono">
                Contract: 10 Longitudinal Features
              </div>
            </div>
          </div>

          {/* 4 Architectural Safeguards Grid */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Institutional Safety &amp; Production Isolation Invariants
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Operational Isolation</span>
                <div className="text-sm font-bold text-emerald-800 flex items-center gap-1">
                  <Check className="w-4 h-4" /> 100% ISOLATED
                </div>
                <p className="text-[11px] text-slate-600">
                  Zero automated promotion paths. Production routes load only V1 artifact.
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Database Immutability</span>
                <div className="text-sm font-bold text-emerald-800 flex items-center gap-1">
                  <Check className="w-4 h-4" /> VERIFIED (31 Projects)
                </div>
                <p className="text-[11px] text-slate-600">
                  PRAGMA integrity_check passes. Operational scores, alerts, recommendations unchanged.
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Cryptographic Parity</span>
                <div className="text-sm font-bold text-emerald-800 flex items-center gap-1">
                  <Check className="w-4 h-4" /> MATCH (Delta &le; 1e-12)
                </div>
                <p className="text-[11px] text-slate-600">
                  V1 SHA, V2 SHA, Dataset SHA verified. Repeat scoring verified deterministic.
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Evaluation Gating</span>
                <div className="text-sm font-bold text-amber-800 flex items-center gap-1">
                  <Info className="w-4 h-4" /> OUTCOME_MATURITY_INSUFFICIENT
                </div>
                <p className="text-[11px] text-slate-600">
                  Statistical metrics suppressed honestly when sample &lt; 10 mature observations.
                </p>
              </div>
            </div>
          </div>

          {/* Executive 7-Point Governance Brief */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-2.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-900" />
                  Executive Governance Brief — 7 Key Clarifications for MoRTH &amp; NHAI Officials
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  High-level summary separating operational reality from background evaluation
                </p>
              </div>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900 border border-blue-200 self-start sm:self-auto">
                STATUTORY DISCLOSURE
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-[10px] font-bold">1</span>
                  What is the shadow model?
                </span>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  Candidate Random Forest V2.0 testing 10 longitudinal features (including 3D-to-3G conversion velocity and Tehsil dispute density).
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-[10px] font-bold">2</span>
                  Is it operational?
                </span>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  <strong>Strictly No.</strong> Production Model V1.0 remains the sole legally authoritative decision-support system. V2 has zero operational power.
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-[10px] font-bold">3</span>
                  What evidence is available?
                </span>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  Point-in-time e-Gazette evidence classified across all 31 operational corridors under 5 canonical states (Complete, Pre-3A, Partial, etc.).
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-[10px] font-bold">4</span>
                  Is the data stable?
                </span>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  <strong>Yes.</strong> Continuous monitoring tracks PSI (&lt; 0.10) and KS statistics with zero uncontrolled feature drift.
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center text-[10px] font-bold">5</span>
                  Is evaluation possible?
                </span>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  <strong>Gated.</strong> System truthfully suppresses formal promotion metrics until at least 10 mature statutory outcomes accumulate.
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center text-[10px] font-bold">6</span>
                  What requires human review?
                </span>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  Pre-3A corridor alignment planning (e.g. BhoomiRashi_57405) and Tehsil land record title reconciliations.
                </p>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1 md:col-span-2 lg:col-span-3">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center text-[10px] font-bold">7</span>
                  What is only diagnostic?
                </span>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  All V2 shadow scores, multi-threshold curves, and bootstrap confidence intervals are diagnostic only. Decision thresholds remain locked to <strong className="text-slate-900">PENDING_STAKEHOLDER_APPROVAL</strong>.
                </p>
              </div>
            </div>
          </div>

          {/* Three-State Governance Architecture */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-slate-700" />
              Three-State Operational Governance Contract
            </h3>
            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              BhoomiDrishti avoids forced binary decisions by enforcing a three-state operational output.
              The third state (<code className="font-mono bg-slate-100 px-1 py-0.5 rounded text-slate-800">INSUFFICIENT_EVIDENCE</code>) is a data-quality
              and provenance circuit breaker that bypasses probability thresholding.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-red-50/60 border border-red-200">
                <span className="text-xs font-bold text-red-900 uppercase tracking-wider">State 1: HIGHER_RISK_SIGNAL</span>
                <p className="text-xs text-red-800 mt-2 leading-relaxed">
                  Triggered only when model probability &ge; threshold AND all point-in-time evidence gates are 100% verified.
                  <em> (Currently inactive pending approved stakeholder threshold).</em>
                </p>
              </div>

              <div className="p-4 rounded-lg bg-emerald-50/60 border border-emerald-200">
                <span className="text-xs font-bold text-emerald-900 uppercase tracking-wider">State 2: LOWER_RISK_SIGNAL</span>
                <p className="text-xs text-emerald-800 mt-2 leading-relaxed">
                  Triggered only when model probability &lt; threshold AND all point-in-time evidence gates are 100% verified.
                  <em> (Currently inactive pending approved stakeholder threshold).</em>
                </p>
              </div>

              <div className="p-4 rounded-lg bg-slate-100 border border-slate-300">
                <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">State 3: INSUFFICIENT_EVIDENCE</span>
                <p className="text-xs text-slate-700 mt-2 leading-relaxed">
                  Emitted when statutory Section 3A date is unverified, features are missing or out of bounds,
                  or threshold policy is pending. <strong>Active safe fallback state.</strong>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: AUTHORITATIVE EVIDENCE WORKSPACE                                    */}
      {/* ========================================================================= */}
      {activeTab === 'evidence' && (
        <AuthoritativeEvidenceWorkspace userRole={userRole} />
      )}

      {/* ========================================================================= */}
      {/* TAB 3: RETROSPECTIVE STATUTORY OUTCOME TRACKING                           */}
      {/* ========================================================================= */}
      {activeTab === 'outcomes' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-tight flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-indigo-600" />
                  Retrospective Statutory Outcome Tracking (Section 3A vs 3D)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Authoritative e-Gazette ground-truth reconciliation under Section 3A(7) 365-day statutory acquisition lapse rule.
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500">
                Total Reconciled Corridors: {outcomesData.length}
              </span>
            </div>

            {/* Outcome Summary Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Mature Outcomes</span>
                <div className="text-lg font-bold text-slate-900 mt-0.5">
                  {outcomesSummary?.matureOutcomesCount || outcomesData.filter(o => o.is_mature === 1).length}
                </div>
                <span className="text-[10px] text-slate-400">Statutory Window Resolved</span>
              </div>

              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
                <span className="text-[10px] font-bold text-amber-800 uppercase">Pending Statutory Window</span>
                <div className="text-lg font-bold text-amber-950 mt-0.5">
                  {outcomesSummary?.pendingOutcomesCount || outcomesData.filter(o => o.statutory_outcome === 'OUTCOME_PENDING').length}
                </div>
                <span className="text-[10px] text-amber-700">&lt; 365 days since Section 3A</span>
              </div>

              <div className="p-3 bg-rose-50 rounded-lg border border-rose-200">
                <span className="text-[10px] font-bold text-rose-800 uppercase">Delayed / Lapsed</span>
                <div className="text-lg font-bold text-rose-950 mt-0.5">
                  {outcomesSummary?.delayedCount || outcomesData.filter(o => o.statutory_outcome === 'DELAYED_LAPSED').length}
                </div>
                <span className="text-[10px] text-rose-700">&gt; 365 days window breach</span>
              </div>

              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                <span className="text-[10px] font-bold text-emerald-800 uppercase">Completed On-Time</span>
                <div className="text-lg font-bold text-emerald-950 mt-0.5">
                  {outcomesSummary?.completedOnTimeCount || outcomesData.filter(o => o.statutory_outcome === 'COMPLETED_ON_TIME').length}
                </div>
                <span className="text-[10px] text-emerald-700">Section 3D within 365 days</span>
              </div>
            </div>

            {/* Outcomes Table */}
            <div className="overflow-x-auto border border-slate-100 rounded-lg">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200 uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="py-2.5 px-3">Corridor ID</th>
                    <th className="py-2.5 px-3">Observation Time</th>
                    <th className="py-2.5 px-3">Section 3A Notice</th>
                    <th className="py-2.5 px-3">Section 3D Notice</th>
                    <th className="py-2.5 px-3">Window Duration</th>
                    <th className="py-2.5 px-3">Statutory Outcome</th>
                    <th className="py-2.5 px-3">Maturity Status</th>
                    <th className="py-2.5 px-3">Provenance Reference</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                  {outcomesData.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-400 font-sans italic">
                        No reconciled statutory outcome records found in the database.
                      </td>
                    </tr>
                  ) : (
                    outcomesData.map(row => (
                      <tr key={row.outcome_id || row.project_id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-bold text-slate-900">{row.project_id}</td>
                        <td className="py-2.5 px-3 text-slate-600">{(row.observation_timestamp || '').slice(0, 10)}</td>
                        <td className="py-2.5 px-3 text-slate-700">{row.first_3a_date || '—'}</td>
                        <td className="py-2.5 px-3 text-slate-700">{row.section_3d_date || 'None Published'}</td>
                        <td className="py-2.5 px-3 text-slate-700">
                          {row.outcome_window_days !== null && row.outcome_window_days !== undefined
                            ? `${row.outcome_window_days} days`
                            : 'Ongoing'}
                        </td>
                        <td className="py-2.5 px-3 font-sans">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                            row.statutory_outcome === 'COMPLETED_ON_TIME'
                              ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                              : row.statutory_outcome === 'DELAYED_LAPSED'
                              ? 'bg-rose-100 text-rose-900 border-rose-300'
                              : row.statutory_outcome === 'OUTCOME_PENDING'
                              ? 'bg-amber-100 text-amber-900 border-amber-300'
                              : 'bg-slate-100 text-slate-700 border-slate-300'
                          }`}>
                            {row.statutory_outcome}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-sans">
                          <span className={`text-[10px] font-bold ${
                            row.is_mature === 1 ? 'text-emerald-700' : 'text-amber-700'
                          }`}>
                            {row.is_mature === 1 ? 'MATURE' : 'IMMATURE'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-500 truncate max-w-[160px]" title={row.provenance_reference || ''}>
                          {row.provenance_reference || 'Official Gazette Reconciliation'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: DRIFT & CONTINUOUS MONITORING                                       */}
      {/* ========================================================================= */}
      {activeTab === 'monitoring' && (
        <ShadowMonitoringWorkspace userRole={userRole} />
      )}

      {/* ========================================================================= */}
      {/* TAB 5: MODEL EVALUATION & CALIBRATION                                     */}
      {/* ========================================================================= */}
      {activeTab === 'evaluation' && (
        <ShadowEvaluationWorkspace userRole={userRole} />
      )}

      {/* ========================================================================= */}
      {/* TAB 6: GOVERNANCE EVIDENCE PACKAGE (PHASE 7B-10)                          */}
      {/* ========================================================================= */}
      {activeTab === 'package' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-4 mb-6">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-black uppercase tracking-wider bg-slate-900 text-white px-2 py-0.5 rounded">
                    PHASE 7B-10 EVIDENCE PACKAGE
                  </span>
                  <span className="text-xs text-slate-500 font-semibold">Institutional Shadow Audit Artifact</span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  Long-Run Shadow Validation & Governance Evidence Package
                </h3>
                <p className="text-xs text-slate-600 mt-0.5">
                  Durable, auditable evidence package verifying deterministic V2 shadow execution across repeated runs with zero production impact.
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => {
                    if (evidencePackage) {
                      navigator.clipboard.writeText(JSON.stringify(evidencePackage, null, 2));
                      setCopiedPackage(true);
                      setTimeout(() => setCopiedPackage(false), 2000);
                    }
                  }}
                  className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  {copiedPackage ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedPackage ? 'Copied JSON' : 'Copy Package JSON'}
                </button>
                <button
                  onClick={() => {
                    if (evidencePackage) {
                      const blob = new Blob([JSON.stringify(evidencePackage, null, 2)], { type: 'application/json' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `bhoomidrishti_phase_7b10_evidence_package_${Date.now()}.json`;
                      a.click();
                      URL.revokeObjectURL(url);
                    }
                  }}
                  className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  Export Artifact (.json)
                </button>
              </div>
            </div>

            {/* High-Level Status Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="p-4 rounded-lg bg-indigo-50/70 border border-indigo-200">
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-800">Candidate V2 Status</span>
                <div className="text-sm font-bold text-slate-900 mt-1">SHADOW_CANDIDATE</div>
                <div className="text-[11px] text-indigo-700 font-semibold mt-0.5">NON_OPERATIONAL</div>
              </div>

              <div className="p-4 rounded-lg bg-amber-50/70 border border-amber-200">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800">Threshold Governance</span>
                <div className="text-sm font-bold text-slate-900 mt-1">PENDING APPROVAL</div>
                <div className="text-[11px] text-amber-700 font-semibold mt-0.5">Stakeholder Sign-off Required</div>
              </div>

              <div className="p-4 rounded-lg bg-emerald-50/70 border border-emerald-200">
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">Production Model</span>
                <div className="text-sm font-bold text-slate-900 mt-1">BHOOMI-DRISHTI-ML-V1.0</div>
                <div className="text-[11px] text-emerald-700 font-semibold mt-0.5">Sole Authoritative System</div>
              </div>

              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">Operational Cohort</span>
                <div className="text-sm font-bold text-slate-900 mt-1">31 PROJECTS</div>
                <div className="text-[11px] text-emerald-700 font-semibold mt-0.5">100% Unchanged Population</div>
              </div>
            </div>

            {/* Raw JSON Inspect View */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Verifiable Evidence Payload
                </span>
                <span className="text-[11px] font-mono text-slate-500">
                  data/shadow_evaluation/phase_7b10_evidence_package.json
                </span>
              </div>
              <pre className="p-4 bg-slate-900 text-slate-100 rounded-xl text-xs font-mono overflow-x-auto max-h-96 leading-relaxed border border-slate-800">
                {evidencePackage ? JSON.stringify(evidencePackage, null, 2) : '// Loading evidence package...'}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 7: THRESHOLD POLICY & COST MATRIX                                      */}
      {/* ========================================================================= */}
      {activeTab === 'thresholds' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-200 pb-4 mb-5">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Phase 5B Temporal Holdout Empirical Trade-off Analysis
                </h3>
                <p className="text-xs text-slate-600 mt-0.5">
                  Evaluated on 46 unseen future projects (113 observations, 67 delayed, 46 on-track) initiated chronologically on or after 2023-01-01.
                </p>
              </div>
              <div className="px-3 py-1 bg-amber-100 text-amber-900 rounded-lg text-xs font-bold border border-amber-300 shrink-0">
                POLICY STATUS: PENDING STAKEHOLDER APPROVAL
              </div>
            </div>

            {/* Threshold Evidence Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold uppercase tracking-wider border-b border-slate-300">
                    <th className="py-2.5 px-3">Threshold (&tau;)</th>
                    <th className="py-2.5 px-3">Recall (Sensitivity)</th>
                    <th className="py-2.5 px-3">Specificity</th>
                    <th className="py-2.5 px-3">Precision</th>
                    <th className="py-2.5 px-3">Balanced Accuracy</th>
                    <th className="py-2.5 px-3 text-amber-800">False Alarms (FP)</th>
                    <th className="py-2.5 px-3 text-red-800">Missed Lapses (FN)</th>
                    <th className="py-2.5 px-3">Operational Trade-off</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-900">0.30</td>
                    <td className="py-2.5 px-3 font-mono">1.0000 (100.0%)</td>
                    <td className="py-2.5 px-3 font-mono text-slate-500">0.1522 (15.2%)</td>
                    <td className="py-2.5 px-3 font-mono">0.6321</td>
                    <td className="py-2.5 px-3 font-mono">0.5761</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-amber-700">39 / 46 on-track</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-emerald-700">0 / 67 delayed</td>
                    <td className="py-2.5 px-3 text-slate-600">Zero missed statutory lapses; high administrative burden (85% false alarm rate).</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-900">0.40</td>
                    <td className="py-2.5 px-3 font-mono">0.9851 (98.5%)</td>
                    <td className="py-2.5 px-3 font-mono">0.4348 (43.5%)</td>
                    <td className="py-2.5 px-3 font-mono">0.7174</td>
                    <td className="py-2.5 px-3 font-mono">0.7099</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-amber-700">26 / 46 on-track</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">1 / 67 delayed</td>
                    <td className="py-2.5 px-3 text-slate-600">Catches 66/67 lapses; false alarms reduced to 26 corridors.</td>
                  </tr>
                  <tr className="hover:bg-slate-50 bg-slate-50/70">
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-900">0.50</td>
                    <td className="py-2.5 px-3 font-mono">0.9403 (94.0%)</td>
                    <td className="py-2.5 px-3 font-mono">0.6087 (60.9%)</td>
                    <td className="py-2.5 px-3 font-mono">0.7778</td>
                    <td className="py-2.5 px-3 font-mono">0.7745</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-amber-700">18 / 46 on-track</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">4 / 67 delayed</td>
                    <td className="py-2.5 px-3 text-slate-600">Standard uncalibrated midpoint; 63 lapses detected, 28 on-track cleared.</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-900">0.60</td>
                    <td className="py-2.5 px-3 font-mono">0.6269 (62.7%)</td>
                    <td className="py-2.5 px-3 font-mono">0.8261 (82.6%)</td>
                    <td className="py-2.5 px-3 font-mono">0.8400</td>
                    <td className="py-2.5 px-3 font-mono">0.7265</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-emerald-700">8 / 46 on-track</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-rose-700">25 / 67 delayed</td>
                    <td className="py-2.5 px-3 text-slate-600">Fewer false alarms (8); unacceptably high lapse rate (25 unflagged lapses).</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-900">0.70</td>
                    <td className="py-2.5 px-3 font-mono">0.4925 (49.3%)</td>
                    <td className="py-2.5 px-3 font-mono">0.9565 (95.7%)</td>
                    <td className="py-2.5 px-3 font-mono">0.9429</td>
                    <td className="py-2.5 px-3 font-mono">0.7245</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-emerald-700">2 / 46 on-track</td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-rose-700">34 / 67 delayed</td>
                    <td className="py-2.5 px-3 text-slate-600">Conservative alerting; misses 34 out of 67 statutory window lapses.</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 leading-relaxed">
              <strong>Notice:</strong> This table reflects empirical performance on authentic historical records.
              <strong> No threshold is highlighted as recommended or optimal.</strong> Selecting an operational threshold
              requires formal stakeholder determination of the institutional cost ratio between a false alarm (unnecessary scrutiny)
              and a missed lapse (Section 3A statutory expiry).
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 8: V1 VS CANDIDATE COMPARISON                                         */}
      {/* ========================================================================= */}
      {activeTab === 'comparison' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center shadow-xs">
            <GitBranch className="w-10 h-10 text-indigo-600 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-900">
              Comparative Analysis: Operational V1.0 vs Candidate V2.0
            </h3>
            <p className="text-xs text-slate-600 max-w-xl mx-auto mt-2 leading-relaxed">
              Disagreement rate monitoring and correlation diagnostics are continuously computed in shadow mode.
              Candidate scores operate purely diagnostically with zero impact on live operational risk scores.
            </p>
            <div className="mt-6 pt-6 border-t border-slate-100 max-w-md mx-auto text-left space-y-2">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">Scheduled Comparison Dimensions:</div>
              <ul className="text-xs text-slate-600 list-disc list-inside space-y-1">
                <li>Directional disagreement rate: |P(V1.0) - P(V2.0)| &gt; 0.20</li>
                <li>State divergence: High vs Low risk classification discordance</li>
                <li>Mean absolute probability difference across regional cohorts</li>
                <li>Relative frequency of INSUFFICIENT_EVIDENCE emissions</li>
                <li>Post-resolution Brier score comparison on matured statutory outcomes</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 9: SIX PROMOTION GATES                                                 */}
      {/* ========================================================================= */}
      {activeTab === 'gates' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="border-b border-slate-200 pb-4 mb-5">
              <h3 className="text-base font-bold text-slate-900">
                Institutional Promotion Gates for Candidate Model V2.0
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Every gate must be independently satisfied and formally signed off before V2.0 may be considered for operational deployment.
              </p>
            </div>

            <div className="space-y-4">
              {[
                {
                  id: 'Gate 1',
                  title: 'Temporal Holdout Validation Pass',
                  status: 'VERIFIED',
                  statusColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
                  description: 'Candidate model achieves ROC-AUC >= 0.70 on future chronological holdout without data leakage.'
                },
                {
                  id: 'Gate 2',
                  title: 'Cryptographic Zero-Leakage Verification',
                  status: 'VERIFIED',
                  statusColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
                  description: 'Strict point-in-time enforcement: zero Section 3D dates or target variables present in feature vectors.'
                },
                {
                  id: 'Gate 3',
                  title: 'Statistically Validated Shadow Observation Window',
                  status: 'IN_PROGRESS',
                  statusColor: 'bg-indigo-100 text-indigo-800 border-indigo-300',
                  description: 'Active continuous shadow monitoring tracking feature drift (PSI/KS) and prediction stability.'
                },
                {
                  id: 'Gate 4',
                  title: 'Formal Stakeholder Threshold Sign-off',
                  status: 'PENDING_APPROVAL',
                  statusColor: 'bg-amber-100 text-amber-900 border-amber-300',
                  description: 'Executive committee and CALA nodal officers review the cost-matrix trade-off curve and formally select a decision threshold.'
                },
                {
                  id: 'Gate 5',
                  title: 'Automated Dual-Run Parity & Fallback Verification',
                  status: 'VERIFIED',
                  statusColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
                  description: 'Shadow scoring pipeline operates concurrently without degrading V1 production latency or altering live tables.'
                },
                {
                  id: 'Gate 6',
                  title: 'CALA Competent Authority Policy Memorandum',
                  status: 'PENDING_SIGNATURE',
                  statusColor: 'bg-amber-100 text-amber-900 border-amber-300',
                  description: 'Written policy circular issued and counter-signed by CALA Nodal Officer and MoRTH Joint Secretary.'
                }
              ].map(gate => (
                <div key={gate.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-500">{gate.id}:</span>
                      <span className="font-bold text-slate-900 text-sm">{gate.title}</span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1">{gate.description}</p>
                  </div>
                  <span className={`px-2.5 py-1 rounded text-xs font-bold border shrink-0 ${gate.statusColor}`}>
                    {gate.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 10: DRAFT POLICY MEMORANDUM                                           */}
      {/* ========================================================================= */}
      {activeTab === 'memorandum' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-8 shadow-xs max-w-4xl mx-auto space-y-6 text-xs text-slate-800 font-serif leading-relaxed">
            <div className="text-center border-b pb-4 space-y-1 font-sans">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-widest">Government of India</div>
              <div className="text-sm font-bold text-slate-900">Ministry of Road Transport &amp; Highways (MoRTH)</div>
              <div className="text-xs text-slate-600">Land Acquisition &amp; Statutory Compliance Monitoring Cell</div>
              <div className="text-[11px] text-amber-800 font-mono font-bold mt-2">DRAFT FOR INTER-DEPARTMENTAL CIRCULATION ONLY</div>
            </div>

            <div className="space-y-3">
              <p><strong>Memorandum Reference:</strong> MoRTH/NHAI/LA-DRISHTI/2026/04</p>
              <p><strong>Subject:</strong> Evaluation and Shadow Benchmark of Machine Learning Model V2.0 for Land Acquisition Delay Warning System.</p>
              <p>
                1. <strong>Background:</strong> Under the National Highways Act, 1956, land acquisition notifications under Section 3A expire after 365 days
                unless followed by a Section 3D declaration. The BHOOMI-DRISHTI system currently deploys Production Model V1.0 to monitor acquisition timelines.
              </p>
              <p>
                2. <strong>Candidate Model V2.0:</strong> An offline candidate model (V2.0-SHADOW) has been developed utilizing longitudinal notification
                frequency features and point-in-time statutory milestones.
              </p>
              <p>
                3. <strong>Shadow Governance Status:</strong> V2.0 operates strictly in shadow evaluation mode without modifying live operational tables,
                risk scores, or priority alerts.
              </p>
              <p>
                4. <strong>Threshold Decision:</strong> A selection of the operational classification threshold remains subject to formal stakeholder sign-off
                under Gate 4 of the Governance Protocol.
              </p>
            </div>

            <div className="pt-6 border-t-2 border-slate-300 grid grid-cols-2 gap-8 font-sans">
              <div className="space-y-4">
                <div className="text-xs font-bold text-slate-900 uppercase">Recommended By:</div>
                <div className="border-b border-slate-400 h-8"></div>
                <div className="text-[11px] text-slate-500">
                  <div>Designation: CALA Nodal Officer</div>
                  <div className="mt-1">Status: Pending Formal Review</div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="text-xs font-bold text-slate-900 uppercase">Approved By:</div>
                <div className="border-b border-slate-400 h-8"></div>
                <div className="text-[11px] text-slate-500">
                  <div>Designation: Competent Authority / MoRTH Joint Secretary</div>
                  <div className="mt-1">Status: Pending Stakeholder Approval</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 11: SHADOW AUDIT LEDGER & PROVENANCE                                   */}
      {/* ========================================================================= */}
      {activeTab === 'audit' && (
        <div className="space-y-6">
          {/* Cryptographic Artifacts Matrix */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
            <h4 className="text-sm font-bold text-slate-900 uppercase tracking-tight flex items-center gap-2">
              <Database className="w-4 h-4 text-slate-700" />
              Cryptographic Invariants &amp; Artifact Verification Matrix
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                    <th className="py-2.5 px-3">Component</th>
                    <th className="py-2.5 px-3">Canonical Version</th>
                    <th className="py-2.5 px-3">Authoritative SHA-256 Hash</th>
                    <th className="py-2.5 px-3">Validation Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-sans font-semibold text-slate-900">Production V1 Model</td>
                    <td className="py-2.5 px-3 font-sans">BHOOMI-DRISHTI-ML-V1.0</td>
                    <td className="py-2.5 px-3 text-slate-700">7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f</td>
                    <td className="py-2.5 px-3 font-sans">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        MATCH (VERIFIED)
                      </span>
                    </td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-sans font-semibold text-slate-900">Shadow V2 Candidate</td>
                    <td className="py-2.5 px-3 font-sans">BHOOMI-DRISHTI-ML-V2.0-SHADOW</td>
                    <td className="py-2.5 px-3 text-slate-700">4a83e980f9178498be4592a47303f0ebc5ea641934952af5bee92ae5b76729a2</td>
                    <td className="py-2.5 px-3 font-sans">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        MATCH (VERIFIED)
                      </span>
                    </td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-sans font-semibold text-slate-900">Benchmark Dataset</td>
                    <td className="py-2.5 px-3 font-sans">2.0.0-phase4c-authentic</td>
                    <td className="py-2.5 px-3 text-slate-700">0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a</td>
                    <td className="py-2.5 px-3 font-sans">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        MATCH (VERIFIED)
                      </span>
                    </td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-sans font-semibold text-slate-900">Feature Schema</td>
                    <td className="py-2.5 px-3 font-sans">SCHEMA-LONGITUDINAL-V2.0-10FEAT</td>
                    <td className="py-2.5 px-3 font-sans text-slate-700">10 Verified Longitudinal Features (0 Quarantined)</td>
                    <td className="py-2.5 px-3 font-sans">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        CONFORMS
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Evaluation Runs History */}
          {evalRuns.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-bold text-slate-900 uppercase">Statistical Evaluation Runs ({evalRuns.length})</span>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                      <th className="py-2.5 px-3">Run ID</th>
                      <th className="py-2.5 px-3">Dataset Hash</th>
                      <th className="py-2.5 px-3">Mature Observations</th>
                      <th className="py-2.5 px-3">Exclusions</th>
                      <th className="py-2.5 px-3">Triggered At</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                    {evalRuns.map(run => (
                      <tr key={run.run_id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-bold text-slate-900">{run.run_id}</td>
                        <td className="py-2.5 px-3 text-slate-600">{(run.dataset_hash || '').slice(0, 16)}...</td>
                        <td className="py-2.5 px-3 text-slate-700 font-bold">{run.mature_observations_count}</td>
                        <td className="py-2.5 px-3 text-slate-700">{run.exclusions_count}</td>
                        <td className="py-2.5 px-3 text-slate-500">{run.started_at}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Exclusion Ledger */}
          {evalExclusions.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-700" />
                  <span className="text-xs font-bold text-slate-900 uppercase">Evaluation Exclusion Ledger ({evalExclusions.length})</span>
                </div>
              </div>
              <div className="overflow-x-auto max-h-60">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                      <th className="py-2 px-3">Project ID</th>
                      <th className="py-2 px-3">Exclusion Reason</th>
                      <th className="py-2 px-3">Observation Time</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                    {evalExclusions.slice(0, 30).map((ex, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-bold text-slate-900">{ex.project_id}</td>
                        <td className="py-2 px-3 font-sans text-rose-700">{ex.reason}</td>
                        <td className="py-2 px-3 text-slate-500">{(ex.observation_timestamp || '').slice(0, 10)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Audit Logs Trail */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-slate-600" />
                <span className="text-xs font-bold text-slate-900 uppercase">Immutable Shadow Audit Log Trail</span>
              </div>
              <span className="text-xs text-slate-500 font-mono">({auditLogs.length} audit records)</span>
            </div>

            {auditLogs.length === 0 ? (
              <div className="py-16 text-center text-slate-500">
                <p className="text-sm font-semibold">NO SHADOW AUDIT EVENTS RECORDED</p>
                <p className="text-xs mt-1">Audit log records will appear here whenever shadow scoring runs or governance queries execute.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                      <th className="py-2.5 px-3">Timestamp</th>
                      <th className="py-2.5 px-3">Actor / User</th>
                      <th className="py-2.5 px-3">Action</th>
                      <th className="py-2.5 px-3">Resource</th>
                      <th className="py-2.5 px-3">Run ID / Target</th>
                      <th className="py-2.5 px-3">Result</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                    {auditLogs.map(log => (
                      <tr key={log.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 text-slate-600">{log.timestamp}</td>
                        <td className="py-2.5 px-3 font-sans font-semibold text-slate-900">{log.userId}</td>
                        <td className="py-2.5 px-3 text-blue-700 font-bold">{log.action}</td>
                        <td className="py-2.5 px-3 text-slate-600">{log.entityType}</td>
                        <td className="py-2.5 px-3 text-slate-500">{log.entityId || 'N/A'}</td>
                        <td className="py-2.5 px-3">
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            {log.newValue ? 'RECORDED' : 'LOGGED'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
