import React from 'react';
import { RiskLevel, StageStatus, SourceClassification, Section3aSource } from '../types.ts';

interface RiskBadgeProps {
  level: RiskLevel;
  className?: string;
  showDot?: boolean;
}

export const RiskBadge: React.FC<RiskBadgeProps> = ({ level, className = '', showDot = true }) => {
  let colorClasses = '';
  let dotClass = '';
  let label = '';

  switch (level) {
    case 'HIGH':
      colorClasses = 'bg-red-50 text-red-800 border-red-200';
      dotClass = 'bg-red-600';
      label = 'HIGH RISK';
      break;
    case 'MEDIUM':
      colorClasses = 'bg-amber-50 text-amber-900 border-amber-200';
      dotClass = 'bg-amber-600';
      label = 'MEDIUM RISK';
      break;
    case 'LOW':
      colorClasses = 'bg-emerald-50 text-emerald-800 border-emerald-200';
      dotClass = 'bg-emerald-600';
      label = 'LOW RISK';
      break;
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-bold border tracking-wider uppercase tabular-nums ${colorClasses} ${className}`}
    >
      {showDot && <span className={`w-1.5 h-1.5 rounded-full ${dotClass} shrink-0`} />}
      {label}
    </span>
  );
};

export const DataSourceBadge: React.FC<{
  source?: string;
  source_type?: SourceClassification;
  isSynthetic?: boolean;
  className?: string;
}> = ({ source, source_type, isSynthetic, className = '' }) => {
  // Respect explicit source_type classification if present
  const resolvedType: SourceClassification = source_type || (
    isSynthetic ? 'SEEDED' :
    source === 'OfficialExport' ? 'IMPORTED' :
    (source === 'BhoomiRashi' && !isSynthetic ? 'SEEDED' : 'SEEDED')
  );

  if (resolvedType === 'VERIFIED_EXTERNAL') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-50 text-emerald-900 border border-emerald-300 tracking-wide uppercase shadow-2xs ${className}`}
        title="Authoritative external record verified directly with MoRTH BhoomiRashi portal"
      >
        <span className="w-1.5 h-1.5 rounded-xs bg-emerald-600 shrink-0" />
        VERIFIED EXTERNAL
      </span>
    );
  }

  if (resolvedType === 'MANUALLY_MAINTAINED') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-sky-50 text-sky-900 border border-sky-300 tracking-wide uppercase ${className}`}
        title="Maintained manually by authenticated Nodal Officer; pending gazette verification"
      >
        <span className="w-1.5 h-1.5 rounded-xs bg-sky-600 shrink-0" />
        MANUAL DATA
      </span>
    );
  }

  if (resolvedType === 'IMPORTED') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-indigo-50 text-indigo-900 border border-indigo-200 tracking-wide uppercase ${className}`}
        title="Imported via administrative CSV / geospatial schedule"
      >
        <span className="w-1.5 h-1.5 rounded-xs bg-indigo-600 shrink-0" />
        IMPORTED CSV
      </span>
    );
  }

  if (resolvedType === 'UNAVAILABLE') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-rose-50 text-rose-800 border border-rose-200 tracking-wide uppercase ${className}`}
        title="External statutory source is currently unavailable / disconnected"
      >
        <span className="w-1.5 h-1.5 rounded-xs bg-rose-600 shrink-0" />
        SOURCE UNAVAILABLE
      </span>
    );
  }

  // Default: SEEDED
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-medium bg-slate-100 text-slate-700 border border-slate-300 tracking-wide uppercase ${className}`}
      title="Seeded benchmark / demonstration fixture (not connected to live statutory API)"
    >
      <span className="w-1.5 h-1.5 rounded-xs bg-slate-500 shrink-0" />
      SEEDED BENCHMARK
    </span>
  );
};

export const Section3aBadge: React.FC<{
  date?: string | null;
  source?: Section3aSource;
  className?: string;
}> = ({ date, source, className = '' }) => {
  if (!date) {
    return (
      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10.5px] font-medium bg-slate-100 text-slate-500 border border-slate-200 ${className}`}>
        Unrecorded / NULL
      </span>
    );
  }

  if (source === 'GAZETTE_OFFICIAL') {
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10.5px] font-bold bg-emerald-50 text-emerald-900 border border-emerald-300 font-mono ${className}`}>
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
        Verified Gazette ({date})
      </span>
    );
  }

  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10.5px] font-medium bg-amber-50 text-amber-900 border border-amber-300 font-mono ${className}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-amber-600" />
      Manual Entry ({date})
    </span>
  );
};

export const StageStatusBadge: React.FC<{ status: StageStatus; className?: string }> = ({
  status,
  className = ''
}) => {
  let classes = '';
  switch (status) {
    case 'Completed':
      classes = 'bg-slate-100 text-slate-700 border-slate-300';
      break;
    case 'In Progress':
      classes = 'bg-blue-50 text-blue-800 border-blue-200';
      break;
    case 'Delayed':
      classes = 'bg-rose-50 text-rose-800 border-rose-200';
      break;
    case 'Pending':
      classes = 'bg-slate-50 text-slate-600 border-slate-200';
      break;
  }

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium border ${classes} ${className}`}>
      {status}
    </span>
  );
};
