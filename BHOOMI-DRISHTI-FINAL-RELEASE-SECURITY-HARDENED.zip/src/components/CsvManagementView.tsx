import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Upload,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Shield,
  Download,
  ArrowRight,
  RefreshCw,
  Lock,
  Check,
  X,
  FileText,
  Clock,
  Layers,
  Sparkles
} from 'lucide-react';
import { api } from '../services/apiClient.ts';

const SAMPLE_CSV = `id,name,state,district,agency,highway_number,act,total_land_required_ha,land_acquired_ha,pending_land_ha,compensation_sanctioned_cr,compensation_disbursed_cr,compensation_disbursed_percent,unresolved_legal_cases,has_court_stay,court_details,forest_clearance_stage
60940,Pune Ring Road Package 1 (BhoomiRashi Ingestion),Maharashtra,Pune,NHAI,NH-48,National Highways Act 1956,5.2048,5.2048,0.0000,120.50,118.20,98.09,0,false,,Stage II Approved
56972,Bangalore-Chennai Expressway Phase 2,Karnataka,Kolar,NHAI,NE-7,National Highways Act 1956,14.5000,11.2000,3.3000,210.00,185.00,88.09,1,false,Section 3G Arbitration,Stage I In-Principle
58491,Delhi-Amritsar-Katra Expressway Package 4,Punjab,Ludhiana,NHAI,NE-5,National Highways Act 1956,22.1000,18.4000,3.7000,340.00,310.00,91.17,2,false,High Court stay lifted,Stage II Approved
99001,Nagpur Outer Ring Road Package 3,Maharashtra,Nagpur,NHAI,NH-53,National Highways Act 1956,8.4500,6.1000,2.3500,85.00,72.00,84.70,0,false,,Stage II Approved`;

export const CsvManagementView: React.FC = () => {
  const [activeStage, setActiveStage] = useState<number>(1);
  const [csvContent, setCsvContent] = useState<string>(SAMPLE_CSV);
  const [fileName, setFileName] = useState<string>('nhai_statutory_land_records.csv');
  const [stagedSession, setStagedSession] = useState<any>(null);
  const [reviewNote, setReviewNote] = useState<string>('Verified against official CALA gazette notifications under NH Act 1956.');
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [commitResult, setCommitResult] = useState<any>(null);

  const currentRole = api.auth.getCurrentRole();
  const isNodalOfficer = currentRole === 'NODAL_OFFICER';

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      setErrorMessage('File exceeds statutory 10MB threshold.');
      return;
    }

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setCsvContent(content);
      setErrorMessage(null);
    };
    reader.readAsText(file);
  };

  const handleRunValidation = async () => {
    setLoading(true);
    setErrorMessage(null);
    try {
      const res = await api.csvPipeline.upload(csvContent, fileName);
      setStagedSession(res.session);
      setActiveStage(res.session.rejectedRows.length > 0 && res.session.validRows.length === 0 ? 2 : 3);
    } catch (err: any) {
      setErrorMessage(err.message || 'Validation failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!stagedSession) return;
    setLoading(true);
    setErrorMessage(null);
    try {
      const res = await api.csvPipeline.approve(stagedSession.sessionId, reviewNote);
      setStagedSession(res.session);
      setActiveStage(4);
    } catch (err: any) {
      setErrorMessage(err.message || 'Approval failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleCommit = async () => {
    if (!stagedSession) return;
    setLoading(true);
    setErrorMessage(null);
    try {
      const res = await api.csvPipeline.commit(stagedSession.sessionId);
      setCommitResult(res);
      setActiveStage(5);
    } catch (err: any) {
      setErrorMessage(err.message || 'Commit failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadTemplate = () => {
    const blob = new Blob([SAMPLE_CSV], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bhoomidrishti_statutory_template.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Statutory Header */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-2xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                <Shield className="w-3.5 h-3.5 text-amber-700" />
                Statutory Quality Pipeline
              </span>
              <span className="text-xs text-slate-500 font-semibold">
                6-Stage Atomic Ingestion & Audit
              </span>
            </div>
            <h2 className="text-lg font-bold text-slate-900">
              CSV Ingestion & Quality Assurance Engine
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-3xl leading-relaxed">
              Enforces statutory verification under the <strong>National Highways Act 1956</strong> and RFCTLARR 2013.
              Features automatic spreadsheet formula defanging (<code className="font-mono bg-slate-100 px-1 py-0.5 rounded text-rose-700">=, +, -, @</code> sanitization),
              reconciliation preview (INSERT vs UPDATE diffs), statutory approval gating, and atomic database commit.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleDownloadTemplate}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-blue-600" />
              Download Template
            </button>
            <a
              href={api.csvPipeline.getExportUrl()}
              download="bhoomidrishti_verified_export.csv"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-300 rounded-lg hover:bg-emerald-100 transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
              Export Sanitized CSV
            </a>
          </div>
        </div>

        {/* 6-Stage Progress Indicator */}
        <div className="mt-6 pt-5 border-t border-slate-100">
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-center text-xs font-semibold">
            {[
              { num: 1, name: 'Upload & Defang', icon: Upload },
              { num: 2, name: 'Schema Validation', icon: AlertCircle },
              { num: 3, name: 'Diff Reconciliation', icon: Layers },
              { num: 4, name: 'Officer Approval', icon: Lock },
              { num: 5, name: 'Atomic Commit', icon: CheckCircle2 },
              { num: 6, name: 'Audit Record', icon: FileText }
            ].map((stage) => {
              const Icon = stage.icon;
              const isPast = activeStage > stage.num;
              const isCurrent = activeStage === stage.num;
              return (
                <div
                  key={stage.num}
                  className={`p-2.5 rounded-lg border transition-all ${
                    isCurrent
                      ? 'bg-blue-50 border-blue-400 text-blue-900 shadow-2xs'
                      : isPast
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                      : 'bg-slate-50 border-slate-200 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1.5 mb-1">
                    <span className={`w-4 h-4 rounded-full text-[10px] flex items-center justify-center font-bold ${
                      isPast ? 'bg-emerald-600 text-white' : isCurrent ? 'bg-blue-600 text-white' : 'bg-slate-300 text-slate-600'
                    }`}>
                      {isPast ? '✓' : stage.num}
                    </span>
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-[11px] font-bold truncate">{stage.name}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Error notification */}
        {errorMessage && (
          <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center justify-between text-xs text-rose-800">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button onClick={() => setErrorMessage(null)} className="text-rose-500 hover:text-rose-800">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* STAGE 1: Upload and Input Interface */}
      {activeStage === 1 && (
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase">
                Stage 1: Official CSV Upload & Anti-Injection Defanging
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Paste official CALA statutory dataset or upload from filesystem (Max: 10MB)
              </p>
            </div>
            <div className="flex items-center gap-2">
              <label className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors">
                <Upload className="w-3.5 h-3.5 text-slate-600" />
                Select File...
                <input type="file" accept=".csv,text/csv" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5 text-xs">
              <span className="font-semibold text-slate-700">Target File: <code className="text-blue-700 font-mono">{fileName}</code></span>
              <span className="text-slate-400 font-mono">Formula Injection Defense: Active</span>
            </div>
            <textarea
              rows={9}
              value={csvContent}
              onChange={(e) => setCsvContent(e.target.value)}
              className="w-full p-3 font-mono text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden bg-slate-50/50"
              placeholder="Paste RFC-4180 CSV rows here..."
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="text-[11px] text-slate-500 flex items-center gap-2">
              <Shield className="w-3.5 h-3.5 text-emerald-600" />
              <span>Rows starting with formula characters (<code className="font-mono">=,+,-,@</code>) are strictly defanged.</span>
            </div>

            <button
              onClick={handleRunValidation}
              disabled={loading || !csvContent.trim()}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-blue-700 hover:bg-blue-600 rounded-lg transition-all shadow-sm disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  Validating Schema & Constraints...
                </>
              ) : (
                <>
                  Validate & Stage Records
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* STAGE 2 & 3: Validation Results & Reconciliation Diff Preview */}
      {(activeStage === 2 || activeStage === 3) && stagedSession && (
        <div className="space-y-4">
          {/* Summary KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div className="p-3 bg-white rounded-xl border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Submitted</span>
              <div className="text-base font-bold text-slate-900 font-mono mt-0.5">{stagedSession.totalRowsSubmitted} rows</div>
            </div>

            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
              <span className="text-[10px] uppercase font-bold text-emerald-700 block">Statutorily Valid</span>
              <div className="text-base font-bold text-emerald-900 font-mono mt-0.5">{stagedSession.validRows.length} rows</div>
            </div>

            <div className="p-3 bg-blue-50 rounded-xl border border-blue-200">
              <span className="text-[10px] uppercase font-bold text-blue-700 block">New Projects (INSERT)</span>
              <div className="text-base font-bold text-blue-900 font-mono mt-0.5">{stagedSession.candidateInsertsCount} rows</div>
            </div>

            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
              <span className="text-[10px] uppercase font-bold text-amber-700 block">Revisions (UPDATE)</span>
              <div className="text-base font-bold text-amber-900 font-mono mt-0.5">{stagedSession.candidateUpdatesCount} rows</div>
            </div>

            <div className="p-3 bg-rose-50 rounded-xl border border-rose-200">
              <span className="text-[10px] uppercase font-bold text-rose-700 block">Rejected / Violations</span>
              <div className="text-base font-bold text-rose-900 font-mono mt-0.5">{stagedSession.rejectedRows.length} rows</div>
            </div>
          </div>

          {/* Rejected Rows Display if Any */}
          {stagedSession.rejectedRows.length > 0 && (
            <div className="bg-rose-50 rounded-xl p-4 border border-rose-200 space-y-2">
              <div className="flex items-center gap-2 text-rose-900 font-bold text-xs">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>Statutory Constraint Violations Detected ({stagedSession.rejectedRows.length} rejected)</span>
              </div>
              <div className="overflow-x-auto max-h-48 border border-rose-200 rounded-lg bg-white">
                <table className="w-full text-left text-xs">
                  <thead className="bg-rose-100 text-rose-900 font-semibold uppercase text-[10px]">
                    <tr>
                      <th className="py-1.5 px-3">Row #</th>
                      <th className="py-1.5 px-3">Project ID</th>
                      <th className="py-1.5 px-3">Rejection Reasons</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-rose-100">
                    {stagedSession.rejectedRows.map((rej: any, idx: number) => (
                      <tr key={idx} className="hover:bg-rose-50/50 text-[11px]">
                        <td className="py-1.5 px-3 font-mono font-bold text-slate-700">{rej.rowNumber}</td>
                        <td className="py-1.5 px-3 font-mono text-slate-900">{rej.projectId || 'N/A'}</td>
                        <td className="py-1.5 px-3 text-rose-700">
                          <ul className="list-disc list-inside space-y-0.5">
                            {rej.reasons.map((r: string, rIdx: number) => (
                              <li key={rIdx}>{r}</li>
                            ))}
                          </ul>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Candidate Diff Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase">
                  Stage 3: Reconciliation Diff Table
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Inspect candidate mutations prior to Nodal Officer authorization
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => { setActiveStage(1); setStagedSession(null); }}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Discard & Re-upload
                </button>
                <button
                  onClick={() => setActiveStage(4)}
                  disabled={stagedSession.validRows.length === 0}
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-white bg-blue-700 hover:bg-blue-600 rounded-lg transition-colors disabled:opacity-50"
                >
                  Proceed to Nodal Approval
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="overflow-x-auto max-h-80">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px] sticky top-0">
                  <tr>
                    <th className="py-2.5 px-3">Action</th>
                    <th className="py-2.5 px-3">Project ID</th>
                    <th className="py-2.5 px-3">Project Title</th>
                    <th className="py-2.5 px-3">State / District</th>
                    <th className="py-2.5 px-3">Land Req / Acquired</th>
                    <th className="py-2.5 px-3">Disbursed %</th>
                    <th className="py-2.5 px-3">Detected Diffs</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {stagedSession.validRows.map((row: any) => (
                    <tr key={row.id} className="hover:bg-slate-50/75 transition-colors">
                      <td className="py-2 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          row.actionType === 'INSERT'
                            ? 'bg-blue-100 text-blue-800 border border-blue-300'
                            : row.actionType === 'UPDATE'
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : 'bg-slate-100 text-slate-600'
                        }`}>
                          {row.actionType}
                        </span>
                      </td>
                      <td className="py-2 px-3 font-mono font-bold text-slate-900">{row.id}</td>
                      <td className="py-2 px-3 font-medium text-slate-800 max-w-xs truncate">{row.name}</td>
                      <td className="py-2 px-3 text-slate-600">{row.state} / {row.district}</td>
                      <td className="py-2 px-3 font-mono text-slate-700">
                        {row.landAcquiredHa.toFixed(2)} / {row.totalLandRequiredHa.toFixed(2)} Ha
                      </td>
                      <td className="py-2 px-3 font-mono text-slate-700">
                        {row.compensationDisbursedPercent.toFixed(1)}%
                      </td>
                      <td className="py-2 px-3 text-[11px]">
                        {row.diffFields.length > 0 ? (
                          <div className="space-y-0.5">
                            {row.diffFields.map((d: any, dIdx: number) => (
                              <div key={dIdx} className="font-mono text-amber-800">
                                <span className="font-semibold">{d.field}:</span> {String(d.oldValue)} → <strong className="text-emerald-700">{String(d.newValue)}</strong>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="text-slate-400 font-mono">No mutations</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* STAGE 4: Nodal Officer Statutory Approval Gate */}
      {activeStage === 4 && stagedSession && (
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-2xs space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-900 border border-purple-300">
                Statutory Approval Gate
              </span>
              <span className="text-xs text-slate-500 font-semibold">Stage 4 of 6</span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 uppercase">
              Competent Authority (CALA) Authorization
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Strict RBAC enforcement: Only registered <strong>NODAL_OFFICER</strong> can authorize commits.
            </p>
          </div>

          {!isNodalOfficer ? (
            <div className="p-4 bg-amber-50 border border-amber-300 rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-amber-900 font-bold text-xs">
                <Lock className="w-4 h-4 text-amber-700" />
                <span>Statutory Authorization Required</span>
              </div>
              <p className="text-xs text-amber-800 leading-relaxed">
                You are currently logged in with the <strong>VIEWER (Auditor)</strong> persona.
                In compliance with administrative oversight rules, viewers have read-only inspection access and cannot authorize database commits.
              </p>
              <div className="pt-2">
                <p className="text-[11px] font-semibold text-amber-950">
                  Tip: Switch to <strong>Er. Rajesh Sharma (CALA / Nodal Officer)</strong> in the top-right role switcher to test authorization.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <div className="text-xs">
                  <p className="font-bold text-emerald-950">Authorized Nodal Officer Identified: Er. Rajesh Sharma</p>
                  <p className="text-emerald-800">CALA Competent Authority • Full statutory write and commit authority verified.</p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Statutory Review Note & Gazette Reference <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  value={reviewNote}
                  onChange={(e) => setReviewNote(e.target.value)}
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden font-mono"
                  placeholder="e.g., Section 3D gazette published 14-May-2026. Verified with District Collectorate."
                />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                <button
                  onClick={() => setActiveStage(3)}
                  className="px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Back to Diff Preview
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleApprove}
                    disabled={loading || !reviewNote.trim()}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-purple-700 hover:bg-purple-600 rounded-lg transition-colors shadow-2xs cursor-pointer"
                  >
                    {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Lock className="w-3.5 h-3.5" />}
                    Approve Staged Batch
                  </button>

                  <button
                    onClick={handleCommit}
                    disabled={loading || stagedSession.status !== 'APPROVED'}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-600 rounded-lg transition-colors shadow-2xs cursor-pointer disabled:opacity-50"
                  >
                    {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    Commit to Database
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* STAGE 5: Commit Confirmation & Audit Log */}
      {activeStage === 5 && commitResult && (
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-2xs space-y-4">
          <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-emerald-950 font-bold text-sm">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <span>Atomic CSV Ingestion Successfully Committed</span>
            </div>
            <p className="text-xs text-emerald-800 leading-relaxed">
              All validated project records have been atomically merged into BhoomiDrishti's authoritative SQLite database within an isolated database transaction.
              An immutable audit log entry has been recorded.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Dataset Version</span>
              <div className="text-xs font-bold text-slate-900 font-mono mt-0.5 truncate" title={commitResult.datasetVersion}>
                {commitResult.datasetVersion}
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Rows Committed</span>
              <div className="text-base font-bold text-emerald-800 font-mono mt-0.5">
                {commitResult.rowsCommitted} records
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Audit Log ID</span>
              <div className="text-xs font-bold text-blue-900 font-mono mt-0.5">
                {commitResult.auditLogId}
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <button
              onClick={() => {
                setActiveStage(1);
                setStagedSession(null);
                setCommitResult(null);
              }}
              className="px-4 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              Start New Batch Import
            </button>

            <a
              href={api.csvPipeline.getExportUrl()}
              download="bhoomidrishti_verified_export.csv"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-600 rounded-lg transition-colors shadow-2xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Download Updated Dataset (CSV)
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
