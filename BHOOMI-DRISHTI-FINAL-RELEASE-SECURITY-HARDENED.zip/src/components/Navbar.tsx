import React from 'react';
import { Menu, RefreshCw, Bell, Cpu, UserCheck, LogOut, Shield } from 'lucide-react';
import { NavView } from './Sidebar.tsx';
import { GovernmentEmblem } from './common/GovernmentEmblem.tsx';
import { AuthUser } from '../types.ts';

interface NavbarProps {
  currentView: NavView;
  projectName?: string;
  onOpenMobileSidebar: () => void;
  onRefresh: () => void;
  isRefreshing?: boolean;
  onOpenModelInfo?: () => void;
  unreadAlertsCount?: number;
  onNavigateToAlerts?: () => void;
  currentUser?: AuthUser | null;
  onLogout?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  projectName,
  onOpenMobileSidebar,
  onRefresh,
  isRefreshing = false,
  onOpenModelInfo,
  unreadAlertsCount = 0,
  onNavigateToAlerts,
  currentUser,
  onLogout
}) => {
  const getViewTitle = () => {
    switch (currentView) {
      case 'dashboard':
        return 'Executive Monitoring Dashboard';
      case 'projects':
        return 'National Corridor Projects Directory';
      case 'project-details':
        return projectName ? `Project Review: ${projectName}` : 'Project Intelligence Review';
      case 'data-sync':
        return 'Data Hub & Statutory BhoomiRashi Ingestion';
      case 'map':
        return 'Geographic Risk & Spatial Corridor Grid';
      case 'alerts':
        return 'Early Warning & Escalation Center';
      case 'what-if':
        return 'What-if Scenario & Policy Simulator';
      case 'reports':
        return 'Statutory & Executive Reports Hub';
      default:
        return 'Land Acquisition Risk & Delay Monitoring';
    }
  };

  return (
    <header className="sticky top-0 z-30 gov-glass px-4 lg:px-7 py-2.5 flex items-center justify-between transition-all">
      <div className="flex items-center gap-3 min-w-0">
        {/* Mobile menu trigger */}
        <button
          onClick={onOpenMobileSidebar}
          className="lg:hidden p-1.5 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          aria-label="Open navigation sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Institutional Title & Hierarchy */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="hidden sm:block lg:hidden">
            <GovernmentEmblem size={28} />
          </div>
          <div className="min-w-0">
            <div className="text-[10px] font-bold text-slate-600 uppercase tracking-wider truncate flex items-center gap-1.5">
              <span>Government of India</span>
              <span className="text-slate-300">•</span>
              <span className="text-slate-700 font-semibold">Ministry of Road Transport & Highways (MoRTH)</span>
            </div>
            <h1 className="text-sm sm:text-base font-bold text-slate-900 leading-tight truncate">
              {getViewTitle()}
            </h1>
          </div>
        </div>
      </div>

      {/* Right Controls: Notifications, ML Inspector, Refresh, User Profile */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* ML Model Explanation Quick Trigger */}
        {onOpenModelInfo && (
          <button
            onClick={onOpenModelInfo}
            className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors shadow-2xs cursor-pointer"
            title="Inspect Delay Risk Model Architecture & Statutory Features"
          >
            <Cpu className="w-3.5 h-3.5 text-[#1E3A5F]" />
            <span className="hidden xl:inline">Model Info ⓘ</span>
          </button>
        )}

        {/* Live Refresh Trigger */}
        <button
          onClick={onRefresh}
          disabled={isRefreshing}
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors disabled:opacity-50 shadow-2xs cursor-pointer"
          title="Query live backend state & refresh statutory records"
        >
          <RefreshCw
            className={`w-3.5 h-3.5 ${
              isRefreshing ? 'animate-spin text-blue-700' : 'text-slate-500'
            }`}
          />
          <span className="hidden sm:inline">Refresh</span>
        </button>

        {/* Notification Bell */}
        {onNavigateToAlerts && (
          <button
            onClick={onNavigateToAlerts}
            className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-white rounded-lg transition-colors border border-transparent hover:border-slate-200 cursor-pointer"
            title={`${unreadAlertsCount} active statutory escalations`}
            aria-label="View alerts"
          >
            <Bell className="w-4 h-4" />
            {unreadAlertsCount > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-600 ring-2 ring-white" />
            )}
          </button>
        )}

        {/* Authoritative User Profile & Logout */}
        <UserProfileMenu currentUser={currentUser} onLogout={onLogout} />
      </div>
    </header>
  );
};

interface UserProfileMenuProps {
  currentUser?: AuthUser | null;
  onLogout?: () => void;
}

const UserProfileMenu: React.FC<UserProfileMenuProps> = ({ currentUser, onLogout }) => {
  const [dropdownOpen, setDropdownOpen] = React.useState(false);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const userName = currentUser?.name || 'Authorized Officer';
  const userEmail = currentUser?.email || 'officer@morth.gov.in';
  const role = currentUser?.role || 'VIEWER';
  const isNodal = role === 'NODAL_OFFICER';

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setDropdownOpen(!dropdownOpen)}
        className="flex items-center gap-2 pl-2 border-l border-slate-200 hover:bg-slate-50 py-1 px-1.5 rounded-lg transition-colors cursor-pointer text-left"
        title="Inspect verified credentials or sign out"
      >
        <div
          className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shadow-2xs ${
            isNodal
              ? 'bg-[#0F2027] text-amber-300 ring-1 ring-amber-400/40'
              : 'bg-slate-700 text-sky-300 ring-1 ring-sky-400/40'
          }`}
        >
          <UserCheck className="w-3.5 h-3.5" />
        </div>
        <div className="hidden lg:block text-left text-xs leading-tight">
          <div className="flex items-center gap-1.5">
            <p className="font-semibold text-slate-900">{userName}</p>
            <span
              className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                isNodal ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-blue-100 text-blue-900 border border-blue-300'
              }`}
            >
              {isNodal ? 'NODAL OFFICER' : 'VIEWER'}
            </span>
          </div>
          <p className="text-[10px] text-slate-500 truncate max-w-[150px]">
            {userEmail}
          </p>
        </div>
      </button>

      {dropdownOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 p-4 z-50 animate-in fade-in zoom-in-95 duration-100">
          <div className="pb-3 mb-3 border-b border-slate-100">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                <Shield className="w-3 h-3 text-emerald-600" />
                Verified Institutional Identity
              </span>
              <span
                className={`text-[9px] px-1.5 py-0.5 rounded font-bold border ${
                  isNodal
                    ? 'bg-amber-50 text-amber-900 border-amber-300'
                    : 'bg-blue-50 text-blue-900 border-blue-300'
                }`}
              >
                {role}
              </span>
            </div>
            <p className="text-sm font-bold text-slate-900 mt-2">{userName}</p>
            <p className="text-xs text-slate-500 font-mono mt-0.5">{userEmail}</p>

            {currentUser?.designation && (
              <p className="text-[11px] text-slate-600 font-medium mt-1.5 bg-slate-50 p-2 rounded-lg border border-slate-100">
                {currentUser.designation}
              </p>
            )}

            {currentUser?.department && (
              <p className="text-[10px] text-slate-400 mt-1">
                {currentUser.department}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <div className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded-lg border border-slate-100">
              <span className="font-semibold text-slate-700">Authority Scope: </span>
              {isNodal
                ? 'Full administrative access: project registration, statutory milestone updates, and data imports.'
                : 'Auditor access: read-only monitoring and statutory oversight.'}
            </div>

            {onLogout && (
              <button
                onClick={() => {
                  setDropdownOpen(false);
                  onLogout();
                }}
                className="w-full mt-2 py-2 px-3 bg-red-50 hover:bg-red-100 text-red-800 rounded-lg text-xs font-bold border border-red-200 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5 text-red-600" />
                <span>Sign Out of BhoomiDrishti</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

