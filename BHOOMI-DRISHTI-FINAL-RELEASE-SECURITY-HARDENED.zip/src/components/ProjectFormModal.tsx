import React, { useState, useEffect } from 'react';
import { Project, AcquisitionStage, StageStatus } from '../types.ts';
import { api } from '../services/apiClient.ts';
import {
  X,
  Save,
  AlertCircle,
  Building2,
  Calendar,
  Layers,
  Landmark,
  Scale,
  TreePine,
  CheckCircle2,
  Loader2,
  HelpCircle,
  Info
} from 'lucide-react';

interface ProjectFormModalProps {
  isOpen: boolean;
  mode: 'create' | 'edit';
  project?: Project | null;
  onClose: () => void;
  onSuccess: (savedProject: Project) => void;
}

export const ProjectFormModal: React.FC<ProjectFormModalProps> = ({
  isOpen,
  mode,
  project,
  onClose,
  onSuccess
}) => {
  // Form fields
  const [id, setId] = useState('');
  const [name, setName] = useState('');
  const [highwayNumber, setHighwayNumber] = useState('');
  const [state, setState] = useState('');
  const [district, setDistrict] = useState('');
  const [talukOrTehsil, setTalukOrTehsil] = useState('');
  const [currentStage, setCurrentStage] = useState<AcquisitionStage>('Identification');
  const [stageStatus, setStageStatus] = useState<StageStatus>('In Progress');

  // Land metrics
  const [totalLandRequiredHa, setTotalLandRequiredHa] = useState<number>(100);
  const [landAcquiredHa, setLandAcquiredHa] = useState<number>(0);

  // Compensation metrics
  const [compensationSanctionedCr, setCompensationSanctionedCr] = useState<number>(0);
  const [compensationDisbursedCr, setCompensationDisbursedCr] = useState<number>(0);
  const [compensationDisbursedPercent, setCompensationDisbursedPercent] = useState<number>(0);

  // Legal & environmental metrics
  const [hasCourtStay, setHasCourtStay] = useState<boolean>(false);
  const [courtDetails, setCourtDetails] = useState('');
  const [unresolvedLegalCases, setUnresolvedLegalCases] = useState<number>(0);
  const [incompleteDocumentsCount, setIncompleteDocumentsCount] = useState<number>(0);
  const [forestClearanceStage, setForestClearanceStage] = useState<
    'Not Required' | 'Stage 1 Approved' | 'Stage 2 Pending' | 'Stage 2 Approved'
  >('Not Required');

  // Statutory Section 3A date (nullable, never fabricated)
  const [section3aDate, setSection3aDate] = useState<string>('');

  // UI state
  const [loading, setLoading] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [apiError, setApiError] = useState<string | null>(null);

  // Populate fields when editing or reset when creating
  useEffect(() => {
    if (mode === 'edit' && project) {
      setId(project.id);
      setName(project.name);
      setHighwayNumber(project.highwayNumber || '');
      setState(project.state);
      setDistrict(project.district);
      setTalukOrTehsil(project.talukOrTehsil || project.district);
      setCurrentStage(project.currentStage);
      setStageStatus(project.stageStatus);
      setTotalLandRequiredHa(project.totalLandRequiredHa || 100);
      setLandAcquiredHa(project.landAcquiredHa || 0);
      setCompensationSanctionedCr(project.compensationSanctionedCr || 0);
      setCompensationDisbursedCr(project.compensationDisbursedCr || 0);
      setCompensationDisbursedPercent(project.compensationDisbursedPercent || 0);
      setHasCourtStay(Boolean(project.hasCourtStay));
      setCourtDetails(project.courtDetails || '');
      setUnresolvedLegalCases(project.unresolvedLegalCases || 0);
      setIncompleteDocumentsCount(project.incompleteDocumentsCount || 0);
      setForestClearanceStage(project.forestClearanceStage || 'Not Required');
      setSection3aDate(project.section_3a_date || '');
    } else {
      setId('');
      setName('');
      setHighwayNumber('');
      setState('');
      setDistrict('');
      setTalukOrTehsil('');
      setCurrentStage('Identification');
      setStageStatus('In Progress');
      setTotalLandRequiredHa(100);
      setLandAcquiredHa(0);
      setCompensationSanctionedCr(0);
      setCompensationDisbursedCr(0);
      setCompensationDisbursedPercent(0);
      setHasCourtStay(false);
      setCourtDetails('');
      setUnresolvedLegalCases(0);
      setIncompleteDocumentsCount(0);
      setForestClearanceStage('Not Required');
      setSection3aDate('');
    }
    setValidationErrors({});
    setApiError(null);
  }, [mode, project, isOpen]);

  if (!isOpen) return null;

  const validate = (): boolean => {
    const errors: Record<string, string> = {};

    if (mode === 'create') {
      if (!id.trim()) {
        errors.id = 'Project ID is required.';
      } else if (!/^[A-Za-z0-9_\-]+$/.test(id.trim())) {
        errors.id = 'Project ID can only contain letters, numbers, hyphens, and underscores.';
      }
    }

    if (!name.trim() || name.trim().length < 3) {
      errors.name = 'Project Name must be at least 3 characters.';
    }

    if (!state.trim()) {
      errors.state = 'State is required.';
    }

    if (!district.trim()) {
      errors.district = 'District is required.';
    }

    if (totalLandRequiredHa <= 0) {
      errors.totalLandRequiredHa = 'Total land required must be greater than 0 hectares.';
    }

    if (landAcquiredHa < 0) {
      errors.landAcquiredHa = 'Land acquired cannot be negative.';
    }

    if (landAcquiredHa > totalLandRequiredHa * 1.5) {
      errors.landAcquiredHa = 'Land acquired exceeds statutory corridor bounds.';
    }

    if (compensationDisbursedPercent < 0 || compensationDisbursedPercent > 100) {
      errors.compensationDisbursedPercent = 'Compensation percentage must be between 0 and 100%.';
    }

    if (unresolvedLegalCases < 0) {
      errors.unresolvedLegalCases = 'Unresolved cases cannot be negative.';
    }

    if (incompleteDocumentsCount < 0) {
      errors.incompleteDocumentsCount = 'Incomplete documents count cannot be negative.';
    }

    // Section 3A Date validation if entered
    if (section3aDate.trim()) {
      const parsed = new Date(section3aDate.trim()).getTime();
      if (isNaN(parsed) || parsed <= 0) {
        errors.section3aDate = 'Invalid Section 3A date format. Use YYYY-MM-DD.';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    setApiError(null);

    const payload: Partial<Project> = {
      name: name.trim(),
      highwayNumber: highwayNumber.trim() || undefined,
      state: state.trim(),
      district: district.trim(),
      talukOrTehsil: talukOrTehsil.trim() || district.trim(),
      currentStage,
      stageStatus,
      totalLandRequiredHa: Number(totalLandRequiredHa),
      landAcquiredHa: Number(landAcquiredHa),
      compensationSanctionedCr: Number(compensationSanctionedCr),
      compensationDisbursedCr: Number(compensationDisbursedCr),
      compensationDisbursedPercent: Number(compensationDisbursedPercent),
      hasCourtStay,
      courtDetails: courtDetails.trim() || undefined,
      unresolvedLegalCases: Number(unresolvedLegalCases),
      incompleteDocumentsCount: Number(incompleteDocumentsCount),
      forestClearanceStage,
      // Section 3A date: strictly NULL if empty string
      section_3a_date: section3aDate.trim() ? section3aDate.trim() : null
    };

    try {
      if (mode === 'create') {
        payload.id = id.trim();
        const res = await api.createProject(payload);
        if (res.success && res.project) {
          onSuccess(res.project);
          onClose();
        } else {
          setApiError(res.project ? 'Project created with warnings' : 'Failed to create project.');
        }
      } else if (project) {
        const res = await api.updateProject(project.id, payload);
        if (res.success && res.project) {
          onSuccess(res.project);
          onClose();
        } else {
          setApiError('Failed to update project.');
        }
      }
    } catch (err: any) {
      console.error('[ProjectFormModal] Error saving project:', err);
      setApiError(err.message || 'Error occurred while saving project record.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden my-8 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-slate-900 to-[#0F2027] text-white flex items-center justify-between border-b border-amber-500/20">
          <div className="flex items-center gap-2.5">
            <Building2 className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base sm:text-lg font-bold">
                {mode === 'create' ? 'Add Highway Infrastructure Package' : `Edit Package: ${project?.id}`}
              </h2>
              <p className="text-[11px] text-slate-300">
                {mode === 'create'
                  ? 'Register new NHAI statutory acquisition package into BhoomiDrishti'
                  : 'Update statutory milestones, land metrics, and court stay status'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1 text-xs sm:text-sm">
          {apiError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-900 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-xs">Error saving project</p>
                <p className="text-xs text-red-700">{apiError}</p>
              </div>
            </div>
          )}

          {/* Section 1: Core Package Identification */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 border-b pb-1">
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
              Package Identification
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* ID */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Package ID <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  disabled={mode === 'edit'}
                  placeholder="e.g. NHAI-2026-099 or BR_NH-48_GJ"
                  value={id}
                  onChange={e => setId(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg text-xs font-mono ${
                    mode === 'edit'
                      ? 'bg-slate-100 text-slate-500 cursor-not-allowed border-slate-200'
                      : validationErrors.id
                      ? 'border-red-400 bg-red-50 text-slate-900'
                      : 'border-slate-300 bg-white text-slate-900 focus:ring-1 focus:ring-blue-500'
                  }`}
                />
                {validationErrors.id && (
                  <p className="text-[11px] text-red-600 mt-0.5">{validationErrors.id}</p>
                )}
              </div>

              {/* Highway Number */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  National Highway / Expressway
                </label>
                <input
                  type="text"
                  placeholder="e.g. NH-48 or NE-1"
                  value={highwayNumber}
                  onChange={e => setHighwayNumber(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* Project Name */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Project Title / Corridor Description <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. 6-Laning of Vadodara-Mumbai Expressway Section Km 102 to 145"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg text-xs ${
                    validationErrors.name
                      ? 'border-red-400 bg-red-50 text-slate-900'
                      : 'border-slate-300 bg-white text-slate-900 focus:ring-1 focus:ring-blue-500'
                  }`}
                />
                {validationErrors.name && (
                  <p className="text-[11px] text-red-600 mt-0.5">{validationErrors.name}</p>
                )}
              </div>

              {/* State */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  State <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Gujarat"
                  value={state}
                  onChange={e => setState(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg text-xs ${
                    validationErrors.state
                      ? 'border-red-400 bg-red-50 text-slate-900'
                      : 'border-slate-300 bg-white text-slate-900 focus:ring-1 focus:ring-blue-500'
                  }`}
                />
                {validationErrors.state && (
                  <p className="text-[11px] text-red-600 mt-0.5">{validationErrors.state}</p>
                )}
              </div>

              {/* District */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  District <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Bharuch"
                  value={district}
                  onChange={e => setDistrict(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg text-xs ${
                    validationErrors.district
                      ? 'border-red-400 bg-red-50 text-slate-900'
                      : 'border-slate-300 bg-white text-slate-900 focus:ring-1 focus:ring-blue-500'
                  }`}
                />
                {validationErrors.district && (
                  <p className="text-[11px] text-red-600 mt-0.5">{validationErrors.district}</p>
                )}
              </div>
            </div>
          </div>

          {/* Section 2: Statutory Stage & Section 3A Date */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 border-b pb-1">
              <Calendar className="w-3.5 h-3.5 text-amber-600" />
              Statutory Stage & Gazette 3A Date
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Current Statutory Stage */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Current Statutory Stage
                </label>
                <select
                  value={currentStage}
                  onChange={e => setCurrentStage(e.target.value as AcquisitionStage)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="Identification">Identification (Preliminary)</option>
                  <option value="Verification">Verification (Section 3A / 3C)</option>
                  <option value="Compensation">Compensation (Section 3G / 3H)</option>
                  <option value="Legal / Documentation">Legal / Documentation (Litigation)</option>
                  <option value="Possession">Possession (Handover)</option>
                </select>
              </div>

              {/* Stage Status */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Operational Milestone Status
                </label>
                <select
                  value={stageStatus}
                  onChange={e => setStageStatus(e.target.value as StageStatus)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="In Progress">In Progress (Active)</option>
                  <option value="Delayed">Delayed (Behind Schedule)</option>
                  <option value="Completed">Completed</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>

              {/* CRITICAL: SECTION 3A DATE */}
              <div className="sm:col-span-2 p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-amber-950 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-amber-700" />
                    Section 3A Gazette Date (Optional / Statutory)
                  </label>
                  {section3aDate && (
                    <button
                      type="button"
                      onClick={() => setSection3aDate('')}
                      className="text-[10px] text-red-600 hover:text-red-800 font-bold underline cursor-pointer"
                    >
                      Clear Date (Keep NULL)
                    </button>
                  )}
                </div>
                <input
                  type="date"
                  value={section3aDate}
                  onChange={e => setSection3aDate(e.target.value)}
                  className="w-full sm:w-64 px-3 py-1.5 border border-amber-300 rounded-lg text-xs bg-white text-slate-900 font-mono focus:ring-2 focus:ring-amber-500"
                />
                <p className="text-[10.5px] text-amber-900/80 leading-relaxed">
                  <strong>Statutory Notice:</strong> Provide only when an authoritative publication date is verified in the official Gazette of India. If unverified, leave blank to preserve as strictly <code>NULL</code>.
                </p>
                {validationErrors.section3aDate && (
                  <p className="text-[11px] text-red-600 font-semibold">{validationErrors.section3aDate}</p>
                )}
              </div>
            </div>
          </div>

          {/* Section 3: Land & Compensation Metrics */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 border-b pb-1">
              <Landmark className="w-3.5 h-3.5 text-emerald-600" />
              Land & Compensation Metrics
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Total Land Required */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Total Land (Hectares) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.1"
                  value={totalLandRequiredHa}
                  onChange={e => setTotalLandRequiredHa(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500 font-mono"
                />
                {validationErrors.totalLandRequiredHa && (
                  <p className="text-[11px] text-red-600 mt-0.5">{validationErrors.totalLandRequiredHa}</p>
                )}
              </div>

              {/* Land Acquired */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Land Acquired (Hectares)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={landAcquiredHa}
                  onChange={e => setLandAcquiredHa(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500 font-mono"
                />
                {validationErrors.landAcquiredHa && (
                  <p className="text-[11px] text-red-600 mt-0.5">{validationErrors.landAcquiredHa}</p>
                )}
              </div>

              {/* Compensation Disbursed % */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Compensation Disbursed (%)
                </label>
                <input
                  type="number"
                  step="1"
                  min="0"
                  max="100"
                  value={compensationDisbursedPercent}
                  onChange={e => setCompensationDisbursedPercent(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500 font-mono"
                />
                {validationErrors.compensationDisbursedPercent && (
                  <p className="text-[11px] text-red-600 mt-0.5">{validationErrors.compensationDisbursedPercent}</p>
                )}
              </div>

              {/* Compensation Sanctioned */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Sanctioned Amount (₹ Crore)
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  value={compensationSanctionedCr}
                  onChange={e => setCompensationSanctionedCr(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500 font-mono"
                />
              </div>

              {/* Compensation Disbursed Cr */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Disbursed Amount (₹ Crore)
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  value={compensationDisbursedCr}
                  onChange={e => setCompensationDisbursedCr(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Legal & Forest Clearances */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 border-b pb-1">
              <Scale className="w-3.5 h-3.5 text-purple-600" />
              Litigation & Clearances
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Court Stay Checkbox */}
              <div className="sm:col-span-2 flex items-center gap-2 p-2.5 bg-slate-50 border rounded-lg">
                <input
                  type="checkbox"
                  id="court-stay-chk"
                  checked={hasCourtStay}
                  onChange={e => setHasCourtStay(e.target.checked)}
                  className="w-4 h-4 text-amber-600 rounded focus:ring-amber-500 cursor-pointer"
                />
                <label htmlFor="court-stay-chk" className="text-xs font-bold text-slate-800 cursor-pointer">
                  Active High Court / Supreme Court Stay Order on Corridor Land
                </label>
              </div>

              {hasCourtStay && (
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Court Stay Details & Writ Petition Number
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. WP (C) No. 412/2025 High Court of Judicature stay on Ch. 120-124"
                    value={courtDetails}
                    onChange={e => setCourtDetails(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              )}

              {/* Unresolved Legal Cases */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Unresolved Legal Cases Count
                </label>
                <input
                  type="number"
                  min="0"
                  value={unresolvedLegalCases}
                  onChange={e => setUnresolvedLegalCases(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500 font-mono"
                />
              </div>

              {/* Incomplete Documents Count */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Incomplete Khatadar Documents Count
                </label>
                <input
                  type="number"
                  min="0"
                  value={incompleteDocumentsCount}
                  onChange={e => setIncompleteDocumentsCount(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500 font-mono"
                />
              </div>

              {/* Forest Clearance Stage */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Forest Clearance Statutory Status
                </label>
                <select
                  value={forestClearanceStage}
                  onChange={e => setForestClearanceStage(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white text-slate-900 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="Not Required">Not Required</option>
                  <option value="Stage 1 Approved">Stage 1 Approved (In-principle)</option>
                  <option value="Stage 2 Pending">Stage 2 Pending</option>
                  <option value="Stage 2 Approved">Stage 2 Approved (Final Working Permission)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg border border-slate-300 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-lg shadow-xs transition-all cursor-pointer flex items-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Saving Record...</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>{mode === 'create' ? 'Register Highway Project' : 'Save Changes'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
