import React, { useState, useEffect } from 'react';
import { GovernmentEmblem } from './common/GovernmentEmblem.tsx';
import { api } from '../services/apiClient.ts';
import { AuthUser } from '../types.ts';
import {
  Lock,
  Mail,
  Eye,
  EyeOff,
  ShieldCheck,
  AlertCircle,
  Loader2,
  CheckCircle2,
  HelpCircle,
  X,
  UserCheck,
  FileText
} from 'lucide-react';

interface LoginScreenProps {
  onLoginSuccess: (user: AuthUser) => void;
}

interface DemoCredentialsInfo {
  nodalEmail: string;
  auditorEmail: string;
  password?: string;
}

/**
 * Standardizes authentication error messages according to institutional security standards.
 * Prevents account enumeration, stack traces, and database/token leakages.
 */
function sanitizeAuthError(rawError?: string): string {
  if (!rawError) {
    return "We couldn't complete the sign-in request. Please try again.";
  }
  const lower = rawError.toLowerCase();

  if (lower.includes('rate limit') || lower.includes('429') || lower.includes('too many')) {
    return 'Too many sign-in attempts. Please wait a moment and try again.';
  }
  if (lower.includes('suspended') || lower.includes('disabled') || lower.includes('inactive')) {
    return 'Your account is currently unavailable. Please contact the portal administrator.';
  }
  if (
    lower.includes('invalid credentials') ||
    lower.includes('invalid password') ||
    lower.includes('user not found') ||
    lower.includes('password_auth_disabled') ||
    lower.includes('unauthorized') ||
    lower.includes('verify credentials') ||
    lower.includes('401')
  ) {
    return 'Email or password is incorrect. Please check your details and try again.';
  }
  if (
    lower.includes('network') ||
    lower.includes('fetch') ||
    lower.includes('failed to fetch') ||
    lower.includes('econnrefused')
  ) {
    return "We couldn't complete the sign-in request. Please try again.";
  }
  return 'Email or password is incorrect. Please check your details and try again.';
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [selectedRole, setSelectedRole] = useState<'NODAL' | 'AUDITOR' | null>(null);
  const [helpModalOpen, setHelpModalOpen] = useState(false);

  // Server-authoritative demo configuration
  const [demoMode, setDemoMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const env = (import.meta as any).env;
      return Boolean(env?.DEV || env?.VITE_DEMO_MODE === 'true');
    }
    return false;
  });
  const [demoCredentials, setDemoCredentials] = useState<DemoCredentialsInfo | null>(null);

  useEffect(() => {
    let mounted = true;
    api.auth
      .getMe()
      .then(res => {
        if (!mounted) return;
        if (typeof res.demoMode === 'boolean') {
          setDemoMode(res.demoMode);
        }
        if (res.demoCredentials) {
          setDemoCredentials(res.demoCredentials);
        }
      })
      .catch(() => {});

    return () => {
      mounted = false;
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;

    const trimmedEmail = email.trim();
    if (!trimmedEmail || !password) {
      setErrorMessage('Please enter both your official email and password.');
      return;
    }

    setLoading(true);
    setErrorMessage(null);

    try {
      const res = await api.auth.login(trimmedEmail, password);
      if (res && res.user) {
        onLoginSuccess(res.user);
      } else {
        setErrorMessage("We couldn't complete the sign-in request. Please try again.");
      }
    } catch (err: any) {
      setErrorMessage(sanitizeAuthError(err?.message));
    } finally {
      setLoading(false);
    }
  };

  const handleSelectNodalOfficer = () => {
    const targetEmail = demoCredentials?.nodalEmail || 'nodal.officer@morth.gov.in';
    setEmail(targetEmail);
    setSelectedRole('NODAL');
    setErrorMessage(null);
    if (demoCredentials?.password && !password) {
      setPassword(demoCredentials.password);
    }
  };

  const handleSelectProjectAuditor = () => {
    const targetEmail = demoCredentials?.auditorEmail || 'viewer.auditor@gov.in';
    setEmail(targetEmail);
    setSelectedRole('AUDITOR');
    setErrorMessage(null);
    if (demoCredentials?.password && !password) {
      setPassword(demoCredentials.password);
    }
  };

  const handleFillDemoPassword = () => {
    if (demoCredentials?.password) {
      setPassword(demoCredentials.password);
      setErrorMessage(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#07131B] flex flex-col justify-between text-slate-100 antialiased selection:bg-amber-400 selection:text-slate-900">
      {/* Top Government Masthead */}
      <header className="border-b border-slate-800/80 bg-[#050E14] px-4 sm:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3 sm:gap-4">
          <GovernmentEmblem size={38} />
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] sm:text-xs font-bold uppercase tracking-widest text-amber-400">
                Government of India
              </span>
              <span className="text-slate-600 hidden sm:inline" aria-hidden="true">
                ·
              </span>
              <span className="text-[11px] text-slate-300 font-medium hidden sm:inline">
                Ministry of Road Transport &amp; Highways
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-400 font-medium">
              National Highways Authority of India (NHAI)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {demoMode && (
            <button
              type="button"
              onClick={() => setHelpModalOpen(true)}
              className="flex items-center gap-1.5 text-xs text-amber-300/90 hover:text-amber-200 px-3 py-1.5 rounded-lg border border-amber-500/30 bg-amber-950/20 hover:bg-amber-950/40 transition-colors focus-visible:ring-2 focus-visible:ring-amber-500 focus-visible:outline-none"
              aria-label="View evaluation instructions"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Evaluation Guide</span>
            </button>
          )}

          <div className="hidden md:flex items-center gap-2 text-xs text-slate-400 bg-slate-900/90 px-3 py-1.5 rounded-lg border border-slate-800">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Statutory Access Control &amp; Audit Enforced</span>
          </div>
        </div>
      </header>

      {/* Main Authentication Surface */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6 md:p-8 my-auto">
        <div className="w-full max-w-xl bg-[#0B1720] text-slate-100 rounded-2xl shadow-2xl border border-slate-800/90 overflow-hidden">
          {/* Header Banner */}
          <div className="bg-[#08131A] p-6 sm:p-8 border-b border-slate-800/80 text-center">
            <div className="inline-flex p-3 rounded-2xl bg-slate-900 border border-slate-800 mb-3 shadow-inner">
              <GovernmentEmblem size={44} />
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              BHOOMI-DRISHTI
            </h1>
            <p className="text-xs sm:text-sm text-amber-400 font-semibold tracking-wide mt-1">
              Statutory Land Acquisition Intelligence &amp; Monitoring Portal
            </p>
            <p className="text-xs text-slate-400 mt-2 max-w-md mx-auto leading-relaxed">
              Monitor land acquisition progress, project status and statutory milestones through a unified decision-support portal.
            </p>
          </div>

          {/* Conditional SIH Hackathon Evaluation Banner */}
          {demoMode && (
            <div className="bg-amber-950/25 border-b border-amber-500/30 px-6 py-3.5 sm:px-8">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded">
                  SIH HACKATHON
                </span>
                <span className="text-slate-500" aria-hidden="true">
                  ·
                </span>
                <span className="text-xs font-semibold text-slate-200">
                  Evaluation / Demonstration Environment
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Use the provided evaluation account to explore the portal.
              </p>
            </div>
          )}

          {/* Body Section */}
          <div className="p-6 sm:p-8 space-y-6">
            {/* Conditional SIH Role Selection Cards */}
            {demoMode && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Select Evaluation Account
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Click to load institutional role
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Card 1: Nodal Officer (CALA) */}
                  <div
                    className={`p-4 rounded-xl border text-left transition-all ${
                      selectedRole === 'NODAL'
                        ? 'border-amber-500 bg-amber-950/30 ring-1 ring-amber-500/50'
                        : 'border-slate-800 bg-slate-900/60 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">Nodal Officer (CALA)</span>
                      <span className="text-[10px] font-medium text-amber-400/90 bg-amber-400/10 px-2 py-0.5 rounded">
                        Full evaluation access
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1.5 leading-normal">
                      Operational dashboard, project package edits &amp; statutory decision review
                    </p>
                    <button
                      type="button"
                      onClick={handleSelectNodalOfficer}
                      className="mt-3 w-full py-2 px-3 text-xs font-semibold text-amber-300 hover:text-amber-200 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 rounded-lg transition-colors flex items-center justify-center gap-1.5 focus-visible:ring-2 focus-visible:ring-amber-500 focus-visible:outline-none"
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>Continue as Nodal Officer</span>
                    </button>
                  </div>

                  {/* Card 2: Project Auditor */}
                  <div
                    className={`p-4 rounded-xl border text-left transition-all ${
                      selectedRole === 'AUDITOR'
                        ? 'border-sky-500 bg-sky-950/30 ring-1 ring-sky-500/50'
                        : 'border-slate-800 bg-slate-900/60 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">Project Auditor</span>
                      <span className="text-[10px] font-medium text-sky-400/90 bg-sky-400/10 px-2 py-0.5 rounded">
                        Read-only oversight access
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1.5 leading-normal">
                      Read-only monitoring, audit trail inspection &amp; shadow evaluation analysis
                    </p>
                    <button
                      type="button"
                      onClick={handleSelectProjectAuditor}
                      className="mt-3 w-full py-2 px-3 text-xs font-semibold text-sky-300 hover:text-sky-200 bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/40 rounded-lg transition-colors flex items-center justify-center gap-1.5 focus-visible:ring-2 focus-visible:ring-sky-500 focus-visible:outline-none"
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>Continue as Project Auditor</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Error Message Alert */}
            {errorMessage && (
              <div
                role="alert"
                aria-live="assertive"
                className="p-3.5 bg-red-950/50 border border-red-800/80 rounded-xl text-xs text-red-200 flex items-start gap-2.5 animate-in fade-in duration-150"
              >
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold text-red-300">Authentication Failed</p>
                  <p className="text-red-200 mt-0.5 leading-relaxed">{errorMessage}</p>
                </div>
              </div>
            )}

            {/* Credential Form */}
            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              {/* Email Input */}
              <div className="space-y-1.5">
                <label
                  htmlFor="email"
                  className="block text-xs font-bold text-slate-300 uppercase tracking-wider"
                >
                  Official Institutional Email
                </label>
                <div className="relative">
                  <Mail
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"
                    aria-hidden="true"
                  />
                  <input
                    id="email"
                    type="email"
                    required
                    autoComplete="username"
                    placeholder="e.g. nodal.officer@morth.gov.in"
                    value={email}
                    onChange={e => {
                      setEmail(e.target.value);
                      setSelectedRole(null);
                    }}
                    className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-900 border border-slate-700/80 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all"
                  />
                </div>
              </div>

              {/* Password Input */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label
                    htmlFor="password"
                    className="block text-xs font-bold text-slate-300 uppercase tracking-wider"
                  >
                    Password
                  </label>
                  {demoMode && demoCredentials?.password && !password && (
                    <button
                      type="button"
                      onClick={handleFillDemoPassword}
                      className="text-[11px] text-amber-400 hover:text-amber-300 font-medium transition-colors focus-visible:outline-none focus-visible:underline"
                    >
                      Fill demo password
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"
                    aria-hidden="true"
                  />
                  <input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    autoComplete="current-password"
                    placeholder="Enter password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full pl-10 pr-10 py-2.5 text-xs sm:text-sm bg-slate-900 border border-slate-700/80 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 transition-colors focus-visible:ring-2 focus-visible:ring-amber-500 rounded p-0.5"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    aria-pressed={showPassword}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Demo Credential Note (DEMO_MODE only) */}
              {demoMode && (
                <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
                  <span>Evaluation access</span>
                  <span className="text-slate-500">
                    Demo credentials are provided with the SIH submission.
                  </span>
                </div>
              )}

              {/* Primary CTA Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-3 px-4 bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 hover:from-amber-700 hover:to-amber-900 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed focus-visible:ring-2 focus-visible:ring-amber-400 focus-visible:outline-none cursor-pointer"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>Signing in…</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>Sign In to Statutory Portal</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Statutory Footer Warning */}
          <div className="bg-[#08131A] px-6 py-3 border-t border-slate-800/80 text-center">
            <p className="text-[10px] text-slate-400 leading-relaxed">
              <strong>Notice:</strong> Authorized government access only. Activities are recorded in the institutional audit trail under Section 43 of the IT Act.
            </p>
          </div>
        </div>
      </main>

      {/* Institutional Legal Footer */}
      <footer className="border-t border-slate-800/80 bg-[#050E14] px-4 sm:px-8 py-3 text-center text-xs text-slate-500">
        © 2026 Ministry of Road Transport &amp; Highways (MoRTH) &amp; National Highways Authority of India (NHAI). BhoomiDrishti Portal.
      </footer>

      {/* Evaluation Instructions Modal (DEMO_MODE only) */}
      {demoMode && helpModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200"
          role="dialog"
          aria-modal="true"
          aria-labelledby="eval-guide-title"
        >
          <div className="bg-[#0B1720] border border-slate-700 w-full max-w-lg rounded-2xl p-6 text-slate-100 shadow-2xl relative space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <GovernmentEmblem size={24} />
                <h2 id="eval-guide-title" className="text-base font-bold text-white">
                  SIH Evaluator Quick-Start Guide
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setHelpModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg focus-visible:ring-2 focus-visible:ring-amber-500"
                aria-label="Close evaluation guide"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-slate-300 space-y-3 leading-relaxed">
              <p>
                <strong>BHOOMI-DRISHTI</strong> is the institutional statutory land acquisition intelligence and risk monitoring portal for National Highway projects under the National Highways Act, 1956.
              </p>

              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 space-y-2">
                <p className="font-semibold text-amber-400 text-[11px] uppercase tracking-wider">
                  Evaluation Role Matrix (RBAC)
                </p>
                <div className="space-y-1.5 text-[11px]">
                  <div>
                    <span className="font-bold text-white">Nodal Officer (CALA):</span>
                    <span className="text-slate-400 ml-1">
                      Full operational authority. Can review projects, run What-If simulations, ingest data, and approve milestone items.
                    </span>
                  </div>
                  <div>
                    <span className="font-bold text-white">Project Auditor:</span>
                    <span className="text-slate-400 ml-1">
                      Read-only oversight authority. Can inspect all dashboards, view audit logs, and examine shadow governance telemetry without mutation rights.
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-1 text-slate-400 text-[11px]">
                <p className="font-medium text-slate-200">How to Evaluate:</p>
                <ol className="list-decimal list-inside space-y-1">
                  <li>Click <em>&ldquo;Continue as Nodal Officer&rdquo;</em> or <em>&ldquo;Continue as Project Auditor&rdquo;</em>.</li>
                  <li>Verify the institutional email is populated.</li>
                  <li>Enter the evaluation password provided with the submission.</li>
                  <li>Click <em>&ldquo;Sign In to Statutory Portal&rdquo;</em> to access the system.</li>
                </ol>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setHelpModalOpen(false)}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-amber-500"
              >
                Close Guide
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
