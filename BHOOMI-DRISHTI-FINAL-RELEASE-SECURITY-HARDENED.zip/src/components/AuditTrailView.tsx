import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  Search,
  RefreshCw,
  Filter,
  CheckCircle2,
  AlertTriangle,
  FileText,
  User,
  Clock,
  ChevronDown,
  ChevronRight,
  Download,
  KeyRound
} from 'lucide-react';
import { api } from '../services/apiClient.ts';

export const AuditTrailView: React.FC = () => {
  const [logs, setLogs] = useState<any[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [forbiddenError, setForbiddenError] = useState<string | null>(null);
  const [actionFilter, setActionFilter] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    setForbiddenError(null);
    try {
      const res = await api.audit.query({
        action: actionFilter === 'ALL' ? undefined : actionFilter,
        limit: 100
      });
      setLogs(res.logs || []);
      setTotal(res.total || 0);
    } catch (err: any) {
      if (err?.message?.includes('Statutory') || err?.message?.includes('403') || err?.message?.includes('Forbidden')) {
        setForbiddenError(err.message);
      } else {
        console.error('Failed to load audit logs', err);
      }
    } finally {
      setLoading(false);
    }
  }, [actionFilter]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const filteredLogs = logs.filter((log) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      (log.action || '').toLowerCase().includes(term) ||
      (log.user_name || '').toLowerCase().includes(term) ||
      (log.user_role || '').toLowerCase().includes(term) ||
      (log.resource || '').toLowerCase().includes(term) ||
      (log.resource_id || '').toLowerCase().includes(term) ||
      (log.id || '').toLowerCase().includes(term)
    );
  });

  const getActionBadgeColor = (action: string) => {
    if (action.includes('COMMIT')) return 'bg-emerald-100 text-emerald-900 border-emerald-300';
    if (action.includes('APPROVE')) return 'bg-purple-100 text-purple-900 border-purple-300';
    if (action.includes('UPLOAD') || action.includes('IMPORT')) return 'bg-blue-100 text-blue-900 border-blue-300';
    if (action.includes('SYNC')) return 'bg-sky-100 text-sky-900 border-sky-300';
    if (action.includes('ROLE') || action.includes('AUTH')) return 'bg-amber-100 text-amber-900 border-amber-300';
    return 'bg-slate-100 text-slate-800 border-slate-300';
  };

  const handleExportJson = () => {
    const blob = new Blob([JSON.stringify(logs, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bhoomidrishti_audit_trail_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {forbiddenError && (
        <div className="bg-amber-50 border border-amber-300 rounded-xl p-6 text-amber-950 shadow-2xs">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-200 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6 text-amber-800" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Statutory Administrative Restriction (403 Forbidden)</h3>
              <p className="text-xs text-slate-700 mt-1 leading-relaxed">
                Access to the immutable audit ledger is strictly restricted to CALA Nodal Officers.
                Your current authenticated role is <span className="font-bold text-blue-900">VIEWER</span>.
                Viewers have statutory access to project dashboards, maps, and permitted predictions, but may not inspect government administrative audit trails.
              </p>
              <div className="mt-3 flex items-center gap-2">
                <span className="text-[11px] font-semibold text-slate-500">To inspect this ledger:</span>
                <span className="text-[11px] bg-white px-2 py-0.5 rounded border border-slate-300 font-mono text-slate-700">
                  Switch to Nodal Officer (CALA) via the top-right persona menu
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-2xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-900 text-amber-300 border border-slate-700 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
                Immutable Statutory Audit Trail
              </span>
              <span className="text-xs text-slate-500 font-semibold">
                Tamper-Evident SHA-256 Provenance Log
              </span>
            </div>
            <h2 className="text-lg font-bold text-slate-900">
              Government Administrative Event & Oversight Ledger
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-3xl leading-relaxed">
              Maintains an immutable ledger of every statutory mutation, CSV ingestion batch, officer approval, and data synchronization run.
              All sensitive credentials and authorization tokens are strictly redacted prior to serialization.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleExportJson}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              Export Audit Trail (JSON)
            </button>
            <button
              onClick={fetchLogs}
              disabled={loading}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-blue-700 hover:bg-blue-600 rounded-lg transition-colors shadow-2xs cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh Events
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="mt-5 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by action, user, or resource..."
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden bg-slate-50/50"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto">
            <span className="text-[11px] font-semibold text-slate-500 uppercase whitespace-nowrap">Filter Action:</span>
            {['ALL', 'CSV_COMMIT', 'CSV_APPROVE', 'CSV_UPLOAD', 'DATAHUB_SYNC', 'ROLE_SWITCH'].map((act) => (
              <button
                key={act}
                onClick={() => setActionFilter(act)}
                className={`px-2.5 py-1 rounded text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  actionFilter === act
                    ? 'bg-blue-900 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {act}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs text-slate-600">
          <span className="font-semibold">Displaying {filteredLogs.length} of {total} authoritative events</span>
          <span className="font-mono text-[11px] text-slate-400">Zero-Tamper Enforcement Active</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Timestamp (IST)</th>
                <th className="py-2.5 px-3">Action</th>
                <th className="py-2.5 px-3">Statutory User</th>
                <th className="py-2.5 px-3">Role</th>
                <th className="py-2.5 px-3">Resource & ID</th>
                <th className="py-2.5 px-3">Result</th>
                <th className="py-2.5 px-3 text-right">Inspection</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 font-sans">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-slate-400" />
                    Loading authoritative audit logs...
                  </td>
                </tr>
              ) : filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 font-sans">
                    No matching audit records found for the specified filter criteria.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => {
                  const isExpanded = expandedLogId === log.id;
                  let parsedDetails = null;
                  try {
                    parsedDetails = typeof log.details === 'string' ? JSON.parse(log.details) : log.details;
                  } catch {
                    parsedDetails = log.details;
                  }

                  return (
                    <React.Fragment key={log.id}>
                      <tr className={`hover:bg-slate-50/75 transition-colors ${isExpanded ? 'bg-blue-50/30' : ''}`}>
                        <td className="py-2.5 px-3 text-slate-700 whitespace-nowrap font-mono">
                          {log.created_at ? new Date(log.created_at).toLocaleString() : 'N/A'}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getActionBadgeColor(log.action)}`}>
                            {log.action}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-sans font-semibold text-slate-900">
                          {log.user_name || 'System Pipeline'}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                            log.user_role === 'NODAL_OFFICER' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {log.user_role}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-700 font-mono">
                          <span className="text-slate-500 font-sans">{log.resource}:</span> {log.resource_id || 'N/A'}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            log.result === 'SUCCESS' ? 'text-emerald-700 bg-emerald-50' : 'text-rose-700 bg-rose-50'
                          }`}>
                            {log.result}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-sans">
                          <button
                            onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                            className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 hover:text-blue-900 cursor-pointer"
                          >
                            <span>{isExpanded ? 'Collapse' : 'Inspect'}</span>
                            {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                          </button>
                        </td>
                      </tr>

                      {isExpanded && (
                        <tr className="bg-slate-50/80">
                          <td colSpan={7} className="p-4 border-b border-slate-200">
                            <div className="bg-white rounded-lg p-3 border border-slate-200 text-xs font-mono space-y-2">
                              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                                <span className="font-bold text-slate-700 font-sans">Audit Event Metadata</span>
                                <span className="text-slate-400 text-[10px]">Log UUID: {log.id}</span>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
                                <div><span className="text-slate-400">User ID:</span> {log.user_id}</div>
                                <div><span className="text-slate-400">IP Address:</span> {log.ip_address || '127.0.0.1'}</div>
                                <div><span className="text-slate-400">User Agent:</span> {log.user_agent ? log.user_agent.slice(0, 30) + '...' : 'Internal API'}</div>
                              </div>
                              <div className="pt-2">
                                <span className="text-slate-500 font-semibold font-sans block mb-1">Payload Details (Redacted):</span>
                                <pre className="p-2 bg-slate-900 text-emerald-300 rounded text-[11px] overflow-x-auto max-h-48">
                                  {JSON.stringify(parsedDetails, null, 2)}
                                </pre>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
