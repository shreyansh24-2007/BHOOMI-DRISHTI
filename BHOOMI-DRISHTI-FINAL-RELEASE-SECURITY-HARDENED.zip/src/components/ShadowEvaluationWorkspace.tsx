/**
 * BHOOMI-DRISHTI PHASE 7B-7: SHADOW EVALUATION & STATISTICAL GOVERNANCE WORKSPACE
 * 
 * Institutional governance workspace for V2 candidate evaluation against mature statutory outcomes:
 * 1. Evaluation Readiness & Gate Status
 * 2. Mature Outcome Coverage
 * 3. V2 Observed Performance & Discrimination (Point estimates + 95% Project-level Bootstrap CIs)
 * 4. Calibration Analysis (Brier, Log Loss, Slope, Intercept, ECE, Reliability Bins)
 * 5. Diagnostic Threshold Sensitivity Analysis (Non-operational)
 * 6. V1 vs V2 Retrospective Comparative Diagnostics
 * 7. Temporal Evidence Analysis (Observation Year Cohorts)
 * 8. Jurisdictional & Implementing Agency Diagnostics
 * 9. Coverage Bias Analysis
 * 10. Exclusion Ledger (Traceable rejection reasons)
 * 11. Evaluation Run History & Audit Trail
 * 12. Statistical Methodology & Governance Disclosure
 * 
 * Strict non-operational disclosures:
 * SHADOW EVALUATION — NON-OFFICIAL
 * V1 REMAINS AUTHORITATIVE · V2 REMAINS NON-OPERATIONAL
 * THRESHOLD POLICY: PENDING STAKEHOLDER APPROVAL
 */

import React, { useState, useEffect } from 'react';
import {
  Activity,
  ShieldCheck,
  AlertTriangle,
  RefreshCw,
  BarChart3,
  CheckCircle2,
  Clock,
  Database,
  Sliders,
  TrendingUp,
  FileText,
  AlertCircle,
  HelpCircle,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  XCircle,
  GitBranch,
  Layers,
  Info
} from 'lucide-react';
import { api } from '../services/apiClient.ts';

interface ShadowEvaluationWorkspaceProps {
  userRole?: string;
}

export const ShadowEvaluationWorkspace: React.FC<ShadowEvaluationWorkspaceProps> = ({ userRole }) => {
  const isNodalOrAuditor = userRole === 'NODAL_OFFICER' || userRole === 'AUDITOR';
  const isNodal = userRole === 'NODAL_OFFICER';

  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [summary, setSummary] = useState<any | null>(null);
  const [runs, setRuns] = useState<any[]>([]);
  const [exclusions, setExclusions] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  // Collapsible sections
  const [showThresholdDetails, setShowThresholdDetails] = useState(true);
  const [showCoverageBias, setShowCoverageBias] = useState(false);
  const [showExclusions, setShowExclusions] = useState(false);
  const [showRunsHistory, setShowRunsHistory] = useState(false);
  const [showMethodology, setShowMethodology] = useState(false);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [sumRes, runsRes, exclRes] = await Promise.all([
        api.shadow.getEvaluationSummary().catch(() => null),
        api.shadow.getEvaluationRuns().catch(() => null),
        api.shadow.getEvaluationExclusions().catch(() => null)
      ]);

      if (sumRes && sumRes.summary) {
        setSummary(sumRes.summary);
      }
      if (runsRes && runsRes.runs) {
        setRuns(runsRes.runs);
      }
      if (exclRes && exclRes.exclusions) {
        setExclusions(exclRes.exclusions);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load shadow evaluation diagnostics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRunEvaluation = async () => {
    setRunning(true);
    setMessage(null);
    setError(null);
    try {
      const res = await api.shadow.runEvaluationCycle();
      if (res.summary) {
        setSummary(res.summary);
        setMessage(`Evaluation cycle executed successfully (Run ID: ${res.run?.run_id || res.summary.latestRunId})`);
      }
      await loadData();
    } catch (err: any) {
      setError(err.message || 'Evaluation run failed');
    } finally {
      setRunning(false);
    }
  };

  if (loading && !summary) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-8 text-center shadow-xs">
        <RefreshCw className="w-6 h-6 text-indigo-700 animate-spin mx-auto mb-2" />
        <div className="text-xs text-slate-600 font-medium">Reconciling point-in-time statutory outcomes and computing bootstrap diagnostics...</div>
      </div>
    );
  }

  const metrics = summary?.metrics;
  const reliabilityBins = summary?.reliabilityBins || [];
  const thresholds = summary?.diagnosticThresholds || [];
  const v1v2 = summary?.v1v2Comparison;
  const temporal = summary?.temporalCohorts;
  const segmentation = summary?.segmentation;
  const coverageBias = summary?.coverageBias;
  const isSufficient = summary?.isStatisticallySufficient;
  const evalState = summary?.evaluationState;

  return (
    <div className="space-y-6">
      {/* 1. TOP GOVERNANCE BANNER & SAFETY DISCLOSURES */}
      <div className="bg-slate-900 text-white rounded-xl p-5 shadow-sm border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-indigo-400" />
              <h2 className="text-base font-bold tracking-tight">V2 Shadow Model-vs-Outcome Evaluation &amp; Statistical Governance</h2>
            </div>
            <p className="text-xs text-slate-300 mt-1 max-w-3xl leading-relaxed">
              Retrospective statistical validation against authoritative e-Gazette statutory outcomes (Section 3A vs 3D 365-day lapse window).
              Enforces project-level bootstrap uncertainty estimation and data sufficiency gating.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded bg-amber-400 text-slate-950 text-[11px] font-black uppercase tracking-wider">
              V2 SHADOW CANDIDATE — NON-OPERATIONAL
            </span>
            <span className="px-2.5 py-1 rounded bg-blue-500/20 text-blue-300 border border-blue-500/40 text-[11px] font-bold uppercase tracking-wider">
              V1 REMAINS AUTHORITATIVE
            </span>
          </div>
        </div>

        {/* Action Controls & Audit Fingerprint */}
        <div className="mt-4 pt-4 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-4 text-slate-400 font-mono text-[11px]">
            <div>Model: <span className="text-slate-200">BHOOMI-DRISHTI-ML-V2.0-SHADOW</span></div>
            <div>Artifact SHA: <span className="text-slate-200">4a83e980...</span></div>
            <div>Evaluation SHA: <span className="text-slate-200">{summary?.evaluationDatasetSha256 ? summary.evaluationDatasetSha256.substring(0, 12) + '...' : '—'}</span></div>
          </div>

          <div className="flex items-center gap-2">
            {isNodalOrAuditor && (
              <button
                onClick={handleRunEvaluation}
                disabled={running}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 shadow-xs focus:outline-hidden focus-visible:ring-2 focus-visible:ring-indigo-400"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${running ? 'animate-spin' : ''}`} />
                {running ? 'Evaluating...' : 'Run Evaluation Cycle'}
              </button>
            )}
          </div>
        </div>

        {/* Diagnostic Watermark Bar */}
        <div className="mt-3 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-amber-300 font-mono">
          <span className="flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            SHADOW / DIAGNOSTIC ONLY — NOT AN OPERATIONAL RISK SCORE
          </span>
          <span className="text-slate-400">
            THRESHOLDS: PENDING STAKEHOLDER APPROVAL
          </span>
        </div>
      </div>

      {message && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-lg text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* 2. EVALUATION READINESS & DATA SUFFICIENCY GATE */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-600" />
              1. Statistical Sufficiency Gate &amp; Evaluation Readiness
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Strict institutional guardrails suppress premature metric reporting when mature sample sizes are insufficient.
            </p>
          </div>

          <span className={`px-2.5 py-1 rounded text-xs font-bold border ${
            isSufficient
              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
              : 'bg-amber-100 text-amber-800 border-amber-300'
          }`}>
            GATE STATUS: {evalState || 'OUTCOME_MATURITY_INSUFFICIENT'}
          </span>
        </div>

        {/* 4 Overview Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/70">
            <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Operational Projects</div>
            <div className="text-lg font-bold text-slate-900 mt-1">{summary?.totalOperationalProjects || 31}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Active registry cohort</div>
          </div>

          <div className="p-3 rounded-lg border border-blue-200 bg-blue-50/60">
            <div className="text-[11px] font-semibold text-blue-800 uppercase tracking-wider">Mature Observations</div>
            <div className="text-lg font-bold text-blue-950 mt-1">{summary?.matureObservations || 0}</div>
            <div className="text-[10px] text-blue-700 mt-0.5">{summary?.matureProjects || 0} unique corridors</div>
          </div>

          <div className="p-3 rounded-lg border border-rose-200 bg-rose-50/60">
            <div className="text-[11px] font-semibold text-rose-800 uppercase tracking-wider">Delayed / Lapsed</div>
            <div className="text-lg font-bold text-rose-950 mt-1">{summary?.delayedCount || 0}</div>
            <div className="text-[10px] text-rose-700 mt-0.5">&gt; 365 days statutory delay</div>
          </div>

          <div className="p-3 rounded-lg border border-emerald-200 bg-emerald-50/60">
            <div className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wider">Completed On-Time</div>
            <div className="text-lg font-bold text-emerald-950 mt-1">{summary?.onTimeCount || 0}</div>
            <div className="text-[10px] text-emerald-700 mt-0.5">&le; 365 days Section 3D notice</div>
          </div>
        </div>

        {/* Gate Guidance Message */}
        <div className={`mt-4 p-3.5 rounded-lg border text-xs flex items-start gap-2.5 ${
          isSufficient
            ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
            : 'bg-amber-50 border-amber-200 text-amber-900'
        }`}>
          <Info className="w-4 h-4 shrink-0 mt-0.5 text-amber-700" />
          <div className="leading-relaxed">
            <strong>Institutional Evaluation Disclosure:</strong> {summary?.message || 'A minimum of 10 mature authoritative statutory outcomes with both delayed and on-time representations is required for unbiased discrimination analysis. Current metrics are provided in accordance with strict empirical readiness.'}
          </div>
        </div>
      </div>

      {/* 3 & 4. PERFORMANCE & CALIBRATION METRICS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Discrimination Metrics Card */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-1">
              <BarChart3 className="w-4 h-4 text-indigo-600" />
              2. Discrimination Metrics (Project-Level Bootstrap CIs)
            </h3>
            <p className="text-[11px] text-slate-500 mb-4">
              95% Confidence intervals estimated via 1,000 project-level cluster resamples (Seed: 42).
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] border-b border-slate-200">
                    <th className="py-2 px-2.5">Metric</th>
                    <th className="py-2 px-2.5">Point Estimate</th>
                    <th className="py-2 px-2.5">95% Confidence Interval</th>
                    <th className="py-2 px-2.5">Validation State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                  {[
                    { label: 'ROC-AUC', m: metrics?.rocAuc },
                    { label: 'PR-AUC', m: metrics?.prAuc },
                    { label: 'Sensitivity / Recall', m: metrics?.sensitivity },
                    { label: 'Specificity', m: metrics?.specificity },
                    { label: 'Precision / PPV', m: metrics?.precision },
                    { label: 'Negative Pred Value', m: metrics?.npv },
                    { label: 'Balanced Accuracy', m: metrics?.balancedAccuracy },
                    { label: 'F1 Score', m: metrics?.f1 }
                  ].map(row => (
                    <tr key={row.label} className="hover:bg-slate-50">
                      <td className="py-2 px-2.5 font-sans font-medium text-slate-900">{row.label}</td>
                      <td className="py-2 px-2.5 font-bold text-indigo-950">
                        {row.m ? row.m.estimate.toFixed(4) : '—'}
                      </td>
                      <td className="py-2 px-2.5 text-slate-600">
                        {row.m && row.m.ciLower !== null && row.m.ciUpper !== null
                          ? `[${row.m.ciLower.toFixed(4)}, ${row.m.ciUpper.toFixed(4)}]`
                          : 'INSUFFICIENT_POWER'}
                      </td>
                      <td className="py-2 px-2.5 font-sans">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          row.m ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {row.m ? 'COMPUTED' : 'SUPPRESSED'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500 italic">
            Discrimination estimates reflect retrospective statutory performance. No model promotion is implied.
          </div>
        </div>

        {/* Calibration & Reliability Bins Card */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-slate-700" />
                3. Calibration Analysis &amp; Expected Calibration Error
              </h3>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                metrics?.calibrationStatus === 'CALIBRATION_EVIDENCE_SUFFICIENT'
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                  : 'bg-amber-100 text-amber-800 border-amber-300'
              }`}>
                {metrics?.calibrationStatus || 'CALIBRATION_EVIDENCE_INSUFFICIENT'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-4">
              Measures correspondence between predicted probabilities and observed statutory event rates.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs mb-4">
              <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Prediction Accuracy Index (Brier)</span>
                <div className="text-base font-bold text-slate-900 mt-0.5">
                  {metrics?.brierScore ? metrics.brierScore.estimate.toFixed(4) : '—'}
                </div>
                <div className="text-[9px] text-slate-400 mt-0.5">Closer to 0 is better</div>
              </div>
              <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Log Loss (Entropy)</span>
                <div className="text-base font-bold text-slate-900 mt-0.5">
                  {metrics?.logLoss ? metrics.logLoss.estimate.toFixed(4) : '—'}
                </div>
                <div className="text-[9px] text-slate-400 mt-0.5">Penalty for overconfidence</div>
              </div>
              <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Calibration Slope</span>
                <div className="text-base font-bold text-slate-900 mt-0.5">
                  {metrics?.calibrationSlope !== null && metrics?.calibrationSlope !== undefined ? metrics.calibrationSlope.toFixed(4) : '—'}
                </div>
                <div className="text-[9px] text-slate-400 mt-0.5">Target: ~1.00</div>
              </div>
              <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Expected Calib Error (ECE)</span>
                <div className="text-base font-bold text-slate-900 mt-0.5">
                  {metrics?.ece !== null && metrics?.ece !== undefined ? metrics.ece.toFixed(4) : '—'}
                </div>
                <div className="text-[9px] text-slate-400 mt-0.5">Target: &lt; 0.05</div>
              </div>
            </div>

            {/* Reliability Bins Table */}
            <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                    <th className="py-2 px-2.5">Bin</th>
                    <th className="py-2 px-2.5">N Obs</th>
                    <th className="py-2 px-2.5">Projects</th>
                    <th className="py-2 px-2.5">Mean Pred</th>
                    <th className="py-2 px-2.5">Obs Rate</th>
                    <th className="py-2 px-2.5">Calib Err</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                  {reliabilityBins.map((b: any) => (
                    <tr key={b.binIndex} className="hover:bg-slate-50">
                      <td className="py-2 px-2.5 font-bold text-slate-900">[{b.binStart.toFixed(1)}-{b.binEnd.toFixed(1)}]</td>
                      <td className="py-2 px-2.5">{b.sampleCount}</td>
                      <td className="py-2 px-2.5">{b.projectCount}</td>
                      <td className="py-2 px-2.5">{b.meanPredictedProbability.toFixed(3)}</td>
                      <td className="py-2 px-2.5">{b.observedEventRate.toFixed(3)}</td>
                      <td className="py-2 px-2.5 text-indigo-900 font-bold">{b.calibrationError.toFixed(3)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500 italic">
            Zero post-hoc recalibration transforms applied. Frozen artifact parameters are strictly preserved.
          </div>
        </div>
      </div>

      {/* 5. THRESHOLD SENSITIVITY ANALYSIS (DIAGNOSTIC ONLY) */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-slate-800" />
              4. Multi-Threshold Sensitivity Workspace (Diagnostic Only)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Evaluating hypothetical decision boundaries across candidate cutoffs. <em>No operational threshold is approved or active.</em>
            </p>
          </div>

          <span className="px-2.5 py-1 rounded bg-amber-100 text-amber-800 border border-amber-300 text-[10px] font-bold uppercase tracking-wider">
            POLICY STATUS: PENDING_STAKEHOLDER_APPROVAL
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                <th className="py-2.5 px-3">Cutoff</th>
                <th className="py-2.5 px-3">TP</th>
                <th className="py-2.5 px-3">FP</th>
                <th className="py-2.5 px-3">TN</th>
                <th className="py-2.5 px-3">FN</th>
                <th className="py-2.5 px-3">Sensitivity</th>
                <th className="py-2.5 px-3">Specificity</th>
                <th className="py-2.5 px-3">Precision</th>
                <th className="py-2.5 px-3">Balanced Acc</th>
                <th className="py-2.5 px-3">Classified High</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
              {thresholds.map((t: any) => (
                <tr key={t.threshold} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-bold text-slate-900">{t.threshold.toFixed(2)}</td>
                  <td className="py-2.5 px-3">{t.truePositives}</td>
                  <td className="py-2.5 px-3">{t.falsePositives}</td>
                  <td className="py-2.5 px-3">{t.trueNegatives}</td>
                  <td className="py-2.5 px-3">{t.falseNegatives}</td>
                  <td className="py-2.5 px-3 font-bold text-indigo-900">{t.sensitivity.toFixed(3)}</td>
                  <td className="py-2.5 px-3">{t.specificity.toFixed(3)}</td>
                  <td className="py-2.5 px-3">{t.precision.toFixed(3)}</td>
                  <td className="py-2.5 px-3">{t.balancedAccuracy.toFixed(3)}</td>
                  <td className="py-2.5 px-3 font-bold">{t.classifiedHighCount} / {t.classifiedHighCount + t.classifiedLowCount}</td>
                  <td className="py-2.5 px-3 font-sans">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                      DIAGNOSTIC
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-3 p-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-600 text-xs">
          <strong>Mandatory Institutional Safeguard:</strong> Neither this sensitivity grid nor any illustrative cost ratio (e.g. 3:1 or 5:1) constitutes an approved threshold policy. Operational risk alerts remain exclusively generated by production model V1.0.
        </div>
      </div>

      {/* 6. V1 VS V2 RETROSPECTIVE COMPARISON */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-blue-900" />
              5. V1 Operational vs V2 Candidate Retrospective Comparison
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Side-by-side empirical performance on identical eligible mature observations. <em>Comparative diagnostic evidence only.</em>
            </p>
          </div>

          <span className="text-[11px] font-mono text-slate-500">
            {v1v2?.v1ComparabilityNote || 'Mature cohort comparison'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">Production Model V1.0</span>
              <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">OPERATIONAL</span>
            </div>
            <div className="font-mono text-xs text-slate-600">SHA-256: 7e0e1a7dac2e...7f</div>
            <div className="pt-2 border-t border-slate-200 grid grid-cols-2 gap-2 text-xs">
              <div>ROC-AUC: <span className="font-bold">{v1v2?.v1?.rocAuc ? v1v2.v1.rocAuc.toFixed(4) : 'INSUFFICIENT_SAMPLE'}</span></div>
              <div>Brier Score: <span className="font-bold">{v1v2?.v1?.brierScore ? v1v2.v1.brierScore.toFixed(4) : 'INSUFFICIENT_SAMPLE'}</span></div>
              <div>Available Observations: <span className="font-bold">{v1v2?.v1?.availableCount || 0}</span></div>
              <div>Model Family: <span className="font-bold">Logistic Regression</span></div>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-indigo-200 bg-indigo-50/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-950">Candidate Model V2.0</span>
              <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-[10px] font-bold">NON-OPERATIONAL SHADOW</span>
            </div>
            <div className="font-mono text-xs text-indigo-900">SHA-256: 4a83e980f917...a2</div>
            <div className="pt-2 border-t border-indigo-200 grid grid-cols-2 gap-2 text-xs text-indigo-950">
              <div>ROC-AUC: <span className="font-bold">{v1v2?.v2?.rocAuc ? v1v2.v2.rocAuc.toFixed(4) : 'INSUFFICIENT_SAMPLE'}</span></div>
              <div>Brier Score: <span className="font-bold">{v1v2?.v2?.brierScore ? v1v2.v2.brierScore.toFixed(4) : 'INSUFFICIENT_SAMPLE'}</span></div>
              <div>Available Observations: <span className="font-bold">{v1v2?.v2?.availableCount || 0}</span></div>
              <div>Model Family: <span className="font-bold">HistGradientBoosting</span></div>
            </div>
          </div>
        </div>

        <div className="mt-3 text-[11px] text-slate-500 italic">
          {v1v2?.disclaimer || 'Comparative diagnostic evidence only. No production model decision is made here.'}
        </div>
      </div>

      {/* 7 & 8. TEMPORAL & SEGMENTATION DIAGNOSTICS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Temporal Cohorts */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-1">
            <Clock className="w-4 h-4 text-blue-900" />
            6. Temporal Cohort Evaluation
          </h3>
          <p className="text-[11px] text-slate-500 mb-3">
            Performance evaluated across chronologically grouped observation years.
          </p>

          <div className="space-y-2">
            {(temporal?.cohorts || []).map((c: any) => (
              <div key={c.cohortKey} className="p-2.5 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-slate-900">{c.cohortLabel}</div>
                  <div className="text-[11px] text-slate-500">
                    {c.sampleSize} observations · {c.delayedCount} delayed, {c.onTimeCount} on-time
                  </div>
                </div>
                <div className="text-right font-mono">
                  <div className="text-[11px] text-slate-600">
                    {c.status === 'SUFFICIENT_SAMPLE' ? `AUC: ${c.rocAuc?.toFixed(3)} | Brier: ${c.brierScore?.toFixed(3)}` : 'INSUFFICIENT_SAMPLE'}
                  </div>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    c.status === 'SUFFICIENT_SAMPLE' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {c.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Jurisdictional & Operational Segmentation */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-1">
            <Layers className="w-4 h-4 text-indigo-600" />
            7. Jurisdictional &amp; Operational Segmentation
          </h3>
          <p className="text-[11px] text-slate-500 mb-3">
            Diagnostic segmentation by state jurisdiction and implementing agency. <em>No entity ranking permitted.</em>
          </p>

          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            <div className="text-[11px] font-bold text-slate-700 uppercase">By State Jurisdiction</div>
            {(segmentation?.byState || []).map((s: any) => (
              <div key={s.name} className="p-2 rounded border border-slate-100 bg-slate-50/70 flex items-center justify-between text-xs">
                <span className="font-medium text-slate-900 truncate max-w-[140px]">{s.name}</span>
                <span className="text-[11px] font-mono text-slate-600">
                  {s.sampleSize} obs ({s.delayedCount} del) · <span className="font-bold">{s.status}</span>
                </span>
              </div>
            ))}

            <div className="text-[11px] font-bold text-slate-700 uppercase mt-3">By Implementing Agency</div>
            {(segmentation?.byAgency || []).map((a: any) => (
              <div key={a.name} className="p-2 rounded border border-slate-100 bg-slate-50/70 flex items-center justify-between text-xs">
                <span className="font-medium text-slate-900 truncate max-w-[140px]">{a.name}</span>
                <span className="text-[11px] font-mono text-slate-600">
                  {a.sampleSize} obs ({a.delayedCount} del) · <span className="font-bold">{a.status}</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 9. COVERAGE BIAS ANALYSIS */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-900" />
              8. Evidence Coverage Bias Analysis
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Assesses whether scoreable corridors differ systematically from the operational project population.
            </p>
          </div>

          <button
            onClick={() => setShowCoverageBias(!showCoverageBias)}
            className="text-xs text-indigo-700 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
          >
            {showCoverageBias ? 'Hide Bias Details' : 'View Full Bias Report'}
            {showCoverageBias ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700">
          <strong>Coverage Finding:</strong> {coverageBias?.biasFinding || 'Evaluation sample is currently restricted to corridors with complete statutory provenance.'}
        </div>

        {showCoverageBias && (
          <div className="mt-4 pt-4 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <div className="font-bold text-slate-800 mb-2">State Coverage Breakdown</div>
              <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                {(coverageBias?.stateDistribution || []).map((st: any) => (
                  <div key={st.state} className="flex justify-between items-center p-1.5 bg-slate-50 rounded border border-slate-100">
                    <span className="text-slate-700">{st.state}</span>
                    <span className="font-mono font-bold text-slate-900">{st.scoreableProjects} / {st.totalProjects} ({st.scoreablePercentage}%)</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="font-bold text-slate-800 mb-2">Land Area Representative Comparison</div>
              <div className="space-y-2">
                <div className="p-2.5 bg-slate-50 rounded border border-slate-100 flex justify-between">
                  <span>Operational Cohort Mean Required Land</span>
                  <span className="font-mono font-bold">{coverageBias?.landRequirementStats?.operationalMeanHa || 0} ha</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded border border-slate-100 flex justify-between">
                  <span>Scoreable Cohort Mean Required Land</span>
                  <span className="font-mono font-bold text-indigo-950">{coverageBias?.landRequirementStats?.scoreableMeanHa || 0} ha</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 10. EVALUATION EXCLUSION LEDGER */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <XCircle className="w-4 h-4 text-rose-700" />
              9. Immutable Evaluation Exclusion Ledger
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Every excluded observation preserves an institutional rejection reason to ensure tamper-evident reproducibility.
            </p>
          </div>

          <button
            onClick={() => setShowExclusions(!showExclusions)}
            className="text-xs text-indigo-700 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
          >
            {showExclusions ? 'Collapse Ledger' : `View ${exclusions.length} Exclusions`}
            {showExclusions ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Exclusion Summary Chips */}
        <div className="flex flex-wrap gap-2 mb-3">
          {Object.entries(summary?.exclusionSummary || {}).map(([reason, count]: any) => (
            <span key={reason} className="px-2.5 py-1 rounded bg-slate-100 border border-slate-200 text-slate-700 text-xs font-mono">
              <strong>{reason}:</strong> {count}
            </span>
          ))}
        </div>

        {showExclusions && (
          <div className="border border-slate-200 rounded-lg overflow-x-auto text-xs max-h-64 overflow-y-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] sticky top-0">
                  <th className="py-2 px-3">Project ID</th>
                  <th className="py-2 px-3">Observation Time</th>
                  <th className="py-2 px-3">Reason</th>
                  <th className="py-2 px-3">Auditable Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                {exclusions.map((ex: any) => (
                  <tr key={ex.exclusion_id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-bold text-slate-900">{ex.project_id}</td>
                    <td className="py-2 px-3 text-slate-600">{ex.observation_timestamp}</td>
                    <td className="py-2 px-3">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                        {ex.reason}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-sans text-slate-600 text-[11px]">{ex.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 11 & 12. RUN HISTORY & METHODOLOGY DISCLOSURE */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-slate-700" />
              10. Evaluation Run History &amp; Statistical Methodology Disclosure
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Reproducible audit trail stored in <code>shadow_evaluation_runs</code>.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowMethodology(!showMethodology)}
              className="text-xs text-indigo-700 font-semibold hover:underline cursor-pointer"
            >
              {showMethodology ? 'Hide Methodology' : 'Methodology Spec'}
            </button>
            <button
              onClick={() => setShowRunsHistory(!showRunsHistory)}
              className="text-xs text-indigo-700 font-semibold hover:underline cursor-pointer"
            >
              {showRunsHistory ? 'Hide Runs' : `View ${runs.length} Runs`}
            </button>
          </div>
        </div>

        {showMethodology && (
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 space-y-2 mb-4">
            <div className="font-bold text-slate-900 uppercase text-[11px]">Phase 7B-7 Statistical Standards:</div>
            <ul className="list-disc list-inside space-y-1">
              <li><strong>Project-Level Cluster Resampling:</strong> Bootstrapping samples unique project corridors with replacement (Seed: 42, B: 1,000) to account for intra-corridor longitudinal autocorrelation.</li>
              <li><strong>Point-in-Time Causality:</strong> Strictly enforces t_outcome &ge; t_obs. Observations where gazette outcomes precede observation times are rejected under <code>FUTURE_FEATURE_DETECTED</code>.</li>
              <li><strong>Zero Imputation &amp; Label Substitution:</strong> Section 3D dates are sourced strictly from authentic e-Gazette publications. No simulated or administrative dates are substituted.</li>
              <li><strong>Frozen Invariants:</strong> V1 SHA (`7e0e1a7d...`) and V2 SHA (`4a83e980...`) are validated at every run invocation.</li>
            </ul>
          </div>
        )}

        {showRunsHistory && (
          <div className="border border-slate-200 rounded-lg overflow-x-auto text-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                  <th className="py-2 px-3">Run ID</th>
                  <th className="py-2 px-3">Timestamp</th>
                  <th className="py-2 px-3">Scope</th>
                  <th className="py-2 px-3">Mature N</th>
                  <th className="py-2 px-3">Projects</th>
                  <th className="py-2 px-3">Evaluation State</th>
                  <th className="py-2 px-3">Evaluator</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                {runs.map((r: any) => (
                  <tr key={r.run_id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-bold text-slate-900">{r.run_id}</td>
                    <td className="py-2 px-3 text-slate-600">{r.run_timestamp}</td>
                    <td className="py-2 px-3">{r.evaluation_scope}</td>
                    <td className="py-2 px-3 font-bold">{r.mature_observations}</td>
                    <td className="py-2 px-3">{r.mature_projects}</td>
                    <td className="py-2 px-3 font-sans">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        r.evaluation_state === 'EVALUATION_READY'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {r.evaluation_state}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-sans text-slate-600">{r.created_by}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
