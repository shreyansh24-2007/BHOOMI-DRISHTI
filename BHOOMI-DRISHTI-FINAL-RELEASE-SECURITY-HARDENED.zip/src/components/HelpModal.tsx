import React, { useState } from 'react';
import { X, BookOpen, ShieldCheck, Scale, FileText, HelpCircle, Users, CheckCircle2, ArrowRight, Activity, Cpu } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type HelpTab = 'principles' | 'workflow' | 'statute' | 'models' | 'glossary' | 'roles';

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<HelpTab>('principles');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-3xl w-full p-6 shadow-2xl space-y-5 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-800">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Institutional Guidance &amp; Reference Center</h2>
              <p className="text-xs text-slate-500">Government of India • Ministry of Road Transport &amp; Highways (MoRTH)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Close guide"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-semibold shrink-0 overflow-x-auto">
          <button
            onClick={() => setActiveTab('principles')}
            className={`py-1.5 px-3 rounded-md transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'principles'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Core Mission
          </button>
          <button
            onClick={() => setActiveTab('workflow')}
            className={`py-1.5 px-3 rounded-md transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'workflow'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Officer Workflow
          </button>
          <button
            onClick={() => setActiveTab('statute')}
            className={`py-1.5 px-3 rounded-md transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'statute'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            NH Act, 1956
          </button>
          <button
            onClick={() => setActiveTab('models')}
            className={`py-1.5 px-3 rounded-md transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'models'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            V1 vs V2 Models
          </button>
          <button
            onClick={() => setActiveTab('glossary')}
            className={`py-1.5 px-3 rounded-md transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'glossary'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Plain Glossary
          </button>
          <button
            onClick={() => setActiveTab('roles')}
            className={`py-1.5 px-3 rounded-md transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'roles'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Officer Roles
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-4 text-xs">
          {/* TAB 1: PRINCIPLES */}
          {activeTab === 'principles' && (
            <div className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1.5">
                <span className="font-bold text-slate-900 uppercase tracking-wider text-[11px] text-amber-800">
                  Institutional Mission &amp; Statutory Mandate
                </span>
                <p className="text-slate-800 font-semibold text-sm leading-snug">
                  “See the bottleneck → Understand the statutory cause → Identify prior interventions → De-escalate delay.”
                </p>
                <p className="text-slate-600 text-[11.5px] pt-1 leading-relaxed">
                  BHOOMI-DRISHTI provides calibrated, actionable decision support for Competent Authorities for Land Acquisition (CALA), NHAI Project Directors, and Ministry leadership under the National Highways Act, 1956 and RFCTLARR Act, 2013 without requiring technical machine learning expertise.
                </p>
              </div>

              <div className="space-y-2.5">
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                  The 4 Key Operational Questions Answered:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                    <span className="font-bold text-slate-900 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-[10px]">1</span>
                      Which corridors face delay risks?
                    </span>
                    <p className="text-slate-600 text-[11px]">
                      National Dashboard monitors all 31 active corridors, categorizing risk into Low (&lt;35%), Medium (35%–69.9%), and High (≥70%).
                    </p>
                  </div>
                  <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                    <span className="font-bold text-slate-900 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-[10px]">2</span>
                      What is the root cause?
                    </span>
                    <p className="text-slate-600 text-[11px]">
                      Exposes exact bottlenecks: Section 3H disbursement deficit, Section 3A statutory lapse window, judicial stay orders, or forest diversion hold-ups.
                    </p>
                  </div>
                  <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                    <span className="font-bold text-slate-900 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-[10px]">3</span>
                      Who needs urgent attention?
                    </span>
                    <p className="text-slate-600 text-[11px]">
                      The Action Queue prioritizes projects nearing statutory deadlines (e.g. 365-day 3A-to-3D lapse) or experiencing disbursement stalls.
                    </p>
                  </div>
                  <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                    <span className="font-bold text-slate-900 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-[10px]">4</span>
                      What administrative action to take?
                    </span>
                    <p className="text-slate-600 text-[11px]">
                      Interactive What-If policy simulator calculates schedule recovery when legal remedies, revenue camps, or fund releases are executed.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: OFFICER WORKFLOW */}
          {activeTab === 'workflow' && (
            <div className="space-y-3">
              <div className="bg-blue-50/70 p-3.5 rounded-xl border border-blue-200 space-y-1">
                <span className="font-bold text-blue-950 uppercase tracking-wider text-[11px]">
                  5-Step Administrative Resolution Protocol
                </span>
                <p className="text-blue-900/90 text-[11.5px] leading-relaxed">
                  How a Regional Officer or Competent Authority acts upon early warnings:
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-start gap-3 p-3 bg-white border border-slate-200 rounded-xl">
                  <div className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    1
                  </div>
                  <div className="space-y-0.5">
                    <h5 className="font-bold text-slate-900">Review Early Warning in Alerts or Dashboard</h5>
                    <p className="text-slate-600 text-[11px]">
                      Identify packages flagged with High Delay Probability (≥ 70%) or urgent statutory escalation notices.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-white border border-slate-200 rounded-xl">
                  <div className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    2
                  </div>
                  <div className="space-y-0.5">
                    <h5 className="font-bold text-slate-900">Inspect Project Dossier &amp; Root Causes</h5>
                    <p className="text-slate-600 text-[11px]">
                      Open Project Details to inspect the Statutory Timeline, compensation disbursement ratio, and document mutation backlog.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-white border border-slate-200 rounded-xl">
                  <div className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    3
                  </div>
                  <div className="space-y-0.5">
                    <h5 className="font-bold text-slate-900">Test Remedies with What-If Simulator</h5>
                    <p className="text-slate-600 text-[11px]">
                      Adjust compensation disbursement from 40% to 80% or simulate vacating court stays to see exact predicted delay reduction.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-white border border-slate-200 rounded-xl">
                  <div className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    4
                  </div>
                  <div className="space-y-0.5">
                    <h5 className="font-bold text-slate-900">Execute Field &amp; Legal Interventions</h5>
                    <p className="text-slate-600 text-[11px]">
                      Convene District Revenue Coordination Meetings, disburse pending Section 3H awards, or instruct Government Pleader to file counter-affidavits.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-white border border-slate-200 rounded-xl">
                  <div className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    5
                  </div>
                  <div className="space-y-0.5">
                    <h5 className="font-bold text-slate-900">Record Progress &amp; Audit Trail</h5>
                    <p className="text-slate-600 text-[11px]">
                      Update milestone progress and verify authoritative BhoomiRashi e-Gazette synchronizations in the Data Hub.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: STATUTORY SECTIONS */}
          {activeTab === 'statute' && (
            <div className="space-y-3">
              <p className="text-slate-600 leading-relaxed">
                Land acquisition for National Highways is governed by the <strong>National Highways Act, 1956</strong> as amended by the RFCTLARR Act, 2013:
              </p>

              <div className="space-y-2.5">
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">Section 3A — Preliminary Notification (Power to Acquire)</span>
                    <span className="font-mono text-[10.5px] bg-slate-200 px-1.5 py-0.5 rounded text-slate-700">Notice</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed text-[11.5px]">
                    Central Government declares its intention to acquire specified land parcels. Landowners may submit objections to the Competent Authority (CALA) within 21 days under Section 3C.
                    <br /><strong className="text-red-700">Statutory Guardrail:</strong> Section 3D must be issued within 365 days of Section 3A, otherwise the entire acquisition lapses.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">Section 3D — Declaration of Acquisition (Absolute Vesting)</span>
                    <span className="font-mono text-[10.5px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded">Vesting</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed text-[11.5px]">
                    Published in the Official Gazette after hearing objections. Upon publication of 3D, the land vests absolutely in the Central Government free from all encumbrances.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">Section 3G — Determination of Compensation Award</span>
                    <span className="font-mono text-[10.5px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">Award</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed text-[11.5px]">
                    The CALA determines the compensation award based on market value, 100% solatium, and additional statutory allowances under the First and Second Schedules of RFCTLARR Act 2013.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">Section 3H &amp; 3E — Deposit, Payment &amp; Physical Possession</span>
                    <span className="font-mono text-[10.5px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">Handover</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed text-[11.5px]">
                    NHAI deposits the awarded compensation into the CALA escrow account for disbursement to Khatadars. Notice under Section 3E grants 60 days to surrender physical possession of land.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: V1 VS V2 MODELS */}
          {activeTab === 'models' && (
            <div className="space-y-4">
              <div className="bg-amber-50/70 p-4 rounded-xl border border-amber-200 space-y-1.5">
                <span className="font-bold text-amber-950 uppercase tracking-wider text-[11px]">
                  Demystifying Models for Government Officials
                </span>
                <p className="text-amber-900 font-semibold text-xs">
                  Why are there two models, and which one is legally authoritative?
                </p>
                <p className="text-slate-600 text-[11.5px] leading-relaxed">
                  BHOOMI-DRISHTI maintains strict separation between operational decision support and experimental testing:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="p-4 bg-white border-2 border-emerald-300 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                      OFFICIAL PRODUCTION MODEL (V1)
                    </span>
                    <span className="text-[10px] text-emerald-700 font-bold">Active</span>
                  </div>
                  <h5 className="font-bold text-slate-900 text-sm">BHOOMI-DRISHTI-ML-V1.0</h5>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    <strong>Sole Operational System:</strong> This is the legally binding decision-support model currently calculating all risk scores, delay probabilities, and executive alerts.
                  </p>
                  <div className="text-[10.5px] text-slate-500 space-y-0.5 pt-1 border-t border-slate-100 font-mono">
                    <div>Features: 6 core statutory inputs</div>
                    <div>Trained: 2,871 historical records</div>
                    <div>SHA-256: 7e0e1a...307f (Immutable)</div>
                  </div>
                </div>

                <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                      CANDIDATE MODEL (V2 - SHADOW)
                    </span>
                    <span className="text-[10px] text-slate-500 font-bold">Internal Only</span>
                  </div>
                  <h5 className="font-bold text-slate-900 text-sm">BHOOMI-DRISHTI-ML-V2.0-SHADOW</h5>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    <strong>Strictly Non-Operational:</strong> Runs in the background solely for research and statistical comparison. Has <strong>zero operational authority</strong> and does not change risk scores.
                  </p>
                  <div className="text-[10.5px] text-slate-500 space-y-0.5 pt-1 border-t border-slate-100 font-mono">
                    <div>Features: 10 longitudinal features</div>
                    <div>Status: SHADOW_CANDIDATE</div>
                    <div>Thresholds: Pending Approval</div>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11.5px] text-slate-700 space-y-1">
                <span className="font-bold text-slate-900">Why do predictions differ between V1 and V2?</span>
                <p className="text-slate-600 leading-relaxed">
                  Candidate V2 evaluates temporal velocity (e.g. rate of transition from Section 3D to 3G) and granular Tehsil dispute densities. Until V2 completes statutory shadow observation and receives MoRTH/NHAI Competent Authority sign-off, all administrative decisions must rely strictly on V1.
                </p>
              </div>
            </div>
          )}

          {/* TAB 5: PLAIN GLOSSARY */}
          {activeTab === 'glossary' && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                  <span className="font-bold text-slate-900">Delay Risk Level (Low / Medium / High)</span>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    <strong>Low (&lt; 35%):</strong> Project proceeding on schedule.<br />
                    <strong>Medium (35%–69.9%):</strong> Approaching statutory milestone limits.<br />
                    <strong>High (≥ 70%):</strong> Severe disruption (e.g. court stay, &lt;60% compensation).
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                  <span className="font-bold text-slate-900">Data Distribution Shift (PSI)</span>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    Measures whether current corridor data patterns match the historical training baseline. Normal range is &lt; 0.20 (values &lt; 0.10 indicate high stability).
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                  <span className="font-bold text-slate-900">Distribution Divergence (KS Statistic)</span>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    Compares candidate model prediction spreads against expected historical distributions. Target: &lt; 0.15 indicates candidate predictions are well-behaved.
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                  <span className="font-bold text-slate-900">Prediction Accuracy Index (Brier Score)</span>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    Calibrated forecast accuracy score between 0 and 1. Closer to 0 is better (e.g., 0.118 represents high calibration and accuracy).
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                  <span className="font-bold text-slate-900">CALA</span>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    Competent Authority for Land Acquisition, appointed by Central Government (typically SDM, Additional Collector, or District Revenue Officer).
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                  <span className="font-bold text-slate-900">Solatium</span>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    Mandatory 100% additional compensation on the market value of land awarded to land losers under the RFCTLARR Act, 2013 for compulsory acquisition.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: ROLES */}
          {activeTab === 'roles' && (
            <div className="space-y-3">
              <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl space-y-1">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-600" />
                  <span className="font-bold text-amber-950">Nodal Officer (CALA Administrative Officer)</span>
                </div>
                <p className="text-amber-900/90 text-[11.5px] leading-relaxed">
                  Full statutory operational authority: registering new highway corridor packages, updating acquisition milestone progress, initiating e-Gazette sync, and modifying land records.
                </p>
              </div>

              <div className="p-3.5 bg-sky-50/70 border border-sky-200 rounded-xl space-y-1">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-sky-600" />
                  <span className="font-bold text-sky-950">Project Auditor &amp; Public Official (VIEWER)</span>
                </div>
                <p className="text-sky-900/90 text-[11.5px] leading-relaxed">
                  Read-only oversight access: inspecting real-time predictive analytics, reviewing immutable audit trails, tracking national risk distributions, and running what-if policy simulations.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-400">BHOOMI-DRISHTI • MoRTH Institutional Platform</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold tracking-wide transition-colors cursor-pointer"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
