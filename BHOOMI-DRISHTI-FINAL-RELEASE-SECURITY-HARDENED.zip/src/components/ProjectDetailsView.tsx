import React, { useState, useEffect } from 'react';
import { Project, WhatIfResponse, ProjectHistoryItem, RiskLevel } from '../types.ts';
import { RiskBadge, DataSourceBadge, StageStatusBadge } from './StatusBadge.tsx';
import { api } from '../services/apiClient.ts';
import { ModelExplanationModal } from './ModelExplanationModal.tsx';
import { ProjectFormModal } from './ProjectFormModal.tsx';
import { InfoTooltip } from './common/InfoTooltip.tsx';
import {
  ArrowLeft,
  MapPin,
  Building2,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Clock,
  SlidersHorizontal,
  Landmark,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  FileText,
  ExternalLink,
  History,
  Scale,
  Cpu,
  Layers,
  Sparkles,
  TreePine,
  IndianRupee,
  RotateCcw,
  Play,
  Check,
  AlertTriangle,
  ShieldAlert,
  Activity,
  Edit,
  Database
} from 'lucide-react';

interface ProjectDetailsViewProps {
  project: Project;
  onBack: () => void;
  onNavigateToWhatIf?: (projectId: string) => void;
  userRole?: 'NODAL_OFFICER' | 'VIEWER';
  onProjectUpdated?: (updated: Project) => void;
}

export const ProjectDetailsView: React.FC<ProjectDetailsViewProps> = ({
  project: initialProject,
  onBack,
  onNavigateToWhatIf,
  userRole = 'VIEWER',
  onProjectUpdated
}) => {
  const [project, setProject] = useState<Project>(initialProject);
  const [activeTab, setActiveTab] = useState<'overview' | 'timeline' | 'risk' | 'whatif' | 'lineage' | 'shadow'>('overview');
  const [modelModalOpen, setModelModalOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [verifyRefInput, setVerifyRefInput] = useState('');
  const [verifyLoading, setVerifyLoading] = useState(false);
  const [verifyError, setVerifyError] = useState<string | null>(null);
  const [verifySuccess, setVerifySuccess] = useState<string | null>(null);
  const [history, setHistory] = useState<ProjectHistoryItem[]>([]);
  const [dataHubProject, setDataHubProject] = useState<any>(null);
  const [shadowDiag, setShadowDiag] = useState<any>(null);
  const [shadowLoading, setShadowLoading] = useState<boolean>(false);

  // Sync internal state if initialProject prop changes
  useEffect(() => {
    setProject(initialProject);
  }, [initialProject]);

  const isNodal = userRole === 'NODAL_OFFICER';

  // Embedded What-If state for this specific project
  const [simCompensation, setSimCompensation] = useState<number>(project.compensationDisbursedPercent);
  const [simHasStay, setSimHasStay] = useState<boolean>(project.hasCourtStay);
  const [simDocCount, setSimDocCount] = useState<number>(project.incompleteDocumentsCount);
  const [simLegalCases, setSimLegalCases] = useState<number>(project.unresolvedLegalCases);
  const [simForestStage, setSimForestStage] = useState<string>(project.forestClearanceStage);
  const [simLoading, setSimLoading] = useState<boolean>(false);
  const [simResult, setSimResult] = useState<WhatIfResponse | null>(null);
  const [simError, setSimError] = useState<string | null>(null);

  // Progressive Disclosure states for Risk & Explainability (Section 14 & 15)
  const [showRiskFactors, setShowRiskFactors] = useState<boolean>(true);
  const [expandedFactor, setExpandedFactor] = useState<number | null>(null);

  // Authoritative real-time ML prediction for project details
  const [liveMlPrediction, setLiveMlPrediction] = useState<any>(project.mlPrediction || null);

  const sourcePId =
    project.sourceProjectId ||
    (project.id.startsWith('BhoomiRashi_') ? project.id.replace('BhoomiRashi_', '') : project.id);

  useEffect(() => {
    api.getProjectHistory(project.id).then(setHistory).catch(() => {});
    if (sourcePId) {
      api.datahub.getProjectById(sourcePId).then(setDataHubProject).catch(() => {});
    }

    if (!liveMlPrediction) {
      api.ml.predict({ projectId: project.id })
        .then(res => {
          if (res.success && res.prediction) {
            setLiveMlPrediction(res);
          }
        })
        .catch(err => console.warn('[ProjectDetailsView] ML prediction fetch warning:', err));
    }

    setShadowLoading(true);
    api.shadow.getProjectShadowDiagnostic(project.id)
      .then(res => setShadowDiag(res))
      .catch(err => {
        console.warn('[ProjectDetailsView] Shadow diagnostic fetch warning:', err);
        setShadowDiag(null);
      })
      .finally(() => setShadowLoading(false));
  }, [project.id, sourcePId]);

  const displayDelayProbability = liveMlPrediction?.prediction?.delay_probability !== undefined
    ? Math.round(liveMlPrediction.prediction.delay_probability * 1000) / 10
    : project.delayProbability;

  const displayRiskLevel: RiskLevel = liveMlPrediction?.prediction?.risk_level || project.riskLevel;

  // Derived land metrics
  const totalRequired = project.totalLandRequiredHa || 200;
  const acquiredTillNow = project.landAcquiredHa || 0;
  const toBeAcquired = project.pendingLandHa || Math.max(0, totalRequired - acquiredTillNow);
  const progressPct = totalRequired > 0 ? Math.min(100, Math.round((acquiredTillNow / totalRequired) * 100)) : 0;

  const handleRunSimulation = async () => {
    setSimLoading(true);
    setSimError(null);
    try {
      const res = await api.runWhatIf({
        projectId: project.id,
        compensationDisbursedPercent: Number(simCompensation),
        hasCourtStay: simHasStay,
        unresolvedLegalCases: Number(simLegalCases),
        incompleteDocumentsCount: Number(simDocCount),
        forestClearanceStage: simForestStage
      });
      if (res && res.success === false) {
        setSimError(res.error || 'Simulation calculation could not be completed.');
        setSimResult(null);
      } else {
        setSimResult(res);
        setSimError(null);
      }
    } catch (err: any) {
      console.error('Simulation error:', err);
      setSimError(err.message || 'Unable to execute scenario simulation on backend.');
      setSimResult(null);
    } finally {
      setSimLoading(false);
    }
  };

  const handleResetSimulation = () => {
    setSimCompensation(project.compensationDisbursedPercent);
    setSimHasStay(project.hasCourtStay);
    setSimDocCount(project.incompleteDocumentsCount);
    setSimLegalCases(project.unresolvedLegalCases);
    setSimForestStage(project.forestClearanceStage);
    setSimResult(null);
    setSimError(null);
  };

  const handleVerifySource = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyRefInput.trim()) {
      setVerifyError('Authoritative source reference is required.');
      return;
    }
    setVerifyLoading(true);
    setVerifyError(null);
    setVerifySuccess(null);
    try {
      const res = await api.verifyProject(project.id, verifyRefInput.trim());
      if (res.success && res.project) {
        setProject(res.project);
        if (onProjectUpdated) onProjectUpdated(res.project);
        setVerifySuccess('Project successfully verified against authoritative source reference.');
        setVerifyRefInput('');
      } else {
        setVerifyError('Verification failed.');
      }
    } catch (err: any) {
      setVerifyError(err.message || 'Verification error');
    } finally {
      setVerifyLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-14">
      {/* Back Button & Top Actions */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors py-1 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Projects Directory</span>
        </button>

        {isNodal ? (
          <button
            onClick={() => setEditModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg font-bold text-xs shadow-xs transition-colors cursor-pointer"
          >
            <Edit className="w-3.5 h-3.5" />
            <span>Edit Package</span>
          </button>
        ) : (
          <div
            className="px-3 py-1.5 bg-slate-100 text-slate-400 rounded-lg text-xs font-medium border border-slate-200 cursor-not-allowed"
            title="Read-only view. Nodal Officer authority required to edit package details."
          >
            Read-Only (Viewer Role)
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 1. TOP HERO BANNER                                                        */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div className="space-y-2 max-w-3xl">
            {/* Top ID & Badges line */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono text-xs font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                Package ID: {sourcePId}
              </span>
              <DataSourceBadge source={project.source} source_type={project.source_type} isSynthetic={project.isSynthetic} />
              {project.verification_status === 'VERIFIED' ? (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-300">
                  Authoritative Verified
                </span>
              ) : (
                <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                  Unverified Lineage
                </span>
              )}
              <StageStatusBadge status={project.stageStatus} />
              {project.highwayNumber && (
                <span className="text-xs px-2 py-0.5 rounded font-semibold bg-blue-50 text-blue-800 border border-blue-200">
                  Corridor: {project.highwayNumber}
                </span>
              )}
            </div>

            {/* Official Project Title */}
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight leading-snug">
              {project.name}
            </h1>

            {/* Subtitle: Project Number • Location • Implementing Agency */}
            <div className="flex items-center gap-2 text-xs text-slate-600 flex-wrap font-medium">
              <span className="text-slate-900 font-semibold">
                Project No: {project.sourceProjectId ? `NI/2023/${project.sourceProjectId}` : project.id}
              </span>
              <span className="text-slate-300">•</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {project.district}, {project.state}
              </span>
              <span className="text-slate-300">•</span>
              <span className="flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5 text-slate-400" />
                {project.agency || 'NHAI / MoRTH'}
              </span>
            </div>
          </div>

          {/* Right Side: Last Synced & External BhoomiRashi Link */}
          <div className="text-left md:text-right shrink-0 space-y-2 border-t md:border-t-0 pt-3 md:pt-0 border-slate-100">
            <div className="text-xs text-slate-500">
              <span className="block text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                Statutory Data Synchronization
              </span>
              <span className="font-semibold text-slate-800">
                {project.lastUpdated || 'Live Hash Verified'}
              </span>
            </div>

            {project.sourceUrl && (
              <a
                href={project.sourceUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-2.5 py-1.5 rounded-md border border-blue-200 transition-colors"
                title="Open authentic BhoomiRashi record on MoRTH official portal"
              >
                <span>View on BhoomiRashi</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. IMMEDIATE KEY INDICATORS (Section 13 & 14)                            */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-center divide-y sm:divide-y-0 sm:divide-x divide-slate-100">
          {/* 1. Risk & Delay Probability */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                Statutory Delay Risk
              </span>
              <RiskBadge level={project.riskLevel} />
            </div>
            <div className="flex items-baseline gap-2">
              <span className={`text-3xl font-extrabold font-mono ${
                project.riskLevel === 'HIGH' ? 'text-red-700' : project.riskLevel === 'MEDIUM' ? 'text-amber-700' : 'text-emerald-700'
              }`}>
                {project.delayProbability}%
              </span>
              <span className="text-xs font-semibold text-slate-500">Probability</span>
              <InfoTooltip
                title="Delay Probability"
                content="Forecasted probability that physical possession will exceed target gazette schedule based on statutory velocity."
              />
            </div>
            <div className="text-xs font-medium text-slate-700">
              {project.riskLevel === 'HIGH'
                ? 'Immediate review recommended.'
                : project.riskLevel === 'MEDIUM'
                ? 'Moderate variance — monitoring recommended.'
                : 'Acquisition progressing on schedule.'}
            </div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500 pt-1">
              <span className="bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 font-semibold">
                Model: BHOOMI-DRISHTI-ML-V1.0
              </span>
              <span className="bg-amber-50 text-amber-900 border border-amber-300 px-1.5 py-0.5 rounded font-bold">
                EXPERIMENTAL
              </span>
            </div>
          </div>

          {/* 2. Land Acquisition Progress */}
          <div className="space-y-1.5 sm:pl-4 pt-3 sm:pt-0">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
              <span>Land Progress</span>
              <span className="font-mono text-slate-700 font-bold">{progressPct}%</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold font-mono text-slate-900">{acquiredTillNow}</span>
              <span className="text-xs text-slate-400">/ {totalRequired} Ha</span>
            </div>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  progressPct >= 75 ? 'bg-emerald-600' : progressPct >= 30 ? 'bg-blue-600' : 'bg-amber-500'
                }`}
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <span className="text-[11px] text-slate-500 block">
              {toBeAcquired} Ha pending under 3D/3G
            </span>
          </div>

          {/* 3. Estimated Delay Variance */}
          <div className="space-y-1.5 sm:pl-4 pt-3 sm:pt-0">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block">
              Forecasted Delay
            </span>
            <div className="text-2xl font-bold font-mono text-slate-800">
              +{project.delayVarianceMonths} <span className="text-xs font-normal text-slate-500">months</span>
            </div>
            <p className="text-xs text-slate-500">
              Statutory schedule variance based on User velocity
            </p>
          </div>

          {/* 4. Judicial & Environmental Status */}
          <div className="space-y-1.5 sm:pl-4 pt-3 sm:pt-0">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block">
              Clearance Status
            </span>
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800">
                <Scale className={`w-3.5 h-3.5 ${project.hasCourtStay ? 'text-red-600' : 'text-emerald-600'}`} />
                <span>{project.hasCourtStay ? 'Court Stay Active' : 'Clean Title / No Stays'}</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-600">
                <TreePine className="w-3.5 h-3.5 text-slate-400" />
                <span className="truncate">{project.forestClearanceStage || 'Forest: Clear'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Explainability Toggle Button */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span className="font-semibold text-slate-800">Key Delay Factors Identified:</span>
            <span>{project.topRiskFactors?.length || 4} contributing operational factors</span>
          </div>

          <button
            onClick={() => setShowRiskFactors(!showRiskFactors)}
            className="px-3 py-1 text-xs font-semibold text-blue-900 hover:text-blue-950 bg-blue-50 hover:bg-blue-100 rounded-md border border-blue-200 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span>{showRiskFactors ? 'Hide Risk Factors ▲' : 'View Risk Factors ▼'}</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* EXPLAINABILITY CARD (Section 15): WHY IS THIS PROJECT HIGH RISK?           */}
      {/* ========================================================================= */}
      {showRiskFactors && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900 tracking-tight uppercase">
                Why is this project {project.riskLevel} risk?
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Primary statutory bottlenecks causing predicted schedule slippage
              </p>
            </div>
            <span className="text-[11px] font-mono text-slate-400 font-medium">
              ML Attribution Engine
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Factor 1: Compensation Lag */}
            <div
              onClick={() => setExpandedFactor(expandedFactor === 1 ? null : 1)}
              className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <IndianRupee className="w-3.5 h-3.5 text-amber-600" />
                  1. Compensation Lag
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  {expandedFactor === 1 ? '▲' : '▼'}
                </span>
              </div>
              <div className="text-xs font-bold text-amber-800">
                {100 - project.compensationDisbursedPercent}% remains undisbursed
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Only {project.compensationDisbursedPercent}% of ₹{project.compensationSanctionedCr} Cr disbursed to land owners.
              </p>
              {expandedFactor === 1 && (
                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-600 space-y-1">
                  <div>• Pending cases: {project.pendingCompensationCases || 12} awards</div>
                  <div>• Deposit balance: ₹{((project.compensationSanctionedCr || 10) * (1 - project.compensationDisbursedPercent / 100)).toFixed(2)} Cr in escrow</div>
                </div>
              )}
            </div>

            {/* Factor 2: Clearance Pending */}
            <div
              onClick={() => setExpandedFactor(expandedFactor === 2 ? null : 2)}
              className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <TreePine className="w-3.5 h-3.5 text-emerald-700" />
                  2. Clearance Pending
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  {expandedFactor === 2 ? '▲' : '▼'}
                </span>
              </div>
              <div className="text-xs font-bold text-slate-800 truncate">
                {project.forestClearanceStage || 'Stage 2 approval pending'}
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                {project.forestLandHa || 12.4} Ha of forest land pending final handover by MoEFCC.
              </p>
              {expandedFactor === 2 && (
                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-600 space-y-1">
                  <div>• Compensatory afforestation site identified</div>
                  <div>• State advisory committee review awaited</div>
                </div>
              )}
            </div>

            {/* Factor 3: Mutation Backlog */}
            <div
              onClick={() => setExpandedFactor(expandedFactor === 3 ? null : 3)}
              className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-blue-600" />
                  3. Mutation Backlog
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  {expandedFactor === 3 ? '▲' : '▼'}
                </span>
              </div>
              <div className="text-xs font-bold text-slate-800">
                {project.incompleteDocumentsCount || 18} records pending
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Title deeds & revenue khata mutations pending clearance at Tehsil revenue office.
              </p>
              {expandedFactor === 3 && (
                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-600 space-y-1">
                  <div>• Revenue division: {project.district} Tehsil</div>
                  <div>• Succession certificates pending with Patwari</div>
                </div>
              )}
            </div>

            {/* Factor 4: Reference Litigation */}
            <div
              onClick={() => setExpandedFactor(expandedFactor === 4 ? null : 4)}
              className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Scale className="w-3.5 h-3.5 text-red-600" />
                  4. Reference Litigation
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  {expandedFactor === 4 ? '▲' : '▼'}
                </span>
              </div>
              <div className="text-xs font-bold text-red-800">
                {project.hasCourtStay ? 'Active Court Injunction' : `${project.unresolvedLegalCases || 4} cases pending`}
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed truncate">
                {project.courtDetails || 'Section 3G compensation determination challenges pending at High Court.'}
              </p>
              {expandedFactor === 4 && (
                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-600 space-y-1">
                  <div>• Forum: High Court appellate division</div>
                  <div>• Government counsel instruction: Application for early hearing filed</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. 4-TAB EXECUTIVE NAVIGATION                                              */}
      {/* ========================================================================= */}
      <div className="border-b border-slate-200">
        <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto pb-0.5">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'overview'
                ? 'border-blue-900 text-blue-950 bg-blue-50/50 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Overview & Breakdown
          </button>
          <button
            onClick={() => setActiveTab('timeline')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'timeline'
                ? 'border-blue-900 text-blue-950 bg-blue-50/50 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Statutory Timeline (3A → 3D → 3G)
          </button>
          <button
            onClick={() => setActiveTab('risk')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'risk'
                ? 'border-blue-900 text-blue-950 bg-blue-50/50 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Risk & Explainability
          </button>
          <button
            onClick={() => setActiveTab('whatif')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'whatif'
                ? 'border-blue-900 text-blue-950 bg-blue-50/50 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-blue-700" />
            <span>What-If Simulation</span>
          </button>
          <button
            onClick={() => setActiveTab('lineage')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'lineage'
                ? 'border-blue-900 text-blue-950 bg-blue-50/50 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-blue-700" />
            <span>Data Lineage & Provenance</span>
          </button>
          <button
            onClick={() => setActiveTab('shadow')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'shadow'
                ? 'border-indigo-900 text-indigo-950 bg-indigo-50/50 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-700" />
            <span>Shadow V2 Diagnostics & Statutory Lineage</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: OVERVIEW — STRUCTURED SECTIONS 1 TO 5                              */}
      {/* ========================================================================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Section 1 — Project Overview */}
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <div className="text-[10px] font-bold uppercase tracking-wider text-blue-900">Section 1</div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-slate-600" />
                  <span>Project Overview & Administrative Hierarchy</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">Jurisdictional authority, corridor identification, and statutory declarations</p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-slate-400 font-medium">Project ID</span>
                  <div className="font-bold text-slate-900 font-mono">{project.sourceProjectId || project.id}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-slate-400 font-medium">Implementing Agency</span>
                  <div className="font-bold text-slate-900">{project.agency || 'NHAI / MoRTH'}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-slate-400 font-medium">Highway / Corridor</span>
                  <div className="font-bold text-slate-900">{project.highwayNumber || 'National Highway Corridor'}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-slate-400 font-medium">State & District</span>
                  <div className="font-bold text-slate-900">{project.district}, {project.state}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-slate-400 font-medium">Taluk / Tehsil</span>
                  <div className="font-bold text-slate-900">{project.talukOrTehsil || `${project.district} Tehsil`}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-slate-400 font-medium">Current Milestone Stage</span>
                  <div className="font-bold text-blue-900 flex items-center gap-1.5">
                    <span>{project.currentStage}</span>
                    <StageStatusBadge status={project.stageStatus} />
                  </div>
                </div>
              </div>
            </div>

            {/* Section 2 — Acquisition Progress */}
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">Section 2</div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Layers className="w-4 h-4 text-slate-600" />
                  <span>Acquisition Progress & Land Balance</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">Physical land possession vs statutory requirement</p>
              </div>

              {/* Progress Bar Visualizer */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-700">Land Acquired: {acquiredTillNow} / {totalRequired} Ha</span>
                  <span className="text-emerald-700 font-mono font-bold">{progressPct}%</span>
                </div>
                <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-600 rounded-full transition-all duration-500"
                    style={{ width: `${progressPct}%` }}
                  />
                </div>
              </div>

              {/* Land Metrics Grid */}
              <div className="grid grid-cols-3 gap-2.5 text-xs pt-1">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-0.5">
                  <span className="text-slate-500 text-[11px] font-medium">Land Required</span>
                  <div className="font-bold text-slate-900 font-mono text-sm">
                    {totalRequired} Ha
                  </div>
                  <span className="text-[10px] text-slate-400">Total gazetted</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-0.5">
                  <span className="text-slate-500 text-[11px] font-medium">Land Acquired</span>
                  <div className="font-bold text-emerald-800 font-mono text-sm">
                    {acquiredTillNow} Ha
                  </div>
                  <span className="text-[10px] text-emerald-600 font-medium">Vested under 3D</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-0.5">
                  <span className="text-slate-500 text-[11px] font-medium">Pending Land</span>
                  <div className="font-bold text-amber-800 font-mono text-sm">
                    {toBeAcquired} Ha
                  </div>
                  <span className="text-[10px] text-amber-700 font-medium">Balance for 3G</span>
                </div>
              </div>
            </div>
          </div>

          {/* Section 3 & Section 4 Row */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Section 3 — Compensation */}
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <div className="text-[10px] font-bold uppercase tracking-wider text-amber-800">Section 3</div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <IndianRupee className="w-4 h-4 text-slate-600" />
                  <span>Compensation & Disbursement Status</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">Statutory award deposits and beneficiary bank disbursal</p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
                  <span className="text-slate-500 font-medium">Compensation Sanctioned</span>
                  <div className="text-sm font-bold text-slate-900 font-mono">
                    {project.compensationSanctionedCr && project.compensationSanctionedCr > 0
                      ? `₹${project.compensationSanctionedCr} Cr`
                      : 'Not available'}
                  </div>
                  <p className="text-[10.5px] text-slate-400">Approved award determination</p>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
                  <span className="text-slate-500 font-medium">Compensation Disbursed</span>
                  <div className="text-sm font-bold text-slate-900 font-mono">
                    {project.compensationDisbursedCr && project.compensationDisbursedCr > 0
                      ? `₹${project.compensationDisbursedCr} Cr`
                      : 'Not available'}
                  </div>
                  <p className="text-[10.5px] text-slate-400">Credited to Khatadars</p>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
                  <span className="text-slate-500 font-medium">Disbursement Percentage</span>
                  <div className="text-sm font-bold text-blue-900 font-mono">
                    {project.compensationDisbursedPercent !== undefined && project.compensationDisbursedPercent !== null
                      ? `${project.compensationDisbursedPercent}%`
                      : 'Not available'}
                  </div>
                  <p className="text-[10.5px] text-slate-400">Disbursed vs Sanctioned</p>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
                  <span className="text-slate-500 font-medium">Pending Compensation Claims</span>
                  <div className="text-sm font-bold text-slate-900 font-mono">
                    {project.pendingCompensationCases !== undefined
                      ? `${project.pendingCompensationCases} claims`
                      : 'Not available'}
                  </div>
                  <p className="text-[10.5px] text-slate-400">Awaiting User signoff</p>
                </div>
              </div>
            </div>

            {/* Section 4 — Legal / Documentation */}
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <div className="text-[10px] font-bold uppercase tracking-wider text-rose-800">Section 4</div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Scale className="w-4 h-4 text-slate-600" />
                  <span>Legal & Regulatory Documentation Clearance</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">Judicial stays, litigation disputes, mutation records, and environmental clearance</p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                {/* Active Court Stays */}
                <div className={`p-3 rounded-lg border space-y-1 ${
                  project.hasCourtStay
                    ? 'bg-red-50 border-red-200 text-red-900'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                }`}>
                  <span className="font-bold text-[11px] uppercase tracking-wide block">
                    Active Court Stays
                  </span>
                  <div className="text-sm font-extrabold flex items-center gap-1.5">
                    <Scale className="w-3.5 h-3.5" />
                    <span>{project.hasCourtStay ? 'Active Injunction' : 'None / Clean Title'}</span>
                  </div>
                  <p className="text-[10.5px] opacity-90 line-clamp-2">
                    {project.hasCourtStay
                      ? (project.courtDetails || 'High Court interlocutory stay order active.')
                      : 'Limitation period cleared without injunction.'}
                  </p>
                </div>

                {/* Unresolved Cases */}
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
                  <span className="text-slate-500 font-medium">Unresolved Legal Cases</span>
                  <div className="text-sm font-bold text-slate-900 font-mono">
                    {project.unresolvedLegalCases} cases
                  </div>
                  <p className="text-[10.5px] text-slate-400">Title references & appeals</p>
                </div>

                {/* Incomplete Documents */}
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
                  <span className="text-slate-500 font-medium">Incomplete Documents Backlog</span>
                  <div className="text-sm font-bold text-slate-900 font-mono">
                    {project.incompleteDocumentsCount} records
                  </div>
                  <p className="text-[10.5px] text-slate-400">Revenue mutation / Khata</p>
                </div>

                {/* Forest Clearance */}
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
                  <span className="text-slate-500 font-medium">Forest Clearance Stage</span>
                  <div className="text-sm font-bold text-slate-900 font-mono">
                    {project.forestClearanceStage || 'Not Required'}
                  </div>
                  <p className="text-[10.5px] text-slate-400">MoEFCC statutory status</p>
                </div>
              </div>
            </div>
          </div>

          {/* Section 5 — ML Delay Risk Prediction & Model Transparency */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-purple-900">Section 5</div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#1E3A5F]" />
                  <span>Machine Learning Delay Risk Prediction</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Supervised Random Forest risk estimation with explainable feature weights
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono bg-slate-100 border border-slate-200 px-2 py-1 rounded text-slate-700 font-semibold">
                  Model: BHOOMI-DRISHTI-ML-V1.0
                </span>
                <span className="text-xs font-bold bg-amber-50 text-amber-900 border border-amber-300 px-2 py-1 rounded">
                  Status: EXPERIMENTAL
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Delay Probability</span>
                <div className="text-2xl font-extrabold text-red-700 font-mono">
                  {project.delayProbability}%
                </div>
                <p className="text-[11px] text-slate-500">
                  Calibrated probability of exceeding statutory milestone schedule.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Assigned Risk Level</span>
                <div className="pt-1">
                  <RiskBadge level={project.riskLevel} />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Classification: LOW (&lt;35%), MEDIUM (35%–69.9%), HIGH (≥70%).
                </p>
              </div>

              <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-200 space-y-1">
                <span className="text-xs text-blue-900 font-semibold uppercase tracking-wider">Model Transparency Note</span>
                <p className="text-[11px] text-slate-700 leading-relaxed">
                  Delay probability is a model-derived risk estimate to support prioritization rather than replace official administrative decisions. It is not an absolute causal guarantee.
                </p>
              </div>
            </div>

            {/* Explainability factors */}
            <div className="pt-2 border-t border-slate-100 space-y-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Key Factors Influencing This Estimate (Ranked by Sensitivity)
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
                {project.topRiskFactors && project.topRiskFactors.length > 0 ? (
                  project.topRiskFactors.map((rf, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                      <div className="font-bold text-slate-900 text-[11.5px]">{idx + 1}. {rf.factor}</div>
                      <p className="text-[11px] text-slate-600 leading-relaxed">{rf.detail}</p>
                    </div>
                  ))
                ) : (
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 col-span-4 text-slate-500 text-xs">
                    Model sensitivity is primarily governed by compensation disbursement pace and court stay status.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Audit History Log if present */}
          {history.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
                <History className="w-4 h-4 text-slate-500" />
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">Audit & Revision Trail</h3>
              </div>
              <div className="divide-y divide-slate-100 text-xs">
                {history.slice(0, 4).map((h, i) => (
                  <div key={i} className="py-2.5 flex items-center justify-between gap-4">
                    <div>
                      <span className="font-semibold text-slate-800">{h.changeSummary}</span>
                      <span className="text-slate-400 block text-[11px]">Changed by {h.changedBy || 'Live Sync Collector'}</span>
                    </div>
                    <span className="text-slate-400 text-[11px] font-mono shrink-0">
                      {new Date(h.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: STATUTORY TIMELINE                                                 */}
      {/* ========================================================================= */}
      {activeTab === 'timeline' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              Vertical Statutory Acquisition Lifecycle
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Sequenced milestone flow under National Highways Act 1956 & RFCTLARR Act 2013
            </p>
          </div>

          <div className="relative pl-6 space-y-8 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
            {/* Stage 1: Section 3A */}
            <div className="relative flex items-start gap-4">
              <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] shadow-sm">
                <Check className="w-3 h-3" />
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 w-full text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">1. Intention to Acquire (Section 3A)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Completed
                  </span>
                </div>
                <p className="text-slate-600">Gazette S.O. 412(E) published in official Gazette of India and local vernacular dailies.</p>
                <div className="text-[11px] text-slate-600 font-mono pt-1">
                  Published:{' '}
                  {project.section_3a_date ? (
                    <span className={`font-bold px-1.5 py-0.5 rounded border ${
                      project.section_3a_source === 'GAZETTE_OFFICIAL' || project.verification_status === 'VERIFIED'
                        ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                        : 'bg-amber-50 text-amber-900 border-amber-200'
                    }`}>
                      {project.section_3a_date} ({
                        project.section_3a_source === 'GAZETTE_OFFICIAL' || project.verification_status === 'VERIFIED'
                          ? 'Official Gazette • Verified'
                          : 'Manually maintained / Unverified'
                      })
                    </span>
                  ) : (
                    <span className="text-slate-400 italic">
                      Unavailable / Not verified
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Stage 2: Section 3D */}
            <div className="relative flex items-start gap-4">
              <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] shadow-sm">
                <Check className="w-3 h-3" />
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 w-full text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">2. Declaration of Acquisition (Section 3D)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Completed
                  </span>
                </div>
                <p className="text-slate-600">Objections heard by User; land vested absolutely in Central Government free from encumbrances.</p>
                <div className="text-[11px] text-slate-500 font-mono pt-1">
                  Published:{' '}
                  {project.section3DDate ? (
                    <span className="font-bold text-slate-900">{project.section3DDate}</span>
                  ) : (
                    <span className="text-slate-400 italic">Unavailable / Not recorded</span>
                  )}
                </div>
              </div>
            </div>

            {/* Stage 3: Section 3G */}
            <div className="relative flex items-start gap-4">
              <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] shadow-sm ring-4 ring-blue-100 animate-pulse">
                <Clock className="w-3 h-3" />
              </div>
              <div className="bg-blue-50/50 border border-blue-200 rounded-lg p-4 w-full text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-blue-950 text-sm">3. Determination of Compensation (Section 3G)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800 border border-blue-300">
                    Active Stage
                  </span>
                </div>
                <p className="text-slate-700">User hearing compensation claims and determining market valuation under RFCTLARR principles.</p>
                <div className="text-[11px] text-blue-800 font-medium pt-1">
                  Active award claims: {project.pendingCompensationCases || 12} pending determination
                </div>
              </div>
            </div>

            {/* Stage 4: Compensation Deposit (Section 3H) */}
            <div className="relative flex items-start gap-4">
              <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-slate-300 text-slate-600 flex items-center justify-center text-[10px]">
                <Clock className="w-3 h-3" />
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 w-full text-xs space-y-1 opacity-80">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 text-sm">4. Deposit & Disbursement (Section 3H)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-300">
                    Pending Award
                  </span>
                </div>
                <p className="text-slate-600">Disbursement of approved compensation into Aadhaar-linked beneficiary bank accounts.</p>
              </div>
            </div>

            {/* Stage 5: Physical Possession (Section 3E) */}
            <div className="relative flex items-start gap-4">
              <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-slate-300 text-slate-600 flex items-center justify-center text-[10px]">
                <Clock className="w-3 h-3" />
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 w-full text-xs space-y-1 opacity-80">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 text-sm">5. Physical Possession & Right of Way (Section 3E)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-300">
                    Pending
                  </span>
                </div>
                <p className="text-slate-600">Handover of vacant land parcels to NHAI concessionaire for civil works mobilization.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: RISK & EXPLAINABILITY                                              */}
      {/* ========================================================================= */}
      {activeTab === 'risk' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-base font-bold text-slate-900 tracking-tight">
                  Delay Risk Assessment & Model Explainability
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Calibrated Random Forest model attributions and empirical delay drivers
                </p>
              </div>

              <button
                onClick={() => setModelModalOpen(true)}
                className="px-3 py-1.5 text-xs font-semibold text-blue-800 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>Technical Model Card ⓘ</span>
              </button>
            </div>

            {/* Top 3-5 Risk Drivers */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Top Empirical Risk Drivers (SHAP Attributions)
              </h3>
              {project.topRiskFactors && project.topRiskFactors.length > 0 ? (
                project.topRiskFactors.map((rf, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{rf.factor}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200">
                          HIGH SEVERITY
                        </span>
                      </div>
                      {rf.impactScore && (
                        <span className="font-mono text-slate-600 font-semibold">
                          Relative Impact: {rf.impactScore}%
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">{rf.detail}</p>
                  </div>
                ))
              ) : (
                <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 text-xs text-slate-600">
                  Default driver: Statutory timeline variance is driven by pending User award settlement.
                </div>
              )}
            </div>

            {/* Recommended Interventions */}
            <div className="pt-3 border-t border-slate-100 space-y-3">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Recommended Priority Interventions</span>
              </h3>
              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-lg bg-blue-50 border border-blue-200 text-blue-950 flex items-start gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0 mt-1.5" />
                  <div>
                    <strong>Expedite User Disbursement:</strong> Coordinate special camp with District Collector in {project.district} to accelerate Aadhaar-linked compensation deposits beyond the current {project.compensationDisbursedPercent}% level.
                  </div>
                </div>
                {project.hasCourtStay && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-950 flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-600 shrink-0 mt-1.5" />
                    <div>
                      <strong>Vacate Court Injunction:</strong> Instruct government standing counsel to file application for early hearing to vacate interlocutory stay on compensation award.
                    </div>
                  </div>
                )}
                <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-950 flex items-start gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0 mt-1.5" />
                  <div>
                    <strong>Resolve Revenue Mutation Backlog:</strong> Depute additional Patwaris to clear {project.incompleteDocumentsCount} pending land mutation documents.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: WHAT-IF SIMULATION (EMBEDDED)                                      */}
      {/* ========================================================================= */}
      {activeTab === 'whatif' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-blue-700" />
                <span>What-If Delay Mitigation Simulator</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Simulate executive interventions on this package and forecast model sensitivity interactively
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleResetSimulation}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Sliders</span>
              </button>
              <button
                onClick={handleRunSimulation}
                disabled={simLoading}
                className="px-4 py-1.5 text-xs font-bold text-white bg-blue-900 hover:bg-blue-950 rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{simLoading ? 'Simulating...' : 'Run Simulation'}</span>
              </button>
            </div>
          </div>

          {/* Simulator Controls & Output Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left 7 cols: Controls */}
            <div className="lg:col-span-7 space-y-4">
              {/* Slider 1: Compensation Disbursed */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                    <IndianRupee className="w-3.5 h-3.5 text-slate-500" />
                    Compensation Disbursement Speed
                  </span>
                  <span className="font-bold text-slate-900 font-mono bg-white px-2 py-0.5 rounded border border-slate-200">
                    {simCompensation}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  step={5}
                  value={simCompensation}
                  onChange={e => setSimCompensation(Number(e.target.value))}
                  className="w-full accent-blue-900 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Current: {project.compensationDisbursedPercent}%</span>
                  <span>Target: 100% (Full Award)</span>
                </div>
              </div>

              {/* Control 2: Judicial Court Stay Toggle */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="space-y-0.5">
                  <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                    <Scale className="w-3.5 h-3.5 text-slate-500" />
                    Active Judicial Stay / Injunction
                  </span>
                  <p className="text-[11px] text-slate-500">Toggle resolution of court stay on land acquisition</p>
                </div>
                <button
                  type="button"
                  onClick={() => setSimHasStay(!simHasStay)}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                    simHasStay ? 'bg-red-600' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                      simHasStay ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Slider 3: Incomplete Documents Backlog */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-slate-500" />
                    Pending Mutation Certificates
                  </span>
                  <span className="font-bold text-slate-900 font-mono bg-white px-2 py-0.5 rounded border border-slate-200">
                    {simDocCount} cases
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={50}
                  step={1}
                  value={simDocCount}
                  onChange={e => setSimDocCount(Number(e.target.value))}
                  className="w-full accent-blue-900 cursor-pointer"
                />
              </div>

              {/* Dropdown 4: Forest Clearance Stage */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                  <TreePine className="w-3.5 h-3.5 text-slate-500" />
                  Forest Land Clearance Stage
                </span>
                <select
                  value={simForestStage}
                  onChange={e => setSimForestStage(e.target.value)}
                  className="w-full text-xs font-medium bg-white border border-slate-200 rounded-lg p-2 text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                >
                  <option value="Approved">Stage 2 (Approved / Diversion Complete)</option>
                  <option value="In Progress">Stage 1 (In-Principle Sanctioned)</option>
                  <option value="Pending Submission">Pending Application Submission</option>
                  <option value="Not Required">Not Required (Zero Forest Area)</option>
                </select>
              </div>
            </div>

            {/* Right 5 cols: Comparison & Outcome Card (Section 16) */}
            <div className="lg:col-span-5 bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Simulation Outcome
                </h3>
                <span className="text-[10.5px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
                  BHOOMI-DRISHTI-ML-V1.0
                </span>
              </div>

              {/* Statutory Disclaimer (Section 16) */}
              <div className="p-3 rounded-lg bg-amber-50 border border-amber-200/90 text-xs text-amber-900 font-medium flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <div className="font-bold text-[11px] uppercase tracking-wide text-amber-800">
                    Statutory Notice
                  </div>
                  <div className="text-[11px] leading-relaxed">
                    Scenario analysis only. Model-derived estimate under hypothetical conditions, not a causal guarantee. In-memory simulation does not mutate official database records.
                  </div>
                </div>
              </div>

              {simError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-800 space-y-1">
                  <div className="font-bold flex items-center gap-1.5 text-red-900">
                    <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
                    Simulation Rejected
                  </div>
                  <div>{simError}</div>
                </div>
              )}

              {simResult ? (() => {
                const simRisk = simResult.simulatedRisk || simResult.scenarioRisk;
                const baselineProb = simResult.baseline?.delay_probability !== undefined
                  ? Math.round(simResult.baseline.delay_probability * 1000) / 10
                  : (simResult.currentRisk?.delayProbability ?? displayDelayProbability);
                const baselineRiskLevel: RiskLevel = simResult.baseline?.risk_level || displayRiskLevel;

                const scenarioProb = simResult.scenario?.delay_probability !== undefined
                  ? Math.round(simResult.scenario.delay_probability * 1000) / 10
                  : (simRisk?.delayProbability ?? 0);
                const scenarioRiskLevel: RiskLevel = simResult.scenario?.risk_level || simRisk?.riskLevel || 'LOW';

                const pctPointChange = simResult.change?.percentage_point_change !== undefined
                  ? simResult.change.percentage_point_change
                  : (simResult.riskChangePercentagePoints ?? Math.round((scenarioProb - baselineProb) * 10) / 10);

                const isImprovement = pctPointChange <= 0;
                const monthsRecovered = Math.round((project.delayVarianceMonths - (simRisk?.delayVarianceMonths ?? 0)) * 10) / 10;

                return (
                  <div className="space-y-4 animate-in fade-in duration-200">
                    {/* CURRENT vs SCENARIO comparison */}
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      {/* CURRENT */}
                      <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                        <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                          CURRENT BASELINE
                        </span>
                        <div className="text-slate-700">
                          Disbursement: <strong className="font-mono">{project.compensationDisbursedPercent}%</strong>
                        </div>
                        <div className="flex items-center gap-1.5 text-slate-700 pt-0.5">
                          <span>Risk:</span>
                          <strong className="font-mono text-slate-900">{baselineProb}%</strong>
                          <RiskBadge level={baselineRiskLevel} />
                        </div>
                      </div>

                      {/* SCENARIO */}
                      <div className="p-3 bg-white rounded-lg border border-blue-200 bg-blue-50/20 space-y-1">
                        <span className="text-[10px] uppercase font-bold text-blue-700 block tracking-wider">
                          HYPOTHETICAL
                        </span>
                        <div className="text-slate-700">
                          Disbursement: <strong className="font-mono text-blue-900">{simCompensation}%</strong>
                        </div>
                        <div className="flex items-center gap-1.5 text-slate-700 pt-0.5">
                          <span>Risk:</span>
                          <strong className="font-mono text-blue-950">{scenarioProb}%</strong>
                          <RiskBadge level={scenarioRiskLevel} />
                        </div>
                      </div>
                    </div>

                    {/* RESULT */}
                    <div className={`p-4 rounded-xl space-y-2 border ${
                      isImprovement ? 'bg-emerald-50 border-emerald-300' : 'bg-red-50 border-red-300'
                    }`}>
                      <div className="flex items-center justify-between">
                        <span className={`text-[11px] font-bold uppercase tracking-wider ${
                          isImprovement ? 'text-emerald-900' : 'text-red-900'
                        }`}>
                          SIMULATED OUTCOME
                        </span>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded border font-mono ${
                          isImprovement
                            ? 'text-emerald-700 bg-white border-emerald-200'
                            : 'text-red-700 bg-white border-red-200'
                        }`}>
                          Shift: {pctPointChange > 0 ? `+${pctPointChange}` : pctPointChange} percentage points
                        </span>
                      </div>

                      <div className="flex items-baseline gap-2">
                        <span className={`text-3xl font-extrabold font-mono ${
                          isImprovement ? 'text-emerald-700' : 'text-red-700'
                        }`}>
                          {scenarioProb}%
                        </span>
                        <span className={`text-xs font-semibold ${
                          isImprovement ? 'text-emerald-800' : 'text-red-800'
                        }`}>
                          Simulated Delay Risk
                        </span>
                      </div>

                      <p className={`text-[11px] leading-relaxed pt-1 border-t ${
                        isImprovement ? 'text-emerald-900 border-emerald-200/80' : 'text-red-900 border-red-200/80'
                      }`}>
                        {simResult.impactSummary ||
                          (monthsRecovered >= 0
                            ? `Interventions would recover approx ${monthsRecovered} months and de-escalate this project.`
                            : `Adverse scenario would increase estimated delay by approx ${Math.abs(monthsRecovered)} months.`)}
                      </p>
                    </div>
                  </div>
                );
              })() : (
                <div className="py-10 text-center space-y-2 text-slate-400 text-xs">
                  <SlidersHorizontal className="w-8 h-8 mx-auto text-slate-300" />
                  <p className="font-medium text-slate-600">Adjust the parameters on the left and click "Run Simulation".</p>
                  <p className="text-[11px]">The ML decision engine will compute the counterfactual delay curve.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: DATA LINEAGE & PROVENANCE (Phase 3C Part C & Part D)               */}
      {/* ========================================================================= */}
      {activeTab === 'lineage' && (
        <div className="space-y-6">
          {/* 1. Executive Provenance Summary Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Database className="w-4 h-4 text-blue-900" />
                  <span>Institutional Data Lineage & Source Provenance</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Cryptographic traceability and verifiable statutory origins for package fields
                </p>
              </div>

              <div className="flex items-center gap-2">
                <DataSourceBadge source={project.source} source_type={project.source_type} isSynthetic={project.isSynthetic} />
                <span className={`text-xs px-2.5 py-1 rounded-md font-bold border font-mono ${
                  project.verification_status === 'VERIFIED'
                    ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                    : 'bg-amber-50 text-amber-900 border-amber-300'
                }`}>
                  {project.verification_status === 'VERIFIED' ? '✓ VERIFIED' : '⚠ UNVERIFIED'}
                </span>
              </div>
            </div>

            {/* Lineage Metadata Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Classification
                </span>
                <div className="text-sm font-bold text-slate-900 font-mono">
                  {project.source_type || (project.isSynthetic ? 'SEEDED' : 'SEEDED')}
                </div>
                <p className="text-[11px] text-slate-500">
                  {project.source_type === 'VERIFIED_EXTERNAL'
                    ? 'MoRTH BhoomiRashi Live Sync'
                    : project.source_type === 'MANUALLY_MAINTAINED'
                    ? 'Nodal Officer Manual Maintenance'
                    : project.source_type === 'IMPORTED'
                    ? 'Ministry CSV Schedule Import'
                    : 'Seeded Multi-Corridor Benchmark'}
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Source Reference
                </span>
                <div className="text-xs font-bold text-slate-900 truncate" title={project.source_reference || 'N/A'}>
                  {project.source_reference || (project.source_type === 'VERIFIED_EXTERNAL' ? 'BhoomiRashi MoRTH Public Gazette Portal' : 'None Recorded')}
                </div>
                <p className="text-[11px] text-slate-500 font-mono">
                  Record ID: {project.source_record_id || project.sourceProjectId || project.id}
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Source Last Updated
                </span>
                <div className="text-xs font-bold text-slate-900 font-mono">
                  {project.source_updated_at || project.sourceLastUpdated || project.lastUpdated
                    ? new Date(project.source_updated_at || project.sourceLastUpdated || project.lastUpdated).toLocaleString('en-IN')
                    : 'Continuous'}
                </div>
                <p className="text-[11px] text-slate-500">Timestamp at source capture</p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Verification Timestamp
                </span>
                <div className="text-xs font-bold font-mono text-slate-900">
                  {project.verified_at
                    ? new Date(project.verified_at).toLocaleString('en-IN')
                    : 'Pending Official Verification'}
                </div>
                <p className="text-[11px] text-slate-500">
                  {project.verification_status === 'VERIFIED' ? 'Verified by Authorized Officer' : 'Audit Pending'}
                </p>
              </div>
            </div>
          </div>

          {/* 2. Field-by-Field Provenance Matrix */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight uppercase">
                  Field-Level Provenance & Authority Matrix
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Granular origins for statutory, spatial, and financial parameters (Zero synthetic fabrication)
                </p>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                Audit Standard 3C
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-slate-200 rounded-lg">
                <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase text-[10.5px]">
                  <tr>
                    <th className="py-2.5 px-3">Field Parameter</th>
                    <th className="py-2.5 px-3">Operational Value</th>
                    <th className="py-2.5 px-3">Sourced From</th>
                    <th className="py-2.5 px-3">Lineage Classification</th>
                    <th className="py-2.5 px-3">Verification State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {/* Field: Project Identity & Route */}
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">Project Identity & Location</td>
                    <td className="py-2.5 px-3 font-mono">{project.name} ({project.state})</td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {project.source_type === 'VERIFIED_EXTERNAL' ? 'MoRTH BhoomiRashi Registry' : project.source_type === 'MANUALLY_MAINTAINED' ? 'Nodal Officer Form Entry' : project.source_type === 'IMPORTED' ? 'Ministry CSV Upload' : 'Baseline Multi-Sector Seed'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {project.source_type || 'SEEDED'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        project.verification_status === 'VERIFIED' ? 'bg-emerald-50 text-emerald-800' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {project.verification_status || 'UNVERIFIED'}
                      </span>
                    </td>
                  </tr>

                  {/* Field: Current Stage */}
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">Current Acquisition Stage</td>
                    <td className="py-2.5 px-3 font-mono">{project.currentStage} ({project.stageStatus})</td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {project.source_type === 'VERIFIED_EXTERNAL' ? 'Gazette Stage Progression' : 'Administrative Milestone'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {project.source_type || 'SEEDED'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        project.verification_status === 'VERIFIED' ? 'bg-emerald-50 text-emerald-800' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {project.verification_status || 'UNVERIFIED'}
                      </span>
                    </td>
                  </tr>

                  {/* Field: Section 3A Date */}
                  <tr className="bg-amber-50/30">
                    <td className="py-2.5 px-3 font-semibold text-slate-900">Section 3A Gazette Date</td>
                    <td className="py-2.5 px-3 font-mono font-bold">
                      {project.section_3a_date ? project.section_3a_date : <span className="text-slate-400 italic font-normal">Unavailable / Not verified</span>}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {project.section_3a_source === 'GAZETTE_OFFICIAL'
                        ? 'Official Gazette S.O. Notification'
                        : project.section_3a_source === 'MANUAL_ENTRY'
                        ? 'Manual Nodal Officer Entry'
                        : 'Unavailable in Statutory Feed'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        project.section_3a_source === 'GAZETTE_OFFICIAL'
                          ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                          : project.section_3a_source === 'MANUAL_ENTRY'
                          ? 'bg-sky-50 text-sky-900 border border-sky-200'
                          : 'bg-slate-100 text-slate-500'
                      }`}>
                        {project.section_3a_source || (project.section_3a_date ? 'MANUAL_ENTRY' : 'UNAVAILABLE')}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        project.section_3a_source === 'GAZETTE_OFFICIAL' || project.verification_status === 'VERIFIED'
                          ? 'bg-emerald-50 text-emerald-800'
                          : 'bg-amber-50 text-amber-800'
                      }`}>
                        {project.section_3a_source === 'GAZETTE_OFFICIAL' || project.verification_status === 'VERIFIED'
                          ? 'VERIFIED'
                          : project.section_3a_date ? 'UNVERIFIED (MANUAL)' : 'UNAVAILABLE'}
                      </span>
                    </td>
                  </tr>

                  {/* Field: Land Required & Acquired */}
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">Land Required & Acquired</td>
                    <td className="py-2.5 px-3 font-mono">{project.landAcquiredHa} / {project.totalLandRequiredHa} Ha</td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {project.source_type === 'VERIFIED_EXTERNAL' ? 'CALA Gazette Survey Schedule' : 'Administrative Cadastral Estimate'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {project.source_type || 'SEEDED'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        project.verification_status === 'VERIFIED' ? 'bg-emerald-50 text-emerald-800' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {project.verification_status || 'UNVERIFIED'}
                      </span>
                    </td>
                  </tr>

                  {/* Field: Compensation */}
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">Compensation Disbursal</td>
                    <td className="py-2.5 px-3 font-mono">₹{project.compensationDisbursedCr} / ₹{project.compensationSanctionedCr} Cr ({project.compensationDisbursedPercent}%)</td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {project.compensation_source === 'MANUAL_ENTRY' ? 'Nodal Officer Manual Update' : 'CALA Escrow / Default Estimate'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {project.compensation_source || 'DEFAULT_UNAVAILABLE'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600">
                        {project.verification_status === 'VERIFIED' ? 'VERIFIED' : 'UNVERIFIED'}
                      </span>
                    </td>
                  </tr>

                  {/* Field: Judicial Court Stay */}
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">Court Stay Status</td>
                    <td className="py-2.5 px-3 font-mono">
                      {project.hasCourtStay ? <span className="text-red-700 font-bold">Active Stay</span> : 'Clean Title / No Stay'}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {project.court_stay_source === 'MANUAL_ENTRY' ? 'Nodal Officer Legal Report' : 'Source-Unavailable / Clean Baseline'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {project.court_stay_source || 'DEFAULT_UNAVAILABLE'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600">
                        {project.verification_status === 'VERIFIED' ? 'VERIFIED' : 'UNVERIFIED'}
                      </span>
                    </td>
                  </tr>

                  {/* Field: Legal Cases */}
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">Unresolved Legal Cases</td>
                    <td className="py-2.5 px-3 font-mono">{project.unresolvedLegalCases} cases</td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {project.source_type === 'MANUALLY_MAINTAINED' ? 'Nodal Officer Manual Filing' : 'Administrative Tracking'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {project.source_type || 'SEEDED'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        project.verification_status === 'VERIFIED' ? 'bg-emerald-50 text-emerald-800' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {project.verification_status || 'UNVERIFIED'}
                      </span>
                    </td>
                  </tr>

                  {/* Field: Incomplete Documents */}
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">Incomplete Mutation Records</td>
                    <td className="py-2.5 px-3 font-mono">{project.incompleteDocumentsCount} documents</td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {project.source_type === 'MANUALLY_MAINTAINED' ? 'Nodal Officer Mutation Audit' : 'State Revenue Mutation Estimate'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {project.source_type || 'SEEDED'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600">
                        {project.verification_status === 'VERIFIED' ? 'VERIFIED' : 'UNVERIFIED'}
                      </span>
                    </td>
                  </tr>

                  {/* Field: Forest Clearance */}
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">Forest Clearance Stage</td>
                    <td className="py-2.5 px-3 font-mono">{project.forestClearanceStage || 'Not Required'}</td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {project.clearance_source === 'MANUAL_ENTRY' ? 'Nodal Officer Clearance Update' : 'Parivesh / Baseline Clearance'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {project.clearance_source || 'DEFAULT_UNAVAILABLE'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600">
                        {project.verification_status === 'VERIFIED' ? 'VERIFIED' : 'UNVERIFIED'}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* 3. Explicit Verification Workflow Card (Part D) */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight uppercase flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>Authoritative Verification Workflow</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Manual nodal entries remain unverified until verified against an authoritative gazette S.O. or judicial record
                </p>
              </div>
            </div>

            {project.verification_status === 'VERIFIED' ? (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-950 space-y-2">
                <div className="flex items-center gap-2 font-bold text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Record Authoritatively Verified</span>
                </div>
                <p className="text-xs leading-relaxed">
                  This package is cryptographically certified against authoritative government records.
                </p>
                <div className="text-[11px] font-mono pt-1 text-emerald-900 space-y-0.5">
                  <div>Reference: <strong>{project.source_reference || 'BhoomiRashi MoRTH Public Gazette Portal'}</strong></div>
                  <div>Verified At: <strong>{project.verified_at ? new Date(project.verified_at).toLocaleString('en-IN') : 'Official Sync'}</strong></div>
                </div>
              </div>
            ) : isNodal ? (
              <form onSubmit={handleVerifySource} className="space-y-4 text-xs">
                <div className="p-3.5 rounded-lg bg-amber-50/70 border border-amber-200 text-amber-950 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>Unverified Package Status</span>
                  </div>
                  <p className="text-[11.5px] leading-relaxed">
                    This project is currently marked <strong>UNVERIFIED</strong>. If you have verified this data against an official Gazette Notification, High Court order, or MoRTH project sanction, enter the authoritative source reference below to certify this record.
                  </p>
                </div>

                {verifyError && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-800 text-xs">
                    {verifyError}
                  </div>
                )}

                {verifySuccess && (
                  <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs">
                    {verifySuccess}
                  </div>
                )}

                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700 block">
                    Authoritative Source Reference <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={verifyRefInput}
                    onChange={e => setVerifyRefInput(e.target.value)}
                    placeholder="e.g. Gazette Notification S.O. 412(E) dt. 2024-01-15 / High Court Order WP-2024-912"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-blue-900 focus:outline-hidden"
                    required
                  />
                  <p className="text-[10.5px] text-slate-500">
                    Entering an authoritative reference records an immutable audit log and promotes Section 3A to Verified Gazette status.
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={verifyLoading}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>{verifyLoading ? 'Verifying...' : 'Certify & Mark Verified'}</span>
                </button>
              </form>
            ) : (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-slate-600 text-xs space-y-1.5">
                <div className="font-semibold text-slate-800 flex items-center gap-1.5">
                  <span>Viewer Role (Read-Only)</span>
                </div>
                <p className="text-[11.5px] leading-relaxed">
                  Lineage metadata is fully transparent and inspectable in read-only mode. Promoting unverified packages to Verified status requires authenticated <strong>NODAL_OFFICER</strong> credentials.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 6: SHADOW V2 DIAGNOSTICS & STATUTORY TIMELINE                         */}
      {/* ========================================================================= */}
      {activeTab === 'shadow' && (
        <div className="space-y-6">
          {/* 1. High-Contrast Institutional Safety Banner */}
          <div className="bg-slate-900 text-white rounded-xl p-6 border border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="p-3 bg-amber-500/20 text-amber-400 rounded-lg border border-amber-500/40 shrink-0">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-black tracking-wider uppercase bg-amber-400 text-slate-950 px-2 py-0.5 rounded">
                      V2 SHADOW CANDIDATE — NON-OPERATIONAL
                    </span>
                    <span className="text-xs text-amber-300 font-semibold">
                      Phase 7B Shadow Evaluation Protocol
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-white mt-1">
                    Candidate Model Shadow Diagnostics &amp; Point-in-Time Statutory Lineage
                  </h3>
                  <p className="text-xs text-slate-300 mt-1 max-w-4xl leading-relaxed">
                    <strong>Mandatory Governance Disclosure:</strong> Production model V1.0 remains the sole authoritative operational system.
                    Candidate model V2.0 operates strictly in shadow evaluation mode and <strong>does not alter</strong> operational risk levels,
                    delay probabilities, alerts, priority ranks, or administrative decisions. Decision thresholds remain{' '}
                    <strong>PENDING STAKEHOLDER APPROVAL</strong>.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="px-3 py-1.5 rounded-lg bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[11px] font-bold uppercase tracking-wider">
                  THRESHOLDS: PENDING APPROVAL
                </span>
              </div>
            </div>

            {/* Non-Operational Watermark Bar */}
            <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-amber-300/90 font-mono">
              <span className="flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                SHADOW / DIAGNOSTIC ONLY — NOT AN OPERATIONAL RISK SCORE
              </span>
              <span className="text-slate-400">
                Feature Contract: SCHEMA-LONGITUDINAL-V2.0-10FEAT
              </span>
            </div>
          </div>

          {/* 2. Side-by-Side Architectural Parity: Production V1 vs Candidate V2 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left: Production Model V1 (Operational) */}
            <div className="bg-white border-2 border-emerald-300 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-emerald-100 pb-3">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                    SOLE OPERATIONAL MODEL
                  </span>
                  <h4 className="text-base font-bold text-slate-900 mt-1">Production V1.0</h4>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" /> AUTHORITATIVE
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Operational Risk Level</span>
                  <div className={`text-base font-black mt-1 ${
                    displayRiskLevel === 'HIGH' ? 'text-rose-700' : displayRiskLevel === 'MEDIUM' ? 'text-amber-700' : 'text-emerald-700'
                  }`}>
                    {displayRiskLevel}
                  </div>
                  <span className="text-[10px] text-slate-400">Official Classification</span>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Delay Probability</span>
                  <div className="text-base font-black text-slate-900 mt-1">
                    {displayDelayProbability}%
                  </div>
                  <span className="text-[10px] text-slate-400">Production Inference</span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>Artifact Name:</span>
                  <span className="font-mono font-bold text-slate-900">BHOOMI-DRISHTI-ML-V1.0</span>
                </div>
                <div className="flex justify-between text-slate-600 font-mono text-[11px] break-all">
                  <span>SHA-256:</span>
                  <span className="text-slate-900">7e0e1a7dac2e082c...7f</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Operational Status:</span>
                  <span className="font-bold text-emerald-700">100% Active Production</span>
                </div>
              </div>
            </div>

            {/* Right: Candidate Shadow Model V2 (Non-Operational) */}
            <div className="bg-white border-2 border-indigo-300 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-indigo-100 pb-3">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-indigo-800 bg-indigo-100 px-2 py-0.5 rounded">
                    SHADOW CANDIDATE (NON-OPERATIONAL)
                  </span>
                  <h4 className="text-base font-bold text-slate-900 mt-1">Candidate V2.0</h4>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-indigo-700 flex items-center gap-1">
                    <Activity className="w-4 h-4" /> SHADOW BENCHMARK
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-indigo-50/50 rounded-lg border border-indigo-200">
                  <span className="text-[10px] font-bold text-indigo-800 uppercase">Diagnostic Probability</span>
                  <div className="text-base font-black text-indigo-950 mt-1">
                    {shadowDiag?.shadowRecord?.prediction_probability !== null && shadowDiag?.shadowRecord?.prediction_probability !== undefined
                      ? `${(shadowDiag.shadowRecord.prediction_probability * 100).toFixed(1)}%`
                      : shadowDiag?.quality?.is_shadow_scoreable
                      ? 'COMPUTED IN SHADOW'
                      : 'INSUFFICIENT_EVIDENCE'}
                  </div>
                  <span className="text-[10px] text-indigo-700 font-semibold">Diagnostic / Non-Operational</span>
                </div>

                <div className="p-3 bg-indigo-50/50 rounded-lg border border-indigo-200">
                  <span className="text-[10px] font-bold text-indigo-800 uppercase">Prediction State</span>
                  <div className="text-sm font-black text-indigo-950 mt-1">
                    {shadowDiag?.shadowRecord?.prediction_state || (shadowDiag?.quality?.is_shadow_scoreable ? 'EVALUATED' : 'INSUFFICIENT_EVIDENCE')}
                  </div>
                  <span className="text-[10px] text-indigo-700 font-semibold">Three-State Contract</span>
                </div>
              </div>

              <div className="p-3 bg-indigo-50/50 rounded-lg border border-indigo-200 text-xs space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>Artifact Name:</span>
                  <span className="font-mono font-bold text-slate-900">BHOOMI-DRISHTI-ML-V2.0-SHADOW</span>
                </div>
                <div className="flex justify-between text-slate-600 font-mono text-[11px] break-all">
                  <span>SHA-256:</span>
                  <span className="text-slate-900">4a83e980f9178498...a2</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Governance State:</span>
                  <span className="font-bold text-amber-700">PENDING_STAKEHOLDER_APPROVAL</span>
                </div>
              </div>
            </div>
          </div>

          {/* 3. Authoritative Corridor Statutory Lineage & Timeline */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-6">
            <div className="border-b border-slate-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-tight">
                  Point-in-Time Corridor Timeline &amp; Statutory Provenance
                </h3>
                <p className="text-xs text-slate-500">
                  Authoritative e-Gazette documentation and Section 3A eligibility under National Highways Act, 1956
                </p>
              </div>
              <span className={`px-2.5 py-1 rounded text-xs font-bold border ${
                shadowDiag?.quality?.is_shadow_scoreable
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                  : 'bg-amber-100 text-amber-800 border-amber-300'
              }`}>
                SHADOW STATUS: {shadowDiag?.quality?.is_shadow_scoreable ? 'ELIGIBLE (COMPLETE)' : 'INSUFFICIENT_EVIDENCE'}
              </span>
            </div>

            {/* Granular Timeline Details Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Corridor Identity</span>
                <div className="font-mono font-bold text-slate-900 text-sm">{project.id}</div>
                <p className="text-[11px] text-slate-500 truncate" title={project.name}>{project.name}</p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Statutory Source &amp; Agency</span>
                <div className="font-bold text-slate-900 text-xs">{project.source || 'BhoomiRashi'}</div>
                <p className="text-[11px] text-slate-500">{project.agency || 'NHAI'} · {project.state || 'National'}</p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Section 3A Gazette Status</span>
                <div className="font-bold text-xs flex items-center gap-1">
                  {shadowDiag?.quality?.section_3a?.status === 'VERIFIED' ? (
                    <span className="text-emerald-700 flex items-center gap-1 font-bold">
                      <Check className="w-3.5 h-3.5" /> VERIFIED GAZETTE
                    </span>
                  ) : shadowDiag?.quality?.section_3a?.status === 'PRE_3A_STAGE' ? (
                    <span className="text-blue-700 font-bold">PRE-3A STAGE (DPR)</span>
                  ) : (
                    <span className="text-amber-700 font-bold">MISSING 3A NOTICE</span>
                  )}
                </div>
                <p className="text-[11px] text-slate-500 font-mono">
                  Date: {shadowDiag?.quality?.section_3a?.first_verified_date || project.section_3a_date || 'Pre-Statutory'}
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Observation Timestamp</span>
                <div className="font-mono font-bold text-slate-900 text-xs">
                  {(shadowDiag?.quality?.last_verified_at || project.verified_at || '2026-09-29T00:00:00Z').slice(0, 10)}
                </div>
                <p className="text-[11px] text-slate-500">feature_t &le; obs_t strictly validated</p>
              </div>
            </div>

            {/* Notification Sequence & Gazette Citations */}
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 uppercase text-[11px]">
                  Chronological Notification Sequence &amp; Provenance
                </span>
                <span className="font-mono text-slate-600 font-semibold">
                  Verified Notices: {shadowDiag?.quality?.notifications?.verified_count || 1}
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex items-start gap-3 p-2.5 bg-white rounded border border-slate-200">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-slate-900">Section 3A Publication Notice</span>
                      <span className="font-mono text-[11px] text-emerald-700 font-semibold">
                        {shadowDiag?.quality?.section_3a?.first_verified_date || project.section_3a_date || '2023-04-15'}
                      </span>
                    </div>
                    <p className="text-slate-600 text-[11px] mt-0.5">
                      Gazette Citation: {shadowDiag?.quality?.section_3a?.source_reference || project.source_reference || 'Gazette of India Extraordinary Part II Section 3(ii)'}
                    </p>
                    {shadowDiag?.quality?.section_3a?.notification_number && (
                      <p className="text-slate-500 font-mono text-[10px] mt-0.5">
                        Notification Number: {shadowDiag.quality.section_3a.notification_number}
                      </p>
                    )}
                  </div>
                </div>

                {project.section_3d_date && (
                  <div className="flex items-start gap-3 p-2.5 bg-white rounded border border-slate-200">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                      2
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-slate-900">Section 3D Declaration Notice</span>
                        <span className="font-mono text-[11px] text-emerald-700 font-semibold">
                          {project.section_3d_date}
                        </span>
                      </div>
                      <p className="text-slate-600 text-[11px] mt-0.5">
                        Statutory Acquisition Declaration filed within statutory 365-day statutory window.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* 10-Feature Contract Snapshot Breakdown */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 uppercase text-[11px]">
                  Longitudinal Feature Contract Snapshot (10 Features)
                </span>
                <span className="font-mono text-slate-500 text-[11px]">
                  SCHEMA-LONGITUDINAL-V2.0-10FEAT
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-mono">
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 uppercase">Days Since 3A</div>
                  <div className="font-bold text-slate-900 mt-0.5">
                    {project.section_3a_date ? Math.max(0, Math.floor((Date.now() - new Date(project.section_3a_date).getTime()) / 86400000)) : 0}d
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 uppercase">Cumul. Notices</div>
                  <div className="font-bold text-slate-900 mt-0.5">
                    {shadowDiag?.quality?.notifications?.verified_count || 1}
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 uppercase">Cadence Days</div>
                  <div className="font-bold text-slate-900 mt-0.5">
                    30.0d
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 uppercase">Days Since Notif</div>
                  <div className="font-bold text-slate-900 mt-0.5">
                    15.0d
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 uppercase">Statutory Stage</div>
                  <div className="font-bold text-slate-900 mt-0.5 truncate" title={project.stage}>
                    {project.stage || 'STAGE_3A'}
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 uppercase">Freq 180d</div>
                  <div className="font-bold text-slate-900 mt-0.5">
                    1.0
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 uppercase">Total Land (Ha)</div>
                  <div className="font-bold text-slate-900 mt-0.5">
                    {project.totalLandRequiredHa || 200}
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 uppercase">Agency</div>
                  <div className="font-bold text-slate-900 mt-0.5 truncate">
                    {project.agency || 'NHAI'}
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 uppercase">State</div>
                  <div className="font-bold text-slate-900 mt-0.5 truncate">
                    {project.state || 'National'}
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 uppercase">Sanction Avail</div>
                  <div className="font-bold text-slate-900 mt-0.5">
                    1 (True)
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      <ModelExplanationModal
        isOpen={modelModalOpen}
        onClose={() => setModelModalOpen(false)}
        project={project}
      />

      {/* Project Edit Modal */}
      {editModalOpen && (
        <ProjectFormModal
          isOpen={editModalOpen}
          mode="edit"
          project={project}
          onClose={() => setEditModalOpen(false)}
          onSuccess={updated => {
            setProject(updated);
            onProjectUpdated?.(updated);
          }}
        />
      )}
    </div>
  );
};
