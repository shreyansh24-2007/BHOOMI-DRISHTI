import React, { useState, useEffect, useCallback } from 'react';
import { AlertTriangle, RefreshCw, Loader2 } from 'lucide-react';
import { Sidebar, NavView } from './components/Sidebar.tsx';
import { Navbar } from './components/Navbar.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { ProjectsView } from './components/ProjectsView.tsx';
import { ProjectDetailsView } from './components/ProjectDetailsView.tsx';
import { RiskMapView } from './components/RiskMapView.tsx';
import { AlertsView } from './components/AlertsView.tsx';
import { DataHubManagement } from './components/DataHubManagement.tsx';
import { WhatIfView } from './components/WhatIfView.tsx';
import { ReportsView } from './components/ReportsView.tsx';
import { ShadowGovernanceView } from './components/ShadowGovernanceView.tsx';
import { SettingsModal } from './components/SettingsModal.tsx';
import { HelpModal } from './components/HelpModal.tsx';
import { ModelExplanationModal } from './components/ModelExplanationModal.tsx';
import { LoginScreen } from './components/LoginScreen.tsx';
import { GovernmentEmblem } from './components/common/GovernmentEmblem.tsx';
import { api } from './services/apiClient.ts';
import { DashboardSummary, Project, AlertItem, AuthUser } from './types.ts';

export default function App() {
  // Authentication & Session State
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [authChecking, setAuthChecking] = useState<boolean>(true);

  const [currentView, setCurrentView] = useState<NavView>(() => {
    if (typeof window !== 'undefined') {
      if (window.location.pathname === '/shadow-governance' || window.location.hash === '#shadow-governance') {
        return 'shadow-governance';
      }
    }
    return 'dashboard';
  });
  const [previousView, setPreviousView] = useState<NavView>('dashboard');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);

  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Modals
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [modelModalOpen, setModelModalOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Check auth session on startup
  useEffect(() => {
    let mounted = true;
    api.auth.getMe().then(res => {
      if (mounted) {
        if (res.isAuthenticated && res.user) {
          setCurrentUser(res.user);
        } else {
          setCurrentUser(null);
        }
        setAuthChecking(false);
      }
    }).catch(() => {
      if (mounted) {
        setCurrentUser(null);
        setAuthChecking(false);
      }
    });

    return () => {
      mounted = false;
    };
  }, []);

  const loadData = useCallback(async (isManualRefresh = false) => {
    if (isManualRefresh) {
      setIsRefreshing(true);
    } else {
      setLoading(true);
    }
    setErrorMessage(null);

    try {
      const [sumRes, projRes, alertsRes] = await Promise.all([
        api.getDashboardSummary(),
        api.getProjects(),
        api.getAlerts()
      ]);

      setSummary(sumRes);
      setProjects(projRes);
      setAlerts(alertsRes);
      setErrorMessage(null);
    } catch (err: any) {
      console.error('Error fetching data from API:', err);
      if (err.message && err.message.includes('401')) {
        // Expired/invalid session
        await api.auth.logout();
        setCurrentUser(null);
      } else {
        setErrorMessage('Unable to retrieve current project data.');
      }
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    if (currentUser) {
      loadData();
    }
  }, [currentUser, loadData]);

  const handleLoginSuccess = (user: AuthUser) => {
    setCurrentUser(user);
    loadData();
  };

  const handleLogout = async () => {
    await api.auth.logout();
    setCurrentUser(null);
    setCurrentView('dashboard');
    setSelectedProjectId(null);
    setProjects([]);
    setSummary(null);
    setAlerts([]);
  };

  // Initial Auth Loading Screen
  if (authChecking) {
    return (
      <div className="min-h-screen bg-[#0F2027] flex flex-col items-center justify-center p-6 text-white text-center">
        <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 shadow-xl mb-4 animate-pulse">
          <GovernmentEmblem size={56} />
        </div>
        <h2 className="text-xl font-bold tracking-tight text-white mb-1">BHOOMI-DRISHTI</h2>
        <p className="text-xs text-amber-300 font-medium uppercase tracking-wider mb-6">
          Ministry of Road Transport & Highways · NHAI
        </p>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
          <span>Verifying Statutory Session & Credentials...</span>
        </div>
      </div>
    );
  }

  // Unauthenticated: Dedicated Login Screen
  if (!currentUser) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  // Handle project selection to navigate to Project Details
  const handleSelectProject = (projectId: string) => {
    setSelectedProjectId(projectId);
    setPreviousView(currentView);
    setCurrentView('project-details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackFromDetails = () => {
    setCurrentView(previousView === 'project-details' ? 'projects' : previousView);
    setSelectedProjectId(null);
  };

  const handleNavigateToWhatIf = (projectId: string) => {
    setSelectedProjectId(projectId);
    setCurrentView('what-if');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAcknowledgeAlert = async (alertId: string) => {
    await api.acknowledgeAlert(alertId);
    setAlerts(prev =>
      prev.map(a => (a.id === alertId ? { ...a, status: 'Acknowledged' as const } : a))
    );
  };

  const activeProject = selectedProjectId
    ? projects.find(p => p.id === selectedProjectId) || null
    : null;

  const unreadAlertsCount = alerts.filter(a => a.status === 'New').length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col lg:flex-row antialiased selection:bg-blue-100 selection:text-blue-900">
      {/* Left Institutional Sidebar */}
      <Sidebar
        currentView={currentView}
        onNavigate={view => {
          if (view !== 'project-details' && view !== 'what-if') {
            setSelectedProjectId(null);
          }
          setCurrentView(view);
        }}
        onOpenSettings={() => setSettingsOpen(true)}
        onOpenHelp={() => setHelpOpen(true)}
        onOpenModelInfo={() => setModelModalOpen(true)}
        unreadAlertsCount={unreadAlertsCount}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
        userRole={currentUser.role}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col lg:pl-64 min-w-0 print:pl-0 print:block">
        {/* Top Government Platform Header */}
        <Navbar
          currentView={currentView}
          projectName={activeProject?.name}
          onOpenMobileSidebar={() => setMobileSidebarOpen(true)}
          onRefresh={() => loadData(true)}
          isRefreshing={isRefreshing}
          onOpenModelInfo={() => setModelModalOpen(true)}
          unreadAlertsCount={unreadAlertsCount}
          onNavigateToAlerts={() => setCurrentView('alerts')}
          currentUser={currentUser}
          onLogout={handleLogout}
        />

        {/* Global Error Banner */}
        {errorMessage && (
          <div className="bg-red-50 border-b border-red-200 px-4 py-2 text-xs text-red-800 flex items-center justify-between font-medium no-print">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-600"></span>
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => loadData(true)}
              className="px-3 py-1 bg-red-100 hover:bg-red-200 text-red-900 rounded font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              Retry
            </button>
          </div>
        )}

        {/* Dedicated Error State if projects cannot be retrieved */}
        {!loading && projects.length === 0 && errorMessage ? (
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="max-w-md w-full bg-white rounded-xl border border-red-200 p-8 text-center shadow-xs">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h2 className="text-base font-bold text-slate-900 mb-2">Unable to retrieve current project data.</h2>
              <p className="text-xs text-slate-600 mb-6 leading-relaxed">
                The application could not retrieve intelligence records from the backend service. Please check server connectivity and retry.
              </p>
              <button
                onClick={() => loadData(true)}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Retry
              </button>
            </div>
          </div>
        ) : (
          /* Main Viewport */
          <main className="flex-1 p-4 md:p-6 lg:p-8 print:p-0 print:block">
            {currentView === 'dashboard' && (
              <DashboardView
                summary={summary}
                loading={loading}
                onSelectProject={handleSelectProject}
                onViewAllAlerts={() => setCurrentView('alerts')}
                onViewAllProjects={() => setCurrentView('projects')}
              />
            )}

            {currentView === 'projects' && (
              <ProjectsView
                projects={projects}
                loading={loading}
                onSelectProject={handleSelectProject}
                userRole={currentUser.role}
                onRefresh={() => loadData(true)}
              />
            )}

            {currentView === 'project-details' && (
              activeProject ? (
                <ProjectDetailsView
                  project={activeProject}
                  onBack={handleBackFromDetails}
                  onNavigateToWhatIf={handleNavigateToWhatIf}
                  userRole={currentUser.role}
                  onProjectUpdated={() => loadData(true)}
                />
              ) : (
                <div className="text-center py-20 bg-white rounded-xl border border-slate-200 p-8">
                  <p className="text-sm font-semibold text-slate-800">Project record not found.</p>
                  <button
                    onClick={() => setCurrentView('projects')}
                    className="mt-3 px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    Return to Projects
                  </button>
                </div>
              )
            )}

            {currentView === 'map' && (
              <RiskMapView
                projects={projects}
                onSelectProject={handleSelectProject}
              />
            )}

            {currentView === 'alerts' && (
              <AlertsView
                alerts={alerts}
                onSelectProject={handleSelectProject}
                onAcknowledge={handleAcknowledgeAlert}
              />
            )}

            {currentView === 'data-sync' && (
              <DataHubManagement
                onSyncComplete={() => loadData(true)}
                onSelectProject={handleSelectProject}
              />
            )}

            {currentView === 'what-if' && (
              <WhatIfView
                projects={projects}
                initialProjectId={selectedProjectId || undefined}
                onSelectProject={handleSelectProject}
              />
            )}

            {currentView === 'reports' && (
              <ReportsView
                projects={projects}
                summary={summary}
              />
            )}

            {currentView === 'shadow-governance' && (
              <ShadowGovernanceView
                userRole={currentUser.role}
              />
            )}
          </main>
        )}
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        currentUser={currentUser}
      />

      {/* Help & Reference Modal */}
      <HelpModal
        isOpen={helpOpen}
        onClose={() => setHelpOpen(false)}
      />

      {/* ML Model Explanation & Formula Modal */}
      <ModelExplanationModal
        isOpen={modelModalOpen}
        onClose={() => setModelModalOpen(false)}
        project={activeProject}
      />
    </div>
  );
}
