import {
  DashboardSummary,
  Project,
  AlertItem,
  WhatIfRequest,
  WhatIfResponse,
  SystemStatus,
  SourceStatusItem,
  SyncRunResponse,
  ProjectHistoryItem,
  DataSourceItem,
  FileInspectionResult,
  DataValidationErrorItem,
  AuditLogItem,
  DatabaseOverview,
  ConnectionTestResult,
  DataModeType,
  SourceTestResult,
  DataQualitySummary
} from '../types.ts';
import { isFirebaseConfigured, signInWithFirebase, signOutFirebase } from './firebaseClient.ts';

const API_BASE = '/api';

// Auth State in Client
let activeToken: string | null = typeof window !== 'undefined' ? localStorage.getItem('bdt_auth_token') : null;
let activeRole: 'NODAL_OFFICER' | 'VIEWER' = typeof window !== 'undefined' 
  ? (localStorage.getItem('bdt_auth_role') as any || 'NODAL_OFFICER') 
  : 'NODAL_OFFICER';

function getAuthHeaders(customHeaders: Record<string, string> = {}): Record<string, string> {
  const headers: Record<string, string> = { ...customHeaders };
  if (activeToken) {
    headers['Authorization'] = `Bearer ${activeToken}`;
  }
  return headers;
}

/**
 * High-Reliability BhoomiDrishti API Client
 * Connects directly to backend SQLite & ML engine.
 * Never silently falls back to synthetic mock data on error;
 * provides explicit, actionable failure states for UI retry components.
 */
export const api = {
  async getDashboardSummary(): Promise<DashboardSummary> {
    const res = await fetch(`${API_BASE}/dashboard/summary`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      throw new Error(`Unable to retrieve dashboard summary (HTTP ${res.status}). Please verify server availability and retry.`);
    }
    return await res.json();
  },

  async getProjects(params?: {
    search?: string;
    risk?: string;
    state?: string;
    district?: string;
    stage?: string;
    page?: number;
    pageSize?: number;
  }): Promise<Project[]> {
    const url = new URL(`${window.location.origin}${API_BASE}/projects`);
    if (params?.search) url.searchParams.set('search', params.search);
    if (params?.risk) url.searchParams.set('risk', params.risk);
    if (params?.state) url.searchParams.set('state', params.state);
    if (params?.district) url.searchParams.set('district', params.district);
    if (params?.stage) url.searchParams.set('stage', params.stage);
    if (params?.page) url.searchParams.set('page', String(params.page));
    url.searchParams.set('pageSize', String(params?.pageSize || 100));

    const res = await fetch(url.toString(), {
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      throw new Error(`Unable to retrieve current project data (HTTP ${res.status}). Backend service may be initializing.`);
    }
    const data = await res.json();
    return Array.isArray(data) ? data : (data.items || []);
  },

  async getProjectById(id: string): Promise<Project> {
    const res = await fetch(`${API_BASE}/projects/${encodeURIComponent(id)}`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      throw new Error(`Unable to retrieve project '${id}' (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async createProject(fields: Partial<Project>): Promise<{ success: boolean; project?: Project }> {
    const res = await fetch(`${API_BASE}/projects`, {
      method: 'POST',
      headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(fields)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Failed to create project (HTTP ${res.status})`);
    }
    return await res.json();
  },

  async updateProject(id: string, fields: Partial<Project>): Promise<{ success: boolean; project?: Project }> {
    const res = await fetch(`${API_BASE}/projects/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(fields)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Failed to update project (HTTP ${res.status})`);
    }
    return await res.json();
  },

  async deleteProject(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`${API_BASE}/projects/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Failed to delete project (HTTP ${res.status})`);
    }
    return await res.json();
  },

  async verifyProject(id: string, authoritativeSourceRef: string): Promise<{ success: boolean; project?: Project }> {
    const res = await fetch(`${API_BASE}/projects/${encodeURIComponent(id)}/verify`, {
      method: 'POST',
      headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ authoritative_source_ref: authoritativeSourceRef })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Failed to verify project (HTTP ${res.status})`);
    }
    return await res.json();
  },

  async getProjectHistory(projectId: string): Promise<ProjectHistoryItem[]> {
    const res = await fetch(`${API_BASE}/projects/${encodeURIComponent(projectId)}/history`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      throw new Error(`Unable to retrieve project audit trail (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getAlerts(status?: string): Promise<AlertItem[]> {
    const url = status ? `${API_BASE}/alerts?status=${encodeURIComponent(status)}` : `${API_BASE}/alerts`;
    const res = await fetch(url, {
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      throw new Error(`Unable to retrieve statutory alerts (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async acknowledgeAlert(id: string): Promise<AlertItem> {
    const res = await fetch(`${API_BASE}/alerts/${encodeURIComponent(id)}/acknowledge`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      throw new Error(`Unable to acknowledge alert (HTTP ${res.status}).`);
    }
    const data = await res.json();
    return data.alert || data;
  },

  async getRiskMap(): Promise<any[]> {
    const res = await fetch(`${API_BASE}/risk-map`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      throw new Error(`Unable to retrieve GIS corridor coordinates (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async runWhatIf(payload: WhatIfRequest): Promise<WhatIfResponse> {
    const res = await fetch(`${API_BASE}/scenarios/what-if`, {
      method: 'POST',
      headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      throw new Error(`Simulation engine error (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getSystemStatus(): Promise<SystemStatus> {
    const res = await fetch(`${API_BASE}/system/status`);
    if (!res.ok) {
      throw new Error(`Unable to retrieve system telemetry (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getSourcesStatus(): Promise<SourceStatusItem[]> {
    const res = await fetch(`${API_BASE}/system/source-status`);
    if (!res.ok) {
      throw new Error(`Unable to retrieve government source status (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getDataSources(): Promise<DataSourceItem[]> {
    const res = await fetch(`${API_BASE}/data-sources`);
    if (!res.ok) {
      throw new Error(`Unable to load registered data sources (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async updateDataSource(id: string, update: Partial<DataSourceItem>): Promise<DataSourceItem> {
    const res = await fetch(`${API_BASE}/data-sources/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(update)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Failed to update data source config (HTTP ${res.status})`);
    }
    const data = await res.json();
    return data.dataSource;
  },

  async testDataSource(id: string): Promise<ConnectionTestResult> {
    const res = await fetch(`${API_BASE}/data-sources/${encodeURIComponent(id)}/test`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      throw new Error(`Connection probe failed with HTTP ${res.status}`);
    }
    return await res.json();
  },

  async inspectFile(content: string, fileType: string, fileName?: string): Promise<FileInspectionResult> {
    const res = await fetch(`${API_BASE}/data/inspect`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, fileType, fileName })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `File inspection failed (HTTP ${res.status})`);
    }
    return await res.json();
  },

  async importMappedFile(
    content: string,
    fileType: string,
    columnMapping?: Record<string, string>,
    fileName?: string
  ): Promise<SyncRunResponse> {
    const res = await fetch(`${API_BASE}/data/import-mapped`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, fileType, columnMapping, fileName })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Import failed with HTTP ${res.status}`);
    }
    const data = await res.json();
    return data.summary;
  },

  async triggerSync(source: 'BhoomiRashi' | 'LACRRIS'): Promise<SyncRunResponse> {
    const res = await fetch(`${API_BASE}/sync`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Sync failed with HTTP ${res.status}`);
    }
    const data = await res.json();
    return data.summary;
  },

  async importFile(content: string, fileType: 'csv' | 'xlsx' | 'xls' | 'json', fileName?: string): Promise<SyncRunResponse> {
    const res = await fetch(`${API_BASE}/data/import`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, fileType, fileName })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Import failed with HTTP ${res.status}`);
    }
    const data = await res.json();
    return data.summary;
  },

  async getSyncHistory(): Promise<SyncRunResponse[]> {
    const res = await fetch(`${API_BASE}/sync/history`);
    if (!res.ok) {
      throw new Error(`Unable to fetch synchronization history (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getValidationErrors(syncId?: string, limit = 50): Promise<DataValidationErrorItem[]> {
    const url = syncId ? `${API_BASE}/validation-errors?syncId=${encodeURIComponent(syncId)}&limit=${limit}` : `${API_BASE}/validation-errors?limit=${limit}`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`Unable to fetch validation errors (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getAuditLogs(limit = 50): Promise<AuditLogItem[]> {
    const res = await fetch(`${API_BASE}/audit-logs?limit=${limit}`);
    if (!res.ok) {
      throw new Error(`Unable to fetch audit logs (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getDatabaseOverview(): Promise<DatabaseOverview> {
    const res = await fetch(`${API_BASE}/database/overview`);
    if (!res.ok) {
      throw new Error(`Unable to fetch database overview (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async setDataMode(mode: DataModeType): Promise<{ success: boolean; mode: string }> {
    const res = await fetch(`${API_BASE}/system/data-mode`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode })
    });
    if (!res.ok) {
      throw new Error(`Failed to set data mode (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  getExportDownloadUrl(type: 'all' | 'high_risk' | 'alerts' | 'audit_logs', format: 'csv' | 'json'): string {
    return `${API_BASE}/export?type=${type}&format=${format}`;
  },

  // ==========================================================
  // PHASE 1 DATA HUB CLIENT API
  // ==========================================================
  datahub: {
    async getProjects(): Promise<any[]> {
      const res = await fetch(`${API_BASE}/datahub/projects`);
      if (!res.ok) throw new Error(`Failed to fetch Data Hub projects (${res.status})`);
      return await res.json();
    },

    async getProjectById(sourceProjectId: string): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/projects/${encodeURIComponent(sourceProjectId)}`);
      if (!res.ok) throw new Error(`Project ${sourceProjectId} not found in Data Hub`);
      return await res.json();
    },

    async getProjectHistory(sourceProjectId: string): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/projects/${encodeURIComponent(sourceProjectId)}/history`);
      if (!res.ok) throw new Error(`Failed to fetch project history (${res.status})`);
      return await res.json();
    },

    async getRecentChanges(limit = 30): Promise<any[]> {
      const res = await fetch(`${API_BASE}/datahub/changes?limit=${limit}`);
      if (!res.ok) throw new Error(`Failed to fetch changes (${res.status})`);
      return await res.json();
    },

    async getSyncStatus(): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/sync-status`);
      if (!res.ok) throw new Error(`Failed to fetch sync status (${res.status})`);
      return await res.json();
    },

    async getQualitySummary(): Promise<DataQualitySummary> {
      const res = await fetch(`${API_BASE}/datahub/quality-summary`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to fetch quality summary (${res.status})`);
      return await res.json();
    },

    async getSyncRuns(limit = 15): Promise<any[]> {
      const res = await fetch(`${API_BASE}/datahub/sync-runs?limit=${limit}`);
      if (!res.ok) throw new Error(`Failed to fetch sync runs (${res.status})`);
      return await res.json();
    },

    async triggerSync(): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/sync`, {
        method: 'POST',
        headers: getAuthHeaders()
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Sync trigger failed (${res.status})`);
      }
      return await res.json();
    },

    async registerProject(projectId: string, projectName?: string): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/projects/register`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ projectId, projectName })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Registration failed (${res.status})`);
      }
      return await res.json();
    },

    async importProjectIds(content: string, format: 'csv' | 'txt' | 'json' = 'csv'): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/projects/import`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ content, format })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Import failed (${res.status})`);
      }
      return await res.json();
    },

    async getSourceStatus(): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/source-status`);
      if (!res.ok) throw new Error(`Failed to fetch source status (${res.status})`);
      return await res.json();
    },

    async testSource(projectId?: string): Promise<SourceTestResult> {
      const res = await fetch(`${API_BASE}/datahub/source/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId })
      });
      if (!res.ok) throw new Error(`Test connection failed (${res.status})`);
      return await res.json();
    },

    async toggleFixture60940(enabled?: boolean): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/test-fixture/toggle-60940`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled })
      });
      if (!res.ok) throw new Error(`Toggle fixture failed (${res.status})`);
      return await res.json();
    },

    async updateConfig(intervalMinutes: number): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/config`, {
        method: 'PUT',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ intervalMinutes })
      });
      if (!res.ok) throw new Error(`Update config failed (${res.status})`);
      return await res.json();
    },

    async getDiscoveryReport(): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/discovery/status`);
      if (!res.ok) throw new Error(`Failed to fetch discovery report (${res.status})`);
      return await res.json();
    },

    async discoverCandidates(candidateIds: string[]): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/discovery/candidates`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ candidateIds })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Candidate discovery failed (${res.status})`);
      }
      return await res.json();
    },

    async discoverRange(baseProjectId: string, windowSize: number = 1): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/discovery/probe-range`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ baseProjectId, windowSize })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Range probe failed (${res.status})`);
      }
      return await res.json();
    },

    getExportUrl(format: 'csv' | 'json' = 'csv'): string {
      return `${API_BASE}/datahub/export?format=${format}`;
    },

    // Phase 7B-4 Statutory Evidence Methods
    async getStatutorySources(): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/sources`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error(`Failed to fetch statutory sources (${res.status})`);
      return await res.json();
    },

    async getProjectEvidence(projectId: string): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/projects/${encodeURIComponent(projectId)}/evidence`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error(`Failed to fetch project statutory evidence (${res.status})`);
      return await res.json();
    },

    async getProjectEvidenceQuality(projectId: string): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/projects/${encodeURIComponent(projectId)}/evidence-quality`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error(`Failed to fetch project evidence quality (${res.status})`);
      return await res.json();
    },

    async getProjectNotifications(projectId: string): Promise<any[]> {
      const res = await fetch(`${API_BASE}/datahub/projects/${encodeURIComponent(projectId)}/notifications`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error(`Failed to fetch project notifications (${res.status})`);
      return await res.json();
    },

    async getReviewQueue(status?: string): Promise<any[]> {
      const url = new URL(`${window.location.origin}${API_BASE}/datahub/review-queue`);
      if (status) url.searchParams.set('status', status);
      const res = await fetch(url.toString(), { headers: getAuthHeaders() });
      if (!res.ok) throw new Error(`Failed to fetch review queue (${res.status})`);
      return await res.json();
    },

    async recordReviewDecision(reviewId: string, decision: string, notes?: string): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/review-queue/${encodeURIComponent(reviewId)}/decision`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ decision, notes })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Failed to record review decision (${res.status})`);
      }
      return await res.json();
    },

    async importOfficialDocument(upload: {
      fileName: string;
      mimeType: string;
      base64Content: string;
      projectId: string;
      sourceReference: string;
      statutorySection: string;
      notificationNumber: string;
      publicationDate: string;
      sourceUrl?: string;
    }): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/ingestion/import`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(upload)
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Document upload failed (${res.status})`);
      }
      return await res.json();
    },

    async triggerStatutorySync(source: 'BhoomiRashi' | 'LACRRIS'): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/sync/${encodeURIComponent(source)}`, {
        method: 'POST',
        headers: getAuthHeaders()
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Source sync failed (${res.status})`);
      }
      return await res.json();
    }
  },


  // Authentication & RBAC Services (Phase 0.6 / Phase 3B)
  auth: {
    getCurrentRole(): 'NODAL_OFFICER' | 'VIEWER' {
      return activeRole;
    },

    getActiveToken(): string | null {
      return activeToken;
    },

    async getMe(): Promise<{
      isAuthenticated: boolean;
      user: any;
      demoMode?: boolean;
      demoCredentials?: {
        nodalEmail: string;
        auditorEmail: string;
        password?: string;
      };
    }> {
      try {
        const res = await fetch(`${API_BASE}/auth/me`, {
          headers: getAuthHeaders()
        });
        if (!res.ok) {
          if (res.status === 401) {
            activeToken = null;
            if (typeof window !== 'undefined') {
              localStorage.removeItem('bdt_auth_token');
            }
          }
          return { isAuthenticated: false, user: null };
        }
        const data = await res.json();
        if (data.user?.role) {
          activeRole = data.user.role;
          if (typeof window !== 'undefined') {
            localStorage.setItem('bdt_auth_role', activeRole);
          }
        } else if (!data.isAuthenticated) {
          activeToken = null;
          if (typeof window !== 'undefined') {
            localStorage.removeItem('bdt_auth_token');
          }
        }
        return data;
      } catch {
        return { isAuthenticated: false, user: null };
      }
    },

    async login(email: string, pass: string): Promise<any> {
      // 1. If Firebase is configured with real client credentials, attempt Firebase sign-in first
      if (isFirebaseConfigured()) {
        try {
          const { idToken } = await signInWithFirebase(email, pass);
          return await this.loginWithFirebase(idToken);
        } catch (fbErr: any) {
          console.warn('[apiClient] Firebase client sign-in unavailable, proceeding with institutional credential login:', fbErr?.message);
        }
      }

      // 2. Authoritative institutional email & password login against server SQLite user_accounts
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password: pass })
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || err.error || 'Authentication failed. Please verify credentials.');
      }

      const data = await res.json();
      activeToken = data.token;
      activeRole = data.user?.role || 'VIEWER';
      if (typeof window !== 'undefined') {
        localStorage.setItem('bdt_auth_token', data.token);
        localStorage.setItem('bdt_auth_role', activeRole);
      }
      return data;
    },

    async loginWithFirebase(idToken: string): Promise<any> {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || 'Firebase login verification failed');
      }
      const data = await res.json();
      activeToken = data.token;
      activeRole = data.user?.role || 'VIEWER';
      if (typeof window !== 'undefined') {
        localStorage.setItem('bdt_auth_token', data.token);
        localStorage.setItem('bdt_auth_role', activeRole);
      }
      return data;
    },

    async logout(): Promise<void> {
      try {
        await fetch(`${API_BASE}/auth/logout`, {
          method: 'POST',
          headers: getAuthHeaders()
        }).catch(() => {});
        await signOutFirebase().catch(() => {});
      } finally {
        activeToken = null;
        activeRole = 'VIEWER';
        if (typeof window !== 'undefined') {
          localStorage.removeItem('bdt_auth_token');
          localStorage.removeItem('bdt_auth_role');
        }
      }
    }
  },

  // Production CSV Management Pipeline
  csvPipeline: {
    async upload(csvContent: string, fileName: string): Promise<any> {
      const res = await fetch(`${API_BASE}/csv/upload`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ csvContent, fileName })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Upload failed (${res.status})`);
      }
      return await res.json();
    },

    async preview(sessionId: string): Promise<any> {
      const res = await fetch(`${API_BASE}/csv/preview/${sessionId}`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Preview failed (${res.status})`);
      }
      return await res.json();
    },

    async approve(sessionId: string, reviewNote?: string): Promise<any> {
      const res = await fetch(`${API_BASE}/csv/approve/${sessionId}`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ reviewNote })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Approval failed (${res.status})`);
      }
      return await res.json();
    },

    async commit(sessionId: string): Promise<any> {
      const res = await fetch(`${API_BASE}/csv/commit/${sessionId}`, {
        method: 'POST',
        headers: getAuthHeaders()
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Commit failed (${res.status})`);
      }
      return await res.json();
    },

    getExportUrl(): string {
      return `${API_BASE}/csv/export`;
    }
  },

  // Immutable Audit Log Service
  audit: {
    async query(params?: {
      action?: string;
      userId?: string;
      resource?: string;
      limit?: number;
      offset?: number;
    }): Promise<{ total: number; logs: any[] }> {
      const url = new URL(`${window.location.origin}${API_BASE}/audit-logs`);
      if (params?.action) url.searchParams.set('action', params.action);
      if (params?.userId) url.searchParams.set('userId', params.userId);
      if (params?.resource) url.searchParams.set('resource', params.resource);
      if (params?.limit) url.searchParams.set('limit', String(params.limit));
      if (params?.offset) url.searchParams.set('offset', String(params.offset));

      const res = await fetch(url.toString(), {
        headers: getAuthHeaders()
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Failed to query audit logs (${res.status})`);
      }
      return await res.json();
    }
  },

  // Authoritative Machine Learning Prediction Service
  ml: {
    async predict(payload: { projectId?: string; features?: any }): Promise<{
      success: boolean;
      prediction?: {
        delay_probability: number;
        raw_probability: number;
        risk_level: 'HIGH' | 'MEDIUM' | 'LOW';
      };
      model?: {
        model_version: string;
        model_type: string;
        algorithm: string;
        status: string;
      };
      metadata?: {
        prediction_timestamp?: string;
        feature_schema_version?: string;
        dataset_version?: string;
        artifact_sha256?: string;
        input_features?: any;
        imputed_features?: string[];
        projectId?: string;
        feature_provenance?: string;
      };
      error?: string;
      error_code?: string;
    }> {
      const res = await fetch(`${API_BASE}/ml/predict`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `ML prediction failed (HTTP ${res.status})`);
      }
      return await res.json();
    },

    async getModelInfo(): Promise<any> {
      const res = await fetch(`${API_BASE}/ml/model-info`);
      if (!res.ok) {
        throw new Error(`Failed to retrieve model info (HTTP ${res.status})`);
      }
      return await res.json();
    },

    async getReadinessAudit(): Promise<any> {
      const res = await fetch(`${API_BASE}/ml/readiness-audit`);
      if (!res.ok) {
        throw new Error(`Failed to retrieve readiness audit (HTTP ${res.status})`);
      }
      return await res.json();
    },

    async getDatasetSummary(): Promise<any> {
      const res = await fetch(`${API_BASE}/ml/dataset/summary`);
      if (!res.ok) {
        throw new Error(`Failed to retrieve dataset summary (HTTP ${res.status})`);
      }
      return await res.json();
    }
  },

  shadow: {
    async getDiagnostics(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/diagnostics`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) {
        throw new Error(`Failed to load shadow diagnostics (HTTP ${res.status})`);
      }
      return await res.json();
    },

    async getRuns(params?: { projectId?: string; predictionState?: string; limit?: number; offset?: number }): Promise<any> {
      const q = new URLSearchParams();
      if (params?.projectId) q.append('projectId', params.projectId);
      if (params?.predictionState) q.append('predictionState', params.predictionState);
      if (params?.limit) q.append('limit', String(params.limit));
      if (params?.offset) q.append('offset', String(params.offset));
      const res = await fetch(`${API_BASE}/shadow/runs?${q.toString()}`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) {
        throw new Error(`Failed to load shadow runs (HTTP ${res.status})`);
      }
      return await res.json();
    },

    async score(payload: any): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/score`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        throw new Error(`Shadow scoring request failed (HTTP ${res.status})`);
      }
      return await res.json();
    },

    // Phase 7B-6: Shadow Monitoring APIs
    async getMonitoringSummary(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/monitoring/summary`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load shadow monitoring summary (${res.status})`);
      return await res.json();
    },

    async getEvidenceCoverage(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/monitoring/evidence`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load evidence coverage (${res.status})`);
      return await res.json();
    },

    async getFeatureSnapshots(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/monitoring/features`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load feature snapshots (${res.status})`);
      return await res.json();
    },

    async getDriftReport(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/monitoring/drift`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load drift report (${res.status})`);
      return await res.json();
    },

    async getPredictionDistribution(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/monitoring/predictions`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load prediction distribution (${res.status})`);
      return await res.json();
    },

    async getOutcomes(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/monitoring/outcomes`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load eventual outcomes (${res.status})`);
      return await res.json();
    },

    async getPerformanceMetrics(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/monitoring/performance`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load performance metrics (${res.status})`);
      return await res.json();
    },

    async runMonitoringCycle(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/monitoring/run`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Failed to execute monitoring cycle (${res.status})`);
      }
      return await res.json();
    },

    async reconcileOutcomes(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/monitoring/outcomes/reconcile`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Failed to reconcile outcomes (${res.status})`);
      }
      return await res.json();
    },

    async getEvaluationSummary(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/evaluation/summary`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load evaluation summary (${res.status})`);
      return await res.json();
    },

    async getEvaluationRuns(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/evaluation/runs`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load evaluation runs (${res.status})`);
      return await res.json();
    },

    async runEvaluationCycle(options?: any): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/evaluation/run`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(options || {})
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Failed to execute evaluation run (${res.status})`);
      }
      return await res.json();
    },

    async getEvaluationExclusions(runId?: string): Promise<any> {
      const url = runId
        ? `${API_BASE}/shadow/evaluation/exclusions?runId=${encodeURIComponent(runId)}`
        : `${API_BASE}/shadow/evaluation/exclusions`;
      const res = await fetch(url, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error(`Failed to load exclusions (${res.status})`);
      return await res.json();
    },

    async getEvaluationThresholds(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/evaluation/thresholds`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load diagnostic thresholds (${res.status})`);
      return await res.json();
    },

    async getEvaluationCalibration(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/evaluation/calibration`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load calibration (${res.status})`);
      return await res.json();
    },

    async getEvidencePackage(): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/evaluation/evidence-package`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load evidence package (${res.status})`);
      return await res.json();
    },

    async getProjectShadowDiagnostic(projectId: string): Promise<any> {
      const res = await fetch(`${API_BASE}/shadow/project/${encodeURIComponent(projectId)}`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`Failed to load project shadow diagnostic (${res.status})`);
      return await res.json();
    }
  }
};

