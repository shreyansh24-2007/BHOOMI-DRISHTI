/**
 * BHOOMI-DRISHTI CLIENT-SIDE FIREBASE & AUTHENTICATION INTEGRATION
 * Phase 0.6: Real Firebase Authentication client initialization.
 * 
 * Secure configuration principles:
 * - Credentials loaded exclusively from Vite environment variables (VITE_FIREBASE_*).
 * - No hardcoded secrets.
 * - Server-side verification for every token.
 */

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
  Auth as FirebaseAuth
} from 'firebase/auth';

// Vite environment variables for Firebase
const metaEnv = ((import.meta as any).env || {}) as Record<string, string>;
const firebaseConfig = {
  apiKey: metaEnv.VITE_FIREBASE_API_KEY || '',
  authDomain: metaEnv.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: metaEnv.VITE_FIREBASE_PROJECT_ID || 'bhoomi-drishti',
  storageBucket: metaEnv.VITE_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: metaEnv.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: metaEnv.VITE_FIREBASE_APP_ID || ''
};

export const isFirebaseConfigured = (): boolean => {
  return Boolean(
    firebaseConfig.apiKey &&
    firebaseConfig.apiKey.length > 5 &&
    firebaseConfig.authDomain &&
    firebaseConfig.projectId
  );
};

let app: FirebaseApp | null = null;
let auth: FirebaseAuth | null = null;

if (typeof window !== 'undefined' && isFirebaseConfigured()) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    auth = getAuth(app);
  } catch (err) {
    console.warn('[BhoomiDrishti Auth] Firebase client initialization skipped or failed:', err);
  }
}

export const getFirebaseAuth = (): FirebaseAuth | null => auth;

/**
 * Signs in via Firebase Authentication and retrieves the genuine ID Token.
 */
export async function signInWithFirebase(email: string, pass: string): Promise<{ idToken: string; user: FirebaseUser }> {
  if (!auth) {
    throw new Error('Firebase Authentication is not configured in client environment variables.');
  }
  const credential = await signInWithEmailAndPassword(auth, email, pass);
  const idToken = await credential.user.getIdToken(true);
  return { idToken, user: credential.user };
}

/**
 * Retrieves the current active Firebase user's fresh ID token.
 */
export async function getCurrentFirebaseIdToken(): Promise<string | null> {
  if (!auth || !auth.currentUser) return null;
  try {
    return await auth.currentUser.getIdToken(false);
  } catch {
    return null;
  }
}

/**
 * Signs out of Firebase Authentication.
 */
export async function signOutFirebase(): Promise<void> {
  if (auth && auth.currentUser) {
    await firebaseSignOut(auth);
  }
}

/**
 * Subscribes to Firebase Auth state transitions.
 */
export function onFirebaseAuthStateChanged(callback: (user: FirebaseUser | null) => void): () => void {
  if (!auth) {
    callback(null);
    return () => {};
  }
  return onAuthStateChanged(auth, callback);
}
