#!/usr/bin/env tsx
/**
 * BhoomiDrishti Phase 3.5: What-If Scenario Analysis Verification & Audit Suite
 * Covers all 16 required tests from Phase 3.5 Master Prompt
 */

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execSync } from 'node:child_process';
import { getDatabase } from '../src/server/database.ts';
import { mlBridge } from '../src/server/mlPredictionBridge.ts';

const CANONICAL_MODEL_SHA256 = '7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f';
const MODEL_PATH = path.resolve(process.cwd(), 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib');

function computeFileSha256(filePath: string): string {
  const buffer = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

async function runTests() {
  console.log('===============================================================');
  console.log('  BHOOMI-DRISHTI PHASE 3.5: WHAT-IF SCENARIO ANALYSIS AUDIT');
  console.log('  Model: BHOOMI-DRISHTI-ML-V1.0 (Status: EXPERIMENTAL)');
  console.log('===============================================================\n');

  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void> | void) {
    try {
      await fn();
      console.log(`  ✓ ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  ✗ ${name}`);
      console.error(`    Error: ${err.message}`);
      failed++;
    }
  }

  // Pre-test DB snapshot
  const db = getDatabase();
  const preTotal = (db.prepare('SELECT count(*) as c FROM ml_labelled_observations').get() as any).c;
  const preEligible = (db.prepare('SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1').get() as any).c;
  const preDelayed = (db.prepare("SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1 AND label = 'VERIFIED_DELAYED'").get() as any).c;
  const preNotDelayed = (db.prepare("SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1 AND label = 'VERIFIED_NOT_DELAYED'").get() as any).c;
  const preProjects = (db.prepare('SELECT count(*) as c FROM projects').get() as any).c;
  const preModelSha = computeFileSha256(MODEL_PATH);

  // -------------------------------------------------------------------------
  // TEST 1: Model Loading
  // -------------------------------------------------------------------------
  await test('TEST 01: Model Loading — Validated model loads successfully and verifies integrity', () => {
    const info = mlBridge.getModelInfo();
    assert.equal(info.model_version, 'BHOOMI-DRISHTI-ML-V1.0');
    assert.equal(info.integrity_verified, true);
    assert.equal(info.expected_sha256, CANONICAL_MODEL_SHA256);
    assert.equal(info.actual_sha256, CANONICAL_MODEL_SHA256);
    assert.equal(info.status, 'EXPERIMENTAL');
  });

  // -------------------------------------------------------------------------
  // TEST 2: Baseline Parity
  // -------------------------------------------------------------------------
  await test('TEST 02: Baseline Parity — Direct project prediction matches What-If baseline probability exactly', async () => {
    const directPred = await mlBridge.predictForProject('NHAI-2026-001');
    assert.equal(directPred.success, true);
    assert.ok(directPred.prediction);

    const whatIf = await mlBridge.runWhatIfScenario({ projectId: 'NHAI-2026-001', changes: {} });
    assert.equal(whatIf.success, true);
    assert.ok(whatIf.baseline);

    const diff = Math.abs(directPred.prediction.raw_probability - whatIf.baseline.raw_probability);
    assert.ok(diff < 1e-6, `Baseline parity diff ${diff} exceeds 1e-6 tolerance`);
    assert.equal(directPred.prediction.delay_probability, whatIf.baseline.delay_probability);
    assert.equal(directPred.prediction.risk_level, whatIf.baseline.risk_level);
  });

  // -------------------------------------------------------------------------
  // TEST 3: Single Feature Scenario
  // -------------------------------------------------------------------------
  await test('TEST 03: Single Feature Scenario — Modifying one valid feature produces bounded output and leaves DB unchanged', async () => {
    // Record DB state of NHAI-2026-001 before
    const beforeRow = db.prepare('SELECT compensation_disbursed_percent FROM projects WHERE id = ?').get('NHAI-2026-001') as any;

    const res = await mlBridge.runWhatIfScenario({
      projectId: 'NHAI-2026-001',
      changes: {
        comp_disbursed_percent_at_t: 85.0
      }
    });

    assert.equal(res.success, true);
    assert.ok(res.scenario.delay_probability >= 0.0 && res.scenario.delay_probability <= 1.0);
    assert.ok(res.changed_features.comp_disbursed_percent_at_t);
    assert.equal(res.changed_features.comp_disbursed_percent_at_t.to, 85.0);
    assert.equal(Object.keys(res.changed_features).length, 1);
    assert.equal(Object.keys(res.unchanged_features).length, 8);

    // Verify DB project row was not modified
    const afterRow = db.prepare('SELECT compensation_disbursed_percent FROM projects WHERE id = ?').get('NHAI-2026-001') as any;
    assert.equal(beforeRow.compensation_disbursed_percent, afterRow.compensation_disbursed_percent);
  });

  // -------------------------------------------------------------------------
  // TEST 4: Multi-Feature Scenario
  // -------------------------------------------------------------------------
  await test('TEST 04: Multi-Feature Scenario — Multiple hypothetical interventions evaluated simultaneously', async () => {
    const res = await mlBridge.runWhatIfScenario({
      projectId: 'NHAI-2026-001',
      changes: {
        comp_disbursed_percent_at_t: 90.0,
        active_court_stays_at_t: 0,
        incomplete_docs_count_at_t: 2,
        forest_clearance_at_t: 'Stage 2 Approved'
      }
    });

    assert.equal(res.success, true);
    assert.ok(res.scenario.delay_probability >= 0.0 && res.scenario.delay_probability <= 1.0);
    assert.equal(Object.keys(res.changed_features).length, 4);
    assert.equal(Object.keys(res.unchanged_features).length, 5);
    assert.equal(res.changed_features.comp_disbursed_percent_at_t.to, 90.0);
    assert.equal(res.changed_features.active_court_stays_at_t.to, 0);
    assert.equal(res.changed_features.incomplete_docs_count_at_t.to, 2);
    assert.equal(res.changed_features.forest_clearance_at_t.to, 'Stage 2 Approved');
  });

  // -------------------------------------------------------------------------
  // TEST 5: No-Change Scenario
  // -------------------------------------------------------------------------
  await test('TEST 05: No-Change Scenario — Empty changes object produces identical baseline and scenario predictions', async () => {
    const res = await mlBridge.runWhatIfScenario({
      projectId: 'NHAI-2026-001',
      changes: {}
    });

    assert.equal(res.success, true);
    assert.equal(res.change.absolute_probability_change, 0.0);
    assert.equal(res.change.percentage_point_change, 0.0);
    assert.equal(res.baseline.delay_probability, res.scenario.delay_probability);
    assert.equal(res.baseline.risk_level, res.scenario.risk_level);
    assert.equal(Object.keys(res.changed_features).length, 0);
    assert.equal(Object.keys(res.unchanged_features).length, 9);
  });

  // -------------------------------------------------------------------------
  // TEST 6: NULL Elapsed Days
  // -------------------------------------------------------------------------
  await test('TEST 06: NULL Elapsed Days — Project with null elapsed days runs safely via SimpleImputer without DB mutation', async () => {
    // NHAI-2026-001 has null elapsed_days_since_3a_at_t
    const res = await mlBridge.runWhatIfScenario({
      projectId: 'NHAI-2026-001',
      changes: {
        unresolved_cases_at_t: 0
      }
    });

    assert.equal(res.success, true);
    assert.equal(res.unchanged_features.elapsed_days_since_3a_at_t, null);
    assert.ok(typeof res.scenario.delay_probability === 'number');
    assert.ok(res.scenario.delay_probability >= 0.0 && res.scenario.delay_probability <= 1.0);
  });

  // -------------------------------------------------------------------------
  // TEST 7: Invalid Binary Value
  // -------------------------------------------------------------------------
  await test('TEST 07: Invalid Binary Value — Non-binary initial_sanction_amount_available rejected with INVALID_FEATURE_INPUT', async () => {
    const res = await mlBridge.runWhatIfScenario({
      projectId: 'NHAI-2026-001',
      changes: {
        initial_sanction_amount_available: 2
      }
    });

    assert.equal(res.success, false);
    assert.equal(res.error_code, 'INVALID_FEATURE_INPUT');
    assert.ok(res.error.includes('strictly'));
  });

  // -------------------------------------------------------------------------
  // TEST 8: Negative Count
  // -------------------------------------------------------------------------
  await test('TEST 08: Negative Count — Negative court stays or cases rejected with INVALID_FEATURE_INPUT', async () => {
    const resStays = await mlBridge.runWhatIfScenario({
      projectId: 'NHAI-2026-001',
      changes: {
        active_court_stays_at_t: -1
      }
    });
    assert.equal(resStays.success, false);
    assert.equal(resStays.error_code, 'INVALID_FEATURE_INPUT');

    const resCases = await mlBridge.runWhatIfScenario({
      projectId: 'NHAI-2026-001',
      changes: {
        unresolved_cases_at_t: -5
      }
    });
    assert.equal(resCases.success, false);
    assert.equal(resCases.error_code, 'INVALID_FEATURE_INPUT');
  });

  // -------------------------------------------------------------------------
  // TEST 9: Unknown Project
  // -------------------------------------------------------------------------
  await test('TEST 09: Unknown Project — Nonexistent project ID returns PROJECT_NOT_FOUND', async () => {
    const res = await mlBridge.runWhatIfScenario({
      projectId: 'NONEXISTENT_PROJECT_9999',
      changes: {
        comp_disbursed_percent_at_t: 50.0
      }
    });

    assert.equal(res.success, false);
    assert.equal(res.error_code, 'PROJECT_NOT_FOUND');
  });

  // -------------------------------------------------------------------------
  // TEST 10: Probability Range
  // -------------------------------------------------------------------------
  await test('TEST 10: Probability Range — Every probability is finite, non-NaN, and strictly within [0.0, 1.0]', async () => {
    const projects = ['NHAI-2026-001', 'DFCC-2026-012', 'NHAI-2026-034'];
    for (const pid of projects) {
      const res = await mlBridge.runWhatIfScenario({
        projectId: pid,
        changes: { comp_disbursed_percent_at_t: 60.0 }
      });
      assert.equal(res.success, true);
      assert.ok(Number.isFinite(res.baseline.delay_probability));
      assert.ok(Number.isFinite(res.scenario.delay_probability));
      assert.ok(!isNaN(res.baseline.delay_probability));
      assert.ok(!isNaN(res.scenario.delay_probability));
      assert.ok(res.baseline.delay_probability >= 0.0 && res.baseline.delay_probability <= 1.0);
      assert.ok(res.scenario.delay_probability >= 0.0 && res.scenario.delay_probability <= 1.0);
    }
  });

  // -------------------------------------------------------------------------
  // TEST 11: Risk Threshold Consistency
  // -------------------------------------------------------------------------
  await test('TEST 11: Risk Threshold Consistency — Classification logic matches Phase 3 thresholds strictly', async () => {
    // Check mapping function
    const direct = await mlBridge.predictForProject('NHAI-2026-001');
    const whatIf = await mlBridge.runWhatIfScenario({ projectId: 'NHAI-2026-001', changes: {} });
    assert.equal(direct.prediction?.risk_level, whatIf.baseline.risk_level);

    // Verify thresholds explicitly
    const highSample = await mlBridge.predict({
      stage_at_t: 'Section 3C Objections / Pre-3D',
      land_acquired_ratio_at_t: 0.1,
      comp_disbursed_percent_at_t: 10.0,
      active_court_stays_at_t: 3,
      unresolved_cases_at_t: 10,
      incomplete_docs_count_at_t: 20,
      forest_clearance_at_t: 'Stage 2 Pending',
      elapsed_days_since_3a_at_t: 800.0,
      initial_sanction_amount_available: 0
    });
    if (highSample.prediction!.delay_probability >= 0.70) {
      assert.equal(highSample.prediction!.risk_level, 'HIGH');
    } else if (highSample.prediction!.delay_probability >= 0.35) {
      assert.equal(highSample.prediction!.risk_level, 'MEDIUM');
    } else {
      assert.equal(highSample.prediction!.risk_level, 'LOW');
    }
  });

  // -------------------------------------------------------------------------
  // TEST 12: Database Immutability
  // -------------------------------------------------------------------------
  await test('TEST 12: Database Immutability — Zero mutations across observations, labels, or projects', () => {
    const postTotal = (db.prepare('SELECT count(*) as c FROM ml_labelled_observations').get() as any).c;
    const postEligible = (db.prepare('SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1').get() as any).c;
    const postDelayed = (db.prepare("SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1 AND label = 'VERIFIED_DELAYED'").get() as any).c;
    const postNotDelayed = (db.prepare("SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1 AND label = 'VERIFIED_NOT_DELAYED'").get() as any).c;
    const postProjects = (db.prepare('SELECT count(*) as c FROM projects').get() as any).c;

    assert.equal(postTotal, preTotal, `Total observations changed: was ${preTotal}, now ${postTotal}`);
    assert.equal(postEligible, preEligible, `Eligible observations changed: was ${preEligible}, now ${postEligible}`);
    assert.equal(postDelayed, preDelayed, `Delayed observations changed: was ${preDelayed}, now ${postDelayed}`);
    assert.equal(postNotDelayed, preNotDelayed, `Not delayed observations changed: was ${preNotDelayed}, now ${postNotDelayed}`);
    assert.equal(postProjects, preProjects, `Projects changed: was ${preProjects}, now ${postProjects}`);

    // Authoritative totals check
    assert.equal(postTotal, 3054);
    assert.equal(postEligible, 2871);
    assert.equal(postDelayed, 964);
    assert.equal(postNotDelayed, 1907);

    const pragmaRes = (db.prepare('PRAGMA integrity_check').get() as any).integrity_check;
    assert.equal(pragmaRes, 'ok');
  });

  // -------------------------------------------------------------------------
  // TEST 13: Model Immutability
  // -------------------------------------------------------------------------
  await test('TEST 13: Model Immutability — Artifact SHA-256 hash remains 100% untouched', () => {
    const currentHash = computeFileSha256(MODEL_PATH);
    assert.equal(currentHash, CANONICAL_MODEL_SHA256);
    assert.equal(currentHash, preModelSha);
  });

  // -------------------------------------------------------------------------
  // TEST 14: Existing Phase 3 Regression
  // -------------------------------------------------------------------------
  await test('TEST 14: Existing Phase 3 Regression — All 14 tests in run_phase_3_tests.ts pass cleanly', () => {
    const output = execSync('npx tsx scripts/run_phase_3_tests.ts', { encoding: 'utf-8' });
    assert.ok(output.includes('PHASE 3 TEST RESULTS: 14 PASSED, 0 FAILED (TOTAL: 14)'));
    assert.ok(output.includes('ALL PHASE 3 TESTS & PARITY AUDIT COMPLETED SUCCESSFULLY.'));
  });

  // -------------------------------------------------------------------------
  // TEST 15: No Scenario Leakage
  // -------------------------------------------------------------------------
  await test('TEST 15: No Scenario Leakage — Scenario simulations never persist as observations or training data', () => {
    const scenarioObs = db.prepare("SELECT count(*) as c FROM ml_labelled_observations WHERE id LIKE '%scenario%' OR id LIKE '%whatif%'").get() as any;
    assert.equal(scenarioObs.c, 0);

    const versionRow = db.prepare("SELECT id FROM ml_dataset_versions WHERE id = 'BHOOMI-DRISHTI-HIST-V1.1-REMEDIATED'").get() as any;
    assert.ok(versionRow, 'Must have BHOOMI-DRISHTI-HIST-V1.1-REMEDIATED dataset version record');
    assert.equal(versionRow.id, 'BHOOMI-DRISHTI-HIST-V1.1-REMEDIATED');
  });

  // -------------------------------------------------------------------------
  // TEST 16: Direct Pipeline Parity (25 Records)
  // -------------------------------------------------------------------------
  await test('TEST 16: Direct Pipeline Parity — 25-record parity between direct Python pipeline and What-If baseline', async () => {
    // Query 25 eligible training observations joined with their feature snapshots
    const rows = db.prepare(`
      SELECT 
        o.id as obs_id,
        o.project_id,
        s.stage_at_t,
        s.land_acquired_ratio_at_t,
        s.comp_disbursed_percent_at_t,
        s.active_court_stays_at_t,
        s.unresolved_cases_at_t,
        s.incomplete_docs_count_at_t,
        s.forest_clearance_at_t,
        s.elapsed_days_since_3a_at_t,
        s.snapshot_features_json
      FROM ml_labelled_observations o
      JOIN ml_project_snapshots s ON o.snapshot_id = s.id
      WHERE o.is_eligible_for_training = 1
      ORDER BY o.id ASC
      LIMIT 25;
    `).all() as any[];

    assert.equal(rows.length, 25);

    // Build batch of features
    const featureList: any[] = [];
    for (const r of rows) {
      let sanctionAvail = 0;
      try {
        const parsed = JSON.parse(r.snapshot_features_json || '{}');
        sanctionAvail = parsed.initialSanctionAmountAvailable === 1 || parsed.initialSanctionAmountAvailable === '1' ? 1 : 0;
      } catch {}

      featureList.push({
        obs_id: r.obs_id,
        stage_at_t: r.stage_at_t,
        land_acquired_ratio_at_t: Number(r.land_acquired_ratio_at_t),
        comp_disbursed_percent_at_t: Number(r.comp_disbursed_percent_at_t),
        active_court_stays_at_t: Number(r.active_court_stays_at_t),
        unresolved_cases_at_t: Number(r.unresolved_cases_at_t),
        incomplete_docs_count_at_t: Number(r.incomplete_docs_count_at_t),
        forest_clearance_at_t: r.forest_clearance_at_t,
        elapsed_days_since_3a_at_t: r.elapsed_days_since_3a_at_t !== null ? Number(r.elapsed_days_since_3a_at_t) : null,
        initial_sanction_amount_available: sanctionAvail
      });
    }

    // Direct Python pipeline batch inference
    const batchPythonScript = `
import joblib, json, sys, pandas as pd
pipe = joblib.load("data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib")
records = json.loads(sys.stdin.read())
df = pd.DataFrame([{
    "land_acquired_ratio_at_t": f["land_acquired_ratio_at_t"],
    "comp_disbursed_percent_at_t": f["comp_disbursed_percent_at_t"],
    "active_court_stays_at_t": f["active_court_stays_at_t"],
    "unresolved_cases_at_t": f["unresolved_cases_at_t"],
    "incomplete_docs_count_at_t": f["incomplete_docs_count_at_t"],
    "elapsed_days_since_3a_at_t": f["elapsed_days_since_3a_at_t"],
    "initial_sanction_amount_available": f["initial_sanction_amount_available"],
    "stage_at_t": f["stage_at_t"],
    "forest_clearance_at_t": f["forest_clearance_at_t"]
} for f in records])
probs = pipe.predict_proba(df)[:, 1].tolist()
print(json.dumps(probs))
`;

    const { execFileSync } = await import('node:child_process');
    const directProbsJson = execFileSync('python3', ['-c', batchPythonScript], {
      input: JSON.stringify(featureList),
      encoding: 'utf-8'
    }).trim();
    const directProbs: number[] = JSON.parse(directProbsJson);

    console.log('\n  --- 25-RECORD DIRECT PIPELINE PARITY AUDIT ---');
    let maxDiff = 0;
    let mismatches = 0;

    for (let i = 0; i < 25; i++) {
      const feat = featureList[i];
      const directProb = directProbs[i];

      // Predict via ML bridge
      const apiPred = await mlBridge.predict(feat);
      assert.equal(apiPred.success, true);
      const apiProb = apiPred.prediction!.raw_probability;

      const diff = Math.abs(directProb - apiProb);
      if (diff > maxDiff) maxDiff = diff;
      if (diff > 1e-6) mismatches++;

      const numStr = String(i + 1).padStart(2, '0');
      console.log(`    Record [${numStr}/25] ${feat.obs_id}: Direct=${directProb.toFixed(6)}, Bridge=${apiProb.toFixed(6)}, Diff=${diff.toExponential(4)} [MATCH]`);
    }

    console.log(`  Parity Mismatches: ${mismatches}, Max Difference: ${maxDiff.toExponential(4)}\n`);
    assert.equal(mismatches, 0, 'Found parity mismatches between direct Python pipeline and What-If bridge');
    assert.ok(maxDiff <= 1e-6, `Maximum difference ${maxDiff} exceeds 1e-6 tolerance`);
  });

  console.log('===============================================================');
  console.log(`  PHASE 3.5 TEST RESULTS: ${passed} PASSED, ${failed} FAILED (TOTAL: ${passed + failed})`);
  console.log('===============================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
  process.exit(0);
}

runTests().catch(err => {
  console.error('Fatal error running Phase 3.5 tests:', err);
  process.exit(1);
});
