import { DatabaseSync } from 'node:sqlite';

const db = new DatabaseSync('data/bhoomidrishti.db');

console.log('--- TEMPORAL BY YEAR ---');
const obsByYear = db.prepare(`
  SELECT SUBSTR(o.prediction_timestamp, 1, 4) as yr,
         count(*) as total_obs,
         count(DISTINCT o.project_id) as projs,
         count(DISTINCT p.highway_number || '_' || p.state) as corrs
  FROM ml_labelled_observations o
  JOIN ml_historical_projects p ON o.project_id = p.id
  WHERE o.is_eligible_for_training = 1
  GROUP BY yr
  ORDER BY yr ASC
`).all();
console.table(obsByYear);

console.log('--- MIN AND MAX TIMESTAMPS ---');
const times = db.prepare(`
  SELECT min(prediction_timestamp) as min_t, max(prediction_timestamp) as max_t
  FROM ml_labelled_observations
  WHERE is_eligible_for_training = 1
`).get();
console.log(times);

console.log('--- TOP 10 STATES BY OBSERVATIONS ---');
const states = db.prepare(`
  SELECT p.state,
         count(*) as obs,
         count(DISTINCT p.id) as projs,
         count(DISTINCT p.highway_number || '_' || p.state) as corrs
  FROM ml_historical_projects p
  JOIN ml_labelled_observations o ON p.id = o.project_id
  WHERE o.is_eligible_for_training = 1
  GROUP BY p.state
  ORDER BY obs DESC
`).all();
console.table(states.slice(0, 15));
console.log('Total unique states:', states.length);

console.log('--- TOP AGENCIES ---');
const agencies = db.prepare(`
  SELECT p.agency,
         count(*) as obs,
         count(DISTINCT p.id) as projs,
         count(DISTINCT p.highway_number || '_' || p.state) as corrs
  FROM ml_historical_projects p
  JOIN ml_labelled_observations o ON p.id = o.project_id
  WHERE o.is_eligible_for_training = 1
  GROUP BY p.agency
  ORDER BY obs DESC
`).all();
console.table(agencies);

console.log('--- 6 NULL ELAPSED DAYS CHECK ---');
const nullObs = db.prepare(`
  SELECT o.id, o.project_id, s.id as snap_id, s.stage_at_t, o.prediction_timestamp, o.label
  FROM ml_labelled_observations o
  JOIN ml_project_snapshots s ON o.snapshot_id = s.id
  WHERE o.is_eligible_for_training = 1 AND s.elapsed_days_since_3a_at_t IS NULL
`).all();
console.table(nullObs);

console.log('--- CHECK PROJECT CORRIDOR COUNTS ---');
const totalProjs = (db.prepare('SELECT count(DISTINCT project_id) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1').get() as any).c;
const totalCorrs = (db.prepare("SELECT count(DISTINCT p.highway_number || '_' || p.state) as c FROM ml_historical_projects p JOIN ml_labelled_observations o ON p.id = o.project_id WHERE o.is_eligible_for_training = 1 AND p.highway_number IS NOT NULL AND p.state IS NOT NULL").get() as any).c;
const nullCorrProjs = (db.prepare("SELECT count(DISTINCT p.id) as c FROM ml_historical_projects p JOIN ml_labelled_observations o ON p.id = o.project_id WHERE o.is_eligible_for_training = 1 AND (p.highway_number IS NULL OR p.state IS NULL)").get() as any).c;
console.log('Total unique projects:', totalProjs);
console.log('Total unique non-null corridors (highway+state):', totalCorrs);
console.log('Projects with null highway or state:', nullCorrProjs);
