#!/usr/bin/env python3
"""
BhoomiDrishti Phase 3: ML Model Prediction & Inference Service
Model Artifact: BHOOMI-DRISHTI-ML-V1.0 (Status: EXPERIMENTAL)
Canonical Pipeline: data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib
SHA-256: 7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f
"""

import os
import sys
import json
import hashlib
import datetime
import traceback
import joblib
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier

EXPECTED_MODEL_SHA256 = "7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f"
DEFAULT_MODEL_PATH = "data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib"
SCHEMA_PATH = "data/ml_models/BHOOMI-DRISHTI-ML-V1.0/feature_schema.json"

APPROVED_FEATURES = [
    "stage_at_t",
    "land_acquired_ratio_at_t",
    "comp_disbursed_percent_at_t",
    "active_court_stays_at_t",
    "unresolved_cases_at_t",
    "incomplete_docs_count_at_t",
    "forest_clearance_at_t",
    "elapsed_days_since_3a_at_t",
    "initial_sanction_amount_available"
]

FORBIDDEN_FEATURES = [
    "delayProbability",
    "delay_probability",
    "riskLevel",
    "risk_level",
    "initial_sanction_amount_cr",
    "project_id",
    "corridor_id",
    "state",
    "highway_number",
    "binary_target",
    "label"
]

class MLModelService:
    def __init__(self, model_path=DEFAULT_MODEL_PATH):
        self.model_path = model_path
        self.pipeline = None
        self.model_version = "BHOOMI-DRISHTI-ML-V1.0"
        self.dataset_version = "BHOOMI-DRISHTI-HIST-V1.1-REMEDIATED"
        self.feature_schema_version = "1.1.0"
        self.status = "EXPERIMENTAL"
        self.verified_hash = None
        self.load_and_verify()

    def verify_integrity(self):
        if not os.path.exists(self.model_path):
            return False, "MODEL_NOT_FOUND", f"Model artifact not found at {self.model_path}"
        
        hasher = hashlib.sha256()
        with open(self.model_path, "rb") as f:
            while chunk := f.read(65536):
                hasher.update(chunk)
        actual_hash = hasher.hexdigest()
        self.verified_hash = actual_hash
        
        if actual_hash != EXPECTED_MODEL_SHA256:
            return False, "MODEL_INTEGRITY_ERROR", f"SHA-256 mismatch: expected {EXPECTED_MODEL_SHA256}, got {actual_hash}"
            
        return True, "OK", actual_hash

    def load_and_verify(self):
        valid, code, msg = self.verify_integrity()
        if not valid:
            raise RuntimeError(f"[{code}] {msg}")
            
        try:
            self.pipeline = joblib.load(self.model_path)
        except Exception as e:
            raise RuntimeError(f"[MODEL_NOT_FOUND] Failed to deserialize joblib pipeline: {str(e)}")
            
        # Verify classifier type
        if "clf" not in self.pipeline.named_steps:
            raise RuntimeError("[MODEL_INTEGRITY_ERROR] Pipeline missing 'clf' step")
            
        clf = self.pipeline.named_steps["clf"]
        if not isinstance(clf, RandomForestClassifier):
            raise RuntimeError(f"[MODEL_INTEGRITY_ERROR] Expected RandomForestClassifier, got {type(clf)}")
            
        # Verify preprocessor step
        if "prep" not in self.pipeline.named_steps:
            raise RuntimeError("[MODEL_INTEGRITY_ERROR] Pipeline missing 'prep' step")

    def validate_features(self, raw_input):
        """
        Strict validation of the 9 approved features.
        Returns: (is_valid, sanitized_dict_or_error_dict, error_code)
        """
        if not isinstance(raw_input, dict):
            return False, {"error": "Input payload must be a JSON object"}, "INVALID_FEATURE_INPUT"

        # Check for forbidden heuristic/leakage fields passed as features
        for f in FORBIDDEN_FEATURES:
            if f in raw_input and raw_input[f] is not None:
                # If they passed delayProbability as a feature, strictly disallow
                if f in ["delayProbability", "delay_probability", "binary_target", "label"]:
                    return False, {
                        "error": f"Forbidden feature '{f}' detected. Heuristic probabilities and target labels must never be fed into ML model."
                    }, "INVALID_FEATURE_INPUT"

        # Check all 9 approved features exist
        missing = [f for f in APPROVED_FEATURES if f not in raw_input]
        if missing:
            return False, {"error": f"Missing required approved features: {', '.join(missing)}"}, "INVALID_FEATURE_INPUT"

        sanitized = {}
        imputed_features = []

        # 1. stage_at_t (string)
        stage = raw_input.get("stage_at_t")
        if not isinstance(stage, str) or not stage.strip():
            return False, {"error": "stage_at_t must be a non-empty string"}, "INVALID_FEATURE_INPUT"
        sanitized["stage_at_t"] = stage.strip()

        # 2. land_acquired_ratio_at_t (numeric >= 0)
        try:
            lar = float(raw_input.get("land_acquired_ratio_at_t"))
            if np.isnan(lar) or lar < 0:
                return False, {"error": "land_acquired_ratio_at_t must be a non-negative number"}, "INVALID_FEATURE_INPUT"
            sanitized["land_acquired_ratio_at_t"] = lar
        except (ValueError, TypeError):
            return False, {"error": "land_acquired_ratio_at_t must be a valid number"}, "INVALID_FEATURE_INPUT"

        # 3. comp_disbursed_percent_at_t (numeric >= 0)
        try:
            cdp = float(raw_input.get("comp_disbursed_percent_at_t"))
            if np.isnan(cdp) or cdp < 0:
                return False, {"error": "comp_disbursed_percent_at_t must be a non-negative number"}, "INVALID_FEATURE_INPUT"
            sanitized["comp_disbursed_percent_at_t"] = cdp
        except (ValueError, TypeError):
            return False, {"error": "comp_disbursed_percent_at_t must be a valid number"}, "INVALID_FEATURE_INPUT"

        # 4. active_court_stays_at_t (integer >= 0)
        try:
            acs = raw_input.get("active_court_stays_at_t")
            if acs is None or isinstance(acs, bool):
                return False, {"error": "active_court_stays_at_t must be an integer count (not boolean or null)"}, "INVALID_FEATURE_INPUT"
            acs_int = int(acs)
            if acs_int < 0:
                return False, {"error": "active_court_stays_at_t must be non-negative"}, "INVALID_FEATURE_INPUT"
            sanitized["active_court_stays_at_t"] = acs_int
        except (ValueError, TypeError):
            return False, {"error": "active_court_stays_at_t must be an integer"}, "INVALID_FEATURE_INPUT"

        # 5. unresolved_cases_at_t (integer >= 0)
        try:
            uc = raw_input.get("unresolved_cases_at_t")
            if uc is None or isinstance(uc, bool):
                return False, {"error": "unresolved_cases_at_t must be an integer count (not boolean or null)"}, "INVALID_FEATURE_INPUT"
            uc_int = int(uc)
            if uc_int < 0:
                return False, {"error": "unresolved_cases_at_t must be non-negative"}, "INVALID_FEATURE_INPUT"
            sanitized["unresolved_cases_at_t"] = uc_int
        except (ValueError, TypeError):
            return False, {"error": "unresolved_cases_at_t must be an integer"}, "INVALID_FEATURE_INPUT"

        # 6. incomplete_docs_count_at_t (integer >= 0)
        try:
            idc = raw_input.get("incomplete_docs_count_at_t")
            if idc is None or isinstance(idc, bool):
                return False, {"error": "incomplete_docs_count_at_t must be an integer count (not boolean or null)"}, "INVALID_FEATURE_INPUT"
            idc_int = int(idc)
            if idc_int < 0:
                return False, {"error": "incomplete_docs_count_at_t must be non-negative"}, "INVALID_FEATURE_INPUT"
            sanitized["incomplete_docs_count_at_t"] = idc_int
        except (ValueError, TypeError):
            return False, {"error": "incomplete_docs_count_at_t must be an integer"}, "INVALID_FEATURE_INPUT"

        # 7. forest_clearance_at_t (string)
        fc = raw_input.get("forest_clearance_at_t")
        if not isinstance(fc, str) or not fc.strip():
            return False, {"error": "forest_clearance_at_t must be a non-empty string"}, "INVALID_FEATURE_INPUT"
        sanitized["forest_clearance_at_t"] = fc.strip()

        # 8. elapsed_days_since_3a_at_t (numeric >= 0 or None/null)
        raw_elapsed = raw_input.get("elapsed_days_since_3a_at_t")
        if raw_elapsed is None or raw_elapsed == "" or (isinstance(raw_elapsed, str) and raw_elapsed.lower() == "null"):
            sanitized["elapsed_days_since_3a_at_t"] = None
            imputed_features.append("elapsed_days_since_3a_at_t")
        else:
            try:
                el = float(raw_elapsed)
                if np.isnan(el):
                    sanitized["elapsed_days_since_3a_at_t"] = None
                    imputed_features.append("elapsed_days_since_3a_at_t")
                elif el < 0:
                    return False, {"error": "elapsed_days_since_3a_at_t must be non-negative or null"}, "INVALID_FEATURE_INPUT"
                else:
                    sanitized["elapsed_days_since_3a_at_t"] = el
            except (ValueError, TypeError):
                return False, {"error": "elapsed_days_since_3a_at_t must be a number or null"}, "INVALID_FEATURE_INPUT"

        # 9. initial_sanction_amount_available (strictly binary integer 0 or 1)
        raw_isaa = raw_input.get("initial_sanction_amount_available")
        if raw_isaa not in (0, 1, "0", "1", True, False):
            return False, {
                "error": "initial_sanction_amount_available must be binary 0 (unavailable) or 1 (available)"
            }, "INVALID_FEATURE_INPUT"
        try:
            val = int(raw_isaa)
            if val not in (0, 1):
                return False, {"error": "initial_sanction_amount_available must be strictly 0 or 1"}, "INVALID_FEATURE_INPUT"
            sanitized["initial_sanction_amount_available"] = val
        except (ValueError, TypeError):
            return False, {"error": "initial_sanction_amount_available must be 0 or 1"}, "INVALID_FEATURE_INPUT"

        return True, (sanitized, imputed_features), "OK"

    def predict(self, raw_input):
        is_valid, res, err_code = self.validate_features(raw_input)
        if not is_valid:
            return {
                "success": False,
                "error_code": err_code,
                "error": res.get("error", "Validation error")
            }

        sanitized_features, imputed_features = res

        try:
            # Build 1-row DataFrame with exact approved columns in correct schema order
            df = pd.DataFrame([{
                "land_acquired_ratio_at_t": sanitized_features["land_acquired_ratio_at_t"],
                "comp_disbursed_percent_at_t": sanitized_features["comp_disbursed_percent_at_t"],
                "active_court_stays_at_t": sanitized_features["active_court_stays_at_t"],
                "unresolved_cases_at_t": sanitized_features["unresolved_cases_at_t"],
                "incomplete_docs_count_at_t": sanitized_features["incomplete_docs_count_at_t"],
                "elapsed_days_since_3a_at_t": sanitized_features["elapsed_days_since_3a_at_t"],
                "initial_sanction_amount_available": sanitized_features["initial_sanction_amount_available"],
                "stage_at_t": sanitized_features["stage_at_t"],
                "forest_clearance_at_t": sanitized_features["forest_clearance_at_t"]
            }])

            # Execute pipeline prediction
            proba = self.pipeline.predict_proba(df)[0, 1]
            delay_prob = float(proba)

            if np.isnan(delay_prob):
                return {
                    "success": False,
                    "error_code": "MODEL_PREDICTION_ERROR",
                    "error": "Model produced NaN probability"
                }

            # Map to BhoomiDrishti documented risk bands:
            # delayProbability >= 70% -> HIGH, >= 35% -> MEDIUM, < 35% -> LOW
            if delay_prob >= 0.70:
                risk_level = "HIGH"
            elif delay_prob >= 0.35:
                risk_level = "MEDIUM"
            else:
                risk_level = "LOW"

            now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()

            return {
                "success": True,
                "prediction": {
                    "delay_probability": round(delay_prob, 4),
                    "raw_probability": delay_prob,
                    "risk_level": risk_level
                },
                "model": {
                    "model_version": self.model_version,
                    "model_type": "Class-Weighted Random Forest",
                    "algorithm": "RandomForestClassifier(n_estimators=100, max_depth=6, min_samples_leaf=2, class_weight='balanced', random_state=42)",
                    "status": self.status
                },
                "metadata": {
                    "prediction_timestamp": now_iso,
                    "feature_schema_version": self.feature_schema_version,
                    "dataset_version": self.dataset_version,
                    "artifact_sha256": self.verified_hash,
                    "imputed_features": imputed_features,
                    "preprocessing_imputation_policy": {
                        "elapsed_days_since_3a_at_t": "SimpleImputer(strategy='median') ~ 180.0 days"
                    }
                }
            }

        except Exception as e:
            return {
                "success": False,
                "error_code": "MODEL_PREDICTION_ERROR",
                "error": f"Inference execution failed: {str(e)}",
                "trace": traceback.format_exc() if os.environ.get("DEBUG") else None
            }

    def get_info(self):
        return {
            "model_version": self.model_version,
            "dataset_version": self.dataset_version,
            "feature_schema_version": self.feature_schema_version,
            "status": self.status,
            "artifact_path": self.model_path,
            "artifact_sha256": self.verified_hash,
            "integrity_verified": (self.verified_hash == EXPECTED_MODEL_SHA256),
            "approved_features": APPROVED_FEATURES,
            "known_limitations": [
                "Temporal holdout ROC-AUC is 0.5000 due to pre-2025 milestone standardization (zero feature variance).",
                "Model status is strictly EXPERIMENTAL; not certified for autonomous statutory procurement decisions.",
                "elapsed_days_since_3a_at_t represents 83.1% Gini importance (acts as milestone maturity coordinate).",
                "Calibration improves probability Brier score alignment but does not restore temporal discrimination."
            ]
        }

def run_daemon():
    """
    Standard I/O JSON-lines protocol for high-performance low-latency integration.
    Express server talks to this long-running worker.
    """
    try:
        service = MLModelService()
    except Exception as e:
        sys.stderr.write(f"FATAL: Service initialization failed: {e}\n")
        sys.stderr.flush()
        # Output error line so parent process knows
        print(json.dumps({"ready": False, "error": str(e), "error_code": "MODEL_INITIALIZATION_ERROR"}), flush=True)
        sys.exit(1)

    # Signal readiness to parent process
    print(json.dumps({
        "ready": True,
        "model_version": service.model_version,
        "artifact_sha256": service.verified_hash,
        "status": service.status
    }), flush=True)

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            req_id = req.get("id")
            action = req.get("action", "predict")

            if action == "health":
                resp = {"id": req_id, "success": True, "info": service.get_info()}
            elif action == "predict":
                features = req.get("features", {})
                pred_result = service.predict(features)
                resp = {"id": req_id, **pred_result}
            else:
                resp = {"id": req_id, "success": False, "error_code": "UNKNOWN_ACTION", "error": f"Unknown action: {action}"}

            print(json.dumps(resp), flush=True)
        except Exception as err:
            err_resp = {
                "id": req.get("id") if "req" in locals() and isinstance(req, dict) else None,
                "success": False,
                "error_code": "REQUEST_PROCESSING_ERROR",
                "error": str(err)
            }
            print(json.dumps(err_resp), flush=True)

if __name__ == "__main__":
    if "--serve" in sys.argv:
        run_daemon()
    elif "--health" in sys.argv:
        svc = MLModelService()
        print(json.dumps(svc.get_info(), indent=2))
    elif "--predict-json" in sys.argv:
        idx = sys.argv.index("--predict-json")
        if idx + 1 < len(sys.argv):
            json_str = sys.argv[idx + 1]
            features = json.loads(json_str)
            svc = MLModelService()
            result = svc.predict(features)
            print(json.dumps(result, indent=2))
        else:
            print("Error: Missing JSON payload after --predict-json", file=sys.stderr)
            sys.exit(1)
    else:
        # Default verification
        svc = MLModelService()
        info = svc.get_info()
        print("BhoomiDrishti ML Model Service Initialized:")
        print(json.dumps(info, indent=2))
