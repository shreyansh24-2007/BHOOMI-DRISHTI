#!/usr/bin/env python3
"""
BhoomiDrishti Phase 7A-2: Offline Candidate V2 Model Training & Artifact Creation

Strict Governance & Production Safety:
1. Frozen Production ML Artifact: V1.0 remains authoritative (SHA: 7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f).
2. Pure Offline Candidate: V2 is created under data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/ only.
3. No Production Modification: Zero DB changes, zero production prediction alterations, zero threshold activation.
4. Threshold Status: PENDING_STAKEHOLDER_APPROVAL.
5. Exact 10-Feature Schema: SCHEMA-LONGITUDINAL-V2.0-10FEAT on authentic longitudinal dataset.
"""

import os
import sys
import json
import hashlib
import numpy as np
import pandas as pd
import joblib
from datetime import datetime, timezone

from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import (
    roc_auc_score, average_precision_score, precision_score, recall_score,
    f1_score, balanced_accuracy_score, brier_score_loss, log_loss, confusion_matrix
)
from sklearn.model_selection import StratifiedGroupKFold

CANONICAL_V1_SHA256 = '7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f'
EXPECTED_DATASET_SHA256 = '0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a'
V1_MODEL_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib'
DATASET_PATH = 'data/reconstructed_longitudinal_dataset_v2.json'
V2_DIR = 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW'
V2_MODEL_PATH = os.path.join(V2_DIR, 'model_pipeline.joblib')
V2_MANIFEST_PATH = os.path.join(V2_DIR, 'model_manifest.json')
V2_MODEL_CARD_PATH = os.path.join(V2_DIR, 'MODEL_CARD.md')

TEMPORAL_CUTOFF = '2023-01-01'
RANDOM_SEED = 42

EXACT_10_FEATURES = [
    'elapsed_days_since_first_3a',
    'cumulative_notifications_count_at_t',
    'notification_cadence_days',
    'days_since_last_notification',
    'statutory_stage_at_t',
    'statutory_notification_frequency_180d',
    'total_land_required_ha',
    'implementing_agency',
    'state_jurisdiction',
    'initial_sanction_available_at_t'
]

NUMERICAL_FEATURES = [
    'elapsed_days_since_first_3a',
    'cumulative_notifications_count_at_t',
    'notification_cadence_days',
    'days_since_last_notification',
    'statutory_notification_frequency_180d',
    'total_land_required_ha',
    'initial_sanction_available_at_t'
]

CATEGORICAL_FEATURES = [
    'statutory_stage_at_t',
    'implementing_agency',
    'state_jurisdiction'
]

FORBIDDEN_FEATURES = [
    'section_3d_date', 'delayed', 'target', 'duration_days', 'eventual_outcome',
    'land_acquired_ratio_at_t', 'comp_disbursed_percent_at_t', 'active_court_stays_at_t',
    'unresolved_cases_at_t', 'incomplete_docs_count_at_t', 'forest_clearance_at_t'
]


def compute_sha256(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def verify_preflight():
    print("=" * 80)
    print("  PHASE 7A-2: PRE-FLIGHT VERIFICATION & SAFETY CHECKS")
    print("=" * 80)

    # 1. Dataset SHA
    if not os.path.exists(DATASET_PATH):
        raise FileNotFoundError(f"Dataset missing at {DATASET_PATH}")
    ds_sha = compute_sha256(DATASET_PATH)
    print(f"Dataset SHA-256: {ds_sha}")
    if ds_sha != EXPECTED_DATASET_SHA256:
        raise ValueError(f"CRITICAL: Dataset SHA mismatch! Expected {EXPECTED_DATASET_SHA256}, got {ds_sha}")
    print("  [PASS] Authentic Dataset SHA-256 verified.")

    # 2. V1 SHA
    if not os.path.exists(V1_MODEL_PATH):
        raise FileNotFoundError(f"V1 model missing at {V1_MODEL_PATH}")
    v1_sha = compute_sha256(V1_MODEL_PATH)
    print(f"Production V1 SHA-256: {v1_sha}")
    if v1_sha != CANONICAL_V1_SHA256:
        raise ValueError(f"CRITICAL: V1 Model SHA mismatch! Expected {CANONICAL_V1_SHA256}, got {v1_sha}")
    print("  [PASS] Production V1 model artifact is FROZEN and UNTOUCHED.")

    with open(DATASET_PATH, 'r') as f:
        data = json.load(f)

    meta = data['metadata']
    obs = data['observations']

    print(f"Dataset Version:       {meta.get('dataset_version')}")
    print(f"Total Observations:    {len(obs)} (Expected: 399)")
    print(f"Unique Projects:       {meta.get('unique_projects')} (Expected: 152)")
    print(f"Delayed Observations:  {meta.get('target_summary', {}).get('delayed')} (Expected: 327)")
    print(f"On-Track Observations: {meta.get('target_summary', {}).get('not_delayed')} (Expected: 72)")

    assert len(obs) == 399, f"Expected 399 observations, got {len(obs)}"
    assert meta.get('unique_projects') == 152, f"Expected 152 projects, got {meta.get('unique_projects')}"
    assert meta.get('target_summary', {}).get('delayed') == 327, "Expected 327 delayed"
    assert meta.get('target_summary', {}).get('not_delayed') == 72, "Expected 72 not delayed"

    # Schema & Forbidden check
    for i, o in enumerate(obs):
        f_keys = list(o['features'].keys())
        assert set(f_keys) == set(EXACT_10_FEATURES), f"Obs {i} feature schema mismatch: {f_keys}"
        for fk in FORBIDDEN_FEATURES:
            assert fk not in o['features'], f"Obs {i} contains forbidden feature: {fk}"
        assert 'T180' not in str(o.get('observation_id', '')), f"Obs {i} is synthetic T180"

    print("  [PASS] Feature schema exactly matches SCHEMA-LONGITUDINAL-V2.0-10FEAT.")
    print("  [PASS] Zero forbidden features and zero synthetic T180 records in X.")
    print("=" * 80 + "\n")
    return obs, ds_sha, v1_sha


def build_pipeline():
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', Pipeline([
                ('imputer', SimpleImputer(strategy='median')),
                ('scaler', StandardScaler())
            ]), NUMERICAL_FEATURES),
            ('cat', Pipeline([
                ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
            ]), CATEGORICAL_FEATURES)
        ],
        remainder='drop'
    )

    clf = RandomForestClassifier(
        n_estimators=100,
        max_depth=6,
        min_samples_leaf=2,
        class_weight='balanced',
        random_state=RANDOM_SEED
    )

    pipeline = Pipeline([
        ('prep', preprocessor),
        ('clf', clf)
    ])
    return pipeline


def evaluate_metrics(y_true, y_prob, threshold=0.5):
    y_pred = (y_prob >= threshold).astype(int)
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel() if cm.shape == (2, 2) else (0, 0, 0, 0)
    spec = float(tn / (tn + fp)) if (tn + fp) > 0 else 0.0
    return {
        'roc_auc': float(roc_auc_score(y_true, y_prob)),
        'pr_auc': float(average_precision_score(y_true, y_prob)),
        'precision': float(precision_score(y_true, y_pred, zero_division=0)),
        'recall': float(recall_score(y_true, y_pred, zero_division=0)),
        'f1': float(f1_score(y_true, y_pred, zero_division=0)),
        'balanced_accuracy': float(balanced_accuracy_score(y_true, y_pred)),
        'specificity': spec,
        'brier': float(brier_score_loss(y_true, y_prob)),
        'log_loss': float(log_loss(y_true, y_prob)),
        'confusion_matrix': cm.tolist(),
        'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)
    }


def run_stratified_group_cv(df):
    print("--- 1. STRATIFIED GROUPED CV (5-Fold, Grouped by project_id) ---")
    sgkf = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=RANDOM_SEED)

    y = df['delayed'].values
    groups = df['project_id'].values

    fold_metrics = []
    all_y_true = []
    all_y_prob = []

    for fold, (train_idx, test_idx) in enumerate(sgkf.split(df, y, groups)):
        train_df, test_df = df.iloc[train_idx], df.iloc[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]

        # Verify zero group leakage
        train_g = set(groups[train_idx])
        test_g = set(groups[test_idx])
        assert len(train_g.intersection(test_g)) == 0, f"Group leakage in fold {fold}"

        pipe = build_pipeline()
        pipe.fit(train_df[EXACT_10_FEATURES], y_train)

        probs = pipe.predict_proba(test_df[EXACT_10_FEATURES])[:, 1]
        m = evaluate_metrics(y_test, probs)
        m['fold'] = fold
        m['train_n'] = len(train_idx)
        m['test_n'] = len(test_idx)
        fold_metrics.append(m)

        all_y_true.extend(y_test)
        all_y_prob.extend(probs)
        print(f"  Fold {fold}: ROC-AUC={m['roc_auc']:.4f} | PR-AUC={m['pr_auc']:.4f} | F1={m['f1']:.4f} | BalAcc={m['balanced_accuracy']:.4f} | Brier={m['brier']:.4f}")

    m_df = pd.DataFrame(fold_metrics)
    agg_cm = confusion_matrix(all_y_true, (np.array(all_y_prob) >= 0.5).astype(int)).tolist()

    cv_summary = {
        'roc_auc_mean': float(m_df['roc_auc'].mean()),
        'roc_auc_std': float(m_df['roc_auc'].std()),
        'pr_auc_mean': float(m_df['pr_auc'].mean()),
        'pr_auc_std': float(m_df['pr_auc'].std()),
        'precision_mean': float(m_df['precision'].mean()),
        'precision_std': float(m_df['precision'].std()),
        'recall_mean': float(m_df['recall'].mean()),
        'recall_std': float(m_df['recall'].std()),
        'f1_mean': float(m_df['f1'].mean()),
        'f1_std': float(m_df['f1'].std()),
        'balanced_accuracy_mean': float(m_df['balanced_accuracy'].mean()),
        'balanced_accuracy_std': float(m_df['balanced_accuracy'].std()),
        'specificity_mean': float(m_df['specificity'].mean()),
        'specificity_std': float(m_df['specificity'].std()),
        'brier_mean': float(m_df['brier'].mean()),
        'brier_std': float(m_df['brier'].std()),
        'log_loss_mean': float(m_df['log_loss'].mean()),
        'log_loss_std': float(m_df['log_loss'].std()),
        'aggregate_confusion_matrix': agg_cm,
        'folds': fold_metrics
    }

    print(f"  --> CV MEAN: ROC-AUC={cv_summary['roc_auc_mean']:.4f}±{cv_summary['roc_auc_std']:.4f} | "
          f"PR-AUC={cv_summary['pr_auc_mean']:.4f}±{cv_summary['pr_auc_std']:.4f} | "
          f"F1={cv_summary['f1_mean']:.4f}±{cv_summary['f1_std']:.4f} | "
          f"BalAcc={cv_summary['balanced_accuracy_mean']:.4f}±{cv_summary['balanced_accuracy_std']:.4f} | "
          f"Brier={cv_summary['brier_mean']:.4f}±{cv_summary['brier_std']:.4f}\n")
    return cv_summary


def run_temporal_holdout(df):
    print("--- 2. CHRONOLOGICAL HOLDOUT (Cutoff: 2023-01-01) ---")
    p_earliest = df.groupby('project_id')['observation_timestamp'].min().to_dict()
    df['proj_earliest'] = df['project_id'].map(p_earliest)

    train_projects = set(p for p, dt in p_earliest.items() if dt < TEMPORAL_CUTOFF)
    val_projects = set(p for p, dt in p_earliest.items() if dt >= TEMPORAL_CUTOFF)

    assert len(train_projects.intersection(val_projects)) == 0, "Temporal project leakage!"
    assert len(train_projects) == 106, f"Expected 106 train projects, got {len(train_projects)}"
    assert len(val_projects) == 46, f"Expected 46 val projects, got {len(val_projects)}"

    train_df = df[df['project_id'].isin(train_projects)]
    val_df = df[df['project_id'].isin(val_projects)]

    assert len(train_df) == 286, f"Expected 286 train observations, got {len(train_df)}"
    assert len(val_df) == 113, f"Expected 113 val observations, got {len(val_df)}"

    print(f"  Training Set:   {len(train_projects)} projects, {len(train_df)} observations (Delayed: {train_df['delayed'].sum()})")
    print(f"  Validation Set: {len(val_projects)} projects, {len(val_df)} observations (Delayed: {val_df['delayed'].sum()})")

    pipe = build_pipeline()
    pipe.fit(train_df[EXACT_10_FEATURES], train_df['delayed'].values)

    val_probs = pipe.predict_proba(val_df[EXACT_10_FEATURES])[:, 1]
    temporal_metrics = evaluate_metrics(val_df['delayed'].values, val_probs)

    print(f"  Temporal Validation Results:")
    print(f"    ROC-AUC:           {temporal_metrics['roc_auc']:.4f}")
    print(f"    PR-AUC:            {temporal_metrics['pr_auc']:.4f}")
    print(f"    Precision:         {temporal_metrics['precision']:.4f}")
    print(f"    Recall:            {temporal_metrics['recall']:.4f}")
    print(f"    F1-Score:          {temporal_metrics['f1']:.4f}")
    print(f"    Balanced Accuracy: {temporal_metrics['balanced_accuracy']:.4f}")
    print(f"    Specificity:       {temporal_metrics['specificity']:.4f}")
    print(f"    Brier Score:       {temporal_metrics['brier']:.4f}")
    print(f"    Log Loss:          {temporal_metrics['log_loss']:.4f}")
    print(f"    Confusion Matrix:  {temporal_metrics['confusion_matrix']}")

    # Reliability calibration bins (5 bins)
    bins = np.linspace(0.0, 1.0, 6)
    bin_indices = np.digitize(val_probs, bins) - 1
    calibration_bins = []
    for b in range(5):
        mask = (bin_indices == b)
        count = int(mask.sum())
        if count > 0:
            mean_prob = float(val_probs[mask].mean())
            actual_rate = float(val_df['delayed'].values[mask].mean())
        else:
            mean_prob = float((bins[b] + bins[b+1]) / 2)
            actual_rate = 0.0
        calibration_bins.append({
            'bin': b + 1,
            'bin_range': [round(bins[b], 2), round(bins[b+1], 2)],
            'count': count,
            'mean_predicted_probability': mean_prob,
            'observed_fraction_delayed': actual_rate
        })

    # Feature Importance
    prep_step = pipe.named_steps['prep']
    rf_step = pipe.named_steps['clf']
    cat_enc = prep_step.named_transformers_['cat'].named_steps['onehot']
    cat_cols = cat_enc.get_feature_names_out(CATEGORICAL_FEATURES).tolist()
    all_feature_cols = NUMERICAL_FEATURES + cat_cols
    importances = rf_step.feature_importances_

    sorted_idx = np.argsort(importances)[::-1]
    rf_feature_importances = []
    for r, idx in enumerate(sorted_idx, 1):
        rf_feature_importances.append({
            'rank': r,
            'feature': all_feature_cols[idx],
            'gini_importance': float(importances[idx])
        })

    # Permutation importance on unseen validation set
    perm_res = permutation_importance(
        pipe, val_df[EXACT_10_FEATURES], val_df['delayed'].values,
        n_repeats=10, random_state=RANDOM_SEED, scoring='roc_auc'
    )
    perm_importances = []
    for i, col in enumerate(EXACT_10_FEATURES):
        perm_importances.append({
            'feature': col,
            'perm_importance_mean': float(perm_res.importances_mean[i]),
            'perm_importance_std': float(perm_res.importances_std[i])
        })
    perm_importances.sort(key=lambda x: x['perm_importance_mean'], reverse=True)

    return temporal_metrics, calibration_bins, rf_feature_importances, perm_importances, pipe


def run_leakage_audit(obs, train_df, val_df):
    print("\n--- 3. COMPREHENSIVE LEAKAGE AUDIT ---")
    checks = {
        'zero_future_feature_violations': True,
        'zero_section_3d_predictors': True,
        'zero_target_derived_predictors': True,
        'zero_synthetic_t180_rows': True,
        'zero_project_overlap': True,
        'zero_post_observation_notifications': True
    }

    # Check project overlap
    train_p = set(train_df['project_id'])
    val_p = set(val_df['project_id'])
    if len(train_p.intersection(val_p)) > 0:
        checks['zero_project_overlap'] = False

    for o in obs:
        t = o['observation_timestamp']
        if 'T180' in str(o.get('observation_id', '')):
            checks['zero_synthetic_t180_rows'] = False
        feats = o['features']
        for fk in FORBIDDEN_FEATURES:
            if fk in feats:
                checks['zero_target_derived_predictors'] = False
                if '3d' in fk.lower():
                    checks['zero_section_3d_predictors'] = False

        prov = o.get('provenance', {})
        for notif in prov.get('notifications_considered', []):
            if notif.get('publish_date', '') > t:
                checks['zero_post_observation_notifications'] = False
                checks['zero_future_feature_violations'] = False

    for k, v in checks.items():
        status = "PASS" if v else "FAIL"
        print(f"  [{status}] {k}")
    all_pass = all(checks.values())
    return checks, all_pass


def main():
    obs, ds_sha, v1_sha = verify_preflight()

    # Build DataFrame
    rows = []
    for o in obs:
        r = dict(o['features'])
        r['observation_id'] = o['observation_id']
        r['project_id'] = o['project_id']
        r['observation_timestamp'] = o['observation_timestamp']
        r['delayed'] = int(o['target']['delayed'])
        rows.append(r)
    df = pd.DataFrame(rows)

    # 1. Stratified Group CV
    cv_summary = run_stratified_group_cv(df)

    # 2. Chronological Holdout
    temporal_metrics, calibration_bins, rf_importances, perm_importances, temporal_pipe = run_temporal_holdout(df)

    # 3. Leakage Audit
    p_earliest = df.groupby('project_id')['observation_timestamp'].min().to_dict()
    df['proj_earliest'] = df['project_id'].map(p_earliest)
    train_df = df[df['proj_earliest'] < TEMPORAL_CUTOFF]
    val_df = df[df['proj_earliest'] >= TEMPORAL_CUTOFF]
    leakage_checks, leakage_pass = run_leakage_audit(obs, train_df, val_df)

    if not leakage_pass:
        raise RuntimeError("FATAL: Leakage audit failed!")

    # 4. Serialize Candidate V2 Model Artifact
    print("\n--- 4. CANDIDATE ARTIFACT PROVISIONING ---")
    os.makedirs(V2_DIR, exist_ok=True)

    # Save the pipeline evaluated in the candidate configuration
    # Note: Candidate artifact represents the reproducible Random Forest candidate pipeline
    joblib.dump(temporal_pipe, V2_MODEL_PATH)
    v2_sha = compute_sha256(V2_MODEL_PATH)
    v2_bytes = os.path.getsize(V2_MODEL_PATH)

    print(f"  Candidate V2 Artifact Path: {V2_MODEL_PATH}")
    print(f"  Candidate V2 Artifact SHA:  {v2_sha}")
    print(f"  Candidate V2 Byte Size:     {v2_bytes} bytes")

    # 5. Save Model Manifest
    manifest = {
        'model_name': 'BHOOMI-DRISHTI-ML-V2.0-SHADOW',
        'model_type': 'RandomForestClassifier',
        'status': 'SHADOW_CANDIDATE',
        'operational_status': 'NON_OPERATIONAL',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'artifact_path': V2_MODEL_PATH,
        'artifact_sha256': v2_sha,
        'artifact_bytes': v2_bytes,
        'dataset': {
            'name': 'BHOOMI-DRISHTI-LONGITUDINAL-HISTORICAL-V2',
            'version': '2.0.0-phase4c-authentic',
            'sha256': ds_sha,
            'total_observations': len(df),
            'unique_projects': int(df['project_id'].nunique()),
            'delayed_count': int(df['delayed'].sum()),
            'not_delayed_count': int(len(df) - df['delayed'].sum())
        },
        'feature_schema': {
            'schema_id': 'SCHEMA-LONGITUDINAL-V2.0-10FEAT',
            'feature_count': 10,
            'features': EXACT_10_FEATURES,
            'numerical_features': NUMERICAL_FEATURES,
            'categorical_features': CATEGORICAL_FEATURES,
            'forbidden_features_quarantined': FORBIDDEN_FEATURES
        },
        'hyperparameters': {
            'n_estimators': 100,
            'max_depth': 6,
            'min_samples_leaf': 2,
            'class_weight': 'balanced',
            'random_state': 42
        },
        'evaluation': {
            'stratified_group_cv': cv_summary,
            'temporal_holdout': {
                'cutoff': TEMPORAL_CUTOFF,
                'train_projects': 106,
                'train_observations': 286,
                'validation_projects': 46,
                'validation_observations': 113,
                'metrics': temporal_metrics,
                'reference_phase5b_comparison': {
                    'roc_auc_diff': round(temporal_metrics['roc_auc'] - 0.8726, 4),
                    'pr_auc_diff': round(temporal_metrics['pr_auc'] - 0.8974, 4),
                    'precision_diff': round(temporal_metrics['precision'] - 0.7778, 4),
                    'recall_diff': round(temporal_metrics['recall'] - 0.9403, 4),
                    'f1_diff': round(temporal_metrics['f1'] - 0.8514, 4),
                    'balanced_accuracy_diff': round(temporal_metrics['balanced_accuracy'] - 0.7745, 4),
                    'specificity_diff': round(temporal_metrics['specificity'] - 0.6087, 4),
                    'brier_diff': round(temporal_metrics['brier'] - 0.1614, 4),
                    'log_loss_diff': round(temporal_metrics['log_loss'] - 0.4936, 4)
                }
            },
            'calibration': {
                'brier_score': temporal_metrics['brier'],
                'log_loss': temporal_metrics['log_loss'],
                'reliability_bins': calibration_bins,
                'calibration_policy': 'UNMODIFIED_RAW_PROBABILITIES'
            },
            'leakage_audit': leakage_checks
        },
        'feature_importance': {
            'rf_gini': rf_importances[:10],
            'permutation_importance_validation': perm_importances,
            'causal_disclaimer': 'Feature importances are purely statistical/associative under historical observational data and MUST NOT be interpreted as causal policy interventions.'
        },
        'governance': {
            'threshold_policy': 'PENDING_STAKEHOLDER_APPROVAL',
            'production_v1_frozen': True,
            'production_v1_sha256': CANONICAL_V1_SHA256,
            'replacement_policy': 'NON_OFFICIAL_SHADOW_ONLY'
        }
    }

    with open(V2_MANIFEST_PATH, 'w') as f:
        json.dump(manifest, f, indent=2)
    print(f"  Model Manifest saved to {V2_MANIFEST_PATH}")

    # 6. Save Model Card
    model_card_content = f"""# Model Card: BHOOMI-DRISHTI-ML-V2.0-SHADOW

## Model Details
- **Model Identifier:** BHOOMI-DRISHTI-ML-V2.0-SHADOW
- **Status:** CANDIDATE / NON-OPERATIONAL SHADOW MODEL
- **Production Status:** NOT DEPLOYED (Production V1.0 remains authoritative)
- **Model Architecture:** Scikit-learn Pipeline with ColumnTransformer and RandomForestClassifier
- **Hyperparameters:** `n_estimators=100`, `max_depth=6`, `min_samples_leaf=2`, `class_weight='balanced'`, `random_state=42`
- **Artifact SHA-256:** `{v2_sha}`
- **Created Timestamp:** `{manifest['created_at']}`

## Dataset & Feature Lineage
- **Dataset:** `BHOOMI-DRISHTI-LONGITUDINAL-HISTORICAL-V2` (v2.0.0-phase4c-authentic)
- **Dataset SHA-256:** `{ds_sha}`
- **Observation Population:** 399 authentic observations across 152 unique NHAI/MoRTH highway projects (327 Delayed / 72 On-Track)
- **Feature Schema:** `SCHEMA-LONGITUDINAL-V2.0-10FEAT`
- **Quarantined / Forbidden Features:** `section_3d_date`, `delayed`, `target`, `duration_days`, `eventual_outcome`, synthetic T180 records, and retired V1 surrogate features.

## Evaluation & Empirical Performance

### 1. 5-Fold Stratified Group Cross-Validation (Grouped by `project_id`)
- **Mean ROC-AUC:** {cv_summary['roc_auc_mean']:.4f} ± {cv_summary['roc_auc_std']:.4f}
- **Mean PR-AUC:** {cv_summary['pr_auc_mean']:.4f} ± {cv_summary['pr_auc_std']:.4f}
- **Mean F1:** {cv_summary['f1_mean']:.4f} ± {cv_summary['f1_std']:.4f}
- **Mean Balanced Accuracy:** {cv_summary['balanced_accuracy_mean']:.4f} ± {cv_summary['balanced_accuracy_std']:.4f}
- **Mean Brier Score:** {cv_summary['brier_mean']:.4f} ± {cv_summary['brier_std']:.4f}

### 2. Chronological Holdout (Cutoff: 2023-01-01, 106 Train Projects / 46 Validation Projects)
- **ROC-AUC:** {temporal_metrics['roc_auc']:.4f} (Phase 5B Ref: 0.8726)
- **PR-AUC:** {temporal_metrics['pr_auc']:.4f} (Phase 5B Ref: 0.8974)
- **Precision:** {temporal_metrics['precision']:.4f} (Phase 5B Ref: 0.7778)
- **Recall:** {temporal_metrics['recall']:.4f} (Phase 5B Ref: 0.9403)
- **F1:** {temporal_metrics['f1']:.4f} (Phase 5B Ref: 0.8514)
- **Balanced Accuracy:** {temporal_metrics['balanced_accuracy']:.4f} (Phase 5B Ref: 0.7745)
- **Specificity:** {temporal_metrics['specificity']:.4f} (Phase 5B Ref: 0.6087)
- **Brier Score:** {temporal_metrics['brier']:.4f} (Phase 5B Ref: 0.1614)
- **Log Loss:** {temporal_metrics['log_loss']:.4f} (Phase 5B Ref: 0.4936)
- **Confusion Matrix:** TN={temporal_metrics['tn']}, FP={temporal_metrics['fp']}, FN={temporal_metrics['fn']}, TP={temporal_metrics['tp']}

## Leakage Audit
- Zero future-feature violations: PASS
- Zero Section 3D predictor usage: PASS
- Zero target-derived predictors: PASS
- Zero synthetic T180 rows: PASS
- Zero cross-partition project overlap: PASS
- Zero post-observation notification usage: PASS

## Non-Causal Feature Importance Interpretation
Feature importance scores derived from Gini impurity reduction or permutation importance measure predictive association within historical statutory notifications. **They do not constitute causal mechanisms.** High importance indicates correlation with historical land acquisition delay patterns, not a prescriptive levers for administrative intervention.

## Governance & Operational Threshold Constraints
- **Operational Threshold Policy:** PENDING_STAKEHOLDER_APPROVAL.
- **Automatic Promotion:** DISABLED.
- **Production Safety:** Production V1 model (`{CANONICAL_V1_SHA256}`) remains the exclusive operational system.
"""

    with open(V2_MODEL_CARD_PATH, 'w') as f:
        f.write(model_card_content)
    print(f"  Model Card saved to {V2_MODEL_CARD_PATH}")

    # 7. Post-Training Production V1 Integrity Check
    post_v1_sha = compute_sha256(V1_MODEL_PATH)
    assert post_v1_sha == CANONICAL_V1_SHA256, f"V1 Model SHA corrupted! Got {post_v1_sha}"
    print("\n" + "=" * 80)
    print("  POST-TRAINING INTEGRITY CHECK: PASS")
    print(f"  Production V1 Model SHA-256 strictly preserved: {post_v1_sha}")
    print("=" * 80 + "\n")

    return {
        'v2_sha': v2_sha,
        'v1_sha': post_v1_sha,
        'cv_summary': cv_summary,
        'temporal_metrics': temporal_metrics,
        'leakage_pass': leakage_pass
    }


if __name__ == '__main__':
    main()
