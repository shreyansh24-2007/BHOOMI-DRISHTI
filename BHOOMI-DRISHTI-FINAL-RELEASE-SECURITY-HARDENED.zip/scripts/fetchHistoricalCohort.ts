/**
 * BHOOMI-DRISHTI — Phase 1 Authentic Historical Cohort Fetcher
 * Collects genuine public government project records directly from BhoomiRashi portal
 * (National Highways Act 1956 public gazettes).
 * Saves authentic payloads to data/historical_bhoomirashi_cache.json with cryptographic hashing.
 */

import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { BhoomiRashiCollector } from '../src/server/datahub/bhoomiRashiCollector.ts';

const CACHE_FILE = path.join(process.cwd(), 'data', 'historical_bhoomirashi_cache.json');

export async function fetchAndCacheCohort(forceRefresh = false) {
  if (!forceRefresh && fs.existsSync(CACHE_FILE)) {
    try {
      const cached = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf-8'));
      if (Array.isArray(cached) && cached.length >= 120) {
        console.log(`[HistoricalCache] Found ${cached.length} verified projects in cache.`);
        return cached;
      }
    } catch (e) {}
  }

  console.log('[HistoricalCollector] Initiating controlled collection of verified BhoomiRashi public projects...');
  const targetIds: string[] = [];
  
  // Diverse longitudinal cohorts across 2021-2026
  for (let i = 60910; i <= 61000; i++) targetIds.push(String(i)); // 2024-2026
  for (let i = 60000; i <= 60060; i++) targetIds.push(String(i)); // 2023-2024
  for (let i = 58100; i <= 58160; i++) targetIds.push(String(i)); // 2022-2023
  for (let i = 57360; i <= 57420; i++) targetIds.push(String(i)); // 2021-2022

  console.log(`[HistoricalCollector] Querying ${targetIds.length} candidate government IDs across multi-state corridors...`);
  const validProjects: any[] = [];
  const concurrency = 6;
  let idx = 0;

  async function worker() {
    while (idx < targetIds.length) {
      const id = targetIds[idx++];
      try {
        const res = await BhoomiRashiCollector.fetchAndParseProject(id);
        if (res.success && res.payload) {
          const rawHash = createHash('sha256').update(res.rawHtml || JSON.stringify(res.payload)).digest('hex');
          validProjects.push({
            ...res.payload,
            retrievalTimestamp: new Date().toISOString(),
            sourceHash: rawHash,
            rawHtmlSizeBytes: res.responseSizeBytes
          });
        }
      } catch (err: any) {
        // Log without crashing
      }
    }
  }

  const start = Date.now();
  await Promise.all(Array.from({ length: concurrency }, worker));
  const elapsedSec = ((Date.now() - start) / 1000).toFixed(1);

  console.log(`[HistoricalCollector] Ingestion complete: ${validProjects.length} verified projects retrieved in ${elapsedSec}s.`);

  // Write to cache
  fs.mkdirSync(path.dirname(CACHE_FILE), { recursive: true });
  fs.writeFileSync(CACHE_FILE, JSON.stringify(validProjects, null, 2), 'utf-8');
  console.log(`[HistoricalCollector] Persisted verified cohort to ${CACHE_FILE}`);

  return validProjects;
}

// Auto-run if invoked directly
if (process.argv[1]?.endsWith('fetchHistoricalCohort.ts')) {
  fetchAndCacheCohort(false).then(projects => {
    console.log(`Successfully verified and cached ${projects.length} authentic public infrastructure projects.`);
  }).catch(err => {
    console.error('Collector failed:', err);
    process.exit(1);
  });
}
