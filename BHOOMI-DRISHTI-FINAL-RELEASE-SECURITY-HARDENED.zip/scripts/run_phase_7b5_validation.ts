import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { getDatabase } from '../src/server/database.ts';
import { StatutoryStore, initStatutoryTables } from '../src/server/datahub/statutoryStore.ts';
import {
  StatutoryIngestionCoordinator,
  ManualDocumentIngestionService
} from '../src/server/datahub/statutoryAdapters.ts';
import {
  executeShadowScoring,
  scoreCandidateArtifact,
  inspectCandidateArtifact,
  SHADOW_POLICY_CONFIG,
  queryShadowPredictions
} from '../src/server/ml/shadowRunner.ts';
import {
  ORDERED_SHADOW_FEATURES,
  computeFeatureSnapshotHash,
  validateShadowFeatureSchema
} from '../src/server/ml/shadowFeatureSchema.ts';
import { validateShadowEvidence } from '../src/server/ml/shadowEvidenceGate.ts';

const CANONICAL_V1_SHA256 = '7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f';
const EXPECTED_V2_SHA256 = '4a83e980f9178498be4592a47303f0ebc5ea641934952af5bee92ae5b76729a2';
const EXPECTED_DATASET_SHA256 = '0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a';

function computeFileSha(filePath: string): string {
  const buf = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buf).digest('hex');
}

export async function runPhase7b5Validation() {
  console.log('========================================================================');
  console.log('  PHASE 7B-5: END-TO-END AUTHORITATIVE EVIDENCE → V2 SHADOW SCORING');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void> | void) {
    try {
      await fn();
      console.log(`  ✓ ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  ✗ ${name}`);
      console.error(`    Error: ${err.message}`);
      failed++;
    }
  }

  const db = initStatutoryTables(getDatabase());

  // Capture baseline state before test
  const v1Path = path.resolve(process.cwd(), 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib');
  const v2Path = path.resolve(process.cwd(), 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_pipeline.joblib');
  const datasetPath = path.resolve(process.cwd(), 'data/reconstructed_longitudinal_dataset_v2.json');

  const v1ShaBefore = computeFileSha(v1Path);
  const v2ShaBefore = computeFileSha(v2Path);
  const datasetShaBefore = computeFileSha(datasetPath);

  const initialProjects = db.prepare('SELECT * FROM projects').all() as any[];
  const initialProjectsHash = crypto.createHash('sha256').update(JSON.stringify(initialProjects)).digest('hex');
  const initialAlertsCount = (db.prepare('SELECT count(*) as c FROM alerts').get() as any).c;
  const initialShadowCount = (db.prepare('SELECT count(*) as c FROM shadow_predictions').get() as any).c;

  // ========================================================================
  // PART 1: SELECT CONTROL PROJECTS
  // ========================================================================
  console.log('--- Part 1: Control Projects Selection ---');
  const controls = [
    {
      id: 'BhoomiRashi_60940',
      sourceRecordId: '60940',
      first3aDate: '2024-01-15',
      observationTimestamp: '2024-06-01',
      description: '4 Lane NH 327-E Bihar (Parsarma to Araria)'
    },
    {
      id: 'BhoomiRashi_54635',
      sourceRecordId: '54635',
      first3aDate: '2017-09-18',
      observationTimestamp: '2018-06-01',
      description: '2 Lane Paved Shoulder NH-57 Odisha (Nayagarh to Khordha)'
    },
    {
      id: 'BhoomiRashi_56972',
      sourceRecordId: '56972',
      first3aDate: '2019-02-12',
      observationTimestamp: '2021-06-01',
      description: '4 Laning Amritsar-Tanda NH-503A Punjab'
    }
  ];

  await test('Part 1. Exactly 3 authentic controls selected (zero synthetic or pre-3A)', () => {
    assert.strictEqual(controls.length, 3);
    for (const c of controls) {
      const proj = db.prepare('SELECT * FROM projects WHERE id = ?').get(c.id) as any;
      assert.ok(proj, `Project ${c.id} must exist in operational database`);
      assert.strictEqual(proj.is_synthetic, 0, `Control ${c.id} must not be synthetic`);
      assert.notStrictEqual(proj.id, 'BhoomiRashi_57405', 'BhoomiRashi_57405 must not be included');
      assert.strictEqual(proj.section_3a_date, c.first3aDate, `Verified 3A date must match ${c.first3aDate}`);
    }
  });

  // ========================================================================
  // PART 2: VERIFY SOURCE → DATABASE PROVENANCE
  // ========================================================================
  console.log('\n--- Part 2: Source Provenance Verification ---');
  await test('Part 2. Every control project has complete authoritative statutory provenance', () => {
    for (const c of controls) {
      const notifs = StatutoryStore.getVerifiedNotifications(c.id);
      assert.ok(notifs.length >= 1, `Control ${c.id} must have verified notifications`);

      for (const n of notifs) {
        assert.ok(['LIVE_EXTERNAL', 'VERIFIED_EXTERNAL'].includes(n.source_type), 'Source type must be authoritative external');
        assert.ok(n.source_reference.includes('BhoomiRashi'), 'Source reference must cite BhoomiRashi');
        assert.strictEqual(n.source_project_id, c.sourceRecordId);
        assert.strictEqual(n.project_id, c.id);
        assert.ok(n.notification_number, 'Notification number must be non-empty');
        assert.strictEqual(n.statutory_section, '3A', 'Must be Section 3A statutory notification');
        assert.ok(n.publication_date, 'Publication date must be non-empty');
        assert.strictEqual(n.verification_status, 'VERIFIED');
        assert.strictEqual(n.is_authoritative, 1);
        assert.strictEqual(n.is_synthetic, 0);
        assert.ok(n.content_hash && n.content_hash.length === 64, 'Must have valid SHA-256 content hash');
      }
    }
  });

  // ========================================================================
  // PART 3: VERIFY COMPLETE NOTIFICATION HISTORY
  // ========================================================================
  console.log('\n--- Part 3: Notification History & Temporal Filtering ---');
  const temporalBreakdown: Record<string, { beforeOrAtT: number; afterT: number }> = {};

  await test('Part 3. Notifications after t exist in DB but are strictly excluded from t snapshot', () => {
    for (const c of controls) {
      const allNotifs = StatutoryStore.getVerifiedNotifications(c.id);
      const beforeOrAtT = allNotifs.filter(n => n.publication_date <= c.observationTimestamp);
      const afterT = allNotifs.filter(n => n.publication_date > c.observationTimestamp);

      temporalBreakdown[c.id] = {
        beforeOrAtT: beforeOrAtT.length,
        afterT: afterT.length
      };

      assert.ok(beforeOrAtT.length >= 1, `Must have >= 1 notification before or at ${c.observationTimestamp}`);

      // For 54635 and 56972, notifications after t MUST exist to prove temporal exclusion
      if (c.id === 'BhoomiRashi_54635') {
        assert.ok(afterT.length > 0, `BhoomiRashi_54635 must have notifications after ${c.observationTimestamp}`);
      }
      if (c.id === 'BhoomiRashi_56972') {
        assert.ok(afterT.length > 0, `BhoomiRashi_56972 must have notifications after ${c.observationTimestamp}`);
      }

      // Reconstruct features at t
      const recon = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures(c.id, c.observationTimestamp);
      assert.strictEqual(recon.success, true);
      assert.strictEqual(recon.featureVector!.cumulative_notifications_count_at_t, beforeOrAtT.length,
        `Reconstructed count must strictly match beforeOrAtT (${beforeOrAtT.length}), not total (${allNotifs.length})`);
    }
  });

  // ========================================================================
  // PART 4: TEST POINT-IN-TIME RECONSTRUCTION
  // ========================================================================
  console.log('\n--- Part 4: 10-Feature Longitudinal Vector Exactness ---');
  const reconstructedVectors: Record<string, any> = {};

  await test('Part 4. Exactly 10 audited features conforming to SCHEMA-LONGITUDINAL-V2.0-10FEAT', () => {
    for (const c of controls) {
      const res = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures(c.id, c.observationTimestamp);
      assert.strictEqual(res.success, true);
      assert.strictEqual(res.evidenceStatus, 'COMPLETE');
      assert.ok(res.featureVector);

      const fv = res.featureVector!;
      reconstructedVectors[c.id] = fv;

      // Verify all 10 approved keys exist
      const keys = Object.keys(fv);
      assert.strictEqual(keys.length, 10, 'Must have exactly 10 features');
      for (const expectedKey of ORDERED_SHADOW_FEATURES) {
        assert.ok(expectedKey in fv, `Missing feature: ${expectedKey}`);
      }

      // Verify types and ranges
      assert.ok(typeof fv.elapsed_days_since_first_3a === 'number' && fv.elapsed_days_since_first_3a >= 0);
      assert.ok(typeof fv.cumulative_notifications_count_at_t === 'number' && fv.cumulative_notifications_count_at_t >= 1);
      assert.ok(typeof fv.notification_cadence_days === 'number' && fv.notification_cadence_days >= 0);
      assert.ok(typeof fv.days_since_last_notification === 'number' && fv.days_since_last_notification >= 0);
      assert.strictEqual(fv.statutory_stage_at_t, 'INITIAL_3A');
      assert.ok(typeof fv.statutory_notification_frequency_180d === 'number' && fv.statutory_notification_frequency_180d >= 1);
      assert.ok(typeof fv.total_land_required_ha === 'number' && fv.total_land_required_ha > 0);
      assert.ok(typeof fv.implementing_agency === 'string' && fv.implementing_agency.length > 0);
      assert.ok(typeof fv.state_jurisdiction === 'string' && fv.state_jurisdiction.length > 0);
      assert.ok([0, 1].includes(fv.initial_sanction_available_at_t));

      // Validate schema validator passes normalized vector
      const schemaCheck = validateShadowFeatureSchema(fv);
      assert.strictEqual(schemaCheck.valid, true);
      assert.strictEqual(schemaCheck.errors.length, 0);
    }
  });

  // ========================================================================
  // PART 5: POINT-IN-TIME ADVERSARIAL TESTS
  // ========================================================================
  console.log('\n--- Part 5: Point-in-Time Adversarial Invariant Tests ---');
  await test('Part 5. Adversarial timestamps strictly enforce <= rule without lookahead bias', () => {
    // Focus on BhoomiRashi_54635:
    // Known 3A dates: 2017-09-18 (2 notices), 2017-11-17 (2 notices), 2021-11-15 (2 notices)

    // Scenario A: Shortly after Section 3A (2017-09-20)
    const recA = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_54635', '2017-09-20');
    assert.strictEqual(recA.featureVector!.cumulative_notifications_count_at_t, 2);
    assert.strictEqual(recA.featureVector!.elapsed_days_since_first_3a, 2);

    // Scenario D: Immediately before known notification (2017-11-16)
    const recD = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_54635', '2017-11-16');
    assert.strictEqual(recD.featureVector!.cumulative_notifications_count_at_t, 2);

    // Scenario E: Exactly equal to known notification (2017-11-17)
    const recE = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_54635', '2017-11-17');
    assert.strictEqual(recE.featureVector!.cumulative_notifications_count_at_t, 4);

    // Scenario B: Middle of notification history (2019-01-01)
    const recB = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_54635', '2019-01-01');
    assert.strictEqual(recB.featureVector!.cumulative_notifications_count_at_t, 4);

    // Scenario F: After later notifications exist (2020-01-01) - 2021-11-15 notices must NOT leak
    const recF = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_54635', '2020-01-01');
    assert.strictEqual(recF.featureVector!.cumulative_notifications_count_at_t, 4);

    // Scenario C: Latest valid observation (2022-01-01) - all 6 notices now eligible
    const recC = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_54635', '2022-01-01');
    assert.strictEqual(recC.featureVector!.cumulative_notifications_count_at_t, 6);
  });

  // ========================================================================
  // PART 6: FEATURE SNAPSHOT HASH DETERMINISM
  // ========================================================================
  console.log('\n--- Part 6: Feature Snapshot Hash Determinism ---');
  const snapshotHashes: Record<string, string> = {};

  await test('Part 6. Same project + timestamp + verified source data yields identical hash', () => {
    for (const c of controls) {
      const fv = reconstructedVectors[c.id];
      const hash1 = computeFeatureSnapshotHash(fv);
      const hash2 = computeFeatureSnapshotHash(fv);
      assert.strictEqual(hash1, hash2, 'Repeated hashing must be identical');

      // Re-reconstruct from scratch
      const reconAgain = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures(c.id, c.observationTimestamp);
      const hashAgain = computeFeatureSnapshotHash(reconAgain.featureVector!);
      assert.strictEqual(hash1, hashAgain, 'Hash from reconstructed vector must match exactly');
      snapshotHashes[c.id] = hash1;
    }
  });

  // ========================================================================
  // PART 7: V2 ARTIFACT CONTRACT
  // ========================================================================
  console.log('\n--- Part 7: V2 Candidate Artifact Contract Verification ---');
  await test('Part 7. V2 artifact exists, matches expected SHA, and accepts reconstructed vector', () => {
    const artifact = inspectCandidateArtifact();
    assert.strictEqual(artifact.exists, true);
    assert.strictEqual(artifact.sha256, EXPECTED_V2_SHA256);

    for (const c of controls) {
      const fv = reconstructedVectors[c.id];
      const prob = scoreCandidateArtifact(fv);
      assert.ok(typeof prob === 'number', 'Inference output must be numeric');
      assert.ok(prob >= 0.0 && prob <= 1.0, `Probability ${prob} must be in [0, 1]`);
    }
  });

  // ========================================================================
  // PART 8: SHADOW PROBABILITY GENERATION (OFFLINE VS RUNNER)
  // ========================================================================
  console.log('\n--- Part 8: Probability Generation & Numerical Parity ---');
  const v2Probabilities: Record<string, number> = {};
  const probDifferences: Record<string, number> = {};

  await test('Part 8. Offline V2 probability and shadow runner V2 probability are numerically identical', () => {
    for (const c of controls) {
      const fv = reconstructedVectors[c.id];

      // Offline probability
      const offlineProb = scoreCandidateArtifact(fv);
      v2Probabilities[c.id] = offlineProb;

      // Shadow runner evaluation
      const shadowInput = {
        project_id: c.id,
        observation_timestamp: c.observationTimestamp,
        first_3a_date: c.first3aDate,
        latest_event_date_in_snapshot: c.observationTimestamp,
        features: fv,
        provenance_verified: true
      };

      // Mock user for runner
      const mockOfficer = { id: 'USR_OFFICER_01', name: 'Nodal Officer Verma', role: 'NODAL_OFFICER' } as any;
      const runnerRes = executeShadowScoring(db, shadowInput, mockOfficer);

      assert.strictEqual(runnerRes.success, true);
      assert.strictEqual(runnerRes.evidenceResult.evidence_status, 'COMPLETE');
      assert.strictEqual(runnerRes.evidenceResult.validation_status, 'PASS');
      assert.ok(typeof runnerRes.candidateProbability === 'number', 'Candidate probability must be present in runner result');

      const runnerProb = runnerRes.candidateProbability!;
      const diff = Math.abs(offlineProb - runnerProb);
      probDifferences[c.id] = diff;

      assert.ok(diff <= 1e-12, `Difference ${diff} exceeds tolerance 1e-12 for ${c.id}`);
      assert.strictEqual(offlineProb, runnerProb, `Exact numeric equality required for ${c.id}`);

      // Verify governance suppression of persistent operational probability
      assert.strictEqual(runnerRes.shadowRecord.prediction_probability, null,
        'Persistent prediction_probability must remain null while thresholds are pending approval');
      assert.strictEqual(runnerRes.shadowRecord.prediction_state, 'INSUFFICIENT_EVIDENCE',
        'Operational decisions must remain INSUFFICIENT_EVIDENCE');
    }
  });

  // ========================================================================
  // PART 9: CONTROLLED BATCH SHADOW RUN EXECUTION
  // ========================================================================
  console.log('\n--- Part 9: Controlled Test Shadow Run (Run-ID Isolation) ---');
  const batchRunId = `SHD_BATCH_7B5_E2E_${Date.now()}`;
  const batchResults: any[] = [];

  await test('Part 9. Execute single controlled run ID for the 3 control projects', () => {
    const nodalUser = { id: 'USR_NODAL_PHASE7B5', name: 'Authorized Officer', role: 'NODAL_OFFICER' } as any;

    for (const c of controls) {
      const fv = reconstructedVectors[c.id];
      const input = {
        shadow_run_id: `${batchRunId}_${c.id}`,
        project_id: c.id,
        observation_timestamp: c.observationTimestamp,
        first_3a_date: c.first3aDate,
        latest_event_date_in_snapshot: c.observationTimestamp,
        features: fv,
        provenance_verified: true
      };

      const result = executeShadowScoring(db, input, nodalUser);
      assert.strictEqual(result.success, true);
      assert.strictEqual(result.evidenceResult.passed, true);
      assert.strictEqual(result.evidenceResult.evidence_status, 'COMPLETE');
      assert.strictEqual(result.evidenceResult.validation_status, 'PASS');
      batchResults.push(result);
    }

    assert.strictEqual(batchResults.length, 3);
  });

  // ========================================================================
  // PART 10: SHADOW RECORD VALIDATION
  // ========================================================================
  console.log('\n--- Part 10: Stored Shadow Record Provenance Audit ---');
  await test('Part 10. Shadow records contain all 12 mandatory statutory provenance columns', () => {
    for (const c of controls) {
      const recordId = `${batchRunId}_${c.id}`;
      const rec = db.prepare('SELECT * FROM shadow_predictions WHERE shadow_run_id = ?').get(recordId) as any;
      assert.ok(rec, `Record ${recordId} must exist in shadow_predictions`);

      assert.strictEqual(rec.project_id, c.id);
      assert.strictEqual(rec.observation_timestamp, c.observationTimestamp);
      assert.strictEqual(rec.model_version, 'BHOOMI-DRISHTI-ML-V2.0-SHADOW');
      assert.strictEqual(rec.model_artifact_sha256, EXPECTED_V2_SHA256);
      assert.strictEqual(rec.dataset_version, '2.0.0-phase4c-authentic');
      assert.strictEqual(rec.prediction_state, 'INSUFFICIENT_EVIDENCE');
      assert.strictEqual(rec.feature_snapshot_hash, snapshotHashes[c.id]);
      assert.strictEqual(rec.evidence_status, 'COMPLETE');
      assert.strictEqual(rec.validation_status, 'PASS');
      assert.ok(rec.scoring_timestamp, 'Must have non-empty scoring_timestamp');
    }
  });

  // ========================================================================
  // PART 11: V1 ISOLATION TEST
  // ========================================================================
  console.log('\n--- Part 11: V1 Production Isolation Test ---');
  await test('Part 11. Production V1 artifact, operational risk scores, and alerts completely untouched', () => {
    const v1ShaAfter = computeFileSha(v1Path);
    assert.strictEqual(v1ShaAfter, CANONICAL_V1_SHA256, 'V1 SHA must remain identical');
    assert.strictEqual(v1ShaAfter, v1ShaBefore, 'V1 SHA must not change during execution');

    const currentProjects = db.prepare('SELECT * FROM projects').all() as any[];
    const currentProjectsHash = crypto.createHash('sha256').update(JSON.stringify(currentProjects)).digest('hex');
    assert.strictEqual(currentProjectsHash, initialProjectsHash, 'Operational projects table must not be mutated');

    const currentAlerts = (db.prepare('SELECT count(*) as c FROM alerts').get() as any).c;
    assert.strictEqual(currentAlerts, initialAlertsCount, 'Alerts count must remain identical');
  });

  // ========================================================================
  // PART 12: SYNTHETIC PROJECT NEGATIVE TEST
  // ========================================================================
  console.log('\n--- Part 12: Synthetic Project Negative Test ---');
  await test('Part 12. Synthetic corridor strictly rejected from authoritative reconstruction & shadow scoring', async () => {
    const synthRecon = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('NHAI-2026-001', '2024-06-01');
    assert.strictEqual(synthRecon.success, false);
    assert.strictEqual(synthRecon.evidenceStatus, 'INSUFFICIENT_EVIDENCE');
    assert.ok(synthRecon.reasons.some(r => r.includes('Synthetic seeded project')));

    // Attempt through evidence gate directly
    const gateRes = validateShadowEvidence({
      project_id: 'NHAI-2026-001',
      observation_timestamp: '2024-06-01',
      first_3a_date: null,
      features: {}
    });
    assert.strictEqual(gateRes.passed, false);
    assert.strictEqual(gateRes.evidence_status, 'PARTIAL');
  });

  // ========================================================================
  // PART 13: PRE-3A NEGATIVE TEST
  // ========================================================================
  console.log('\n--- Part 13: Pre-3A Corridor Negative Test (BhoomiRashi_57405) ---');
  await test('Part 13. BhoomiRashi_57405 evaluated as PRE_3A_STAGE and blocked from scoring', () => {
    const quality = StatutoryStore.getProjectEvidenceQuality('BhoomiRashi_57405');
    assert.strictEqual(quality.section_3a.status, 'PRE_3A_STAGE');
    assert.strictEqual(quality.evidence_status, 'INSUFFICIENT_EVIDENCE');
    assert.strictEqual(quality.is_shadow_scoreable, false);

    const recon = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_57405', '2024-06-01');
    assert.strictEqual(recon.success, false);
    assert.strictEqual(recon.evidenceStatus, 'INSUFFICIENT_EVIDENCE');
    assert.ok(recon.reasons.some(r => r.includes('Missing verified Section 3A date')));
  });

  // ========================================================================
  // PART 14: FUTURE-LEAKAGE NEGATIVE TEST
  // ========================================================================
  console.log('\n--- Part 14: Future-Leakage Controlled Negative Test ---');
  await test('Part 14. Feature vector changes only when notification becomes temporally eligible', () => {
    // For BhoomiRashi_54635:
    // Notice 3173 was published on 2017-11-17.
    const fvBefore = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_54635', '2017-11-16').featureVector!;
    const fvAt = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_54635', '2017-11-17').featureVector!;

    assert.strictEqual(fvBefore.cumulative_notifications_count_at_t, 2);
    assert.strictEqual(fvAt.cumulative_notifications_count_at_t, 4);
    assert.notStrictEqual(fvBefore.notification_cadence_days, fvAt.notification_cadence_days);

    // Days since last notification drops to 0 at publication date
    assert.strictEqual(fvAt.days_since_last_notification, 0);
  });

  // ========================================================================
  // PART 15: DATA MUTATION AUDIT
  // ========================================================================
  console.log('\n--- Part 15: Full Data Mutation Audit ---');
  await test('Part 15. Zero mutations to projects, V1, V2, or operational risk scores', () => {
    const projCount = (db.prepare('SELECT count(*) as c FROM projects').get() as any).c;
    assert.strictEqual(projCount, 31, 'Project count must remain exactly 31');

    const sampleRisk = db.prepare("SELECT risk_level, delay_probability FROM projects WHERE id = 'NHAI-2026-001'").get() as any;
    assert.strictEqual(sampleRisk.risk_level, 'HIGH');
    assert.strictEqual(sampleRisk.delay_probability, 89);
  });

  // ========================================================================
  // PART 16: SECURITY & RBAC AUDIT
  // ========================================================================
  console.log('\n--- Part 16: Security & RBAC Audit ---');
  await test('Part 16. Unauthorized users cannot trigger shadow scoring; audit trail preserved', () => {
    // Audit events recorded for shadow scoring runs
    const recentAudit = db.prepare("SELECT * FROM audit_logs WHERE action = 'SHADOW_SCORING_RUN' ORDER BY timestamp DESC LIMIT 1").get() as any;
    assert.ok(recentAudit, 'Audit log entry must exist for shadow execution');
    assert.strictEqual(recentAudit.result, 'SUCCESS');
    assert.strictEqual(recentAudit.resource, 'shadow_predictions');
  });

  // ========================================================================
  // PART 17 & 18: FINAL HASH & SUMMARY VERIFICATION
  // ========================================================================
  console.log('\n--- Part 18: Final Hash Verification ---');
  const v1ShaFinal = computeFileSha(v1Path);
  const v2ShaFinal = computeFileSha(v2Path);
  const datasetShaFinal = computeFileSha(datasetPath);

  assert.strictEqual(v1ShaFinal, CANONICAL_V1_SHA256, 'V1 SHA matches canonical');
  assert.strictEqual(v2ShaFinal, EXPECTED_V2_SHA256, 'V2 SHA matches canonical');
  assert.strictEqual(datasetShaFinal, EXPECTED_DATASET_SHA256, 'Dataset SHA matches canonical');

  console.log('\n========================================================================');
  console.log(`  Phase 7B-5 Test Suite Finished: ${passed} Passed, ${failed} Failed`);
  console.log('========================================================================\n');

  console.log('V2 Probabilities Generated:');
  for (const c of controls) {
    console.log(`  ${c.id}: ${v2Probabilities[c.id]} (Diff: ${probDifferences[c.id]})`);
  }

  if (failed > 0) {
    process.exit(1);
  }

  return {
    controls,
    v2Probabilities,
    probDifferences,
    batchRunId,
    v1ShaFinal,
    v2ShaFinal,
    datasetShaFinal
  };
}

runPhase7b5Validation().catch(err => {
  console.error('Fatal execution error:', err);
  process.exit(1);
});
