#!/usr/bin/env tsx
/**
 * BhoomiDrishti Phase 3C: Data Source Truthfulness & Synchronization Remediation Test Suite
 * 
 * Covers all 10 required verification areas from Phase 3C Master Prompt:
 *  1. 4 externally sourced projects classified as VERIFIED_EXTERNAL with identifiable source.
 *  2. Seeded/static projects (26) are NEVER classified as VERIFIED_EXTERNAL.
 *  3. Imported CSV project (1) is classified as IMPORTED.
 *  4. Exactly 3 projects have authoritative Section 3A dates; 28 remain strictly NULL.
 *  5. No invented Section 3D fallback date exists anywhere in codebase or data.
 *  6. Manual Section 3A date remains MANUALLY_MAINTAINED/UNVERIFIED unless verified by explicit workflow.
 *  7. Explicit verification workflow promotes unverified manual records only with authoritative reference.
 *  8. Dashboard, ProjectsView, and DataHub report honest partial sync status; misleading claims removed.
 *  9. Test-fixture toggle control and orphaned probe tab are isolated/hidden from production UI.
 * 10. Phase 3B authentication/RBAC tests pass and ML artifact SHA-256 remains strictly unchanged.
 */

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { getDatabase, createProjectRecord, updateProjectRecord, verifyProjectRecord, getProjectById, getDataQualitySummary } from '../src/server/database.ts';
import { requireRole, createSession, validateSession, revokeSession, PRECONFIGURED_USERS } from '../src/server/auth.ts';

const CANONICAL_MODEL_SHA256 = '7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f';
const MODEL_PATH = path.resolve(process.cwd(), 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib');

function computeFileSha256(filePath: string): string {
  const buffer = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

async function runTests() {
  console.log('========================================================================');
  console.log('  BHOOMI-DRISHTI PHASE 3C: DATA SOURCE TRUTHFULNESS & LINEAGE AUDIT');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void> | void) {
    try {
      await fn();
      console.log(`  ✓ ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  ✗ ${name}`);
      console.error(`    Error: ${err.message}`);
      failed++;
    }
  }

  const db = getDatabase();

  // Test 1: ML Model artifact SHA-256 unchanged
  await test('1. ML Artifact SHA-256 strictly preserved (No retraining performed)', () => {
    assert.ok(fs.existsSync(MODEL_PATH), `Model pipeline artifact must exist at ${MODEL_PATH}`);
    const actualHash = computeFileSha256(MODEL_PATH);
    assert.strictEqual(actualHash, CANONICAL_MODEL_SHA256, 'Model SHA-256 must match canonical artifact hash exactly');
  });

  // Test 2: Exactly 4 externally sourced BhoomiRashi projects classified as VERIFIED_EXTERNAL
  await test('2. Exactly 4 operational projects classified as VERIFIED_EXTERNAL with authoritative source', () => {
    const verifiedProjects = db.prepare("SELECT * FROM projects WHERE source_type = 'VERIFIED_EXTERNAL'").all() as any[];
    assert.strictEqual(verifiedProjects.length, 4, `Must have exactly 4 VERIFIED_EXTERNAL projects, found ${verifiedProjects.length}`);

    const verifiedIds = verifiedProjects.map(p => p.id).sort();
    const expectedIds = ['BhoomiRashi_54635', 'BhoomiRashi_56972', 'BhoomiRashi_57405', 'BhoomiRashi_60940'].sort();
    assert.deepStrictEqual(verifiedIds, expectedIds);

    for (const p of verifiedProjects) {
      assert.strictEqual(p.source, 'BhoomiRashi');
      assert.ok(p.source_reference, `Project ${p.id} must have an identifiable source_reference`);
      assert.strictEqual(p.verification_status, 'VERIFIED');
    }
  });

  // Test 3: Seeded and static projects are NEVER presented as VERIFIED_EXTERNAL
  await test('3. Seeded/static projects (26) are never presented as VERIFIED_EXTERNAL', () => {
    const seededProjects = db.prepare("SELECT * FROM projects WHERE source_type = 'SEEDED'").all() as any[];
    assert.strictEqual(seededProjects.length, 26, `Must have exactly 26 SEEDED projects, found ${seededProjects.length}`);

    for (const p of seededProjects) {
      assert.notStrictEqual(p.source_type, 'VERIFIED_EXTERNAL', `Seeded project ${p.id} must not be labeled VERIFIED_EXTERNAL`);
      assert.strictEqual(p.verification_status, 'UNVERIFIED', `Seeded project ${p.id} must be marked UNVERIFIED`);
    }

    // Check LACRRIS records specifically
    const lacrrisProjects = db.prepare("SELECT * FROM projects WHERE source = 'LACRRIS'").all() as any[];
    assert.strictEqual(lacrrisProjects.length, 3, 'Must have exactly 3 LACRRIS projects');
    for (const p of lacrrisProjects) {
      assert.strictEqual(p.source_type, 'SEEDED', `LACRRIS project ${p.id} must be classified as SEEDED`);
      assert.strictEqual(p.verification_status, 'UNVERIFIED');
    }
  });

  // Test 4: Imported CSV project classified as IMPORTED
  await test('4. Imported CSV project is classified as IMPORTED (not VERIFIED_EXTERNAL)', () => {
    const importedProjects = db.prepare("SELECT * FROM projects WHERE source_type = 'IMPORTED'").all() as any[];
    assert.strictEqual(importedProjects.length, 1, `Must have exactly 1 IMPORTED project, found ${importedProjects.length}`);
    const imp = importedProjects[0];
    assert.strictEqual(imp.id, 'OfficialExport_IMP_ROW_1');
    assert.strictEqual(imp.source, 'OfficialExport');
    assert.strictEqual(imp.verification_status, 'UNVERIFIED');
  });

  // Test 5: Section 3A dates: exactly 3 verified, 28 remain NULL
  await test('5. Exactly 3 operational projects have verified Section 3A dates; 28 remain strictly NULL', () => {
    const with3A = db.prepare("SELECT id, section_3a_date, section_3a_source FROM projects WHERE section_3a_date IS NOT NULL").all() as any[];
    assert.strictEqual(with3A.length, 3, `Expected exactly 3 projects with Section 3A date, found ${with3A.length}`);

    const expected3ADates: Record<string, string> = {
      'BhoomiRashi_60940': '2024-01-15',
      'BhoomiRashi_54635': '2017-09-18',
      'BhoomiRashi_56972': '2019-02-12'
    };

    for (const r of with3A) {
      assert.strictEqual(r.section_3a_date, expected3ADates[r.id]);
      assert.strictEqual(r.section_3a_source, 'GAZETTE_OFFICIAL');
    }

    const null3A = db.prepare("SELECT COUNT(*) as c FROM projects WHERE section_3a_date IS NULL").get() as any;
    assert.strictEqual(null3A.c, 28, `Expected exactly 28 projects with NULL Section 3A date, found ${null3A.c}`);
  });

  // Test 6: Invented Section 3D fallback date is removed
  await test('6. Invented Section 3D fallback date ("08 Jul 2024 (Gazette S.O. 1892(E))") is removed', () => {
    const projectDetailsContent = fs.readFileSync(path.resolve(process.cwd(), 'src/components/ProjectDetailsView.tsx'), 'utf-8');
    assert.ok(!projectDetailsContent.includes('08 Jul 2024 (Gazette S.O. 1892(E))'), 'Invented Section 3D fallback date must not be present in ProjectDetailsView.tsx');
    assert.ok(projectDetailsContent.includes('Unavailable / Not recorded'), 'Honest fallback "Unavailable / Not recorded" must be present');
  });

  // Test 7: Manual project maintenance: manual Section 3A date remains unverified
  await test('7. Nodal Officer manual Section 3A date remains unverified unless explicitly verified', () => {
    const testId = `TEST_MANUAL_${Date.now()}`;
    const createRes = createProjectRecord({
      id: testId,
      name: 'Test Manual Highway Corridor',
      sector: 'National Highways',
      state: 'Maharashtra',
      district: 'Pune',
      current_stage: 'Stage 1: Section 3A',
      stage_status: 'In Progress',
      total_land_required_ha: 150.0,
      land_acquired_ha: 20.0,
      section_3a_date: '2025-04-18'
    }, 'USR_NODAL_TEST');

    assert.ok(createRes.success, 'Project creation must succeed');
    const created = getProjectById(testId);
    assert.ok(created, 'Created project must be queryable');
    assert.strictEqual(created?.source_type, 'MANUALLY_MAINTAINED', 'Manually created project must have source_type MANUALLY_MAINTAINED');
    assert.strictEqual(created?.verification_status, 'UNVERIFIED', 'Manual entry must remain UNVERIFIED');
    assert.strictEqual(created?.section_3a_date, '2025-04-18', 'Section 3A date must be preserved');
    assert.strictEqual(created?.section_3a_source, 'MANUAL_ENTRY', 'Section 3A date must have source MANUAL_ENTRY');

    // Clean up test project
    db.prepare('DELETE FROM projects WHERE id = ?').run(testId);
  });

  // Test 8: Explicit verification workflow promotes unverified manual records only with authoritative reference
  await test('8. Explicit verification workflow promotes record to VERIFIED with audit trail', () => {
    const testId = `TEST_VERIFY_${Date.now()}`;
    createProjectRecord({
      id: testId,
      name: 'Test Gazette Verification Corridor',
      sector: 'National Highways',
      state: 'Gujarat',
      district: 'Ahmedabad',
      current_stage: 'Stage 1: Section 3A',
      stage_status: 'In Progress',
      total_land_required_ha: 200.0,
      land_acquired_ha: 50.0,
      section_3a_date: '2024-11-20'
    }, 'USR_NODAL_TEST');

    // Attempt verification without reference -> must fail
    const failRes = verifyProjectRecord(testId, '', 'Nodal Officer Test');
    assert.strictEqual(failRes.success, false, 'Verification without reference must fail');

    // Verify with authoritative reference -> must succeed
    const successRes = verifyProjectRecord(testId, 'Gazette Notification S.O. 981(E) dt. 2024-11-20', 'Nodal Officer Test');
    assert.strictEqual(successRes.success, true, 'Verification with reference must succeed');
    assert.strictEqual(successRes.project?.verification_status, 'VERIFIED');
    assert.strictEqual(successRes.project?.section_3a_source, 'GAZETTE_OFFICIAL');
    assert.strictEqual(successRes.project?.source_reference, 'Gazette Notification S.O. 981(E) dt. 2024-11-20');

    // Clean up test project
    db.prepare('DELETE FROM projects WHERE id = ?').run(testId);
    db.prepare("DELETE FROM audit_logs WHERE entity_id = ?").run(testId);
  });

  // Test 9: UI truthfulness checks: misleading claims removed and test fixtures isolated
  await test('9. UI truthfulness: misleading sync claims removed, test fixture isolated', () => {
    const dashboardContent = fs.readFileSync(path.resolve(process.cwd(), 'src/components/DashboardView.tsx'), 'utf-8');
    assert.ok(!dashboardContent.includes('Statutory Data: Synchronized'), 'Misleading "Statutory Data: Synchronized" must be removed from DashboardView.tsx');
    assert.ok(!dashboardContent.includes('Live BhoomiRashi Ingestion Feed\n              </h2>\n            </div>\n            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1.5">\n              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />\n              Connected'), 'False "Live BhoomiRashi Ingestion Feed - Connected" claim must be removed');
    assert.ok(dashboardContent.includes('Source Status: 4 Verified • 26 Seeded • 1 Imported'), 'Dashboard must display honest source status breakdown');

    const projectsViewContent = fs.readFileSync(path.resolve(process.cwd(), 'src/components/ProjectsView.tsx'), 'utf-8');
    assert.ok(!projectsViewContent.includes('Verified LACRRIS'), 'Misleading "Verified LACRRIS" must be removed from ProjectsView.tsx');
    assert.ok(projectsViewContent.includes('Seeded Benchmark / Fixture'), 'ProjectsView must honestly label seeded benchmark fixtures');

    const dataHubContent = fs.readFileSync(path.resolve(process.cwd(), 'src/components/DataHubManagement.tsx'), 'utf-8');
    assert.ok(!dataHubContent.includes('onClick={() => setActiveTab(\'probe\')}'), 'Orphaned probe tab button must not be exposed in production DataHub tabs');

    // Verify quality summary API
    const summary = getDataQualitySummary();
    assert.strictEqual(summary.totalOperationalProjects, 31);
    assert.strictEqual(summary.externallyVerified, 4);
    assert.strictEqual(summary.seededOrStatic, 26);
    assert.strictEqual(summary.imported, 1);
    assert.strictEqual(summary.verifiedSection3aDates, 3);
    assert.strictEqual(summary.unavailableSection3aDates, 28);
    assert.strictEqual(summary.currentSynchronizationState, 'PARTIAL');
  });

  // Test 10: Phase 3B Authentication & RBAC Regression
  await test('10. Phase 3B Authentication & RBAC regression checks pass', () => {
    const nodalUser = PRECONFIGURED_USERS['nodal.officer@morth.gov.in'];
    const viewerUser = PRECONFIGURED_USERS['viewer.auditor@gov.in'];

    // Session creation & validation
    const nodalSession = createSession(db, nodalUser);
    assert.ok(nodalSession.token.startsWith('bdt_'));
    const validatedNodal = validateSession(db, nodalSession.token);
    assert.strictEqual(validatedNodal?.role, 'NODAL_OFFICER');

    const viewerSession = createSession(db, viewerUser);
    const validatedViewer = validateSession(db, viewerSession.token);
    assert.strictEqual(validatedViewer?.role, 'VIEWER');

    // Revocation
    revokeSession(db, nodalSession.token);
    assert.strictEqual(validateSession(db, nodalSession.token), null, 'Revoked session must be null');

    revokeSession(db, viewerSession.token);
  });

  console.log('\n------------------------------------------------------------------------');
  console.log(`  Phase 3C Verification Summary: ${passed} Passed, ${failed} Failed`);
  console.log('------------------------------------------------------------------------\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch(err => {
  console.error('Fatal error running Phase 3C tests:', err);
  process.exit(1);
});
