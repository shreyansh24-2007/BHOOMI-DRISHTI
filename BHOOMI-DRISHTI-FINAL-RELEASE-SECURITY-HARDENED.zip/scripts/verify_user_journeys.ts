/**
 * BHOOMI-DRISHTI: END-TO-END USER JOURNEY & API INTEGRATION VALIDATION
 * 
 * Verifies live server endpoints against institutional governance requirements:
 * 1. Health check & configuration
 * 2. Nodal Officer authentication and session persistence
 * 3. Dashboard metrics & 31 operational corridors
 * 4. Project detail & point-in-time statutory lineage
 * 5. Shadow diagnostics with non-operational watermarks
 * 6. Authoritative evidence matrix & Pre-3A circuit breaker
 * 7. Shadow monitoring & drift telemetry
 * 8. Shadow evaluation & outcome maturity gating
 * 9. Governance evidence package
 * 10. Viewer session isolation & privilege escalation firewall (403 Forbidden)
 * 11. Session revocation on logout (401 Unauthorized)
 */

import assert from 'node:assert';

const BASE_URL = 'http://localhost:3000/api';
const TEST_DEV_PASSWORD = process.env.AUTH_DEV_PASSWORD || 'BhoomiDev#Test2026';

let passed = 0;
let failed = 0;

async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    console.log(`  ✓ ${name}`);
    passed++;
  } catch (err: any) {
    console.error(`  ✗ ${name}`);
    console.error(`    Error: ${err.message}`);
    failed++;
  }
}

async function runUserJourneyValidation() {
  console.log('========================================================================');
  console.log('  BHOOMI-DRISHTI: END-TO-END USER JOURNEY & REST API VERIFICATION');
  console.log('  Ministry of Road Transport & Highways (MoRTH) / NHAI');
  console.log('========================================================================\n');

  // 1. Health & Config
  console.log('--- 1. Service Health & Auth Config ---');

  await test('1.1 Health endpoint responds with HTTP 200 OK', async () => {
    const res = await fetch(`${BASE_URL}/health`);
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.status, 'ok');
  });

  await test('1.2 Auth session check /auth/me returns unauthenticated initially', async () => {
    const res = await fetch(`${BASE_URL}/auth/me`);
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.isAuthenticated, false);
    assert.ok(data.availableRoles.includes('NODAL_OFFICER'));
    assert.ok(data.availableRoles.includes('VIEWER'));
  });

  // 2. Nodal Officer Journey
  console.log('\n--- 2. Nodal Officer Authentication & Operational Session ---');

  let nodalToken = '';
  await test('2.1 Nodal Officer login succeeds with valid institutional credentials', async () => {
    const res = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'nodal.officer@morth.gov.in', password: TEST_DEV_PASSWORD })
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.success, true);
    assert.strictEqual(data.user.role, 'NODAL_OFFICER');
    assert.ok(data.token);
    nodalToken = data.token;
  });

  await test('2.2 Session persistence: GET /auth/me validates Nodal Officer session', async () => {
    const res = await fetch(`${BASE_URL}/auth/me`, {
      headers: { Authorization: `Bearer ${nodalToken}` }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.isAuthenticated, true);
    assert.strictEqual(data.user.role, 'NODAL_OFFICER');
  });

  // 3. Operational Corridors & Dashboard
  console.log('\n--- 3. Operational Dashboard & Projects Directory ---');

  await test('3.1 Dashboard summary returns operational corridor metrics', async () => {
    const res = await fetch(`${BASE_URL}/dashboard/summary`, {
      headers: { Authorization: `Bearer ${nodalToken}` }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.ok(data.totalProjects !== undefined);
  });

  await test('3.2 Projects directory returns exactly 31 operational projects', async () => {
    const res = await fetch(`${BASE_URL}/projects`, {
      headers: { Authorization: `Bearer ${nodalToken}` }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.total, 31);
    assert.strictEqual(data.items.length, 31);
  });

  await test('3.3 Project detail endpoint returns complete statutory attributes', async () => {
    const res = await fetch(`${BASE_URL}/projects/BhoomiRashi_54635`, {
      headers: { Authorization: `Bearer ${nodalToken}` }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.id, 'BhoomiRashi_54635');
    assert.ok(data.name);
  });

  // 4. Shadow Governance & Diagnostics
  console.log('\n--- 4. Shadow Candidate Telemetry & Evidence Workspaces ---');

  await test('4.1 Project shadow diagnostic returns strictly non-operational label', async () => {
    const res = await fetch(`${BASE_URL}/shadow/project/BhoomiRashi_54635`, {
      headers: { Authorization: `Bearer ${nodalToken}` }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.disclosure, 'SHADOW / DIAGNOSTIC ONLY — NOT AN OPERATIONAL RISK SCORE');
    assert.strictEqual(data.governanceState, 'PENDING_STAKEHOLDER_APPROVAL');
  });

  await test('4.2 Pre-3A corridor BhoomiRashi_57405 is strictly gated from shadow scoring', async () => {
    const res = await fetch(`${BASE_URL}/shadow/project/BhoomiRashi_57405`, {
      headers: { Authorization: `Bearer ${nodalToken}` }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.quality.is_shadow_scoreable, false);
    assert.strictEqual(data.quality.section_3a.status, 'PRE_3A_STAGE');
  });

  await test('4.3 Statutory evidence quality returns corridor quality breakdown', async () => {
    const res = await fetch(`${BASE_URL}/datahub/projects/54635/evidence-quality`, {
      headers: { Authorization: `Bearer ${nodalToken}` }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.ok(data.section_3a);
  });

  await test('4.4 Shadow evaluation evidence package declares V1 only and pending thresholds', async () => {
    const res = await fetch(`${BASE_URL}/shadow/evaluation/evidence-package`, {
      headers: { Authorization: `Bearer ${nodalToken}` }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.evidencePackage.governanceStatus.productionModel, 'V1 ONLY');
    assert.strictEqual(data.evidencePackage.governanceStatus.v2Status, 'SHADOW_CANDIDATE / NON_OPERATIONAL');
    assert.strictEqual(data.evidencePackage.governanceStatus.thresholdStatus, 'PENDING_STAKEHOLDER_APPROVAL');
  });

  // 5. Viewer RBAC & Security Isolation
  console.log('\n--- 5. Viewer RBAC & Privilege Escalation Firewall ---');

  let viewerToken = '';
  await test('5.1 Viewer login succeeds with read-only credentials', async () => {
    const res = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'viewer.auditor@gov.in', password: TEST_DEV_PASSWORD })
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.success, true);
    assert.strictEqual(data.user.role, 'VIEWER');
    assert.ok(data.token);
    viewerToken = data.token;
  });

  await test('5.2 Viewer has transparent read access to shadow telemetry', async () => {
    const res = await fetch(`${BASE_URL}/shadow/runs`, {
      headers: { Authorization: `Bearer ${viewerToken}` }
    });
    assert.strictEqual(res.status, 200);
  });

  await test('5.3 Privilege Escalation Firewall: VIEWER is blocked from shadow scoring mutation with 403', async () => {
    const res = await fetch(`${BASE_URL}/shadow/score`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${viewerToken}`
      },
      body: JSON.stringify({ projectId: '54635' })
    });
    assert.strictEqual(res.status, 403);
    const data = await res.json();
    assert.strictEqual(data.error, 'UNAUTHORIZED_ACCESS');
  });

  // 6. Session Revocation on Logout
  console.log('\n--- 6. Session Revocation on Logout ---');

  await test('6.1 Logout invalidates the active session token', async () => {
    const res = await fetch(`${BASE_URL}/auth/logout`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${viewerToken}` }
    });
    assert.strictEqual(res.status, 200);
  });

  await test('6.2 Revoked session token is rejected on subsequent request with 401', async () => {
    const res = await fetch(`${BASE_URL}/auth/me`, {
      headers: { Authorization: `Bearer ${viewerToken}` }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.isAuthenticated, false);
  });

  console.log('\n========================================================================');
  console.log(`  User Journey & API Verification: ${passed} Passed, ${failed} Failed`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runUserJourneyValidation().catch(err => {
  console.error('Fatal User Journey Error:', err);
  process.exit(1);
});
