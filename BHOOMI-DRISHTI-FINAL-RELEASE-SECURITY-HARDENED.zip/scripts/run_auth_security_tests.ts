/**
 * BHOOMI-DRISHTI COMPREHENSIVE AUTHENTICATION & SECURITY GATES (SECTION 10)
 * 
 * Verifies all 14 mandatory security gates:
 * A. Valid Firebase authentication
 * B. Invalid Firebase token
 * C. Expired Firebase token
 * D. Wrong Firebase project/audience
 * E. Unauthorized user
 * F. Valid authorized user
 * G. VIEWER authorization
 * H. NODAL_OFFICER authorization
 * I. AUDITOR authorization
 * J. Known default password rejected in production
 * K. Missing production auth configuration fails safely
 * L. Demo authentication unavailable in production
 * M. Rate limiting enforcement
 * N. Logout / session invalidation
 */

import assert from 'node:assert/strict';
import * as jose from 'jose';
import { getDatabase } from '../src/server/database.ts';
import {
  initAuthTables,
  verifyToken,
  createSession,
  revokeSession,
  requireAuth,
  requireRole,
  authenticateWithPassword,
  validateAuthEnvironment,
  setCustomJWKSForTesting,
  createDemoToken,
  AuthUser
} from '../src/server/auth.ts';
import { createRateLimiter } from '../src/server/rateLimiter.ts';

let passed = 0;
let failed = 0;

async function test(gate: string, name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    console.log(`  ✓ [Gate ${gate}] ${name}`);
    passed++;
  } catch (err: any) {
    console.error(`  ✗ [Gate ${gate}] ${name}:`, err.message);
    failed++;
  }
}

async function runSecurityAudit() {
  console.log('========================================================================');
  console.log('  BHOOMI-DRISHTI: AUTHENTICATION SECURITY HARDENING AUDIT');
  console.log('  Ministry of Road Transport & Highways (MoRTH) / NHAI');
  console.log('========================================================================\n');

  const db = getDatabase();
  initAuthTables(db);

  // Setup mock RS256 key pair to verify Firebase JWT verification path
  const { publicKey, privateKey } = await jose.generateKeyPair('RS256');
  const publicJwk = await jose.exportJWK(publicKey);
  publicJwk.kid = 'test-firebase-key-01';
  publicJwk.alg = 'RS256';
  publicJwk.use = 'sig';

  const mockJWKS = async (protectedHeader: any) => {
    return publicKey;
  };

  setCustomJWKSForTesting(mockJWKS);

  const PROJECT_ID = process.env.FIREBASE_PROJECT_ID || 'bhoomi-drishti';
  const ISSUER = `https://securetoken.google.com/${PROJECT_ID}`;

  // -------------------------------------------------------------------------
  // GATE A: Valid Firebase Authentication
  // -------------------------------------------------------------------------
  await test('A', 'Valid Firebase ID token verifies successfully and resolves authoritative role', async () => {
    const validToken = await new jose.SignJWT({
      uid: 'USR_NODAL_RAJESH',
      email: 'nodal.officer@morth.gov.in',
      name: 'Er. Rajesh Sharma'
    })
      .setProtectedHeader({ alg: 'RS256', kid: 'test-firebase-key-01' })
      .setIssuer(ISSUER)
      .setAudience(PROJECT_ID)
      .setSubject('USR_NODAL_RAJESH')
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(privateKey);

    const res = await verifyToken(db, validToken);
    assert.equal(res.valid, true);
    assert.equal(res.status, 200);
    assert.ok(res.user);
    assert.equal(res.user.role, 'NODAL_OFFICER');
    assert.equal(res.user.email, 'nodal.officer@morth.gov.in');
  });

  // -------------------------------------------------------------------------
  // GATE B: Invalid Firebase Token (Malformed or Tampered Signature)
  // -------------------------------------------------------------------------
  await test('B', 'Malformed or signature-tampered Firebase token is rejected with 401', async () => {
    // Malformed token
    const malformedRes = await verifyToken(db, 'invalid.malformed.jwt.token');
    assert.equal(malformedRes.valid, false);
    assert.equal(malformedRes.status, 401);

    // Tampered token
    const { privateKey: rogueKey } = await jose.generateKeyPair('RS256');
    const tamperedToken = await new jose.SignJWT({
      uid: 'USR_NODAL_RAJESH',
      email: 'nodal.officer@morth.gov.in'
    })
      .setProtectedHeader({ alg: 'RS256', kid: 'test-firebase-key-01' })
      .setIssuer(ISSUER)
      .setAudience(PROJECT_ID)
      .setSubject('USR_NODAL_RAJESH')
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(rogueKey); // signed by untrusted rogue key

    const tamperedRes = await verifyToken(db, tamperedToken);
    assert.equal(tamperedRes.valid, false);
    assert.equal(tamperedRes.status, 401);
    assert.equal(tamperedRes.error, 'INVALID_FIREBASE_TOKEN');
  });

  // -------------------------------------------------------------------------
  // GATE C: Expired Firebase Token
  // -------------------------------------------------------------------------
  await test('C', 'Expired Firebase ID token is strictly rejected with TOKEN_EXPIRED', async () => {
    const expiredToken = await new jose.SignJWT({
      uid: 'USR_NODAL_RAJESH',
      email: 'nodal.officer@morth.gov.in'
    })
      .setProtectedHeader({ alg: 'RS256', kid: 'test-firebase-key-01' })
      .setIssuer(ISSUER)
      .setAudience(PROJECT_ID)
      .setSubject('USR_NODAL_RAJESH')
      .setIssuedAt(Math.floor(Date.now() / 1000) - 7200)
      .setExpirationTime(Math.floor(Date.now() / 1000) - 3600)
      .sign(privateKey);

    const res = await verifyToken(db, expiredToken);
    assert.equal(res.valid, false);
    assert.equal(res.status, 401);
    assert.equal(res.error, 'TOKEN_EXPIRED');
  });

  // -------------------------------------------------------------------------
  // GATE D: Wrong Firebase Project / Audience & Wrong Issuer
  // -------------------------------------------------------------------------
  await test('D', 'Firebase token for different project/audience or invalid issuer is rejected with 401', async () => {
    // 1. Wrong audience and project
    const wrongAudToken = await new jose.SignJWT({
      uid: 'USR_NODAL_RAJESH',
      email: 'nodal.officer@morth.gov.in'
    })
      .setProtectedHeader({ alg: 'RS256', kid: 'test-firebase-key-01' })
      .setIssuer('https://securetoken.google.com/unauthorized-project-999')
      .setAudience('unauthorized-project-999')
      .setSubject('USR_NODAL_RAJESH')
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(privateKey);

    const res = await verifyToken(db, wrongAudToken);
    assert.equal(res.valid, false);
    assert.equal(res.status, 401);
    assert.equal(res.error, 'INVALID_FIREBASE_TOKEN');

    // 2. Correct audience but wrong issuer
    const wrongIssuerToken = await new jose.SignJWT({
      uid: 'USR_NODAL_RAJESH',
      email: 'nodal.officer@morth.gov.in'
    })
      .setProtectedHeader({ alg: 'RS256', kid: 'test-firebase-key-01' })
      .setIssuer('https://securetoken.google.com/rogue-attacker-project')
      .setAudience(PROJECT_ID)
      .setSubject('USR_NODAL_RAJESH')
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(privateKey);

    const resIssuer = await verifyToken(db, wrongIssuerToken);
    assert.equal(resIssuer.valid, false);
    assert.equal(resIssuer.status, 401);
    assert.equal(resIssuer.error, 'INVALID_FIREBASE_TOKEN');
  });

  // -------------------------------------------------------------------------
  // GATE E: Unauthorized User
  // -------------------------------------------------------------------------
  await test('E', 'Unauthenticated request receives 401; unregistered user is auto-scoped to least-privilege VIEWER', async () => {
    // 1. Unauthenticated request without token
    let unauthCode: number | null = null;
    let unauthBody: any = null;
    const mockReq1: any = { headers: {}, originalUrl: '/api/projects', method: 'GET', ip: '127.0.0.1' };
    const mockRes1: any = {
      status(c: number) { unauthCode = c; return this; },
      json(b: any) { unauthBody = b; return this; }
    };
    requireAuth(mockReq1, mockRes1, () => {});
    assert.equal(unauthCode, 401);
    assert.equal(unauthBody?.error, 'AUTHENTICATION_REQUIRED');

    // 2. Unregistered external user token
    const externalToken = await new jose.SignJWT({
      uid: 'USR_EXTERNAL_123',
      email: 'external.auditor@nic.in',
      name: 'External Auditor'
    })
      .setProtectedHeader({ alg: 'RS256', kid: 'test-firebase-key-01' })
      .setIssuer(ISSUER)
      .setAudience(PROJECT_ID)
      .setSubject('USR_EXTERNAL_123')
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(privateKey);

    const res = await verifyToken(db, externalToken);
    assert.equal(res.valid, true);
    assert.ok(res.user);
    assert.equal(res.user.role, 'VIEWER', 'Unregistered user must default to read-only VIEWER');

    // Verify least-privilege VIEWER is blocked from Nodal Officer routes
    let blockedCode: number | null = null;
    const mockReq2: any = { user: res.user, originalUrl: '/api/projects', method: 'POST', ip: '127.0.0.1' };
    const mockRes2: any = {
      status(c: number) { blockedCode = c; return this; },
      json() { return this; }
    };
    requireRole(['NODAL_OFFICER'])(mockReq2, mockRes2, () => {});
    assert.equal(blockedCode, 403);
  });

  // -------------------------------------------------------------------------
  // GATE F: Valid Authorized User
  // -------------------------------------------------------------------------
  await test('F', 'Authorized institutional user resolves verified profile and assigned authority', async () => {
    const userAccount = db.prepare('SELECT * FROM user_accounts WHERE email = ?').get('nodal.officer@morth.gov.in') as any;
    assert.ok(userAccount);
    assert.equal(userAccount.role, 'NODAL_OFFICER');
    assert.equal(userAccount.status, 'ACTIVE');
  });

  // -------------------------------------------------------------------------
  // GATE G: VIEWER Authorization
  // -------------------------------------------------------------------------
  await test('G', 'VIEWER role is granted read-only access and blocked from mutations with 403', async () => {
    const viewerUser: AuthUser = {
      id: 'USR_VIEWER_POOJA',
      name: 'Pooja Verma',
      email: 'viewer.auditor@gov.in',
      role: 'VIEWER',
      status: 'ACTIVE',
      designation: 'Senior Project Monitoring Auditor',
      department: 'Infrastructure Oversight'
    };

    let passNext = false;
    let blockedStatus: number | null = null;

    // Read-only endpoint check
    requireRole(['VIEWER', 'NODAL_OFFICER', 'AUDITOR'])({ user: viewerUser } as any, {} as any, () => {
      passNext = true;
    });
    assert.equal(passNext, true, 'VIEWER must pass read-only role check');

    // Mutating endpoint check
    const mockRes: any = {
      status(c: number) { blockedStatus = c; return this; },
      json() { return this; }
    };
    requireRole(['NODAL_OFFICER'])({ user: viewerUser, originalUrl: '/api/projects', method: 'DELETE', ip: '127.0.0.1' } as any, mockRes, () => {});
    assert.equal(blockedStatus, 403, 'VIEWER must be blocked from mutations with 403');
  });

  // -------------------------------------------------------------------------
  // GATE H: NODAL_OFFICER Authorization
  // -------------------------------------------------------------------------
  await test('H', 'NODAL_OFFICER role passes administrative mutation authorization check', async () => {
    const nodalUser: AuthUser = {
      id: 'USR_NODAL_RAJESH',
      name: 'Er. Rajesh Sharma',
      email: 'nodal.officer@morth.gov.in',
      role: 'NODAL_OFFICER',
      status: 'ACTIVE',
      designation: 'CALA Nodal Officer',
      department: 'MoRTH'
    };

    let passMutation = false;
    requireRole(['NODAL_OFFICER'])({ user: nodalUser } as any, {} as any, () => {
      passMutation = true;
    });
    assert.equal(passMutation, true, 'NODAL_OFFICER must pass mutation authorization');
  });

  // -------------------------------------------------------------------------
  // GATE I: AUDITOR Authorization
  // -------------------------------------------------------------------------
  await test('I', 'AUDITOR role is recognized, authorized for audit inspection, and blocked from mutations', async () => {
    // Insert test auditor if not present
    db.prepare(`
      INSERT OR REPLACE INTO user_accounts (uid, email, name, role, status, designation, department, created_at, updated_at)
      VALUES ('USR_AUDITOR_TEST', 'test.auditor@cag.gov.in', 'Test Auditor General', 'AUDITOR', 'ACTIVE', 'Principal Auditor', 'CAG Oversight', datetime('now'), datetime('now'))
    `).run();

    const auditorUser: AuthUser = {
      id: 'USR_AUDITOR_TEST',
      name: 'Test Auditor General',
      email: 'test.auditor@cag.gov.in',
      role: 'AUDITOR',
      status: 'ACTIVE',
      designation: 'Principal Auditor',
      department: 'CAG Oversight'
    };

    let passAuditRead = false;
    requireRole(['NODAL_OFFICER', 'AUDITOR', 'VIEWER'])({ user: auditorUser } as any, {} as any, () => {
      passAuditRead = true;
    });
    assert.equal(passAuditRead, true, 'AUDITOR must pass read inspection check');

    let blockedStatus: number | null = null;
    const mockRes: any = {
      status(c: number) { blockedStatus = c; return this; },
      json() { return this; }
    };
    requireRole(['NODAL_OFFICER'])({ user: auditorUser, originalUrl: '/api/projects', method: 'POST', ip: '127.0.0.1' } as any, mockRes, () => {});
    assert.equal(blockedStatus, 403, 'AUDITOR must be blocked from administrative mutations with 403');
  });

  // -------------------------------------------------------------------------
  // GATE J: Known Default Password Rejected in Production
  // -------------------------------------------------------------------------
  await test('J', 'Known default password is strictly rejected in production mode', async () => {
    const origNodeEnv = process.env.NODE_ENV;
    const origDemoMode = process.env.DEMO_MODE;

    try {
      process.env.NODE_ENV = 'production';
      process.env.DEMO_MODE = 'false';

      // Attempt to authenticate with the known default password
      const res = await authenticateWithPassword(db, 'nodal.officer@morth.gov.in', 'Bhoomi@2026!');
      assert.equal(res.valid, false, 'Default password must NEVER succeed in production');
      assert.equal(res.status, 401);
      assert.ok(['INVALID_CREDENTIALS', 'PASSWORD_AUTH_DISABLED'].includes(res.error || ''));
    } finally {
      process.env.NODE_ENV = origNodeEnv;
      process.env.DEMO_MODE = origDemoMode;
    }
  });

  // -------------------------------------------------------------------------
  // GATE K: Missing Production Auth Configuration Fails Safely
  // -------------------------------------------------------------------------
  await test('K', 'validateAuthEnvironment fails safely on missing configuration or dangerous default passwords', async () => {
    const origNodeEnv = process.env.NODE_ENV;
    const origDemoMode = process.env.DEMO_MODE;
    const origFirebase = process.env.FIREBASE_PROJECT_ID;
    const origViteFirebase = process.env.VITE_FIREBASE_PROJECT_ID;
    const origAuthDef = process.env.AUTH_DEFAULT_PASSWORD;

    try {
      process.env.NODE_ENV = 'production';
      process.env.DEMO_MODE = 'false';

      // 1. Missing Firebase Project ID
      delete process.env.FIREBASE_PROJECT_ID;
      delete process.env.VITE_FIREBASE_PROJECT_ID;
      const resMissing = validateAuthEnvironment();
      assert.equal(resMissing.ok, false);
      assert.ok(resMissing.error?.includes('MISSING_PRODUCTION_AUTH_CONFIGURATION'));

      // 2. Dangerous default password configured
      process.env.FIREBASE_PROJECT_ID = 'bhoomi-drishti';
      process.env.AUTH_DEFAULT_PASSWORD = 'Bhoomi@2026!';
      const resDangerous = validateAuthEnvironment();
      assert.equal(resDangerous.ok, false);
      assert.ok(resDangerous.error?.includes('CRITICAL_SECURITY_CONFIGURATION_ERROR'));

      // 3. Any AUTH_DEFAULT_PASSWORD in production is strictly prohibited
      process.env.AUTH_DEFAULT_PASSWORD = 'CustomArbitraryPassword123!';
      const resDevOnly = validateAuthEnvironment();
      assert.equal(resDevOnly.ok, false);
      assert.ok(resDevOnly.error?.includes('CRITICAL_SECURITY_CONFIGURATION_ERROR'));
    } finally {
      process.env.NODE_ENV = origNodeEnv;
      process.env.DEMO_MODE = origDemoMode;
      if (origFirebase) process.env.FIREBASE_PROJECT_ID = origFirebase;
      if (origViteFirebase) process.env.VITE_FIREBASE_PROJECT_ID = origViteFirebase;
      if (origAuthDef) process.env.AUTH_DEFAULT_PASSWORD = origAuthDef;
      else delete process.env.AUTH_DEFAULT_PASSWORD;
    }
  });

  // -------------------------------------------------------------------------
  // GATE L: Demo Authentication Unavailable in Production
  // -------------------------------------------------------------------------
  await test('L', 'Demo tokens and persona switching are strictly unavailable when DEMO_MODE is false', async () => {
    const origNodeEnv = process.env.NODE_ENV;
    const origDemoMode = process.env.DEMO_MODE;

    try {
      process.env.NODE_ENV = 'production';
      process.env.DEMO_MODE = 'false';

      // Create a demo token
      const demoToken = await createDemoToken({ uid: 'USR_NODAL_RAJESH', email: 'nodal.officer@morth.gov.in' }, 3600);
      const res = await verifyToken(db, demoToken);
      assert.equal(res.valid, false);
      assert.equal(res.status, 401);
      assert.equal(res.error, 'DEMO_TOKENS_FORBIDDEN_IN_PRODUCTION');
    } finally {
      process.env.NODE_ENV = origNodeEnv;
      process.env.DEMO_MODE = origDemoMode;
    }
  });

  // -------------------------------------------------------------------------
  // GATE M: Rate Limiting Enforcement
  // -------------------------------------------------------------------------
  await test('M', 'Sliding window rate limiter blocks excessive requests with 429 RATE_LIMIT_EXCEEDED', async () => {
    const limiter = createRateLimiter({
      windowMs: 5000,
      maxRequests: 2,
      message: 'Rate limit exceeded'
    });

    const mockReq = { ip: '10.0.0.1', headers: {}, socket: {} } as any;
    let statusCode: number | null = null;
    let jsonBody: any = null;
    let headersSet: Record<string, string> = {};

    const mockRes = {
      setHeader: (k: string, v: string) => { headersSet[k] = v; },
      status: (code: number) => { statusCode = code; return { json: (b: any) => { jsonBody = b; } }; }
    } as any;

    let nextCount = 0;
    const next = () => { nextCount++; };

    // Request 1 -> pass
    limiter(mockReq, mockRes, next);
    // Request 2 -> pass
    limiter(mockReq, mockRes, next);
    assert.equal(nextCount, 2);

    // Request 3 -> blocked
    limiter(mockReq, mockRes, next);
    assert.equal(nextCount, 2);
    assert.equal(statusCode, 429);
    assert.equal(jsonBody?.error, 'RATE_LIMIT_EXCEEDED');
    assert.ok(headersSet['Retry-After']);
  });

  // -------------------------------------------------------------------------
  // GATE N: Logout / Session Invalidation
  // -------------------------------------------------------------------------
  await test('N', 'Session revocation invalidates token; subsequent calls return 401 TOKEN_REVOKED', async () => {
    const user: AuthUser = {
      id: 'USR_NODAL_RAJESH',
      name: 'Er. Rajesh Sharma',
      email: 'nodal.officer@morth.gov.in',
      role: 'NODAL_OFFICER',
      status: 'ACTIVE',
      designation: 'CALA Officer',
      department: 'MoRTH'
    };

    const session = createSession(db, user);
    assert.ok(session.token);

    // Active session verifies
    const activeRes = await verifyToken(db, session.token);
    assert.equal(activeRes.valid, true);

    // Revoke session
    const revoked = revokeSession(db, session.token);
    assert.equal(revoked, true);

    // Revoked session rejected
    const postRes = await verifyToken(db, session.token);
    assert.equal(postRes.valid, false);
    assert.equal(postRes.status, 401);
    assert.equal(postRes.error, 'TOKEN_REVOKED');
  });

  // Reset custom JWKS
  setCustomJWKSForTesting(null);

  console.log('\n========================================================================');
  console.log(`  Security Audit Results: ${passed} Passed, ${failed} Failed (Total: ${passed + failed})`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runSecurityAudit().catch(err => {
  console.error('Fatal security audit failure:', err);
  process.exit(1);
});
