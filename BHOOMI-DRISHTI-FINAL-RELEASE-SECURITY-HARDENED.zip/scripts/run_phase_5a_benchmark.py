#!/usr/bin/env python3
"""
BhoomiDrishti Phase 5A: Stratified Group Cross-Validation & Candidate Model Benchmarking

Evaluates candidate supervised learning models using the authentic reconstructed dataset:
  Dataset: data/reconstructed_longitudinal_dataset_v2.json
  Version: 2.0.0-phase4c-authentic
  SHA-256: 0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a

Strict Constraints Enforced:
1. Frozen Production Artifact SHA-256 preserved (7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f).
2. Pure Model Evaluation: Zero retraining of production artifact, zero overwrite of model_pipeline.joblib.
3. No SMOTE, no synthetic sampling, no minority duplication, no T180 snapshots.
4. Strict StratifiedGroupKFold on project_id: Zero project leakage between train and test splits.
5. Point-in-time feature quarantine: No Section 3D or target metrics in feature vectors.
"""

import os
import sys
import json
import hashlib
import numpy as np
import pandas as pd

from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import (
    roc_auc_score, average_precision_score, precision_score, recall_score,
    f1_score, balanced_accuracy_score, brier_score_loss, confusion_matrix
)
from sklearn.model_selection import StratifiedGroupKFold

RANDOM_SEED = 42
CANONICAL_MODEL_SHA256 = '7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f'
DATASET_SHA256 = '0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a'
MODEL_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib'
DATASET_PATH = 'data/reconstructed_longitudinal_dataset_v2.json'


def compute_file_sha256(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(8192):
            h.update(chunk)
    return h.hexdigest()


def verify_integrity():
    print("=" * 78)
    print("  PHASE 5A: INTEGRITY AUDIT & PRE-FLIGHT VERIFICATION")
    print("=" * 78)

    # 1. Verify frozen production artifact
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Production artifact missing at {MODEL_PATH}")
    model_hash = compute_file_sha256(MODEL_PATH)
    print(f"Production Artifact SHA-256: {model_hash}")
    assert model_hash == CANONICAL_MODEL_SHA256, (
        f"CRITICAL: Production artifact SHA mismatch! Expected {CANONICAL_MODEL_SHA256}, got {model_hash}"
    )
    print("  [PASS] Production model artifact is FROZEN and UNTOUCHED.\n")

    # 2. Verify reconstructed dataset
    if not os.path.exists(DATASET_PATH):
        raise FileNotFoundError(f"Reconstructed dataset missing at {DATASET_PATH}")
    dataset_hash = compute_file_sha256(DATASET_PATH)
    print(f"Reconstructed Dataset SHA-256: {dataset_hash}")
    assert dataset_hash == DATASET_SHA256, (
        f"CRITICAL: Dataset SHA mismatch! Expected {DATASET_SHA256}, got {dataset_hash}"
    )
    print("  [PASS] Authentic reconstructed dataset SHA-256 verified.\n")

    with open(DATASET_PATH, 'r') as f:
        data = json.load(f)

    meta = data['metadata']
    obs = data['observations']

    print(f"Total Observations:    {len(obs)} (Expected: 399)")
    print(f"Unique Projects:       {meta['unique_projects']} (Expected: 152)")
    print(f"Delayed Observations:  {meta['target_summary']['delayed']} (Expected: 327)")
    print(f"On-Track Observations: {meta['target_summary']['not_delayed']} (Expected: 72)")

    assert len(obs) == 399, f"Expected 399 observations, got {len(obs)}"
    assert meta['unique_projects'] == 152, f"Expected 152 projects, got {meta['unique_projects']}"
    assert meta['target_summary']['delayed'] == 327, f"Expected 327 delayed, got {meta['target_summary']['delayed']}"
    assert meta['target_summary']['not_delayed'] == 72, f"Expected 72 not delayed, got {meta['target_summary']['not_delayed']}"

    # Verify no Section 3D date or target leaks in features
    quarantine_forbidden = ['section_3d_date', 'delayed', 'target', 'duration_days', 'eventual_duration_days']
    seen_keys = set()
    for o in obs:
        # Deduplication
        k = (o['project_id'], o['observation_timestamp'])
        assert k not in seen_keys, f"Duplicate observation key detected: {k}"
        seen_keys.add(k)

        # No T180
        assert 'T180' not in o['observation_id'], f"Synthetic T180 record found: {o['observation_id']}"

        # Feature quarantine
        for fld in quarantine_forbidden:
            assert fld not in o['features'], f"Leakage detected: {fld} in feature dictionary"

    print("  [PASS] Zero synthetic T180 records.")
    print("  [PASS] Zero duplicate (project_id, timestamp) rows.")
    print("  [PASS] Zero target/Section 3D leakage into feature matrix.")
    print("=" * 78 + "\n")
    return obs


def build_dataframe(observations):
    rows = []
    for o in observations:
        r = dict(o['features'])
        r['project_id'] = o['project_id']
        r['observation_timestamp'] = o['observation_timestamp']
        r['delayed'] = o['target']['delayed']
        r['target_type'] = o['target']['target_type']
        # Sector is National Highways across 100% of authentic cohort
        r['primary_sector'] = 'National Highways'
        rows.append(r)
    return pd.DataFrame(rows)


def run_cross_validation_benchmark(df):
    print("=" * 78)
    print("  PHASE 5A: 5-FOLD STRATIFIED GROUP CROSS-VALIDATION BENCHMARK")
    print("=" * 78)

    num_features = [
        'elapsed_days_since_first_3a',
        'cumulative_notifications_count_at_t',
        'notification_cadence_days',
        'days_since_last_notification',
        'statutory_notification_frequency_180d',
        'total_land_required_ha',
        'initial_sanction_available_at_t'
    ]
    cat_features = [
        'statutory_stage_at_t',
        'implementing_agency',
        'state_jurisdiction'
    ]

    def create_preprocessor():
        return ColumnTransformer(
            transformers=[
                ('num', Pipeline([
                    ('imputer', SimpleImputer(strategy='median')),
                    ('scaler', StandardScaler())
                ]), num_features),
                ('cat', Pipeline([
                    ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
                ]), cat_features)
            ],
            remainder='drop'
        )

    y = df['delayed'].values
    groups = df['project_id'].values

    sgkf = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=RANDOM_SEED)

    candidate_models = {
        'Majority Prior Baseline': DummyClassifier(strategy='prior'),
        'Logistic Regression (Balanced)': LogisticRegression(
            class_weight='balanced', max_iter=1000, random_state=RANDOM_SEED
        ),
        'Random Forest (Balanced, max_depth=6)': RandomForestClassifier(
            n_estimators=100, max_depth=6, min_samples_leaf=2,
            class_weight='balanced', random_state=RANDOM_SEED
        ),
        'HistGradientBoosting (Balanced)': HistGradientBoostingClassifier(
            max_iter=100, max_depth=5, class_weight='balanced', random_state=RANDOM_SEED
        ),
        'Calibrated Logistic Regression (Sigmoid)': CalibratedClassifierCV(
            estimator=LogisticRegression(class_weight='balanced', max_iter=1000, random_state=RANDOM_SEED),
            method='sigmoid', cv=3
        )
    }

    benchmark_results = {}

    for name, clf in candidate_models.items():
        print(f"\n--- Model: {name} ---")
        fold_metrics = []
        all_y_true = []
        all_y_pred = []
        all_y_prob = []

        for fold, (train_idx, test_idx) in enumerate(sgkf.split(df, y, groups)):
            train_df, test_df = df.iloc[train_idx], df.iloc[test_idx]
            y_train, y_test = y[train_idx], y[test_idx]

            # Assert strict group isolation
            train_groups = set(groups[train_idx])
            test_groups = set(groups[test_idx])
            overlap = train_groups.intersection(test_groups)
            assert len(overlap) == 0, f"FATAL: Group leakage in fold {fold}: {overlap}"

            prep = create_preprocessor()
            pipe = Pipeline([('prep', prep), ('clf', clf)])
            pipe.fit(train_df, y_train)

            probs = pipe.predict_proba(test_df)[:, 1]
            preds = (probs >= 0.5).astype(int)

            roc = roc_auc_score(y_test, probs)
            pr = average_precision_score(y_test, probs)
            bal_acc = balanced_accuracy_score(y_test, preds)
            f1 = f1_score(y_test, preds, zero_division=0)
            prec = precision_score(y_test, preds, zero_division=0)
            rec = recall_score(y_test, preds, zero_division=0)
            brier = brier_score_loss(y_test, probs)

            fold_metrics.append({
                'fold': fold,
                'train_n': len(train_idx),
                'test_n': len(test_idx),
                'test_delayed': int(y_test.sum()),
                'test_not_delayed': int(len(test_idx) - y_test.sum()),
                'roc_auc': roc,
                'pr_auc': pr,
                'balanced_acc': bal_acc,
                'f1': f1,
                'precision': prec,
                'recall': rec,
                'brier': brier
            })

            all_y_true.extend(y_test)
            all_y_pred.extend(preds)
            all_y_prob.extend(probs)

            print(f"  Fold {fold}: Test N={len(test_idx)} (Del={y_test.sum():2d}, NotDel={len(test_idx)-y_test.sum():2d}) | "
                  f"ROC-AUC: {roc:.4f} | PR-AUC: {pr:.4f} | BalAcc: {bal_acc:.4f} | F1: {f1:.4f} | Brier: {brier:.4f}")

        m_df = pd.DataFrame(fold_metrics)
        agg_cm = confusion_matrix(all_y_true, all_y_pred).tolist()

        summary = {
            'roc_auc_mean': float(m_df['roc_auc'].mean()),
            'roc_auc_std': float(m_df['roc_auc'].std()),
            'pr_auc_mean': float(m_df['pr_auc'].mean()),
            'pr_auc_std': float(m_df['pr_auc'].std()),
            'balanced_acc_mean': float(m_df['balanced_acc'].mean()),
            'balanced_acc_std': float(m_df['balanced_acc'].std()),
            'f1_mean': float(m_df['f1'].mean()),
            'f1_std': float(m_df['f1'].std()),
            'precision_mean': float(m_df['precision'].mean()),
            'precision_std': float(m_df['precision'].std()),
            'recall_mean': float(m_df['recall'].mean()),
            'recall_std': float(m_df['recall'].std()),
            'brier_mean': float(m_df['brier'].mean()),
            'brier_std': float(m_df['brier'].std()),
            'confusion_matrix': agg_cm,
            'folds': fold_metrics
        }
        benchmark_results[name] = summary

        print(f"  --> MEAN: ROC-AUC={summary['roc_auc_mean']:.4f}±{summary['roc_auc_std']:.4f} | "
              f"PR-AUC={summary['pr_auc_mean']:.4f}±{summary['pr_auc_std']:.4f} | "
              f"BalAcc={summary['balanced_acc_mean']:.4f}±{summary['balanced_acc_std']:.4f} | "
              f"F1={summary['f1_mean']:.4f}±{summary['f1_std']:.4f} | "
              f"Brier={summary['brier_mean']:.4f}±{summary['brier_std']:.4f}")
        print(f"      Aggregate Confusion Matrix: TN={agg_cm[0][0]}, FP={agg_cm[0][1]}, FN={agg_cm[1][0]}, TP={agg_cm[1][1]}")

    return benchmark_results


def compute_feature_importances(df):
    print("\n" + "=" * 78)
    print("  PHASE 5A: FEATURE IMPORTANCE ANALYSIS (Random Forest)")
    print("=" * 78)

    num_features = [
        'elapsed_days_since_first_3a',
        'cumulative_notifications_count_at_t',
        'notification_cadence_days',
        'days_since_last_notification',
        'statutory_notification_frequency_180d',
        'total_land_required_ha',
        'initial_sanction_available_at_t'
    ]
    cat_features = [
        'statutory_stage_at_t',
        'implementing_agency',
        'state_jurisdiction'
    ]

    prep = ColumnTransformer(
        transformers=[
            ('num', Pipeline([
                ('imputer', SimpleImputer(strategy='median')),
                ('scaler', StandardScaler())
            ]), num_features),
            ('cat', Pipeline([
                ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
            ]), cat_features)
        ],
        remainder='drop'
    )

    rf = RandomForestClassifier(
        n_estimators=100, max_depth=6, min_samples_leaf=2,
        class_weight='balanced', random_state=RANDOM_SEED
    )
    pipe = Pipeline([('prep', prep), ('clf', rf)])
    pipe.fit(df.drop(columns=['delayed', 'project_id', 'observation_timestamp', 'target_type']), df['delayed'])

    onehot_cols = prep.named_transformers_['cat'].named_steps['onehot'].get_feature_names_out(cat_features).tolist()
    all_feature_names = num_features + onehot_cols
    importances = rf.feature_importances_

    sorted_indices = np.argsort(importances)[::-1]
    importance_records = []
    print("\nRanked Feature Importances (Gini Impurity Reduction):")
    for rank, idx in enumerate(sorted_indices, 1):
        feat_name = all_feature_names[idx]
        imp_val = float(importances[idx])
        importance_records.append({'rank': rank, 'feature': feat_name, 'importance': imp_val})
        if rank <= 12:
            print(f"  {rank:2d}. {feat_name:48}: {imp_val:.4f} ({imp_val*100:.1f}%)")

    return importance_records


def main():
    obs = verify_integrity()
    df = build_dataframe(obs)
    bench_results = run_cross_validation_benchmark(df)
    importances = compute_feature_importances(df)

    # Post-check: ensure frozen model artifact is untouched
    final_model_hash = compute_file_sha256(MODEL_PATH)
    assert final_model_hash == CANONICAL_MODEL_SHA256, "Post-benchmark model SHA mismatch!"
    print("\n" + "=" * 78)
    print("  POST-BENCHMARK ARTIFACT INTEGRITY CHECK: PASS")
    print(f"  Model Pipeline SHA-256 strictly preserved: {final_model_hash}")
    print("=" * 78)

    # Write evaluation benchmark summary report to disk
    report_path = 'data/phase_5a_benchmark_report.json'
    with open(report_path, 'w') as f:
        json.dump({
            'phase': '5A-STRATIFIED-GROUP-CV-BENCHMARK',
            'dataset_sha256': DATASET_SHA256,
            'model_artifact_sha256': final_model_hash,
            'observations_count': len(df),
            'unique_projects': int(df['project_id'].nunique()),
            'delayed_count': int(df['delayed'].sum()),
            'not_delayed_count': int(len(df) - df['delayed'].sum()),
            'benchmarks': bench_results,
            'feature_importances': importances
        }, f, indent=2)
    print(f"\nBenchmark report successfully saved to {report_path}\n")


if __name__ == '__main__':
    main()
