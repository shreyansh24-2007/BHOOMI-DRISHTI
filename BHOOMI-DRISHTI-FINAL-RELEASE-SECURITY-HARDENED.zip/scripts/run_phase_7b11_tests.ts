/**
 * BHOOMI-DRISHTI PHASE 7B-11: SHADOW GOVERNANCE EVIDENCE PACKAGE INTEGRATION & INSTITUTIONAL READINESS
 * 
 * Verifies:
 * 1. Cryptographic Invariants (V1 SHA, V2 SHA, Dataset SHA)
 * 2. Feature Contract (SCHEMA-LONGITUDINAL-V2.0-10FEAT)
 * 3. Threshold Governance Status (PENDING_STAKEHOLDER_APPROVAL)
 * 4. Evidence Package Persistence & Integrity (phase_7b10_evidence_package.json)
 * 5. REST API Route Registration (/api/shadow/evaluation/evidence-package)
 * 6. Evidence Package API Payload Integrity & Canonical Matching
 * 7. Evidence Coverage Distribution across all 31 operational projects
 * 8. Statistical Outcome Maturity Gating (sample < 10 suppression)
 * 9. Production Model Isolation (V1 exclusive, zero V2 in production routes)
 * 10. Database Immutability & PRAGMA integrity_check
 * 11. Zero mutations to operational risk scores, alerts, or recommendations
 * 12. UI Evidence Package Governance Tab Integration without Activation Buttons
 */

import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { getDatabase } from '../src/server/database.ts';
import {
  CANONICAL_V1_SHA256,
  CANONICAL_V2_SHA256,
  CANONICAL_BASELINE_DATASET_SHA,
  CANONICAL_FEATURE_SCHEMA
} from '../src/server/ml/shadowEvaluationEngine.ts';
import { ORDERED_SHADOW_FEATURES, FORBIDDEN_QUARANTINE_KEYS } from '../src/server/ml/shadowFeatureSchema.ts';
import { SHADOW_POLICY_CONFIG, scoreCandidateArtifact } from '../src/server/ml/shadowRunner.ts';

const V1_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib';
const V2_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_pipeline.joblib';
const DATASET_PATH = 'data/reconstructed_longitudinal_dataset_v2.json';
const EVIDENCE_PACKAGE_PATH = 'data/shadow_evaluation/phase_7b10_evidence_package.json';

function computeSha(filePath: string): string {
  const buf = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buf).digest('hex');
}

let passed = 0;
let failed = 0;

async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    console.log(`  ✓ ${name}`);
    passed++;
  } catch (err: any) {
    console.error(`  ✗ ${name}`);
    console.error(`    Error: ${err.message}`);
    failed++;
  }
}

async function runPhase7B11Audit() {
  console.log('========================================================================');
  console.log('  PHASE 7B-11: SHADOW EVIDENCE PACKAGE & INSTITUTIONAL READINESS AUDIT');
  console.log('  Ministry of Road Transport & Highways (MoRTH) / NHAI');
  console.log('========================================================================\n');

  const db = getDatabase();

  // Snapshot initial database state
  const initialProjectCount = (db.prepare('SELECT COUNT(*) as c FROM projects').get() as any).c;
  const initialProjectsData = db.prepare('SELECT id, risk_level, delay_probability FROM projects').all();
  const initialAlertsCount = (db.prepare('SELECT COUNT(*) as c FROM alerts').get() as any).c;
  const initialRecommendationsCount = (db.prepare('SELECT COUNT(*) as c FROM project_recommendations').get() as any).c;

  // 1. CANONICAL CRYPTOGRAPHIC INVARIANTS
  console.log('--- 1. Cryptographic Invariants ---');

  await test('1. Production V1 artifact SHA-256 strictly preserved', () => {
    assert.strictEqual(computeSha(V1_PATH), CANONICAL_V1_SHA256);
  });

  await test('2. Candidate V2 artifact SHA-256 strictly preserved', () => {
    assert.strictEqual(computeSha(V2_PATH), CANONICAL_V2_SHA256);
  });

  await test('3. Authenticated Phase 4C baseline dataset SHA-256 strictly verified', () => {
    assert.strictEqual(computeSha(DATASET_PATH), CANONICAL_BASELINE_DATASET_SHA);
  });

  await test('4. Feature schema strictly conforms to SCHEMA-LONGITUDINAL-V2.0-10FEAT', () => {
    assert.strictEqual(ORDERED_SHADOW_FEATURES.length, 10);
    assert.strictEqual(CANONICAL_FEATURE_SCHEMA, 'SCHEMA-LONGITUDINAL-V2.0-10FEAT');
  });

  await test('5. Quarantined statutory features remain strictly excluded', () => {
    for (const forbidden of FORBIDDEN_QUARANTINE_KEYS) {
      assert.ok(!ORDERED_SHADOW_FEATURES.includes(forbidden as any));
    }
  });

  // 2. EVIDENCE PACKAGE FILE & METADATA AUDIT
  console.log('\n--- 2. Evidence Package File & Schema Verification ---');

  let packageData: any = null;

  await test('6. Evidence package file exists at data/shadow_evaluation/phase_7b10_evidence_package.json', () => {
    assert.ok(fs.existsSync(EVIDENCE_PACKAGE_PATH));
    packageData = JSON.parse(fs.readFileSync(EVIDENCE_PACKAGE_PATH, 'utf-8'));
    assert.ok(packageData);
  });

  await test('7. Evidence package declares V2 status as SHADOW_CANDIDATE / NON_OPERATIONAL', () => {
    assert.strictEqual(packageData.governanceStatus.v2Status, 'SHADOW_CANDIDATE / NON_OPERATIONAL');
    assert.strictEqual(packageData.governanceStatus.v2Promoted, false);
    assert.strictEqual(packageData.governanceStatus.productionChanged, false);
    assert.strictEqual(packageData.governanceStatus.modelTrainingExecuted, false);
  });

  await test('8. Evidence package declares threshold policy as PENDING_STAKEHOLDER_APPROVAL', () => {
    assert.strictEqual(packageData.governanceStatus.thresholdStatus, 'PENDING_STAKEHOLDER_APPROVAL');
    assert.strictEqual(SHADOW_POLICY_CONFIG.HIGHER_RISK_THRESHOLD, 'PENDING_STAKEHOLDER_APPROVAL');
    assert.strictEqual(SHADOW_POLICY_CONFIG.LOWER_RISK_THRESHOLD, 'PENDING_STAKEHOLDER_APPROVAL');
    assert.strictEqual(SHADOW_POLICY_CONFIG.COST_MATRIX_VERSION, 'PENDING_STAKEHOLDER_APPROVAL');
  });

  await test('9. Evidence package declares production model as V1 ONLY', () => {
    assert.strictEqual(packageData.governanceStatus.productionModel, 'V1 ONLY');
    assert.strictEqual(packageData.canonicalInvariants.v1Sha256, CANONICAL_V1_SHA256);
    assert.strictEqual(packageData.canonicalInvariants.v2Sha256, CANONICAL_V2_SHA256);
    assert.strictEqual(packageData.canonicalInvariants.baselineDatasetSha256, CANONICAL_BASELINE_DATASET_SHA);
  });

  // 3. REST API ROUTE INTEGRATION
  console.log('\n--- 3. REST API Route Integration ---');

  await test('10. GET /api/shadow/evaluation/evidence-package is registered in server.ts', () => {
    const serverContent = fs.readFileSync('server.ts', 'utf-8');
    assert.ok(
      serverContent.includes("app.get('/api/shadow/evaluation/evidence-package'"),
      'Route /api/shadow/evaluation/evidence-package must be registered'
    );
  });

  await test('11. Client SDK apiClient exposes getEvidencePackage method', () => {
    const clientContent = fs.readFileSync('src/services/apiClient.ts', 'utf-8');
    assert.ok(
      clientContent.includes('getEvidencePackage()'),
      'apiClient must expose getEvidencePackage'
    );
  });

  // 4. STATISTICAL GOVERNANCE & GATING AUDIT
  console.log('\n--- 4. Statistical Power & Evidence Gates ---');

  await test('12. Evidence coverage breakdown accounts for all 31 operational projects', () => {
    const cov = packageData.evidenceCoverage;
    assert.strictEqual(cov.totalOperationalProjects, 31);
    assert.strictEqual(cov.completeCorridors + cov.insufficientEvidenceCorridors, 31);
    assert.ok(cov.completeCorridors >= 3);
    assert.ok(cov.pre3aCorridors >= 1);
  });

  await test('13. Outcome maturity gate enforces OUTCOME_MATURITY_INSUFFICIENT for sample < 10', () => {
    const diag = packageData.monitoringDiagnostics;
    assert.strictEqual(diag.outcomeMaturityGate, 'OUTCOME_MATURITY_INSUFFICIENT');
  });

  await test('14. Offline scoring repeatability demonstrates numerical delta <= 1e-12', () => {
    const rep = packageData.repeatabilityResults;
    assert.strictEqual(rep.maxObservedProbabilityDiff, 0);
    assert.strictEqual(rep.featureSnapshotHashDeterministic, true);
  });

  // 5. PRODUCTION MODEL ISOLATION & IMMUTABILITY
  console.log('\n--- 5. Production Model Isolation & Immutability ---');

  await test('15. Production V1 bridge exclusively loads V1 model artifact', () => {
    const bridgeContent = fs.readFileSync('src/server/mlPredictionBridge.ts', 'utf-8');
    assert.ok(bridgeContent.includes('data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib'));
    assert.ok(!bridgeContent.includes('BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_pipeline.joblib'));
  });

  await test('16. Zero automatic model promotion or threshold activation pathways exist', () => {
    const serverContent = fs.readFileSync('server.ts', 'utf-8');
    assert.ok(!serverContent.includes('promoteV2ToProduction'));
    assert.ok(!serverContent.includes('activateShadowThresholds'));
  });

  await test('17. SQLite PRAGMA integrity_check passes completely', () => {
    const integrity = (db.prepare('PRAGMA integrity_check').all() as any[])[0]?.integrity_check;
    assert.strictEqual(integrity, 'ok');
  });

  await test('18. Operational projects population remains exactly 31 projects', () => {
    const currentCount = (db.prepare('SELECT COUNT(*) as c FROM projects').get() as any).c;
    assert.strictEqual(currentCount, 31);
    assert.strictEqual(currentCount, initialProjectCount);
  });

  await test('19. Operational risk scores and delay probabilities are 100% unchanged', () => {
    const currentProjectsData = db.prepare('SELECT id, risk_level, delay_probability FROM projects').all();
    assert.deepStrictEqual(currentProjectsData, initialProjectsData);
  });

  await test('20. Operational alerts and recommendations tables remained completely untouched', () => {
    const currentAlertsCount = (db.prepare('SELECT COUNT(*) as c FROM alerts').get() as any).c;
    const currentRecommendationsCount = (db.prepare('SELECT COUNT(*) as c FROM project_recommendations').get() as any).c;
    assert.strictEqual(currentAlertsCount, initialAlertsCount);
    assert.strictEqual(currentRecommendationsCount, initialRecommendationsCount);
  });

  await test('21. UI displays evidence package without any threshold activation buttons', () => {
    const uiContent = fs.readFileSync('src/components/ShadowGovernanceView.tsx', 'utf-8');
    assert.ok(uiContent.includes('PHASE 7B-10 EVIDENCE PACKAGE'));
    assert.ok(uiContent.includes('Long-Run Shadow Validation & Governance Evidence Package'));
    assert.ok(!uiContent.includes('Activate Threshold'));
    assert.ok(!uiContent.includes('Promote Model'));
  });

  console.log('\n========================================================================');
  console.log(`  Phase 7B-11 Audit Finished: ${passed} Passed, ${failed} Failed`);
  console.log('========================================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase7B11Audit().catch(err => {
  console.error('Fatal error running Phase 7B-11 audit:', err);
  process.exit(1);
});
