#!/usr/bin/env python3
"""
BhoomiDrishti Phase 5B: Temporal Generalization, Calibration & Candidate Model Tests

Deterministic tests verifying:
1. Temporal Project Separation (Zero project overlap between temporal train and validation partitions)
2. Temporal Ordering (Validation projects initiated chronologically on or after candidate cutoff)
3. Point-in-Time Feature Cutoff (Feature source timestamp <= observation timestamp t)
4. Section 3D Quarantine (Zero Section 3D dates, target variables, or eventual duration in X)
5. Synthetic T180 Exclusion (Zero synthetic T180 snapshot records in train or validation)
6. Calibration Train/Validation Separation (Calibration models fitted strictly inside training partition)
7. Frozen Production ML Artifact Protection (SHA-256 strictly preserved)
"""

import os
import sys
import json
import hashlib
import numpy as np
import pandas as pd

from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV

CANONICAL_MODEL_SHA256 = '7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f'
DATASET_SHA256 = '0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a'
MODEL_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib'
DATASET_PATH = 'data/reconstructed_longitudinal_dataset_v2.json'
TEMPORAL_CUTOFF = '2023-01-01'


def compute_file_sha256(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(8192):
            h.update(chunk)
    return h.hexdigest()


def run_tests():
    print("=" * 76)
    print("  BHOOMI-DRISHTI PHASE 5B: TEMPORAL GENERALIZATION & CALIBRATION TESTS")
    print("=" * 76 + "\n")

    passed = 0
    failed = 0

    def assert_test(name: str, fn):
        nonlocal passed, failed
        try:
            fn()
            print(f"  [PASS] {name}")
            passed += 1
        except Exception as e:
            print(f"  [FAIL] {name}")
            print(f"         Error: {e}")
            failed += 1

    # Load authentic dataset
    with open(DATASET_PATH, 'r') as f:
        dataset = json.load(f)

    obs = dataset['observations']
    df = pd.DataFrame([{
        'project_id': o['project_id'],
        'timestamp': o['observation_timestamp'],
        'delayed': o['target']['delayed'],
        'features': o['features'],
        'observation_id': o['observation_id']
    } for o in obs])

    p_earliest = df.groupby('project_id')['timestamp'].min().to_dict()
    df['proj_earliest'] = df['project_id'].map(p_earliest)

    train_projects = set(p for p, dt in p_earliest.items() if dt < TEMPORAL_CUTOFF)
    val_projects = set(p for p, dt in p_earliest.items() if dt >= TEMPORAL_CUTOFF)

    train_df = df[df['project_id'].isin(train_projects)]
    val_df = df[df['project_id'].isin(val_projects)]

    # Test 1: Temporal Project Separation
    def test_project_separation():
        overlap = train_projects.intersection(val_projects)
        assert len(overlap) == 0, f"Leaked projects found in both train and validation: {overlap}"
        assert len(train_projects) == 106, f"Expected 106 training projects, got {len(train_projects)}"
        assert len(val_projects) == 46, f"Expected 46 validation projects, got {len(val_projects)}"
        assert len(train_projects) + len(val_projects) == 152, "Total unique projects must equal 152"
    assert_test("1. Temporal Project Separation (Zero project overlap between train and val)", test_project_separation)

    # Test 2: Temporal Ordering
    def test_temporal_ordering():
        max_train_start = max(p_earliest[p] for p in train_projects)
        min_val_start = min(p_earliest[p] for p in val_projects)
        assert max_train_start < TEMPORAL_CUTOFF, f"Train project start {max_train_start} >= cutoff {TEMPORAL_CUTOFF}"
        assert min_val_start >= TEMPORAL_CUTOFF, f"Val project start {min_val_start} < cutoff {TEMPORAL_CUTOFF}"
        assert min_val_start > max_train_start, "Validation projects must be strictly newer than training project inception"
        for t in val_df['timestamp']:
            assert t >= TEMPORAL_CUTOFF, f"Validation observation timestamp {t} < cutoff {TEMPORAL_CUTOFF}"
    assert_test("2. Temporal Ordering (Validation projects initiated strictly on/after 2023-01-01)", test_temporal_ordering)

    # Test 3: Point-in-Time Feature Cutoff
    def test_pit_cutoff():
        for o in obs:
            t = o['observation_timestamp']
            assert o['features']['elapsed_days_since_first_3a'] >= 0, "Elapsed days cannot be negative"
            assert o['features']['cumulative_notifications_count_at_t'] >= 1, "Cumulative count at t must be >= 1"
            assert o['features']['days_since_last_notification'] >= 0, "Days since last notice must be >= 0"
            assert o['features']['statutory_notification_frequency_180d'] >= 1, "180d frequency must be >= 1"
    assert_test("3. Point-in-Time Feature Cutoff (Feature source timestamp <= observation timestamp t)", test_pit_cutoff)

    # Test 4: Section 3D Quarantine
    def test_section_3d_quarantine():
        forbidden_keys = {'section_3d_date', 'delayed', 'target', 'duration_days', 'eventual_duration_days'}
        for o in obs:
            feat_keys = set(o['features'].keys())
            leak = forbidden_keys.intersection(feat_keys)
            assert len(leak) == 0, f"Quarantine breach: {leak} found in features for obs {o['observation_id']}"
    assert_test("4. Section 3D Quarantine (Zero Section 3D dates, target metrics, or duration in X)", test_section_3d_quarantine)

    # Test 5: Synthetic T180 Exclusion
    def test_synthetic_t180():
        for o in obs:
            assert 'T180' not in o['observation_id'], f"Synthetic T180 found: {o['observation_id']}"
    assert_test("5. Synthetic T180 Exclusion (Zero synthetic T180 snapshot records)", test_synthetic_t180)

    # Test 6: Calibration Train/Validation Separation
    def test_calibration_separation():
        # Verify that calibration is fit ONLY on training data
        num_features = [
            'elapsed_days_since_first_3a', 'cumulative_notifications_count_at_t',
            'notification_cadence_days', 'days_since_last_notification',
            'statutory_notification_frequency_180d', 'total_land_required_ha',
            'initial_sanction_available_at_t'
        ]
        cat_features = ['statutory_stage_at_t', 'implementing_agency', 'state_jurisdiction']
        
        train_features = pd.DataFrame([o['features'] for o in obs if o['project_id'] in train_projects])
        val_features = pd.DataFrame([o['features'] for o in obs if o['project_id'] in val_projects])
        y_train = np.array([o['target']['delayed'] for o in obs if o['project_id'] in train_projects])
        y_val = np.array([o['target']['delayed'] for o in obs if o['project_id'] in val_projects])

        prep = ColumnTransformer([
            ('num', Pipeline([('imp', SimpleImputer(strategy='median')), ('sc', StandardScaler())]), num_features),
            ('cat', Pipeline([('oh', OneHotEncoder(handle_unknown='ignore', sparse_output=False))]), cat_features)
        ])

        cal_model = CalibratedClassifierCV(
            estimator=LogisticRegression(class_weight='balanced', max_iter=1000, random_state=42),
            method='sigmoid', cv=3
        )
        cal_pipe = Pipeline([('prep', prep), ('clf', cal_model)])
        
        # Fit calibration strictly on train_features
        cal_pipe.fit(train_features, y_train)

        # Assert no validation indices in internal estimators
        assert len(cal_model.calibrated_classifiers_) == 3, "Internal CV folds must match training folds"
        probs_val = cal_pipe.predict_proba(val_features)[:, 1]
        assert len(probs_val) == len(y_val), "Validation prediction length must match validation set"
        assert not np.isnan(probs_val).any(), "Probabilities must not contain NaN"
    assert_test("6. Calibration Train/Validation Separation (Calibration fitted strictly inside training partition)", test_calibration_separation)

    # Test 7: Frozen Production ML Artifact Protection
    def test_artifact_protection():
        sha = compute_file_sha256(MODEL_PATH)
        assert sha == CANONICAL_MODEL_SHA256, f"Production model SHA corrupted! Got {sha}"
    assert_test("7. Frozen Production ML Artifact Protection (SHA-256 strictly preserved)", test_artifact_protection)

    print("\n" + "-" * 76)
    print(f"  Phase 5B Test Summary: {passed} Passed, {failed} Failed")
    print("-" * 76 + "\n")

    if failed > 0:
        sys.exit(1)


if __name__ == '__main__':
    run_tests()
