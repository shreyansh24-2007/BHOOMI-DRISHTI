import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { getDatabase } from '../src/server/database.ts';
import { RemediationEngine } from '../src/server/historical/remediationEngine.ts';

async function main() {
  const dbPath = path.resolve('data/bhoomidrishti.db');
  const backupFiles = fs.readdirSync('data').filter(f => f.startsWith('bhoomidrishti_backup_')).sort();
  const latestBackup = backupFiles[backupFiles.length - 1];
  const backupPath = path.resolve('data', latestBackup);

  const backupBuffer = fs.readFileSync(backupPath);
  const backupHash = crypto.createHash('sha256').update(backupBuffer).digest('hex');

  // Original hash
  const originalHash = 'b3a25d32ed9b1528c6ed069f1b5d21f857e678541420842d55ecc98ea3c8f89a';

  const db = getDatabase();
  const report = RemediationEngine.runRemediation(db, originalHash, backupPath, backupHash);

  // Checkpoint WAL and flush to disk
  db.exec('PRAGMA wal_checkpoint(TRUNCATE)');

  // Calculate final database hash
  const finalBuffer = fs.readFileSync(dbPath);
  report.database.finalHash = crypto.createHash('sha256').update(finalBuffer).digest('hex');

  console.log('=== REMEDIATION EXECUTION COMPLETE ===');
  console.log(JSON.stringify(report, null, 2));

  // Save report to file for verification
  fs.writeFileSync('data/remediation_report.json', JSON.stringify(report, null, 2));
}

main().catch(err => {
  console.error('Remediation error:', err);
  process.exit(1);
});
