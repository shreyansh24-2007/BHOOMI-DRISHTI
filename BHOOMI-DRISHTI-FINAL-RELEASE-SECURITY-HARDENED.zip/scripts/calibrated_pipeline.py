import numpy as np

class CalibratedRFPipeline:
    def __init__(self, base_pipeline, calibrator):
        self.base_pipeline = base_pipeline
        self.calibrator = calibrator
    
    def predict_proba(self, X_input):
        raw_p = self.base_pipeline.predict_proba(X_input)[:, 1]
        cal_p = self.calibrator.predict_proba(raw_p.reshape(-1, 1))
        return cal_p
    
    def predict(self, X_input, threshold=0.5):
        probs = self.predict_proba(X_input)[:, 1]
        return (probs >= threshold).astype(int)
