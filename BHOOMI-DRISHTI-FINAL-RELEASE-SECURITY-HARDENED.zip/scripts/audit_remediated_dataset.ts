import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';

async function audit() {
  const dbPath = path.resolve('data/bhoomidrishti.db');
  const dbBuffer = fs.readFileSync(dbPath);
  const dbHash = crypto.createHash('sha256').update(dbBuffer).digest('hex');

  const db = new DatabaseSync(dbPath);

  console.log('================ 1. DATASET IDENTITY ================');
  console.log('Database Path:', dbPath);
  console.log('Database Size:', dbBuffer.length, 'bytes');
  console.log('Database SHA-256:', dbHash);

  const versions = db.prepare('SELECT * FROM ml_dataset_versions ORDER BY created_at DESC').all() as any[];
  console.log('Versions in ml_dataset_versions:', JSON.stringify(versions, null, 2));

  console.log('\n================ 2. POPULATION RECONCILIATION ================');
  const totalObs = (db.prepare('SELECT count(*) as c FROM ml_labelled_observations').get() as any).c;
  console.log('Total observations in ml_labelled_observations:', totalObs);

  const byLabel = db.prepare('SELECT label, count(*) as c FROM ml_labelled_observations GROUP BY label').all() as any[];
  console.log('Observations by label:', byLabel);

  const byProvenance = db.prepare('SELECT provenance, count(*) as c FROM ml_labelled_observations GROUP BY provenance').all() as any[];
  console.log('Observations by provenance:', byProvenance);

  const byEligible = db.prepare('SELECT is_eligible_for_training, count(*) as c FROM ml_labelled_observations GROUP BY is_eligible_for_training').all() as any[];
  console.log('Observations by is_eligible_for_training:', byEligible);

  const labelAndEligible = db.prepare('SELECT label, provenance, is_eligible_for_training, count(*) as c FROM ml_labelled_observations GROUP BY label, provenance, is_eligible_for_training').all() as any[];
  console.log('Cross breakdown (label x provenance x is_eligible_for_training):', labelAndEligible);

  // Check overlap or discrepancies
  const demoAndEligible = (db.prepare("SELECT count(*) as c FROM ml_labelled_observations WHERE provenance = 'DEMONSTRATION' AND is_eligible_for_training = 1").get() as any).c;
  console.log('Demonstration AND eligible:', demoAndEligible);

  const demoRecords = db.prepare("SELECT label, is_eligible_for_training, count(*) as c FROM ml_labelled_observations WHERE provenance = 'DEMONSTRATION' GROUP BY label, is_eligible_for_training").all() as any[];
  console.log('Demonstration records details:', demoRecords);

  console.log('\n================ 3. ELIGIBILITY INTEGRITY ================');
  const eligibleObs = (db.prepare('SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1').get() as any).c;
  const ineligibleObs = (db.prepare('SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 0').get() as any).c;
  console.log('Eligible count:', eligibleObs);
  console.log('Ineligible count:', ineligibleObs);

  const ineligibleReasons = db.prepare('SELECT label, provenance, count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 0 GROUP BY label, provenance').all() as any[];
  console.log('Ineligible breakdown:', ineligibleReasons);

  console.log('\n================ 4. CLASS BALANCE ================');
  const eligibleDelayed = (db.prepare("SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1 AND label = 'VERIFIED_DELAYED'").get() as any).c;
  const eligibleNotDelayed = (db.prepare("SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1 AND label = 'VERIFIED_NOT_DELAYED'").get() as any).c;
  const eligibleOther = (db.prepare("SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1 AND label NOT IN ('VERIFIED_DELAYED', 'VERIFIED_NOT_DELAYED')").get() as any).c;
  console.log('Eligible VERIFIED_DELAYED:', eligibleDelayed, `(${(eligibleDelayed / eligibleObs * 100).toFixed(2)}%)`);
  console.log('Eligible VERIFIED_NOT_DELAYED:', eligibleNotDelayed, `(${(eligibleNotDelayed / eligibleObs * 100).toFixed(2)}%)`);
  console.log('Eligible other labels:', eligibleOther);
  console.log('Ratio Delayed : Not Delayed:', `1 : ${(eligibleNotDelayed / eligibleDelayed).toFixed(2)}`);

  console.log('\n================ 5. TEMPORAL COVERAGE ================');
  const minTime = (db.prepare('SELECT min(prediction_timestamp) as m FROM ml_labelled_observations WHERE is_eligible_for_training = 1').get() as any).m;
  const maxTime = (db.prepare('SELECT max(prediction_timestamp) as m FROM ml_labelled_observations WHERE is_eligible_for_training = 1').get() as any).m;
  console.log('Min timestamp:', minTime);
  console.log('Max timestamp:', maxTime);

  const obsByYear = db.prepare(`
    SELECT SUBSTR(prediction_timestamp, 1, 4) as yr, count(*) as c, count(DISTINCT project_id) as projs, count(DISTINCT p.highway_number || '_' || p.state) as corrs
    FROM ml_labelled_observations o
    JOIN ml_historical_projects p ON o.project_id = p.id
    WHERE o.is_eligible_for_training = 1
    GROUP BY yr
    ORDER BY yr ASC
  `).all() as any[];
  console.log('Observations by year (eligible):', obsByYear);

  const count2026 = (db.prepare("SELECT count(*) as c FROM ml_labelled_observations WHERE is_eligible_for_training = 1 AND SUBSTR(prediction_timestamp, 1, 4) = '2026'").get() as any).c;
  console.log('2026 concentration:', count2026, `(${(count2026 / eligibleObs * 100).toFixed(2)}%)`);

  console.log('\n================ 6. GEOGRAPHIC COVERAGE ================');
  const uniqueStates = (db.prepare(`
    SELECT count(DISTINCT p.state) as c
    FROM ml_historical_projects p
    JOIN ml_labelled_observations o ON p.id = o.project_id
    WHERE o.is_eligible_for_training = 1
  `).get() as any).c;
  console.log('Unique states:', uniqueStates);

  const statesBreakdown = db.prepare(`
    SELECT p.state, count(*) as obs_count, count(DISTINCT p.id) as proj_count, count(DISTINCT p.highway_number || '_' || p.state) as corr_count
    FROM ml_historical_projects p
    JOIN ml_labelled_observations o ON p.id = o.project_id
    WHERE o.is_eligible_for_training = 1
    GROUP BY p.state
    ORDER BY obs_count DESC
  `).all() as any[];
  console.log('States breakdown:', statesBreakdown);

  console.log('\n================ 7. AGENCY COVERAGE ================');
  const agencyBreakdown = db.prepare(`
    SELECT p.agency, count(*) as obs_count, count(DISTINCT p.id) as proj_count, count(DISTINCT p.highway_number || '_' || p.state) as corr_count
    FROM ml_historical_projects p
    JOIN ml_labelled_observations o ON p.id = o.project_id
    WHERE o.is_eligible_for_training = 1
    GROUP BY p.agency
    ORDER BY obs_count DESC
  `).all() as any[];
  console.log('Agency breakdown:', agencyBreakdown);

  console.log('\n================ 8. FEATURE COMPLETENESS ================');
  const features = [
    'stage_at_t',
    'land_acquired_ratio_at_t',
    'comp_disbursed_percent_at_t',
    'active_court_stays_at_t',
    'unresolved_cases_at_t',
    'incomplete_docs_count_at_t',
    'forest_clearance_at_t',
    'elapsed_days_since_3a_at_t'
  ];

  for (const feat of features) {
    const valid = (db.prepare(`
      SELECT count(s.${feat}) as c
      FROM ml_project_snapshots s
      JOIN ml_labelled_observations o ON s.id = o.snapshot_id
      WHERE o.is_eligible_for_training = 1
    `).get() as any).c;
    const missing = eligibleObs - valid;
    console.log(`Feature ${feat}: valid=${valid}, missing=${missing} (${(missing / eligibleObs * 100).toFixed(2)}%)`);
  }

  // Check project level features
  const sanctionValid = (db.prepare(`
    SELECT count(p.initial_sanction_amount_cr) as c
    FROM ml_historical_projects p
    JOIN ml_labelled_observations o ON p.id = o.project_id
    WHERE o.is_eligible_for_training = 1
  `).get() as any).c;
  console.log(`Feature initial_sanction_amount_cr: valid=${sanctionValid}, missing=${eligibleObs - sanctionValid} (${((eligibleObs - sanctionValid) / eligibleObs * 100).toFixed(2)}%)`);

  // Check initial_sanction_amount_available in snapshot_features_json
  const featJsonRows = db.prepare(`
    SELECT s.snapshot_features_json
    FROM ml_project_snapshots s
    JOIN ml_labelled_observations o ON s.id = o.snapshot_id
    WHERE o.is_eligible_for_training = 1
  `).all() as any[];
  let sanctionAvailCount = 0;
  for (const r of featJsonRows) {
    try {
      const obj = JSON.parse(r.snapshot_features_json || '{}');
      if (obj.initialSanctionAmountAvailable === 1) sanctionAvailCount++;
    } catch {}
  }
  console.log(`initialSanctionAmountAvailable = 1 in: ${sanctionAvailCount}`);

  console.log('\n================ 9. MISSING DATA & 6 NULL INSPECTION ================');
  const missingElapsed = db.prepare(`
    SELECT o.id as obs_id, o.project_id, o.snapshot_id, o.prediction_timestamp, s.snapshot_timestamp, s.stage_at_t, s.elapsed_days_since_3a_at_t
    FROM ml_labelled_observations o
    JOIN ml_project_snapshots s ON o.snapshot_id = s.id
    WHERE o.is_eligible_for_training = 1 AND s.elapsed_days_since_3a_at_t IS NULL
  `).all() as any[];
  console.log('The 6 observations with missing elapsed_days_since_3a_at_t:', missingElapsed);

  for (const m of missingElapsed) {
    const notifs = db.prepare('SELECT id, notification_type, notification_number, publish_date FROM ml_notifications WHERE project_id = ?').all(m.project_id) as any[];
    console.log(`Notifications for project ${m.project_id}:`, notifs);
  }

  console.log('\n================ 10. LABEL VALIDITY ================');
  const labelCheck = db.prepare(`
    SELECT o.id, o.project_id, o.label, o.binary_target, o.evidence_source, o.evidence_date, o.is_eligible_for_training
    FROM ml_labelled_observations o
    WHERE o.is_eligible_for_training = 1
    LIMIT 10
  `).all() as any[];
  console.log('Sample label records:', labelCheck);

  // Check labels distribution among eligible
  const labelDist = db.prepare(`
    SELECT label, binary_target, count(*) as count
    FROM ml_labelled_observations
    WHERE is_eligible_for_training = 1
    GROUP BY label, binary_target
  `).all() as any[];
  console.log('Eligible label distributions:', labelDist);

  // Check if any VERIFIED_DELAYED has binary_target != 1
  const badDelayed = (db.prepare(`
    SELECT count(*) as c FROM ml_labelled_observations
    WHERE is_eligible_for_training = 1 AND label = 'VERIFIED_DELAYED' AND binary_target != 1
  `).get() as any).c;
  console.log('Inconsistent VERIFIED_DELAYED records (binary_target != 1):', badDelayed);

  const badNotDelayed = (db.prepare(`
    SELECT count(*) as c FROM ml_labelled_observations
    WHERE is_eligible_for_training = 1 AND label = 'VERIFIED_NOT_DELAYED' AND binary_target != 0
  `).get() as any).c;
  console.log('Inconsistent VERIFIED_NOT_DELAYED records (binary_target != 0):', badNotDelayed);

  console.log('\n================ 11. TEMPORAL LEAKAGE ================');
  let futureFeatureViolations = 0;
  let futureNotificationViolations = 0;
  let futureCompensationViolations = 0;
  let futureLegalEventViolations = 0;

  const snaps = db.prepare(`
    SELECT s.id, s.project_id, s.snapshot_timestamp, s.land_acquired_ratio_at_t, s.comp_disbursed_percent_at_t, s.active_court_stays_at_t, s.stage_at_t
    FROM ml_project_snapshots s
    JOIN ml_labelled_observations o ON s.id = o.snapshot_id
    WHERE o.is_eligible_for_training = 1
  `).all() as any[];

  for (const s of snaps) {
    const snapTime = s.snapshot_timestamp;
    // Post-T 3D notification in Section 3A snapshot
    const postT3D = (db.prepare(`
      SELECT count(*) as c FROM ml_notifications
      WHERE project_id = ? AND notification_type = '3D' AND publish_date > ?
    `).get(s.project_id, snapTime) as any).c;
    if (postT3D > 0 && s.land_acquired_ratio_at_t > 0 && s.stage_at_t === 'Section 3A Published') {
      futureNotificationViolations++;
      futureFeatureViolations++;
    }

    // Post-T compensation event
    const postTComp = (db.prepare(`
      SELECT count(*) as c FROM ml_compensation_events
      WHERE project_id = ? AND event_date > ? AND disbursed_percent > 0
    `).get(s.project_id, snapTime) as any).c;
    if (postTComp > 0 && s.comp_disbursed_percent_at_t > 0) {
      futureCompensationViolations++;
      futureFeatureViolations++;
    }

    // Post-T stays: stays active before T vs snapshot active court stays
    const validStaysAtT = (db.prepare(`
      SELECT count(*) as c FROM ml_legal_events
      WHERE project_id = ? AND event_date <= ? AND stay_active = 1
    `).get(s.project_id, snapTime) as any).c;
    if (s.active_court_stays_at_t > validStaysAtT) {
      futureLegalEventViolations++;
      futureFeatureViolations++;
    }
  }
  console.log('Future feature violations:', futureFeatureViolations);
  console.log('Future notification violations:', futureNotificationViolations);
  console.log('Future compensation violations:', futureCompensationViolations);
  console.log('Future legal event violations:', futureLegalEventViolations);

  console.log('\n================ 12. DUPLICATES ================');
  const dupObs = (db.prepare(`
    SELECT count(*) as c FROM (
      SELECT project_id, snapshot_id, prediction_task, count(*) as count
      FROM ml_labelled_observations
      GROUP BY project_id, snapshot_id, prediction_task
      HAVING count > 1
    )
  `).get() as any).c;
  console.log('Duplicate (project_id, snapshot_id, prediction_task) groups in observations:', dupObs);

  const dupSnaps = (db.prepare(`
    SELECT count(*) as c FROM (
      SELECT project_id, snapshot_timestamp, prediction_task, count(*) as count
      FROM ml_project_snapshots
      GROUP BY project_id, snapshot_timestamp, prediction_task
      HAVING count > 1
    )
  `).get() as any).c;
  console.log('Duplicate (project_id, snapshot_timestamp, prediction_task) groups in snapshots:', dupSnaps);

  console.log('\n================ 13. PROJECT / CORRIDOR DEPENDENCE ================');
  const uniqueProjects = (db.prepare(`
    SELECT count(DISTINCT project_id) as c
    FROM ml_labelled_observations
    WHERE is_eligible_for_training = 1
  `).get() as any).c;
  console.log('Unique projects among eligible observations:', uniqueProjects);

  const uniqueCorridors = (db.prepare(`
    SELECT count(DISTINCT p.highway_number || '_' || p.state) as c
    FROM ml_historical_projects p
    JOIN ml_labelled_observations o ON p.id = o.project_id
    WHERE o.is_eligible_for_training = 1
  `).get() as any).c;
  console.log('Unique corridors among eligible observations:', uniqueCorridors);

  const obsPerProj = db.prepare(`
    SELECT project_id, count(*) as count
    FROM ml_labelled_observations
    WHERE is_eligible_for_training = 1
    GROUP BY project_id
    ORDER BY count DESC
  `).all() as any[];
  console.log('Top 5 projects by observation count:', obsPerProj.slice(0, 5));
  console.log('Min observations per project:', obsPerProj[obsPerProj.length - 1].count);
  console.log('Max observations per project:', obsPerProj[0].count);

  const obsPerCorr = db.prepare(`
    SELECT p.highway_number || '_' || p.state as corr, count(*) as count
    FROM ml_historical_projects p
    JOIN ml_labelled_observations o ON p.id = o.project_id
    WHERE o.is_eligible_for_training = 1
    GROUP BY corr
    ORDER BY count DESC
  `).all() as any[];
  console.log('Top 5 corridors by observation count:', obsPerCorr.slice(0, 5));

  console.log('\n================ 14. DATA QUALITY CHECKS ================');
  const invDates = (db.prepare("SELECT count(*) as c FROM ml_notifications WHERE publish_date IS NOT NULL AND publish_date NOT GLOB '????-??-??*'").get() as any).c;
  const negLand = (db.prepare('SELECT count(*) as c FROM ml_project_snapshots WHERE land_acquired_ratio_at_t < 0').get() as any).c;
  const negComp = (db.prepare('SELECT count(*) as c FROM ml_project_snapshots WHERE comp_disbursed_percent_at_t < 0').get() as any).c;
  const invComp = (db.prepare('SELECT count(*) as c FROM ml_project_snapshots WHERE comp_disbursed_percent_at_t > 100').get() as any).c;
  const invLand = (db.prepare('SELECT count(*) as c FROM ml_project_snapshots WHERE land_acquired_ratio_at_t > 1.0').get() as any).c;
  console.log('Invalid publish dates in notifications:', invDates);
  console.log('Negative land acquired ratio:', negLand);
  console.log('Negative comp disbursed percent:', negComp);
  console.log('Comp disbursed > 100%:', invComp);
  console.log('Land acquired ratio > 1.0:', invLand);

  console.log('\n================ 15. AUDIT LOG PROVENANCE ================');
  const auditLogsCount = (db.prepare('SELECT count(*) as c FROM ml_remediation_audit_log').get() as any).c;
  const reconcilCount = (db.prepare('SELECT count(*) as c FROM ml_publication_date_reconciliation').get() as any).c;
  console.log('Remediation audit log entries:', auditLogsCount);
  console.log('Publication date reconciliation entries:', reconcilCount);

  console.log('\n================ 17. CRITICAL ARITHMETIC RECONCILIATION ================');
  console.log('Eligible Training:', eligibleObs);
  console.log('Ineligible:', ineligibleObs);
  console.log('Sum (Eligible + Ineligible):', eligibleObs + ineligibleObs);
  console.log('Total Observations:', totalObs);

  const sumCategories = eligibleObs + 67 + 116 + 36;
  console.log('Claimed formula: 2871 + 67 + 116 + 36 =', sumCategories, 'vs total 3054 (difference:', sumCategories - totalObs, ')');

  // Let's find exactly how the categories intersect
  const crossLabels = db.prepare('SELECT label, provenance, count(*) as count FROM ml_labelled_observations GROUP BY label, provenance').all() as any[];
  console.log('All labels by provenance:', crossLabels);
}

audit().catch(console.error);
