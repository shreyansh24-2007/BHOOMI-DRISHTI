/**
 * BHOOMI-DRISHTI ML DATA-READINESS AUDIT RUNNER
 * Evaluates the 16-point checklist for genuine supervised machine learning training.
 * Usage: npx tsx scripts/mlDataReadiness.ts
 */

import { getDatabase } from '../src/server/database.ts';
import { HistoricalDatabaseService } from '../src/server/historical/database.ts';
import { HistoricalDataIngestionEngine } from '../src/server/historical/dataIngestion.ts';
import { MLReadinessAuditor } from '../src/server/historical/readinessReport.ts';
import { FUTURE_ML_PIPELINE_SPECIFICATION } from '../src/server/historical/futurePipelineDesign.ts';

async function main() {
  console.log("================================================================================");
  console.log("BHOOMI-DRISHTI: PHASE 0 — HISTORICAL DATA ACQUISITION & ML READINESS AUDIT");
  console.log("================================================================================");

  const db = getDatabase();

  // Ensure dataset is initialized
  console.log("\n[1/3] Verifying and bootstrapping historical database schema...");
  const bootstrapRes = await HistoricalDataIngestionEngine.bootstrapHistoricalDataset(db);
  console.log(`✓ Bootstrapped: ${bootstrapRes.projectsIngested} projects, ${bootstrapRes.notificationsIngested} notifications, ${bootstrapRes.snapshotsCreated} snapshots, ${bootstrapRes.observationsGenerated} observations.`);

  // Execute the audit
  console.log("\n[2/3] Executing 16-Point Comprehensive ML Data-Readiness Audit...");
  const audit = MLReadinessAuditor.runAudit(db);

  console.log("\n--------------------------------------------------------------------------------");
  console.log("AUDIT RESULTS & MATHEMATICAL EVALUATION:");
  console.log("--------------------------------------------------------------------------------");
  console.log(`1. Total Historical Projects:        ${audit.totalProjects}`);
  console.log(`2. Provenance Breakdown:`);
  console.log(`   - Source Verified (Govt/Portal):  ${audit.provenanceBreakdown.sourceVerified}`);
  console.log(`   - Official Gazette Entries:       ${audit.provenanceBreakdown.officialEntry}`);
  console.log(`   - Derived Statutory:              ${audit.provenanceBreakdown.derived}`);
  console.log(`   - Demonstration / Synthetic Seed: ${audit.provenanceBreakdown.demonstration} (ISOLATED)`);
  console.log(`3. Geographic & Agency Coverage:`);
  console.log(`   - Distinct States:                ${Object.keys(audit.breakdownByState).length} states`);
  console.log(`   - Implementing Agencies:          ${Object.keys(audit.breakdownByAgency).join(', ')}`);
  console.log(`4. Total Point-in-Time Snapshots:   ${audit.totalSnapshots}`);
  console.log(`5. Total Labelled Observations:     ${audit.totalLabelledObservations}`);
  console.log(`6. Verified Ground-Truth Classes:`);
  console.log(`   - Verified Delayed (Target = 1):  ${audit.classDistribution.delayedCount} (${audit.classDistribution.delayedPercent}%)`);
  console.log(`   - Verified On-Time (Target = 0):  ${audit.classDistribution.notDelayedCount} (${audit.classDistribution.notDelayedPercent}%)`);
  console.log(`7. Unresolved / In-Progress Parcels: ${audit.unresolvedObservationsCount} (actively within statutory window)`);
  console.log(`   Insufficient Evidence (Demo/Null): ${audit.insufficientEvidenceCount}`);
  console.log(`8. Missing Value Critical Findings:`);
  console.log(`   - Completed Date Missingness:     ${audit.missingValueAnalysis.completedDateMissingPercent}%`);
  console.log(`   - Planned Completion Date Miss:   ${audit.missingValueAnalysis.plannedDateMissingPercent}%`);
  console.log(`   - Cadastral Survey Missingness:   ${audit.missingValueAnalysis.cadastralSurveyMissingPercent}%`);
  console.log(`9. Cross-Source Consistency:         ${audit.crossSourceConsistency.status}`);
  console.log(`10. Covariate Shift Analysis:        ${audit.distributionalShift.description}`);
  console.log(`11. Feature-Label Leakage Audit:     ${audit.featureLabelLeakageAudit.auditStatus}`);
  console.log(`12. Minimum Sample Size Check:       ${audit.minimumSampleSizeEvaluation.sufficient ? 'PASS' : 'FAIL (Statistical Insufficiency)'}`);
  console.log(`    Current Verified Eligible:       ${audit.minimumSampleSizeEvaluation.currentEligibleObservations} observations`);
  console.log(`    Required Threshold:              ${audit.minimumSampleSizeEvaluation.recommendedMinimum} observations`);
  console.log(`13. Class Balance Evaluation:        ${audit.classBalanceEvaluation.balanceStatus}`);
  console.log(`14. Geographic Diversity:            ${audit.diversityEvaluation.sufficientlyDiverse ? 'SUFFICIENT' : 'INSUFFICIENT (Need >=15 states)'}`);
  console.log(`15. FINAL DETERMINATION:             ${audit.finalDetermination}`);
  console.log(`16. Additional Observations Needed:  ${audit.additionalObservationsRequired.deficit} verified observations`);
  console.log(`    Acquisition Mandate:             ${audit.additionalObservationsRequired.stateTargetRequirements}`);
  console.log("--------------------------------------------------------------------------------\n");

  console.log("[3/3] Future ML Pipeline Blueprint (Phase 1 Specification):");
  console.log(`- Architecture:                      ${FUTURE_ML_PIPELINE_SPECIFICATION.architectureOverview.systemName}`);
  console.log(`- Candidate Models:                  ${FUTURE_ML_PIPELINE_SPECIFICATION.candidateModelArchitectures.map(m => m.name).join(', ')}`);
  console.log(`- Validation Strategy:               ${FUTURE_ML_PIPELINE_SPECIFICATION.crossValidationStrategy.method} by ${FUTURE_ML_PIPELINE_SPECIFICATION.crossValidationStrategy.groupingVariable}`);
  console.log(`- Explainability Engine:             ${FUTURE_ML_PIPELINE_SPECIFICATION.explainabilityArchitecture.method}`);
  console.log(`- Calibration:                       ${FUTURE_ML_PIPELINE_SPECIFICATION.probabilityCalibration.technique}`);
  console.log("================================================================================");
  console.log("AUDIT COMPLETE: Strict freeze on ML training until data acquisition quota met.");
  console.log("================================================================================");
}

main().catch(err => {
  console.error("Audit failed:", err);
  process.exit(1);
});
