import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { getDatabase } from '../src/server/database.ts';
import {
  ShadowMonitoringStore,
  initShadowMonitoringTables
} from '../src/server/ml/shadowMonitoringStore.ts';
import {
  ShadowDriftEngine,
  CANONICAL_BASELINE_DATASET_SHA,
  DEFAULT_DRIFT_CONFIG
} from '../src/server/ml/shadowDriftEngine.ts';
import { ShadowMonitoringService } from '../src/server/ml/shadowMonitoringService.ts';
import {
  SHADOW_POLICY_CONFIG,
  scoreCandidateArtifact,
  inspectCandidateArtifact
} from '../src/server/ml/shadowRunner.ts';
import { StatutoryIngestionCoordinator } from '../src/server/datahub/statutoryAdapters.ts';
import { ORDERED_SHADOW_FEATURES, computeFeatureSnapshotHash } from '../src/server/ml/shadowFeatureSchema.ts';

const CANONICAL_V1_SHA256 = '7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f';
const EXPECTED_V2_SHA256 = '4a83e980f9178498be4592a47303f0ebc5ea641934952af5bee92ae5b76729a2';
const EXPECTED_DATASET_SHA256 = '0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a';

function computeFileSha(filePath: string): string {
  const buf = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buf).digest('hex');
}

export async function runPhase7b6Tests() {
  console.log('========================================================================');
  console.log('  PHASE 7B-6: SHADOW MONITORING, DRIFT DETECTION & OUTCOME TRACKING');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void> | void) {
    try {
      await fn();
      console.log(`  ✓ ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  ✗ ${name}`);
      console.error(`    Error: ${err.message}`);
      failed++;
    }
  }

  const db = initShadowMonitoringTables(getDatabase());

  // Capture baseline state before test
  const v1Path = path.resolve(process.cwd(), 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib');
  const v2Path = path.resolve(process.cwd(), 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_pipeline.joblib');
  const datasetPath = path.resolve(process.cwd(), 'data/reconstructed_longitudinal_dataset_v2.json');

  const v1ShaBefore = computeFileSha(v1Path);
  const v2ShaBefore = computeFileSha(v2Path);
  const datasetShaBefore = computeFileSha(datasetPath);

  const initialProjects = db.prepare('SELECT * FROM projects').all() as any[];
  const initialProjectsHash = crypto.createHash('sha256').update(JSON.stringify(initialProjects)).digest('hex');
  const initialAlertsCount = (db.prepare('SELECT count(*) as c FROM alerts').get() as any).c;

  // Test 1: Evidence Coverage Calculation
  await test('1. Evidence coverage calculates dynamically across all 31 operational projects', () => {
    const coverage = ShadowMonitoringService.evaluateEvidenceCoverage(db);
    assert.strictEqual(coverage.totalProjects, 31, 'Must evaluate exactly 31 operational corridors');
    assert.strictEqual(coverage.completeCount, 3, 'Exactly 3 complete corridors (60940, 54635, 56972)');
    assert.strictEqual(coverage.pre3aCount, 1, 'Exactly 1 pre-3A corridor (57405)');
    assert.strictEqual(coverage.insufficientCount, 28, 'Exactly 28 insufficient corridors');
    assert.strictEqual(coverage.scoreablePercentage, 9.7, 'Scoreable percentage must equal 9.7%');
    assert.ok(Object.keys(coverage.coverageBySource).length > 0, 'Must provide source breakdown');
    assert.ok(Object.keys(coverage.coverageByState).length > 0, 'Must provide state breakdown');
    assert.ok(Object.keys(coverage.coverageByAgency).length > 0, 'Must provide agency breakdown');
  });

  // Test 2: Feature Completeness & Availability
  await test('2. Feature completeness monitors all 10 features without silent default imputation', () => {
    const recon60940 = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_60940', '2024-06-01');
    assert.strictEqual(recon60940.success, true);
    assert.ok(recon60940.featureVector);

    const fv = recon60940.featureVector!;
    for (const feat of ORDERED_SHADOW_FEATURES) {
      assert.ok(feat in fv, `Feature ${feat} must be present`);
      assert.notStrictEqual((fv as any)[feat], undefined);
      assert.notStrictEqual((fv as any)[feat], null);
    }
  });

  // Test 3: Numeric PSI Calculation
  await test('3. Population Stability Index (PSI) algorithm computes accurate distribution shift', () => {
    // Identical distributions -> PSI = 0
    const sample = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
    const psiIdentical = ShadowDriftEngine.calculateNumericPSI(sample, sample);
    assert.strictEqual(psiIdentical, 0.0, 'Identical distributions must have PSI = 0.0');

    // Drastically shifted distribution -> PSI > 0.25
    const shifted = [1000, 2000, 3000, 4000, 5000];
    const psiShifted = ShadowDriftEngine.calculateNumericPSI(sample, shifted);
    assert.ok(psiShifted > 0.25, `Shifted distribution must indicate material drift: got ${psiShifted}`);
  });

  // Test 4: Categorical Drift Calculation & Novel Category Detection
  await test('4. Categorical drift monitor identifies frequency shifts and unseen categories', () => {
    const baseCats = ['NHAI', 'NHAI', 'MoRTH', 'State PWD'];
    const currCats = ['NHAI', 'UNKNOWN_NEW_AGENCY'];
    const res = ShadowDriftEngine.calculateCategoricalPSI(baseCats, currCats);

    assert.ok(res.unseen.includes('UNKNOWN_NEW_AGENCY'), 'Must detect unseen agency category');
    assert.ok(res.psi > 0, 'PSI must be non-zero when categories shift');
  });

  // Test 5: Two-Sample Kolmogorov-Smirnov Test
  await test('5. Two-sample Kolmogorov-Smirnov test statistic D and asymptotic p-value', () => {
    const s1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    const s2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    const ksSame = ShadowDriftEngine.calculateKS(s1, s2);
    assert.strictEqual(ksSame.dStatistic, 0.0, 'Identical samples must have KS D = 0');
    assert.strictEqual(ksSame.pValue, 1.0, 'Identical samples must have p-value = 1.0');

    const sDiff = [20, 21, 22, 23, 24];
    const ksDiff = ShadowDriftEngine.calculateKS(s1, sDiff);
    assert.strictEqual(ksDiff.dStatistic, 1.0, 'Non-overlapping samples must have KS D = 1.0');
    assert.ok(ksDiff.pValue <= 0.05, 'Non-overlapping samples must be statistically significant');
  });

  // Test 6: Prediction Distribution Diagnostics
  await test('6. Prediction distribution computes mean, median, percentiles, and histogram bins', () => {
    const sampleProbs = [0.12, 0.45, 0.65, 0.78, 0.85, 0.92];
    const dist = ShadowDriftEngine.computePredictionDistribution(sampleProbs);

    assert.strictEqual(dist.count, 6);
    assert.ok(dist.mean > 0 && dist.mean < 1);
    assert.ok(dist.median > 0 && dist.median < 1);
    assert.ok(dist.p10 <= dist.p25 && dist.p25 <= dist.median && dist.median <= dist.p75 && dist.p75 <= dist.p90);
    assert.strictEqual(dist.histogram.length, 5, 'Must produce 5 histogram bins');
  });

  // Test 7: V1 vs V2 Comparison Diagnostics
  await test('7. V1 vs V2 model disagreement diagnostics compute absolute delta and correlation', () => {
    const items = [
      { projectId: 'BhoomiRashi_60940', v1Probability: 0.89, v2Probability: 0.7426, v1RiskLevel: 'HIGH' },
      { projectId: 'BhoomiRashi_54635', v1Probability: 0.85, v2Probability: 0.7990, v1RiskLevel: 'HIGH' },
      { projectId: 'BhoomiRashi_56972', v1Probability: 0.72, v2Probability: 0.7581, v1RiskLevel: 'HIGH' }
    ];

    const comp = ShadowDriftEngine.compareV1AndV2(items);
    assert.strictEqual(comp.comparedProjectsCount, 3);
    assert.ok(comp.meanAbsoluteDifference > 0);
    assert.ok(typeof comp.correlation === 'number');
    assert.strictEqual(comp.stateDisagreementCount, 0, 'All 3 control projects concordance on high risk');
  });

  // Test 8: Deterministic Shadow Scoring Stability Verification
  await test('8. Deterministic shadow inference strictly satisfies repeat scoring tolerance <= 1e-12', () => {
    const recon = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_60940', '2024-06-01');
    assert.strictEqual(recon.success, true);
    const fv = recon.featureVector!;

    const p1 = scoreCandidateArtifact(fv);
    const p2 = scoreCandidateArtifact(fv);
    const p3 = scoreCandidateArtifact(fv);

    const diff1 = Math.abs(p1 - p2);
    const diff2 = Math.abs(p1 - p3);

    assert.ok(diff1 <= 1e-12, `Difference ${diff1} must be <= 1e-12`);
    assert.ok(diff2 <= 1e-12, `Difference ${diff2} must be <= 1e-12`);
    assert.strictEqual(p1, p2, 'Exact numeric equality required');
  });

  // Test 9: Duplicate Prediction Detection & Hash Determinism
  await test('9. Identical project + timestamp + features yield identical snapshot hash', () => {
    const recon1 = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_60940', '2024-06-01');
    const recon2 = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_60940', '2024-06-01');

    const h1 = computeFeatureSnapshotHash(recon1.featureVector!);
    const h2 = computeFeatureSnapshotHash(recon2.featureVector!);

    assert.strictEqual(h1, h2, 'Hashes must be identical');
  });

  // Test 10: Eventual Outcome Chronology Rule
  await test('10. Outcome evaluation enforces outcome timestamp strictly after observation timestamp', () => {
    // 54635: Observation at 2018-06-01, Section 3D at 2018-09-28 -> valid maturity (2018-09-28 > 2018-06-01)
    const recMature = [
      {
        projectId: 'BhoomiRashi_54635',
        observationTimestamp: '2018-06-01',
        first3aDate: '2017-09-18',
        section3dDate: '2018-09-28',
        predictedProbability: 0.7990
      }
    ];

    const summary = ShadowDriftEngine.evaluateOutcomes(recMature, 1);
    assert.strictEqual(summary.matureOutcomesCount, 1);
    assert.strictEqual(summary.delayedLapsedCount, 1, '375 days elapsed (> 365 statutory days) is DELAYED_LAPSED');
  });

  // Test 11: Immature Outcome Protection
  await test('11. Immature or unverified observations are not evaluated prematurely', () => {
    const recImmature = [
      {
        projectId: 'BhoomiRashi_60940',
        observationTimestamp: '2024-06-01',
        first3aDate: '2024-01-15',
        section3dDate: null,
        predictedProbability: 0.7426
      }
    ];

    const summary = ShadowDriftEngine.evaluateOutcomes(recImmature, 1);
    assert.strictEqual(summary.delayedLapsedCount, 0);
    assert.strictEqual(summary.completedOnTimeCount, 0);
    assert.strictEqual(summary.pendingOutcomesCount, 1, 'Still pending within statutory window');
  });

  // Test 12: Mature Outcome Acceptance
  await test('12. Mature outcome classification accurately identifies completed-on-time vs delayed', () => {
    // 56972: 2019-02-12 to 2020-02-11 = 364 days <= 365 days -> COMPLETED_ON_TIME
    const recOnTime = [
      {
        projectId: 'BhoomiRashi_56972',
        observationTimestamp: '2019-06-01',
        first3aDate: '2019-02-12',
        section3dDate: '2020-02-11',
        predictedProbability: 0.7581
      }
    ];

    const summary = ShadowDriftEngine.evaluateOutcomes(recOnTime, 1);
    assert.strictEqual(summary.completedOnTimeCount, 1);
    assert.strictEqual(summary.delayedLapsedCount, 0);
  });

  // Test 13 & 14: Insufficient Sample Protection
  await test('13. Performance metrics safely return OUTCOME_MATURITY_INSUFFICIENT when sample < 10', () => {
    const recFew = [
      { projectId: 'P1', observationTimestamp: '2020-01-01', first3aDate: '2019-01-01', section3dDate: '2019-06-01', predictedProbability: 0.8 },
      { projectId: 'P2', observationTimestamp: '2020-01-01', first3aDate: '2019-01-01', section3dDate: '2020-06-01', predictedProbability: 0.8 }
    ];

    const summary = ShadowDriftEngine.evaluateOutcomes(recFew, 10);
    assert.strictEqual(summary.evaluationStatus, 'OUTCOME_MATURITY_INSUFFICIENT');
    assert.strictEqual(summary.brierScore, null, 'Must not output fake 0.00 Brier score');
    assert.strictEqual(summary.rocAuc, null, 'Must not output fake 0.00 ROC-AUC');
    assert.strictEqual(summary.calibrationStatus, 'OUTCOME_DATA_INSUFFICIENT');
    assert.ok(summary.message.includes('insufficient'));
  });

  // Test 15: Calibration Monitoring with Adequate Sample Size
  await test('15. Calibration monitoring calculates Brier score and ROC-AUC when sample >= 10', () => {
    const mockMature: any[] = [];
    for (let i = 0; i < 12; i++) {
      mockMature.push({
        projectId: `P_${i}`,
        observationTimestamp: '2019-06-01',
        first3aDate: '2018-01-01',
        section3dDate: i % 2 === 0 ? '2018-08-01' : '2019-08-01', // alternate on-time / delayed
        predictedProbability: i % 2 === 0 ? 0.3 : 0.8
      });
    }

    const summary = ShadowDriftEngine.evaluateOutcomes(mockMature, 10);
    assert.strictEqual(summary.evaluationStatus, 'COMPLETE');
    assert.ok(typeof summary.brierScore === 'number' && summary.brierScore > 0);
    assert.ok(typeof summary.rocAuc === 'number' && summary.rocAuc >= 0.5);
    assert.ok(['STABLE', 'CALIBRATION_REVIEW_REQUIRED'].includes(summary.calibrationStatus));
  });

  // Test 16: Missing-Data Protection
  await test('16. Ingestion and monitoring reject default or median value substitution', () => {
    const recon = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_57405', '2024-06-01');
    assert.strictEqual(recon.success, false);
    assert.strictEqual(recon.evidenceStatus, 'INSUFFICIENT_EVIDENCE');
    assert.ok(recon.reasons.some(r => r.includes('Missing verified Section 3A date')));
  });

  // Test 17: Synthetic-Data Exclusion
  await test('17. Synthetic corridors strictly excluded from authoritative evidence monitoring', () => {
    const coverage = ShadowMonitoringService.evaluateEvidenceCoverage(db);
    const synthProject = coverage.projects.find(p => p.projectId === 'NHAI-2026-001');
    assert.ok(synthProject, 'Synthetic corridor must be tracked');
    assert.strictEqual(synthProject.isScoreable, false, 'Synthetic corridor must NEVER be scoreable');
    assert.strictEqual(synthProject.sourceType, 'SYNTHETIC');
  });

  // Test 18: Threshold Governance Intact
  await test('18. Threshold governance remains strictly PENDING_STAKEHOLDER_APPROVAL', () => {
    assert.strictEqual(SHADOW_POLICY_CONFIG.HIGHER_RISK_THRESHOLD, 'PENDING_STAKEHOLDER_APPROVAL');
    assert.strictEqual(SHADOW_POLICY_CONFIG.LOWER_RISK_THRESHOLD, 'PENDING_STAKEHOLDER_APPROVAL');
    assert.strictEqual(SHADOW_POLICY_CONFIG.COST_MATRIX_VERSION, 'PENDING_STAKEHOLDER_APPROVAL');
  });

  // Test 19 & 20: V1 Production Isolation
  await test('19. Production V1 artifact, operational risk scores, and alerts completely untouched', () => {
    const v1ShaAfter = computeFileSha(v1Path);
    assert.strictEqual(v1ShaAfter, CANONICAL_V1_SHA256, 'V1 SHA must match canonical');
    assert.strictEqual(v1ShaAfter, v1ShaBefore, 'V1 SHA must not change');

    const currentProjects = db.prepare('SELECT * FROM projects').all() as any[];
    const currentProjectsHash = crypto.createHash('sha256').update(JSON.stringify(currentProjects)).digest('hex');
    assert.strictEqual(currentProjectsHash, initialProjectsHash, 'Operational projects table must not be mutated');

    const currentAlerts = (db.prepare('SELECT count(*) as c FROM alerts').get() as any).c;
    assert.strictEqual(currentAlerts, initialAlertsCount, 'Alerts count must remain identical');
  });

  // Test 21: Full End-to-End Monitoring Cycle Execution
  await test('20. ShadowMonitoringService executes complete monitoring cycle without operational mutation', () => {
    const report = ShadowMonitoringService.executeMonitoringCycle({
      id: 'USR_AUDITOR_TEST',
      name: 'Auditor Sharma',
      role: 'AUDITOR'
    });

    assert.ok(report.monitoringRunId.startsWith('SMR_'));
    assert.strictEqual(report.evidenceCoverage.totalProjects, 31);
    assert.strictEqual(report.evidenceCoverage.completeCount, 3);
    assert.strictEqual(report.stabilityCheck.isDeterministic, true);
    assert.strictEqual(report.modelManifest.modelVersion, 'BHOOMI-DRISHTI-ML-V2.0-SHADOW');
    assert.strictEqual(report.modelManifest.modelArtifactSha, EXPECTED_V2_SHA256);
    assert.strictEqual(report.modelManifest.datasetBaselineSha, EXPECTED_DATASET_SHA256);
  });

  // Test 22: Monitoring Audit Event Recording
  await test('21. Immutable audit event recorded for shadow monitoring execution', () => {
    const audit = db.prepare(`
      SELECT * FROM audit_logs
      WHERE resource = 'shadow_monitoring_runs'
      ORDER BY timestamp DESC LIMIT 1
    `).get() as any;

    assert.ok(audit, 'Audit log entry must exist for shadow monitoring run');
    assert.strictEqual(audit.result, 'SUCCESS');
    assert.strictEqual(audit.user_role, 'AUDITOR');
  });

  // Test 23: Baseline Dataset Integrity
  await test('22. Authenticated Phase 4C baseline dataset hash strictly verified', () => {
    const sha = ShadowDriftEngine.getBaselineSha();
    assert.strictEqual(sha, EXPECTED_DATASET_SHA256, 'Dataset SHA matches Phase 4C canonical');
  });

  console.log('\n========================================================================');
  console.log(`  Phase 7B-6 Test Suite Finished: ${passed} Passed, ${failed} Failed`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase7b6Tests().catch(err => {
  console.error('Fatal execution error in Phase 7B-6 test suite:', err);
  process.exit(1);
});
