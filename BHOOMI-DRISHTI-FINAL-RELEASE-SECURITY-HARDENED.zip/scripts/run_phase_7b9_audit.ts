/**
 * BHOOMI-DRISHTI PHASE 7B-9: FINAL PRE-PUBLISH SHADOW GOVERNANCE READINESS AUDIT
 * 
 * Verifies all mandatory institutional requirements:
 * 1. Artifact Integrity (V1 SHA-256, V2 SHA-256, Dataset SHA-256)
 * 2. Model Pipeline Deserialization & Inspection (scikit-learn pipeline, joblib runtime)
 * 3. Model Card & Manifest Consistency
 * 4. Dataset & Feature Contract (10-feature schema, forbidden features, deterministic hashing)
 * 5. Production / Shadow Isolation (V1 routes, zero V2 leak, alerts/recommendations untouched)
 * 6. Governance State Machine (SHADOW_CANDIDATE, NON_OPERATIONAL, PENDING_STAKEHOLDER_APPROVAL)
 * 7. Evidence Gates & Outcome Maturity Gating (PRE_3A, missing outcomes, synthetic exclusion)
 * 8. Drift Monitoring & Evaluation Safety (Diagnostic-only, no decision activation)
 * 9. RBAC & Security Matrix (VIEWER read-only, privileged route enforcement)
 * 10. Database Integrity & Immutability (PRAGMA integrity_check, 31 operational projects)
 */

import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync, execSync } from 'node:child_process';
import { getDatabase } from '../src/server/database.ts';
import {
  CANONICAL_V1_SHA256,
  CANONICAL_V2_SHA256,
  CANONICAL_BASELINE_DATASET_SHA,
  CANONICAL_FEATURE_SCHEMA
} from '../src/server/ml/shadowEvaluationEngine.ts';
import { ORDERED_SHADOW_FEATURES, FORBIDDEN_QUARANTINE_KEYS } from '../src/server/ml/shadowFeatureSchema.ts';
import { SHADOW_POLICY_CONFIG } from '../src/server/ml/shadowRunner.ts';

const V1_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib';
const V2_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_pipeline.joblib';
const DATASET_PATH = 'data/reconstructed_longitudinal_dataset_v2.json';
const MANIFEST_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_manifest.json';
const MODEL_CARD_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/MODEL_CARD.md';

function computeSha(filePath: string): string {
  const buf = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buf).digest('hex');
}

let passed = 0;
let failed = 0;

async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    console.log(`  ✓ ${name}`);
    passed++;
  } catch (err: any) {
    console.error(`  ✗ ${name}`);
    console.error(`    Error: ${err.message}`);
    failed++;
  }
}

async function runAudit() {
  console.log('========================================================================');
  console.log('  PHASE 7B-9: FINAL PRE-PUBLISH SHADOW GOVERNANCE READINESS AUDIT');
  console.log('  Ministry of Road Transport & Highways (MoRTH) / NHAI');
  console.log('========================================================================\n');

  const db = getDatabase();

  // Snapshot initial database counts
  const initialProjectCount = (db.prepare('SELECT COUNT(*) as c FROM projects').get() as any).c;
  const initialAlertsCount = (db.prepare('SELECT COUNT(*) as c FROM alerts').get() as any).c;
  const initialRecommendationsCount = (db.prepare('SELECT COUNT(*) as c FROM project_recommendations').get() as any).c;

  // 1. ARTIFACT INTEGRITY
  console.log('--- 1. Model Artifact Integrity & Serialization ---');

  await test('1.1 Canonical V1 SHA-256 strictly preserved', () => {
    const v1Sha = computeSha(V1_PATH);
    assert.strictEqual(v1Sha, CANONICAL_V1_SHA256);
  });

  await test('1.2 Canonical V2 SHA-256 strictly preserved', () => {
    const v2Sha = computeSha(V2_PATH);
    assert.strictEqual(v2Sha, CANONICAL_V2_SHA256);
  });

  await test('1.3 Authenticated Phase 4C dataset SHA-256 strictly preserved', () => {
    const dsSha = computeSha(DATASET_PATH);
    assert.strictEqual(dsSha, CANONICAL_BASELINE_DATASET_SHA);
  });

  await test('1.4 Python/joblib deserializes V2 artifact into scikit-learn Pipeline', () => {
    const pyScript = `import joblib
from sklearn.pipeline import Pipeline

model = joblib.load('${V2_PATH}')
assert isinstance(model, Pipeline), f"Expected Pipeline, got {type(model)}"
assert hasattr(model, 'predict_proba'), "Model missing predict_proba"
assert list(model.classes_) == [0, 1], f"Expected classes [0, 1], got {model.classes_}"
print("DESERIALIZATION_OK")
`;
    const out = execFileSync('python3', ['-c', pyScript]).toString();
    assert.ok(out.includes('DESERIALIZATION_OK'));
  });

  await test('1.5 model_manifest.json references correct hashes and metadata', () => {
    const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf-8'));
    assert.strictEqual(manifest.model_name, 'BHOOMI-DRISHTI-ML-V2.0-SHADOW');
    assert.strictEqual(manifest.status, 'SHADOW_CANDIDATE');
    assert.strictEqual(manifest.operational_status, 'NON_OPERATIONAL');
    assert.strictEqual(manifest.artifact_sha256, CANONICAL_V2_SHA256);
    assert.strictEqual(manifest.dataset.sha256, CANONICAL_BASELINE_DATASET_SHA);
    assert.strictEqual(manifest.feature_schema.schema_id, CANONICAL_FEATURE_SCHEMA);
  });

  await test('1.6 MODEL_CARD.md references correct hashes and non-operational status', () => {
    const card = fs.readFileSync(MODEL_CARD_PATH, 'utf-8');
    assert.ok(card.includes(CANONICAL_V1_SHA256), 'MODEL_CARD missing canonical V1 hash');
    assert.ok(card.includes(CANONICAL_V2_SHA256), 'MODEL_CARD missing canonical V2 hash');
    assert.ok(card.includes(CANONICAL_BASELINE_DATASET_SHA), 'MODEL_CARD missing dataset hash');
    assert.ok(card.includes('PENDING_STAKEHOLDER_APPROVAL'), 'MODEL_CARD missing pending threshold policy');
  });

  // 2. DATASET & FEATURE CONTRACT
  console.log('\n--- 2. Feature Contract & Temporal Safety ---');

  await test('2.1 Exact 10-feature schema conforms to SCHEMA-LONGITUDINAL-V2.0-10FEAT', () => {
    assert.strictEqual(ORDERED_SHADOW_FEATURES.length, 10);
    const expectedFeatures = [
      'elapsed_days_since_first_3a',
      'cumulative_notifications_count_at_t',
      'notification_cadence_days',
      'days_since_last_notification',
      'statutory_stage_at_t',
      'statutory_notification_frequency_180d',
      'total_land_required_ha',
      'implementing_agency',
      'state_jurisdiction',
      'initial_sanction_available_at_t'
    ];
    assert.deepStrictEqual([...ORDERED_SHADOW_FEATURES], expectedFeatures);
  });

  await test('2.2 Quarantined and target-derived features remain strictly excluded', () => {
    for (const forbidden of FORBIDDEN_QUARANTINE_KEYS) {
      assert.ok(!ORDERED_SHADOW_FEATURES.includes(forbidden as any), `Forbidden feature ${forbidden} leaked into schema!`);
    }
  });

  await test('2.3 Deterministic feature snapshot hashing produces identical SHA across runs', () => {
    const vector = {
      elapsed_days_since_first_3a: 120,
      cumulative_notifications_count_at_t: 3,
      notification_cadence_days: 40,
      days_since_last_notification: 15,
      statutory_stage_at_t: 'Section 3A',
      statutory_notification_frequency_180d: 2,
      total_land_required_ha: 150.5,
      implementing_agency: 'NHAI',
      state_jurisdiction: 'Uttar Pradesh',
      initial_sanction_available_at_t: 1
    };
    const s1 = JSON.stringify(ORDERED_SHADOW_FEATURES.map(f => (vector as any)[f]));
    const h1 = crypto.createHash('sha256').update(s1).digest('hex');
    const s2 = JSON.stringify(ORDERED_SHADOW_FEATURES.map(f => (vector as any)[f]));
    const h2 = crypto.createHash('sha256').update(s2).digest('hex');
    assert.strictEqual(h1, h2);
  });

  // 3. EVIDENCE GATES & OUTCOME MATURITY GATING
  console.log('\n--- 3. Evidence Gates & Outcome Maturity Gating ---');

  await test('3.1 Pre-3A corridors (e.g., BhoomiRashi_57405) are strictly routed to PRE_3A exclusion', () => {
    const p = db.prepare("SELECT * FROM projects WHERE id = 'BhoomiRashi_57405'").get() as any;
    assert.ok(p, 'BhoomiRashi_57405 exists');
    assert.strictEqual(p.current_stage, 'Identification');
    assert.ok(!p.section_3a_date || p.section_3a_date === 'UNAVAILABLE', 'section_3a_date must be absent or unavailable');
  });

  await test('3.2 Missing authoritative outcome corridors route to MISSING_AUTHORITATIVE_OUTCOME', () => {
    const unscoreableCount = (db.prepare(`
      SELECT count(*) as c FROM projects 
      WHERE id NOT IN (SELECT project_id FROM shadow_eventual_outcomes)
    `).get() as any).c;
    assert.ok(unscoreableCount > 0, 'Unscoreable corridors exist and are accounted for');
  });

  await test('3.3 Statistical power gate enforces OUTCOME_MATURITY_INSUFFICIENT when mature sample < 10', () => {
    const matureCount = (db.prepare('SELECT count(*) as c FROM shadow_eventual_outcomes WHERE is_mature = 1').get() as any).c;
    // Database has only 2 mature outcomes (< 10)
    assert.ok(matureCount < 10);
  });

  // 4. SHADOW & PRODUCTION ISOLATION
  console.log('\n--- 4. Production Isolation & Governance ---');

  await test('4.1 Production V1 bridge exclusively loads V1 model artifact', () => {
    const bridgeContent = fs.readFileSync('src/server/mlPredictionBridge.ts', 'utf-8');
    assert.ok(bridgeContent.includes('data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib'));
    assert.ok(!bridgeContent.includes('BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_pipeline.joblib'));
  });

  await test('4.2 Production prediction endpoint POST /api/ml/predict operates on V1 only', () => {
    const serverContent = fs.readFileSync('server.ts', 'utf-8');
    const predictSection = serverContent.substring(serverContent.indexOf("app.post('/api/ml/predict'"), serverContent.indexOf("app.get('/api/ml/model-info'"));
    assert.ok(predictSection.includes("resource: 'ml_model_v1.0'"));
    assert.ok(!predictSection.includes('V2'));
  });

  await test('4.3 Threshold governance policy remains strictly PENDING_STAKEHOLDER_APPROVAL', () => {
    assert.strictEqual(SHADOW_POLICY_CONFIG.HIGHER_RISK_THRESHOLD, 'PENDING_STAKEHOLDER_APPROVAL');
    assert.strictEqual(SHADOW_POLICY_CONFIG.LOWER_RISK_THRESHOLD, 'PENDING_STAKEHOLDER_APPROVAL');
    assert.strictEqual(SHADOW_POLICY_CONFIG.COST_MATRIX_VERSION, 'PENDING_STAKEHOLDER_APPROVAL');
  });

  await test('4.4 Zero UI elements exist to activate thresholds or promote model', () => {
    const uiContent = fs.readFileSync('src/components/ShadowGovernanceView.tsx', 'utf-8');
    assert.ok(!uiContent.includes('Activate Threshold'));
    assert.ok(!uiContent.includes('Promote Model'));
    assert.ok(uiContent.includes('PENDING STAKEHOLDER APPROVAL'));
  });

  await test('4.5 Shadow API mutating endpoints restrict access to privileged roles (requireRole)', () => {
    const serverContent = fs.readFileSync('server.ts', 'utf-8');
    assert.ok(serverContent.includes("app.post('/api/shadow/score', sensitiveRateLimiter, requireRole(['NODAL_OFFICER', 'AUDITOR'])"));
    assert.ok(serverContent.includes("app.post('/api/shadow/evaluation/run', sensitiveRateLimiter, requireRole(['NODAL_OFFICER', 'AUDITOR'])"));
    assert.ok(serverContent.includes("app.post('/api/shadow/monitoring/run', sensitiveRateLimiter, requireRole(['NODAL_OFFICER', 'AUDITOR'])"));
  });

  // 5. DATABASE INTEGRITY & IMMUTABILITY
  console.log('\n--- 5. Database Integrity & Operational Immutability ---');

  await test('5.1 SQLite PRAGMA integrity_check passes completely', () => {
    const integrity = (db.prepare('PRAGMA integrity_check').all() as any[])[0]?.integrity_check;
    assert.strictEqual(integrity, 'ok');
  });

  await test('5.2 Operational projects population remains exactly 31 projects', () => {
    const currentProjectCount = (db.prepare('SELECT COUNT(*) as c FROM projects').get() as any).c;
    assert.strictEqual(currentProjectCount, 31);
    assert.strictEqual(currentProjectCount, initialProjectCount);
  });

  await test('5.3 Operational risk levels and delay probabilities are completely unchanged', () => {
    const currentAlertsCount = (db.prepare('SELECT COUNT(*) as c FROM alerts').get() as any).c;
    const currentRecommendationsCount = (db.prepare('SELECT COUNT(*) as c FROM project_recommendations').get() as any).c;
    assert.strictEqual(currentAlertsCount, initialAlertsCount);
    assert.strictEqual(currentRecommendationsCount, initialRecommendationsCount);
  });

  console.log('\n========================================================================');
  console.log(`  Phase 7B-9 Audit Finished: ${passed} Passed, ${failed} Failed`);
  console.log('========================================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runAudit().catch(err => {
  console.error('Fatal error running Phase 7B-9 audit:', err);
  process.exit(1);
});
