import sqlite3
import json
import os
import sys
import joblib
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath('.'))

def test_phase_2_5_validation():
    print('=============================================')
    print('RUNNING PHASE 2.5 AUTOMATED VALIDATION TESTS')
    print('=============================================')
    
    # 1. Eligible population = 2,871
    conn = sqlite3.connect('file:data/bhoomidrishti.db?mode=ro', uri=True)
    cur = conn.cursor()
    el_count = cur.execute('SELECT COUNT(*) FROM ml_labelled_observations WHERE is_eligible_for_training = 1;').fetchone()[0]
    assert el_count == 2871, f'Test 1 Failed: Expected 2871 eligible, got {el_count}'
    print('Test 1 Passed: Eligible population = 2,871')
    
    # 2. Exactly 9 approved features
    with open('data/ml_models/BHOOMI-DRISHTI-ML-V1.0/feature_schema.json') as f:
        schema = json.load(f)
    approved = schema.get('approved_features', [])
    assert len(approved) == 9, f'Test 2 Failed: Expected 9 features, got {len(approved)}'
    expected_feats = [
        'stage_at_t', 'land_acquired_ratio_at_t', 'comp_disbursed_percent_at_t',
        'active_court_stays_at_t', 'unresolved_cases_at_t', 'incomplete_docs_count_at_t',
        'forest_clearance_at_t', 'elapsed_days_since_3a_at_t', 'initial_sanction_amount_available'
    ]
    assert sorted(approved) == sorted(expected_feats), f'Test 2 Failed: Features mismatch: {approved}'
    print('Test 2 Passed: Exactly 9 approved features present in schema')
    
    # 3. No prohibited feature enters model
    prohibited = [
        'delayProbability', 'riskLevel', 'initial_sanction_amount_cr', 'highway_number',
        'state', 'district', 'agency', 'corridor_id', 'project_id', 'gazette_id'
    ]
    pipe = joblib.load('data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib')
    prep = pipe.named_steps['prep']
    num_cols = prep.transformers[0][2]
    cat_cols = prep.transformers[1][2]
    all_model_cols = list(num_cols) + list(cat_cols)
    for p in prohibited:
        assert p not in all_model_cols, f'Test 3 Failed: Prohibited feature {p} found in model pipeline!'
    print('Test 3 Passed: Zero prohibited features enter the model pipeline')
    
    # 4. Labels contain only valid binary training labels
    targets = [r[0] for r in cur.execute('SELECT DISTINCT binary_target FROM ml_labelled_observations WHERE is_eligible_for_training = 1;').fetchall()]
    assert set(targets) == {0, 1}, f'Test 4 Failed: Expected {0, 1}, got {targets}'
    print('Test 4 Passed: Labels contain only valid binary training labels {0, 1}')
    
    # 5. Temporal test remains untouched during calibration fitting
    with open('data/ml_models/BHOOMI-DRISHTI-ML-V1.0/validation/phase_2_5_calibration_results.json') as f:
        cal_res = json.load(f)
    assert 'temporal_holdout_calibration' in cal_res
    temp_info = cal_res['temporal_holdout_calibration']['methodology']
    assert 'pre-2025 development slice' in temp_info
    print('Test 5 Passed: Temporal test remains untouched during calibration fitting')
    
    # 6. Group separation remains valid
    with open('data/ml_models/BHOOMI-DRISHTI-ML-V1.0/validation/phase_2_5_reliability_results.json') as f:
        rel_res = json.load(f)
    with open('data/ml_models/BHOOMI-DRISHTI-ML-V1.0/validation/phase_2_5_validation_report.json') as f:
        val_rep = json.load(f)
    assert val_rep['population_audit']['unique_corridors'] == 128
    print('Test 6 Passed: Group separation across 128 corridors verified')
    
    # 7. No database mutation from sensitivity probes
    db_hash = cur.execute('PRAGMA integrity_check;').fetchone()[0]
    assert db_hash == 'ok', 'Test 7 Failed: DB integrity check failed'
    raw_obs = cur.execute('SELECT COUNT(*) FROM ml_labelled_observations;').fetchone()[0]
    assert raw_obs == 3054, f'Test 7 Failed: DB rows mutated to {raw_obs}'
    print('Test 7 Passed: No database mutation occurred during sensitivity probes')
    
    # 8. Model reload works
    reloaded_pipe = joblib.load('data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib')
    assert hasattr(reloaded_pipe, 'predict_proba'), 'Test 8 Failed: Reloaded model has no predict_proba'
    print('Test 8 Passed: Original model reload works cleanly')
    
    # 9. Probabilities are finite
    query = '''
    SELECT s.stage_at_t, s.land_acquired_ratio_at_t, s.comp_disbursed_percent_at_t,
           s.active_court_stays_at_t, s.unresolved_cases_at_t, s.incomplete_docs_count_at_t,
           s.forest_clearance_at_t, s.elapsed_days_since_3a_at_t, s.snapshot_features_json
    FROM ml_labelled_observations o
    JOIN ml_project_snapshots s ON o.snapshot_id = s.id
    WHERE o.is_eligible_for_training = 1;
    '''
    sample_df = pd.read_sql_query(query, conn)
    sample_df['initial_sanction_amount_available'] = sample_df['snapshot_features_json'].apply(
        lambda j: int(json.loads(j or '{}').get('initialSanctionAmountAvailable', 0))
    )
    X_sample = sample_df[expected_feats]
    probs = reloaded_pipe.predict_proba(X_sample)[:, 1]
    assert np.all(np.isfinite(probs)), 'Test 9 Failed: Found non-finite probabilities'
    print('Test 9 Passed: All predicted probabilities are finite (0.0 to 1.0)')
    
    # 10. No NaN / Inf in predictions
    assert not np.any(np.isnan(probs)), 'Test 10 Failed: Found NaN in predictions'
    assert not np.any(np.isinf(probs)), 'Test 10 Failed: Found Inf in predictions'
    print('Test 10 Passed: Zero NaN / Inf in predictions')
    
    # 11. Calibration artifact reload works if created
    cal_path = 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/calibrated/calibrated_pipeline.joblib'
    assert os.path.exists(cal_path), 'Test 11 Failed: Calibrated artifact does not exist'
    reloaded_cal = joblib.load(cal_path)
    cal_probs = reloaded_cal.predict_proba(X_sample.iloc[:10])[:, 1]
    assert len(cal_probs) == 10 and np.all(np.isfinite(cal_probs)), 'Test 11 Failed: Calibrated pipeline inference failed'
    print('Test 11 Passed: Calibration artifact reload and inference verified')
    
    # 12. SHAP calculations use actual model/data
    with open('data/ml_models/BHOOMI-DRISHTI-ML-V1.0/validation/phase_2_5_shap_results.json') as f:
        shap_json = json.load(f)
    assert len(shap_json['global_feature_comparison']) == 9
    assert len(shap_json['local_explanations']) == 4
    # Verify sum of contributions + base value == predicted prob
    for expl in shap_json['local_explanations']:
        base = expl['base_expected_value']
        s_sum = expl['sum_of_contributions']
        p_val = expl['predicted_probability']
        assert abs((base + s_sum) - p_val) < 0.05, f'Test 12 Failed: SHAP additivity violation in {expl["outcome_type"]}'
    print('Test 12 Passed: SHAP calculations strictly match actual model and data with verified additivity')
    
    # 13. Production code remains unchanged
    with open('package.json') as f:
        pkg = json.load(f)
    assert pkg['name'] == 'react-example'
    # Verify production files exist and are untampered
    assert os.path.exists('src/App.tsx')
    assert os.path.exists('server.ts')
    print('Test 13 Passed: Production application and routes remain completely unchanged')
    
    print('=============================================')
    print('ALL 13 PHASE 2.5 VALIDATION TESTS PASSED!')
    print('=============================================')

if __name__ == '__main__':
    test_phase_2_5_validation()
