import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { getDatabase } from '../src/server/database.ts';
import { StatutoryStore, initStatutoryTables } from '../src/server/datahub/statutoryStore.ts';
import {
  BhoomiRashiStatutoryAdapter,
  LacrrisStatutoryAdapter,
  ManualDocumentIngestionService,
  StatutoryIngestionCoordinator
} from '../src/server/datahub/statutoryAdapters.ts';
import { SHADOW_POLICY_CONFIG } from '../src/server/ml/shadowRunner.ts';

const CANONICAL_V1_SHA256 = '7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f';
const EXPECTED_V2_SHA256 = '4a83e980f9178498be4592a47303f0ebc5ea641934952af5bee92ae5b76729a2';

function computeFileSha(filePath: string): string {
  const buf = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buf).digest('hex');
}

async function runPhase7b4Tests() {
  console.log('========================================================================');
  console.log('  PHASE 7B-4: STATUTORY GAZETTE INGESTION & EVIDENCE COVERAGE TEST SUITE');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void> | void) {
    try {
      await fn();
      console.log(`  ✓ ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  ✗ ${name}`);
      console.error(`    Error: ${err.message}`);
      failed++;
    }
  }

  const db = initStatutoryTables(getDatabase());

  // Test 1: V1 Production Artifact Strict Immutability
  await test('1. Production V1 artifact SHA-256 strictly preserved', () => {
    const v1Path = path.resolve(process.cwd(), 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib');
    const sha = computeFileSha(v1Path);
    assert.strictEqual(sha, CANONICAL_V1_SHA256, 'V1 artifact SHA must match canonical hash');
  });

  // Test 2: V2 Candidate Artifact Strict Immutability
  await test('2. Candidate V2 artifact SHA-256 strictly preserved', () => {
    const v2Path = path.resolve(process.cwd(), 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_pipeline.joblib');
    const sha = computeFileSha(v2Path);
    assert.strictEqual(sha, EXPECTED_V2_SHA256, 'V2 artifact SHA must match Phase 7A-2 hash');
  });

  // Test 3: Dedicated Statutory Tables Initialized
  await test('3. Dedicated statutory provenance tables exist with expected schema', () => {
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all() as any[];
    const names = new Set(tables.map(t => t.name));
    assert.ok(names.has('dh_authoritative_statutory_notifications'), 'Master gazette store must exist');
    assert.ok(names.has('dh_statutory_ingestion_runs'), 'Statutory ingestion runs must exist');
    assert.ok(names.has('dh_statutory_review_queue'), 'Human review queue must exist');
  });

  // Test 4: Operational Projects Population Intact
  await test('4. Operational projects table strictly maintained at 31 records', () => {
    const count = (db.prepare('SELECT count(*) as c FROM projects').get() as any).c;
    assert.strictEqual(count, 31, 'Projects count must remain exactly 31');
  });

  // Test 5: Operational Risk Levels Untouched
  await test('5. Operational risk levels and delay probabilities are 100% unchanged', () => {
    const sample = db.prepare("SELECT risk_level, delay_probability FROM projects WHERE id = 'NHAI-2026-001'").get() as any;
    assert.strictEqual(sample.risk_level, 'HIGH');
    assert.strictEqual(sample.delay_probability, 89);
  });

  // Test 6: Evidence Quality Breakdown
  await test('6. Evidence quality evaluates accurately across all 31 projects', () => {
    const projects = db.prepare('SELECT id, is_synthetic FROM projects').all() as any[];
    let completeCount = 0;
    let pre3aCount = 0;
    let insufficientCount = 0;

    for (const p of projects) {
      const q = StatutoryStore.getProjectEvidenceQuality(p.id);
      if (q.evidence_status === 'COMPLETE') {
        completeCount++;
        assert.strictEqual(q.validation_status, 'PASS');
        assert.strictEqual(q.is_shadow_scoreable, true);
        assert.ok(q.section_3a.first_verified_date);
        assert.ok(q.notifications.verified_count >= 1);
      } else {
        insufficientCount++;
        assert.strictEqual(q.is_shadow_scoreable, false);
        if (q.section_3a.status === 'PRE_3A_STAGE') {
          pre3aCount++;
          assert.strictEqual(q.project_id, 'BhoomiRashi_57405');
          assert.strictEqual(q.validation_status, 'PASS');
        } else {
          assert.strictEqual(q.validation_status, 'OUT_OF_BOUNDS');
        }
      }
    }

    assert.strictEqual(completeCount, 3, 'Exactly 3 projects must have complete authentic statutory evidence');
    assert.strictEqual(pre3aCount, 1, 'Exactly 1 project must be legitimately pre-3A stage');
    assert.strictEqual(insufficientCount, 28, 'Exactly 28 projects must be insufficient evidence');
  });

  // Test 7: Point-in-time Feature Reconstruction
  await test('7. Reconstruct longitudinal features at observation timestamp t with zero leakage', () => {
    const res = StatutoryIngestionCoordinator.reconstructLongitudinalFeatures('BhoomiRashi_60940', '2024-06-01');
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.evidenceStatus, 'COMPLETE');
    assert.ok(res.featureVector);

    const fv = res.featureVector!;
    assert.ok(typeof fv.elapsed_days_since_first_3a === 'number' && fv.elapsed_days_since_first_3a > 0);
    assert.ok(typeof fv.cumulative_notifications_count_at_t === 'number' && fv.cumulative_notifications_count_at_t >= 1);
    assert.ok(typeof fv.notification_cadence_days === 'number');
    assert.ok(typeof fv.days_since_last_notification === 'number');
    assert.strictEqual(fv.statutory_stage_at_t, 'INITIAL_3A');
    assert.ok(typeof fv.statutory_notification_frequency_180d === 'number');
    assert.ok(typeof fv.total_land_required_ha === 'number');
    assert.ok(typeof fv.implementing_agency === 'string');
    assert.ok(typeof fv.state_jurisdiction === 'string');
    assert.ok([0, 1].includes(fv.initial_sanction_available_at_t));
  });

  // Test 8: Statutory Record Idempotency & Deduplication
  await test('8. StatutoryStore guarantees idempotent notification recording without duplicates', () => {
    const dummyRecord = {
      source_type: 'LIVE_EXTERNAL' as const,
      source_name: 'BhoomiRashi',
      source_reference: 'MoRTH Gazette Archive Test',
      source_record_id: 'TEST_ID_001',
      project_id: 'BhoomiRashi_60940',
      source_project_id: '60940',
      notification_number: 'TEST/S.O. 9999(E)',
      statutory_section: '3A' as const,
      notification_type: '3A',
      publication_date: '2022-01-15',
      source_updated_at: '2022-01-15T10:00:00Z',
      retrieval_timestamp: new Date().toISOString(),
      source_url: 'https://bhoomirashi.gov.in',
      document_reference: 'Gazette S.O. 9999(E)',
      document_sha256: 'a1b2c3d4e5f6',
      verification_status: 'VERIFIED' as const,
      verification_method: 'TEST_INGESTION',
      raw_payload_hash: 'hash123',
      is_authoritative: 1,
      is_synthetic: 0,
      supersedes_record_id: null,
      ingestion_run_id: 'RUN_TEST'
    };

    const first = StatutoryStore.recordStatutoryNotification(dummyRecord);
    assert.ok(['INSERTED', 'UNCHANGED'].includes(first.action));

    const second = StatutoryStore.recordStatutoryNotification(dummyRecord);
    assert.strictEqual(second.action, 'UNCHANGED');

    // Clean up test record so authoritative provenance remains clean
    db.prepare('DELETE FROM dh_authoritative_statutory_notifications WHERE source_record_id = ?').run('TEST_ID_001');
  });

  // Test 9: Rejection of Synthetic Corridors
  await test('9. Manual ingestion rejects synthetic projects and non-authoritative documents', async () => {
    // Attempt upload to synthetic project
    const pdfBuffer = Buffer.from('%PDF-1.4 test content %EOF');
    const resSynthetic = await ManualDocumentIngestionService.ingestOfficialDocument({
      fileName: 'gazette.pdf',
      mimeType: 'application/pdf',
      buffer: pdfBuffer,
      projectId: 'NHAI-2026-001', // Synthetic project
      sourceReference: 'Gazette Notice Test',
      statutorySection: '3A',
      notificationNumber: 'S.O. 1234',
      publicationDate: '2023-01-01',
      uploaderId: 'USR_001',
      uploaderName: 'Test Nodal Officer'
    });
    assert.strictEqual(resSynthetic.success, false);
    assert.strictEqual(resSynthetic.status, 'REJECTED');
    assert.ok(resSynthetic.error?.includes('synthetic'));
  });

  // Test 10: Security Checks: MIME & Magic Byte Validation
  await test('10. Security checks enforce valid magic bytes and reject disguised files', async () => {
    const fakePdf = Buffer.from('NOT A PDF FILE BUFFER');
    const resMagic = await ManualDocumentIngestionService.ingestOfficialDocument({
      fileName: 'fake.pdf',
      mimeType: 'application/pdf',
      buffer: fakePdf,
      projectId: 'BhoomiRashi_60940',
      sourceReference: 'Official Gazette Notification',
      statutorySection: '3A',
      notificationNumber: 'S.O. 4321',
      publicationDate: '2023-01-01',
      uploaderId: 'USR_001',
      uploaderName: 'Test Nodal Officer'
    });
    assert.strictEqual(resMagic.success, false);
    assert.strictEqual(resMagic.status, 'REJECTED');
    assert.ok(resMagic.error?.includes('MIME signature'));
  });

  // Test 11: Date Validation: Reject Future Dates and Bad Formats
  await test('11. Ingestion rejects future publication dates and invalid date formats', async () => {
    const pdfBuffer = Buffer.from('%PDF-1.4 valid dummy header %EOF');
    const resFuture = await ManualDocumentIngestionService.ingestOfficialDocument({
      fileName: 'future.pdf',
      mimeType: 'application/pdf',
      buffer: pdfBuffer,
      projectId: 'BhoomiRashi_60940',
      sourceReference: 'Official Gazette Notification S.O. 8888',
      statutorySection: '3A',
      notificationNumber: 'S.O. 8888',
      publicationDate: '2099-01-01',
      uploaderId: 'USR_001',
      uploaderName: 'Test Nodal Officer'
    });
    assert.strictEqual(resFuture.success, false);
    assert.strictEqual(resFuture.status, 'REJECTED');
    assert.ok(resFuture.error?.includes('Future publication date'));
  });

  // Test 12: Ambiguous Document Linkage Routes to Human Review Queue
  await test('12. Ambiguous statutory submissions route to human review queue', async () => {
    const pdfBuffer = Buffer.from('%PDF-1.4 valid dummy header %EOF');
    const resReview = await ManualDocumentIngestionService.ingestOfficialDocument({
      fileName: 'unverified_scan.pdf',
      mimeType: 'application/pdf',
      buffer: pdfBuffer,
      projectId: 'BhoomiRashi_60940',
      sourceReference: 'short', // Ambiguous / insufficient citation (< 10 chars)
      statutorySection: '3A',
      notificationNumber: 'S.O. 5555',
      publicationDate: '2023-05-10',
      uploaderId: 'USR_001',
      uploaderName: 'Test Nodal Officer'
    });
    assert.strictEqual(resReview.success, true);
    assert.strictEqual(resReview.status, 'NEEDS_HUMAN_REVIEW');
    assert.ok(resReview.reviewId);

    // Verify item in queue
    const queue = StatutoryStore.getReviewQueue('PENDING');
    const found = queue.find(q => q.id === resReview.reviewId);
    assert.ok(found, 'Item must be present in human review queue');

    // Test decision recording
    const decided = StatutoryStore.recordReviewDecision(
      resReview.reviewId!,
      'APPROVED',
      { id: 'USR_NODAL', name: 'Nodal Officer Verma' },
      'Verified with Gazette of India hardcopy archive.'
    );
    assert.strictEqual(decided, true);
  });

  // Test 13: Source Adapters Classification & Health
  await test('13. Adapters correctly declare source type and handle health checks', async () => {
    const brAdapter = new BhoomiRashiStatutoryAdapter();
    assert.strictEqual(brAdapter.sourceType, 'LIVE_EXTERNAL');

    const lacrrisAdapter = new LacrrisStatutoryAdapter();
    assert.strictEqual(lacrrisAdapter.sourceType, 'STATIC_REFERENCE');

    const lacrrisHealth = await lacrrisAdapter.healthCheck();
    assert.strictEqual(lacrrisHealth.accessible, true);
    assert.strictEqual(lacrrisHealth.source_type, 'STATIC_REFERENCE');
  });

  // Test 14: Shadow Governance Unchanged
  await test('14. Shadow governance thresholds remain strictly PENDING_STAKEHOLDER_APPROVAL', () => {
    assert.strictEqual(SHADOW_POLICY_CONFIG.HIGHER_RISK_THRESHOLD, 'PENDING_STAKEHOLDER_APPROVAL');
    assert.strictEqual(SHADOW_POLICY_CONFIG.LOWER_RISK_THRESHOLD, 'PENDING_STAKEHOLDER_APPROVAL');
    assert.strictEqual(SHADOW_POLICY_CONFIG.COST_MATRIX_VERSION, 'PENDING_STAKEHOLDER_APPROVAL');
  });

  console.log('\n------------------------------------------------------------------------');
  console.log(`  Phase 7B-4 Test Summary: ${passed} Passed, ${failed} Failed`);
  console.log('------------------------------------------------------------------------\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase7b4Tests().catch(err => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
