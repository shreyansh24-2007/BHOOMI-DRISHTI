/**
 * BHOOMI-DRISHTI PHASE UI-1: SHADOW GOVERNANCE & AUTHORITATIVE EVIDENCE UI VERIFICATION SUITE
 * 
 * Verifies:
 * 1. Canonical Cryptographic Invariants (V1 SHA, V2 SHA, Dataset SHA)
 * 2. Feature Contract (SCHEMA-LONGITUDINAL-V2.0-10FEAT)
 * 3. Component Rendering & Export Integrity (ShadowGovernanceView, AuthoritativeEvidenceWorkspace, ProjectDetailsView, etc.)
 * 4. 5-Way Authoritative Evidence Classification (COMPLETE, PRE_3A, PARTIAL, OUT_OF_BOUNDS, MISSING_AUTHORITATIVE_EVIDENCE)
 * 5. Mandatory Safety Banners & Non-Operational Disclosures in UI Surfaces
 * 6. Absence of Dangerous Controls (No promote buttons, no silent threshold activation, no operational score mutations)
 * 7. REST API Endpoints utilized by the UI
 * 8. Strict RBAC Enforcement on UI-Triggered Action Endpoints (NODAL_OFFICER, AUDITOR, VIEWER)
 * 9. Production Model Isolation (V1 sole authoritative operational model)
 * 10. Database Immutability & PRAGMA integrity_check across all 31 operational projects
 */

import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { getDatabase } from '../src/server/database.ts';
import {
  CANONICAL_V1_SHA256,
  CANONICAL_V2_SHA256,
  CANONICAL_BASELINE_DATASET_SHA,
  CANONICAL_FEATURE_SCHEMA
} from '../src/server/ml/shadowEvaluationEngine.ts';
import { ORDERED_SHADOW_FEATURES, FORBIDDEN_QUARANTINE_KEYS } from '../src/server/ml/shadowFeatureSchema.ts';
import { StatutoryStore } from '../src/server/datahub/statutoryStore.ts';
import { queryShadowPredictions } from '../src/server/ml/shadowRunner.ts';

const V1_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib';
const V2_PATH = 'data/ml_models/BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_pipeline.joblib';
const DATASET_PATH = 'data/reconstructed_longitudinal_dataset_v2.json';
const EVIDENCE_PACKAGE_PATH = 'data/shadow_evaluation/phase_7b10_evidence_package.json';

function computeSha(filePath: string): string {
  const buf = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buf).digest('hex');
}

let passed = 0;
let failed = 0;

async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    console.log(`  ✓ ${name}`);
    passed++;
  } catch (err: any) {
    console.error(`  ✗ ${name}`);
    console.error(`    Error: ${err.message}`);
    failed++;
  }
}

async function runUIPhase1Suite() {
  console.log('========================================================================');
  console.log('  PHASE UI-1: SHADOW GOVERNANCE & AUTHORITATIVE EVIDENCE UI VERIFICATION');
  console.log('  Ministry of Road Transport & Highways (MoRTH) / NHAI');
  console.log('========================================================================\n');

  const db = getDatabase();

  // Snapshot initial database state
  const initialProjectCount = (db.prepare('SELECT COUNT(*) as c FROM projects').get() as any).c;
  const initialProjectsData = db.prepare('SELECT id, risk_level, delay_probability FROM projects').all();
  const initialAlertsCount = (db.prepare('SELECT COUNT(*) as c FROM alerts').get() as any).c;
  const initialRecommendationsCount = (db.prepare('SELECT COUNT(*) as c FROM project_recommendations').get() as any).c;

  // 1. CANONICAL CRYPTOGRAPHIC INVARIANTS
  console.log('--- 1. Canonical Cryptographic Invariants ---');

  await test('1. Production V1 artifact SHA-256 strictly preserved', () => {
    assert.strictEqual(computeSha(V1_PATH), CANONICAL_V1_SHA256);
  });

  await test('2. Candidate V2 artifact SHA-256 strictly preserved', () => {
    assert.strictEqual(computeSha(V2_PATH), CANONICAL_V2_SHA256);
  });

  await test('3. Authenticated Phase 4C baseline dataset SHA-256 strictly verified', () => {
    assert.strictEqual(computeSha(DATASET_PATH), CANONICAL_BASELINE_DATASET_SHA);
  });

  await test('4. Feature schema strictly conforms to SCHEMA-LONGITUDINAL-V2.0-10FEAT', () => {
    assert.strictEqual(ORDERED_SHADOW_FEATURES.length, 10);
    assert.strictEqual(CANONICAL_FEATURE_SCHEMA, 'SCHEMA-LONGITUDINAL-V2.0-10FEAT');
  });

  await test('5. Quarantined statutory features remain strictly excluded', () => {
    for (const forbidden of FORBIDDEN_QUARANTINE_KEYS) {
      assert.ok(!ORDERED_SHADOW_FEATURES.includes(forbidden as any));
    }
  });

  // 2. UI COMPONENT INTEGRITY & EXPORT VERIFICATION
  console.log('\n--- 2. UI Component Architecture & Export Integrity ---');

  await test('6. ShadowGovernanceView component exists and exports properly', () => {
    const filePath = path.resolve('src/components/ShadowGovernanceView.tsx');
    assert.ok(fs.existsSync(filePath), 'ShadowGovernanceView.tsx must exist');
    const content = fs.readFileSync(filePath, 'utf-8');
    assert.ok(content.includes('export const ShadowGovernanceView: React.FC'), 'Must export ShadowGovernanceView');
    assert.ok(content.includes('AuthoritativeEvidenceWorkspace'), 'Must integrate AuthoritativeEvidenceWorkspace');
    assert.ok(content.includes('ShadowMonitoringWorkspace'), 'Must integrate ShadowMonitoringWorkspace');
    assert.ok(content.includes('ShadowEvaluationWorkspace'), 'Must integrate ShadowEvaluationWorkspace');
  });

  await test('7. AuthoritativeEvidenceWorkspace exists with 5-way classification', () => {
    const filePath = path.resolve('src/components/AuthoritativeEvidenceWorkspace.tsx');
    assert.ok(fs.existsSync(filePath), 'AuthoritativeEvidenceWorkspace.tsx must exist');
    const content = fs.readFileSync(filePath, 'utf-8');
    assert.ok(content.includes('export const AuthoritativeEvidenceWorkspace: React.FC'), 'Must export AuthoritativeEvidenceWorkspace');
    assert.ok(content.includes('COMPLETE'), 'Must support COMPLETE');
    assert.ok(content.includes('PRE_3A'), 'Must support PRE_3A');
    assert.ok(content.includes('PARTIAL'), 'Must support PARTIAL');
    assert.ok(content.includes('OUT_OF_BOUNDS'), 'Must support OUT_OF_BOUNDS');
    assert.ok(content.includes('MISSING_AUTHORITATIVE_EVIDENCE'), 'Must support MISSING_AUTHORITATIVE_EVIDENCE');
  });

  await test('8. ProjectDetailsView includes dedicated Shadow V2 Diagnostics Tab', () => {
    const filePath = path.resolve('src/components/ProjectDetailsView.tsx');
    assert.ok(fs.existsSync(filePath), 'ProjectDetailsView.tsx must exist');
    const content = fs.readFileSync(filePath, 'utf-8');
    assert.ok(content.includes("activeTab === 'shadow'"), "Must handle activeTab === 'shadow'");
    assert.ok(content.includes('SHADOW / DIAGNOSTIC ONLY — NOT AN OPERATIONAL RISK SCORE'), 'Must include mandatory warning');
    assert.ok(content.includes('V2 SHADOW CANDIDATE — NON-OPERATIONAL'), 'Must include candidate disclosure');
  });

  await test('9. Sidebar navigation provides Shadow Governance access to all authenticated roles', () => {
    const filePath = path.resolve('src/components/Sidebar.tsx');
    const content = fs.readFileSync(filePath, 'utf-8');
    assert.ok(content.includes('shadow-governance'), 'Must include shadow-governance view');
    assert.ok(content.includes('Candidate Audit (Read-Only)'), 'Must indicate read-only for viewer');
  });

  // 3. VISUAL SAFETY BOUNDARIES & NON-OPERATIONAL DISCLOSURES
  console.log('\n--- 3. Visual Safety Boundaries & Disclosure Discipline ---');

  await test('10. ShadowGovernanceView contains required non-operational disclosures', () => {
    const content = fs.readFileSync('src/components/ShadowGovernanceView.tsx', 'utf-8');
    assert.ok(content.includes('V2 SHADOW CANDIDATE — NON-OPERATIONAL'), 'Must display V2 SHADOW CANDIDATE — NON-OPERATIONAL');
    assert.ok(content.includes('THRESHOLDS: PENDING STAKEHOLDER APPROVAL'), 'Must display THRESHOLDS: PENDING STAKEHOLDER APPROVAL');
    assert.ok(content.includes('Production model V1.0 remains active and authoritative'), 'Must declare V1 active and authoritative');
  });

  await test('11. Zero dangerous promotion or silent activation buttons exist in UI', () => {
    const compDir = path.resolve('src/components');
    const files = fs.readdirSync(compDir).filter(f => f.endsWith('.tsx'));
    for (const f of files) {
      const content = fs.readFileSync(path.join(compDir, f), 'utf-8');
      assert.ok(!content.includes('promoteCandidateModel'), `Dangerous promote button forbidden in ${f}`);
      assert.ok(!content.includes('activateThresholds'), `Dangerous activateThresholds forbidden in ${f}`);
      assert.ok(!content.includes('makeV2Operational'), `Dangerous makeV2Operational forbidden in ${f}`);
      assert.ok(!content.includes('promoteV2ToProduction'), `Dangerous promoteV2ToProduction forbidden in ${f}`);
    }
  });

  // 4. REST API ROUTES & BACKEND ENDPOINTS
  console.log('\n--- 4. Backend Route Registration & Client SDK Parity ---');

  await test('12. server.ts registers required UI endpoints', () => {
    const content = fs.readFileSync('server.ts', 'utf-8');
    assert.ok(content.includes("app.get('/api/shadow/runs'"), 'Must register /api/shadow/runs');
    assert.ok(content.includes("app.get('/api/shadow/diagnostics'"), 'Must register /api/shadow/diagnostics');
    assert.ok(content.includes("app.get('/api/shadow/project/:id'"), 'Must register /api/shadow/project/:id');
    assert.ok(content.includes("app.get('/api/shadow/monitoring/summary'"), 'Must register /api/shadow/monitoring/summary');
    assert.ok(content.includes("app.get('/api/shadow/monitoring/outcomes'"), 'Must register /api/shadow/monitoring/outcomes');
    assert.ok(content.includes("app.get('/api/shadow/evaluation/summary'"), 'Must register /api/shadow/evaluation/summary');
    assert.ok(content.includes("app.get('/api/shadow/evaluation/runs'"), 'Must register /api/shadow/evaluation/runs');
    assert.ok(content.includes("app.get('/api/shadow/evaluation/evidence-package'"), 'Must register /api/shadow/evaluation/evidence-package');
    assert.ok(content.includes("app.get('/api/datahub/projects/:id/evidence-quality'"), 'Must register /api/datahub/projects/:id/evidence-quality');
  });

  await test('13. apiClient SDK exposes getProjectShadowDiagnostic and getEvidencePackage', () => {
    const content = fs.readFileSync('src/services/apiClient.ts', 'utf-8');
    assert.ok(content.includes('getProjectShadowDiagnostic(projectId: string)'), 'apiClient must have getProjectShadowDiagnostic');
    assert.ok(content.includes('getEvidencePackage()'), 'apiClient must have getEvidencePackage');
  });

  // 5. AUTHORITATIVE EVIDENCE COVERAGE & SECTION 3A INTEGRITY
  console.log('\n--- 5. Statutory Evidence Coverage & Section 3A Lineage ---');

  await test('14. StatutoryStore correctly distinguishes Pre-3A corridor BhoomiRashi_57405', () => {
    const quality = StatutoryStore.getProjectEvidenceQuality('BhoomiRashi_57405');
    assert.strictEqual(quality.section_3a.status, 'PRE_3A_STAGE');
    assert.strictEqual(quality.is_shadow_scoreable, false);
    assert.strictEqual(quality.evidence_status, 'INSUFFICIENT_EVIDENCE');
  });

  await test('15. StatutoryStore accounts for all 31 operational projects', () => {
    const rows = db.prepare('SELECT id FROM projects').all() as any[];
    assert.strictEqual(rows.length, 31);
    let completeCount = 0;
    let pre3aCount = 0;
    let insufficientCount = 0;
    for (const r of rows) {
      const q = StatutoryStore.getProjectEvidenceQuality(r.id);
      if (q.evidence_status === 'COMPLETE' && q.is_shadow_scoreable) completeCount++;
      else insufficientCount++;
      if (q.section_3a.status === 'PRE_3A_STAGE') pre3aCount++;
    }
    assert.ok(completeCount >= 3, 'Must have verified complete scoreable corridors');
    assert.ok(pre3aCount >= 1, 'Must have at least 1 legitimate pre-3A corridor');
    assert.strictEqual(completeCount + insufficientCount, 31, 'Must account for all 31 operational projects');
  });

  // 6. RBAC ACCESS CONTROL FOR PRIVILEGED MUTATIONS
  console.log('\n--- 6. Institutional RBAC Enforcement ---');

  await test('16. Privilege Escalation Firewall: requireRole blocks VIEWER from statutory mutations', () => {
    const serverCode = fs.readFileSync('server.ts', 'utf-8');
    // POST /api/shadow/score restricted to NODAL_OFFICER and AUDITOR
    assert.ok(serverCode.includes("app.post('/api/shadow/score', sensitiveRateLimiter, requireRole(['NODAL_OFFICER', 'AUDITOR'])"));
    // POST /api/datahub/ingestion/import restricted to NODAL_OFFICER
    assert.ok(serverCode.includes("app.post('/api/datahub/ingestion/import', sensitiveRateLimiter, requireRole(['NODAL_OFFICER'])"));
    // POST /api/shadow/monitoring/run restricted to NODAL_OFFICER and AUDITOR
    assert.ok(serverCode.includes("app.post('/api/shadow/monitoring/run', sensitiveRateLimiter, requireRole(['NODAL_OFFICER', 'AUDITOR'])"));
    // POST /api/shadow/evaluation/run restricted to NODAL_OFFICER and AUDITOR
    assert.ok(serverCode.includes("app.post('/api/shadow/evaluation/run', sensitiveRateLimiter, requireRole(['NODAL_OFFICER', 'AUDITOR'])"));
  });

  // 7. PRODUCTION MODEL ISOLATION & DATABASE IMMUTABILITY
  console.log('\n--- 7. Production Model Isolation & Database Immutability ---');

  await test('17. Production routes strictly load only V1 artifact', () => {
    const bridgeContent = fs.readFileSync('scripts/ml_prediction_service.py', 'utf-8');
    assert.ok(bridgeContent.includes('data/ml_models/BHOOMI-DRISHTI-ML-V1.0/model_pipeline.joblib'));
    assert.ok(!bridgeContent.includes('BHOOMI-DRISHTI-ML-V2.0-SHADOW/model_pipeline.joblib'));
  });

  await test('18. SQLite PRAGMA integrity_check passes completely', () => {
    const res = db.prepare('PRAGMA integrity_check').get() as any;
    assert.strictEqual(res.integrity_check, 'ok');
  });

  await test('19. Operational projects population remains exactly 31 projects', () => {
    const finalProjectCount = (db.prepare('SELECT COUNT(*) as c FROM projects').get() as any).c;
    assert.strictEqual(finalProjectCount, initialProjectCount);
    assert.strictEqual(finalProjectCount, 31);
  });

  await test('20. Operational risk scores and delay probabilities are 100% unchanged', () => {
    const finalProjectsData = db.prepare('SELECT id, risk_level, delay_probability FROM projects').all();
    assert.deepStrictEqual(finalProjectsData, initialProjectsData);
  });

  await test('21. Operational alerts and recommendations tables remained completely untouched', () => {
    const finalAlertsCount = (db.prepare('SELECT COUNT(*) as c FROM alerts').get() as any).c;
    const finalRecommendationsCount = (db.prepare('SELECT COUNT(*) as c FROM project_recommendations').get() as any).c;
    assert.strictEqual(finalAlertsCount, initialAlertsCount);
    assert.strictEqual(finalRecommendationsCount, initialRecommendationsCount);
  });

  console.log('========================================================================');
  console.log(`  Phase UI-1 Verification Finished: ${passed} Passed, ${failed} Failed`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runUIPhase1Suite().catch(err => {
  console.error('Fatal execution error:', err);
  process.exit(1);
});
