# Model Card: BHOOMI-DRISHTI-ML-V2.0-SHADOW

## Model Details
- **Model Identifier:** BHOOMI-DRISHTI-ML-V2.0-SHADOW
- **Status:** CANDIDATE / NON-OPERATIONAL SHADOW MODEL
- **Production Status:** NOT DEPLOYED (Production V1.0 remains authoritative)
- **Model Architecture:** Scikit-learn Pipeline with ColumnTransformer and RandomForestClassifier
- **Hyperparameters:** `n_estimators=100`, `max_depth=6`, `min_samples_leaf=2`, `class_weight='balanced'`, `random_state=42`
- **Artifact SHA-256:** `4a83e980f9178498be4592a47303f0ebc5ea641934952af5bee92ae5b76729a2`
- **Created Timestamp:** `2026-09-28T12:47:38.774882+00:00`

## Dataset & Feature Lineage
- **Dataset:** `BHOOMI-DRISHTI-LONGITUDINAL-HISTORICAL-V2` (v2.0.0-phase4c-authentic)
- **Dataset SHA-256:** `0da40152ca0866ec54b0a3500186f5ae450b487095bb1a09a0563b95605f052a`
- **Observation Population:** 399 authentic observations across 152 unique NHAI/MoRTH highway projects (327 Delayed / 72 On-Track)
- **Feature Schema:** `SCHEMA-LONGITUDINAL-V2.0-10FEAT`
- **Quarantined / Forbidden Features:** `section_3d_date`, `delayed`, `target`, `duration_days`, `eventual_outcome`, synthetic T180 records, and retired V1 surrogate features.

## Evaluation & Empirical Performance

### 1. 5-Fold Stratified Group Cross-Validation (Grouped by `project_id`)
- **Mean ROC-AUC:** 0.8671 ± 0.0855
- **Mean PR-AUC:** 0.9658 ± 0.0234
- **Mean F1:** 0.8542 ± 0.0296
- **Mean Balanced Accuracy:** 0.7893 ± 0.0944
- **Mean Brier Score:** 0.1402 ± 0.0164

### 2. Chronological Holdout (Cutoff: 2023-01-01, 106 Train Projects / 46 Validation Projects)
- **ROC-AUC:** 0.8726 (Phase 5B Ref: 0.8726)
- **PR-AUC:** 0.8974 (Phase 5B Ref: 0.8974)
- **Precision:** 0.7778 (Phase 5B Ref: 0.7778)
- **Recall:** 0.9403 (Phase 5B Ref: 0.9403)
- **F1:** 0.8514 (Phase 5B Ref: 0.8514)
- **Balanced Accuracy:** 0.7745 (Phase 5B Ref: 0.7745)
- **Specificity:** 0.6087 (Phase 5B Ref: 0.6087)
- **Brier Score:** 0.1614 (Phase 5B Ref: 0.1614)
- **Log Loss:** 0.4936 (Phase 5B Ref: 0.4936)
- **Confusion Matrix:** TN=28, FP=18, FN=4, TP=63

## Leakage Audit
- Zero future-feature violations: PASS
- Zero Section 3D predictor usage: PASS
- Zero target-derived predictors: PASS
- Zero synthetic T180 rows: PASS
- Zero cross-partition project overlap: PASS
- Zero post-observation notification usage: PASS

## Non-Causal Feature Importance Interpretation
Feature importance scores derived from Gini impurity reduction or permutation importance measure predictive association within historical statutory notifications. **They do not constitute causal mechanisms.** High importance indicates correlation with historical land acquisition delay patterns, not a prescriptive levers for administrative intervention.

## Governance & Operational Threshold Constraints
- **Operational Threshold Policy:** PENDING_STAKEHOLDER_APPROVAL.
- **Automatic Promotion:** DISABLED.
- **Production Safety:** Production V1 model (`7e0e1a7dac2e082c20c7e0baa9eafa9f7aa2a120cd10c7a5b129537c0e91307f`) remains the exclusive operational system.
