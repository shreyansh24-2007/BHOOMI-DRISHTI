import type { IncomingMessage, ServerResponse } from 'node:http';
import { createExpressApp } from '../server.ts';

let cachedApp: any = null;

/**
 * Vercel Serverless Function Entry Point for BhoomiDrishti API.
 * Bridges incoming Vercel Serverless HTTP requests directly to the hardened Express backend.
 */
export default async function handler(req: IncomingMessage, res: ServerResponse) {
  if (!cachedApp) {
    cachedApp = await createExpressApp();
  }
  return cachedApp(req, res);
}
